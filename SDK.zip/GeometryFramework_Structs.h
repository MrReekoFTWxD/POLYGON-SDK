#pragma once 
#include "SDK.h" 
 
 
// Function GeometryFramework.BaseDynamicMeshComponent.SetOverrideRenderMaterial
// Size: 0x8(Inherited: 0x0) 
struct FSetOverrideRenderMaterial
{
	struct UMaterialInterface* Material;  // 0x0(0x8)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.HasOverrideRenderMaterial
// Size: 0x8(Inherited: 0x0) 
struct FHasOverrideRenderMaterial
{
	int32_t K;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryRenderMaterial
// Size: 0x8(Inherited: 0x0) 
struct FGetSecondaryRenderMaterial
{
	struct UMaterialInterface* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetEnableRaytracing
// Size: 0x1(Inherited: 0x0) 
struct FGetEnableRaytracing
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryBuffersVisibility
// Size: 0x1(Inherited: 0x0) 
struct FGetSecondaryBuffersVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMeshActor.ReleaseComputeMesh
// Size: 0x10(Inherited: 0x0) 
struct FReleaseComputeMesh
{
	struct UDynamicMesh* Mesh;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction GeometryFramework.OnDynamicMeshModifiedBP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnDynamicMeshModifiedBP__DelegateSignature
{
	struct UDynamicMesh* Mesh;  // 0x0(0x8)

}; 
// ScriptStruct GeometryFramework.DynamicMeshChangeInfo
// Size: 0x20(Inherited: 0x0) 
struct FDynamicMeshChangeInfo
{
	uint8_t  Type;  // 0x0(0x1)
	uint8_t  Flags;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bIsRevertChange : 1;  // 0x2(0x1)
	char pad_3[29];  // 0x3(0x1D)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetDynamicMesh
// Size: 0x8(Inherited: 0x0) 
struct FGetDynamicMesh
{
	struct UDynamicMesh* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetEnableWireframeRenderPass
// Size: 0x1(Inherited: 0x0) 
struct FGetEnableWireframeRenderPass
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetOverrideRenderMaterial
// Size: 0x10(Inherited: 0x0) 
struct FGetOverrideRenderMaterial
{
	int32_t MaterialIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* ReturnValue;  // 0x8(0x8)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetShadowsEnabled
// Size: 0x1(Inherited: 0x0) 
struct FGetShadowsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.GetViewModeOverridesEnabled
// Size: 0x1(Inherited: 0x0) 
struct FGetViewModeOverridesEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.SetEnableRaytracing
// Size: 0x1(Inherited: 0x0) 
struct FSetEnableRaytracing
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSetEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.SetEnableWireframeRenderPass
// Size: 0x1(Inherited: 0x0) 
struct FSetEnableWireframeRenderPass
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMeshPool.ReturnMesh
// Size: 0x8(Inherited: 0x0) 
struct FReturnMesh
{
	struct UDynamicMesh* Mesh;  // 0x0(0x8)

}; 
// Function GeometryFramework.DynamicMeshComponent.ConfigureMaterialSet
// Size: 0x10(Inherited: 0x0) 
struct FConfigureMaterialSet
{
	struct TArray<struct UMaterialInterface*> NewMaterialSet;  // 0x0(0x10)

}; 
// Function GeometryFramework.DynamicMeshActor.AllocateComputeMesh
// Size: 0x8(Inherited: 0x0) 
struct FAllocateComputeMesh
{
	struct UDynamicMesh* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryBuffersVisibility
// Size: 0x1(Inherited: 0x0) 
struct FSetSecondaryBuffersVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSetVisible : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryRenderMaterial
// Size: 0x8(Inherited: 0x0) 
struct FSetSecondaryRenderMaterial
{
	struct UMaterialInterface* Material;  // 0x0(0x8)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.SetShadowsEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetShadowsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.BaseDynamicMeshComponent.SetViewModeOverridesEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetViewModeOverridesEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMeshActor.GetComputeMeshPool
// Size: 0x8(Inherited: 0x0) 
struct FGetComputeMeshPool
{
	struct UDynamicMeshPool* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.DynamicMeshActor.GetDynamicMeshComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetDynamicMeshComponent
{
	struct UDynamicMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.DynamicMeshComponent.SetDynamicMesh
// Size: 0x8(Inherited: 0x0) 
struct FSetDynamicMesh
{
	struct UDynamicMesh* NewMesh;  // 0x0(0x8)

}; 
// Function GeometryFramework.DynamicMeshComponent.GetTangentsType
// Size: 0x1(Inherited: 0x0) 
struct FGetTangentsType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMeshComponent.SetComplexAsSimpleCollisionEnabled
// Size: 0x2(Inherited: 0x0) 
struct FSetComplexAsSimpleCollisionEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bImmediateUpdate : 1;  // 0x1(0x1)

}; 
// Function GeometryFramework.DynamicMeshComponent.SetDeferredCollisionUpdatesEnabled
// Size: 0x2(Inherited: 0x0) 
struct FSetDeferredCollisionUpdatesEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bImmediateUpdate : 1;  // 0x1(0x1)

}; 
// Function GeometryFramework.DynamicMeshComponent.SetTangentsType
// Size: 0x1(Inherited: 0x0) 
struct FSetTangentsType
{
	uint8_t  NewTangentsType;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMeshComponent.UpdateCollision
// Size: 0x1(Inherited: 0x0) 
struct FUpdateCollision
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOnlyIfPending : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMeshComponent.ValidateMaterialSlots
// Size: 0x3(Inherited: 0x0) 
struct FValidateMaterialSlots
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCreateIfMissing : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bDeleteExtraSlots : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ReturnValue : 1;  // 0x2(0x1)

}; 
// Function GeometryFramework.DynamicMesh.GetTriangleCount
// Size: 0x4(Inherited: 0x0) 
struct FGetTriangleCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function GeometryFramework.DynamicMesh.IsEmpty
// Size: 0x1(Inherited: 0x0) 
struct FIsEmpty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GeometryFramework.DynamicMesh.Reset
// Size: 0x8(Inherited: 0x0) 
struct FReset
{
	struct UDynamicMesh* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.DynamicMesh.ResetToCube
// Size: 0x8(Inherited: 0x0) 
struct FResetToCube
{
	struct UDynamicMesh* ReturnValue;  // 0x0(0x8)

}; 
// Function GeometryFramework.DynamicMeshPool.RequestMesh
// Size: 0x8(Inherited: 0x0) 
struct FRequestMesh
{
	struct UDynamicMesh* ReturnValue;  // 0x0(0x8)

}; 
