#pragma once 
#include <GeometryFramework_Structs.h>
 
 
 
// Class GeometryFramework.BaseDynamicMeshComponent
// Size: 0x5C0(Inherited: 0x570) 
struct UBaseDynamicMeshComponent : public UMeshComponent
{
	char pad_1392[24];  // 0x570(0x18)
	char pad_1416_1 : 7;  // 0x588(0x1)
	bool bExplicitShowWireframe : 1;  // 0x588(0x1)
	char pad_1417_1 : 7;  // 0x589(0x1)
	bool bEnableViewModeOverrides : 1;  // 0x589(0x1)
	char pad_1418[6];  // 0x58A(0x6)
	struct UMaterialInterface* OverrideRenderMaterial;  // 0x590(0x8)
	struct UMaterialInterface* SecondaryRenderMaterial;  // 0x598(0x8)
	char pad_1440[1];  // 0x5A0(0x1)
	char pad_1441_1 : 7;  // 0x5A1(0x1)
	bool bEnableRayTracing : 1;  // 0x5A1(0x1)
	char pad_1442[6];  // 0x5A2(0x6)
	struct TArray<struct UMaterialInterface*> BaseMaterials;  // 0x5A8(0x10)
	char pad_1464[8];  // 0x5B8(0x8)

	void SetViewModeOverridesEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetViewModeOverridesEnabled
	void SetShadowsEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetShadowsEnabled
	void SetSecondaryRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryRenderMaterial
	void SetSecondaryBuffersVisibility(bool bSetVisible); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryBuffersVisibility
	void SetOverrideRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetOverrideRenderMaterial
	void SetEnableWireframeRenderPass(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableWireframeRenderPass
	void SetEnableRaytracing(bool bSetEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableRaytracing
	bool HasOverrideRenderMaterial(int32_t K); // Function GeometryFramework.BaseDynamicMeshComponent.HasOverrideRenderMaterial
	bool GetViewModeOverridesEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetViewModeOverridesEnabled
	bool GetShadowsEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetShadowsEnabled
	struct UMaterialInterface* GetSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryRenderMaterial
	bool GetSecondaryBuffersVisibility(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryBuffersVisibility
	struct UMaterialInterface* GetOverrideRenderMaterial(int32_t MaterialIndex); // Function GeometryFramework.BaseDynamicMeshComponent.GetOverrideRenderMaterial
	bool GetEnableWireframeRenderPass(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableWireframeRenderPass
	bool GetEnableRaytracing(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableRaytracing
	struct UDynamicMesh* GetDynamicMesh(); // Function GeometryFramework.BaseDynamicMeshComponent.GetDynamicMesh
	void ClearSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearSecondaryRenderMaterial
	void ClearOverrideRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearOverrideRenderMaterial
}; 



// Class GeometryFramework.DynamicMeshActor
// Size: 0x290(Inherited: 0x278) 
struct ADynamicMeshActor : public AActor
{
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool bEnableComputeMeshPool : 1;  // 0x280(0x1)
	char pad_641[7];  // 0x281(0x7)
	struct UDynamicMeshPool* DynamicMeshPool;  // 0x288(0x8)

	bool ReleaseComputeMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshActor.ReleaseComputeMesh
	void ReleaseAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.ReleaseAllComputeMeshes
	struct UDynamicMeshComponent* GetDynamicMeshComponent(); // Function GeometryFramework.DynamicMeshActor.GetDynamicMeshComponent
	struct UDynamicMeshPool* GetComputeMeshPool(); // Function GeometryFramework.DynamicMeshActor.GetComputeMeshPool
	void FreeAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.FreeAllComputeMeshes
	struct UDynamicMesh* AllocateComputeMesh(); // Function GeometryFramework.DynamicMeshActor.AllocateComputeMesh
}; 



// Class GeometryFramework.DynamicMesh
// Size: 0xB0(Inherited: 0x28) 
struct UDynamicMesh : public UObject
{
	char pad_40[72];  // 0x28(0x48)
	struct FMulticastInlineDelegate MeshModifiedBPEvent;  // 0x70(0x10)
	char pad_128[32];  // 0x80(0x20)
	struct UDynamicMeshGenerator* MeshGenerator;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnableMeshGenerator : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

	struct UDynamicMesh* ResetToCube(); // Function GeometryFramework.DynamicMesh.ResetToCube
	struct UDynamicMesh* Reset(); // Function GeometryFramework.DynamicMesh.Reset
	bool IsEmpty(); // Function GeometryFramework.DynamicMesh.IsEmpty
	int32_t GetTriangleCount(); // Function GeometryFramework.DynamicMesh.GetTriangleCount
}; 



// Class GeometryFramework.DynamicMeshComponent
// Size: 0x750(Inherited: 0x5C0) 
struct UDynamicMeshComponent : public UBaseDynamicMeshComponent
{
	struct UDynamicMesh* MeshObject;  // 0x5C0(0x8)
	char pad_1480[248];  // 0x5C8(0xF8)
	uint8_t  TangentsType;  // 0x6C0(0x1)
	char pad_1729[63];  // 0x6C1(0x3F)
	char ECollisionTraceFlag CollisionType;  // 0x700(0x1)
	char pad_1793_1 : 7;  // 0x701(0x1)
	bool bEnableComplexCollision : 1;  // 0x701(0x1)
	char pad_1794_1 : 7;  // 0x702(0x1)
	bool bDeferCollisionUpdates : 1;  // 0x702(0x1)
	char pad_1795[5];  // 0x703(0x5)
	struct UBodySetup* MeshBodySetup;  // 0x708(0x8)
	char pad_1808[64];  // 0x710(0x40)

	bool ValidateMaterialSlots(bool bCreateIfMissing, bool bDeleteExtraSlots); // Function GeometryFramework.DynamicMeshComponent.ValidateMaterialSlots
	void UpdateCollision(bool bOnlyIfPending); // Function GeometryFramework.DynamicMeshComponent.UpdateCollision
	void SetTangentsType(uint8_t  NewTangentsType); // Function GeometryFramework.DynamicMeshComponent.SetTangentsType
	void SetDynamicMesh(struct UDynamicMesh* NewMesh); // Function GeometryFramework.DynamicMeshComponent.SetDynamicMesh
	void SetDeferredCollisionUpdatesEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetDeferredCollisionUpdatesEnabled
	void SetComplexAsSimpleCollisionEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetComplexAsSimpleCollisionEnabled
	uint8_t  GetTangentsType(); // Function GeometryFramework.DynamicMeshComponent.GetTangentsType
	void EnableComplexAsSimpleCollision(); // Function GeometryFramework.DynamicMeshComponent.EnableComplexAsSimpleCollision
	void ConfigureMaterialSet(struct TArray<struct UMaterialInterface*>& NewMaterialSet); // Function GeometryFramework.DynamicMeshComponent.ConfigureMaterialSet
}; 



// Class GeometryFramework.MeshCommandChangeTarget
// Size: 0x28(Inherited: 0x28) 
struct UMeshCommandChangeTarget : public UInterface
{

}; 



// Class GeometryFramework.DynamicMeshGenerator
// Size: 0x28(Inherited: 0x28) 
struct UDynamicMeshGenerator : public UObject
{

}; 



// Class GeometryFramework.MeshReplacementCommandChangeTarget
// Size: 0x28(Inherited: 0x28) 
struct UMeshReplacementCommandChangeTarget : public UInterface
{

}; 



// Class GeometryFramework.MeshVertexCommandChangeTarget
// Size: 0x28(Inherited: 0x28) 
struct UMeshVertexCommandChangeTarget : public UInterface
{

}; 



// Class GeometryFramework.DynamicMeshPool
// Size: 0x48(Inherited: 0x28) 
struct UDynamicMeshPool : public UObject
{
	struct TArray<struct UDynamicMesh*> CachedMeshes;  // 0x28(0x10)
	struct TArray<struct UDynamicMesh*> AllCreatedMeshes;  // 0x38(0x10)

	void ReturnMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshPool.ReturnMesh
	void ReturnAllMeshes(); // Function GeometryFramework.DynamicMeshPool.ReturnAllMeshes
	struct UDynamicMesh* RequestMesh(); // Function GeometryFramework.DynamicMeshPool.RequestMesh
	void FreeAllMeshes(); // Function GeometryFramework.DynamicMeshPool.FreeAllMeshes
}; 



