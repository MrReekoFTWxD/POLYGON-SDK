#pragma once 
#include "SDK.h" 
 
 
// Function MediaFrameworkUtilities.MediaBundleActorBase.RequestOpenMediaSource
// Size: 0x1(Inherited: 0x0) 
struct FRequestOpenMediaSource
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MediaFrameworkUtilities.MediaBundle.GetLensDisplacementTexture
// Size: 0x8(Inherited: 0x0) 
struct FGetLensDisplacementTexture
{
	struct UTextureRenderTarget2D* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.SetMediaProfile
// Size: 0x8(Inherited: 0x0) 
struct FSetMediaProfile
{
	struct UMediaProfile* MediaProfile;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaBundle.GetMaterial
// Size: 0x8(Inherited: 0x0) 
struct FGetMaterial
{
	struct UMaterialInterface* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaBundle.GetMediaSource
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaSource
{
	struct UMediaSource* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaBundle.GetMediaPlayer
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaPlayer
{
	struct UMediaPlayer* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaBundle.GetMediaTexture
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaTexture
{
	struct UMediaTexture* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaBundle.GetUndistortedCameraViewInfo
// Size: 0xC(Inherited: 0x0) 
struct FGetUndistortedCameraViewInfo
{
	struct FOpenCVCameraViewInfo ReturnValue;  // 0x0(0xC)

}; 
// Function MediaFrameworkUtilities.MediaBundle.OnMediaOpenFailed
// Size: 0x10(Inherited: 0x0) 
struct FOnMediaOpenFailed
{
	struct FString DeviceUrl;  // 0x0(0x10)

}; 
// Function MediaFrameworkUtilities.MediaBundle.OnMediaOpenOpened
// Size: 0x10(Inherited: 0x0) 
struct FOnMediaOpenOpened
{
	struct FString DeviceUrl;  // 0x0(0x10)

}; 
// Function MediaFrameworkUtilities.MediaBundleActorBase.GetMediaBundle
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaBundle
{
	struct UMediaBundle* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.MediaBundleActorBase.SetComponent
// Size: 0x10(Inherited: 0x0) 
struct FSetComponent
{
	struct UPrimitiveComponent* InPrimitive;  // 0x0(0x8)
	struct UMediaSoundComponent* InMediaSound;  // 0x8(0x8)

}; 
// Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.GetAllMediaOutputProxy
// Size: 0x10(Inherited: 0x0) 
struct FGetAllMediaOutputProxy
{
	struct TArray<struct UProxyMediaOutput*> ReturnValue;  // 0x0(0x10)

}; 
// Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.GetAllMediaSourceProxy
// Size: 0x10(Inherited: 0x0) 
struct FGetAllMediaSourceProxy
{
	struct TArray<struct UProxyMediaSource*> ReturnValue;  // 0x0(0x10)

}; 
// Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.GetMediaProfile
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaProfile
{
	struct UMediaProfile* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaFrameworkUtilities.ProxyMediaSource.IsProxyValid
// Size: 0x1(Inherited: 0x0) 
struct FIsProxyValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
