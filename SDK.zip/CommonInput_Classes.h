#pragma once 
#include <CommonInput_Structs.h>
 
 
 
// Class CommonInput.CommonUIInputData
// Size: 0x48(Inherited: 0x28) 
struct UCommonUIInputData : public UObject
{
	struct FDataTableRowHandle DefaultClickAction;  // 0x28(0x10)
	struct FDataTableRowHandle DefaultBackAction;  // 0x38(0x10)

}; 



// Class CommonInput.CommonInputSettings
// Size: 0xE8(Inherited: 0x38) 
struct UCommonInputSettings : public UDeveloperSettings
{
	struct TSoftClassPtr<UObject> InputData;  // 0x38(0x28)
	struct FPerPlatformSettings PlatformInput;  // 0x60(0x10)
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData;  // 0x70(0x50)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bEnableInputMethodThrashingProtection : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t InputMethodThrashingLimit;  // 0xC4(0x4)
	double InputMethodThrashingWindowInSeconds;  // 0xC8(0x8)
	double InputMethodThrashingCooldownInSeconds;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bAllowOutOfFocusDeviceInput : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	UCommonUIInputData* InputDataClass;  // 0xE0(0x8)

}; 



// Class CommonInput.CommonInputPlatformSettings
// Size: 0x70(Inherited: 0x40) 
struct UCommonInputPlatformSettings : public UPlatformSettings
{
	uint8_t  DefaultInputType;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool bSupportsMouseAndKeyboard : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool bSupportsTouch : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool bSupportsGamepad : 1;  // 0x43(0x1)
	struct FName DefaultGamepadName;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bCanChangeGamepadType : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData;  // 0x50(0x10)
	struct TArray<UCommonInputBaseControllerData*> ControllerDataClasses;  // 0x60(0x10)

}; 



// Class CommonInput.CommonInputBaseControllerData
// Size: 0x100(Inherited: 0x28) 
struct UCommonInputBaseControllerData : public UObject
{
	uint8_t  InputType;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FName GamepadName;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct FText GamepadDisplayName;  // 0x38(0x18)
	struct FText GamepadCategory;  // 0x50(0x18)
	struct FText GamepadPlatformName;  // 0x68(0x18)
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping;  // 0x80(0x10)
	struct TSoftObjectPtr<UTexture2D> ControllerTexture;  // 0x90(0x28)
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture;  // 0xB8(0x28)
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap;  // 0xE0(0x10)
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets;  // 0xF0(0x10)

	struct TArray<struct FName> GetRegisteredGamepads(); // Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
}; 



// Class CommonInput.CommonInputSubsystem
// Size: 0x100(Inherited: 0x30) 
struct UCommonInputSubsystem : public ULocalPlayerSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnInputMethodChanged;  // 0x58(0x10)
	int32_t NumberOfInputMethodChangesRecently;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	double LastInputMethodChangeTime;  // 0x70(0x8)
	double LastTimeInputMethodThrashingBegan;  // 0x78(0x8)
	uint8_t  LastInputType;  // 0x80(0x1)
	uint8_t  CurrentInputType;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FName GamepadInputType;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct TMap<struct FName, uint8_t > CurrentInputLocks;  // 0x90(0x50)
	char pad_224[24];  // 0xE0(0x18)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bIsGamepadSimulatedClick : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)

	bool ShouldShowInputKeys(); // Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
	void SetGamepadInputType(struct FName InGamepadInputType); // Function CommonInput.CommonInputSubsystem.SetGamepadInputType
	void SetCurrentInputType(uint8_t  NewInputType); // Function CommonInput.CommonInputSubsystem.SetCurrentInputType
	bool IsUsingPointerInput(); // Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
	bool IsInputMethodActive(uint8_t  InputMethod); // Function CommonInput.CommonInputSubsystem.IsInputMethodActive
	uint8_t  GetDefaultInputType(); // Function CommonInput.CommonInputSubsystem.GetDefaultInputType
	uint8_t  GetCurrentInputType(); // Function CommonInput.CommonInputSubsystem.GetCurrentInputType
	struct FName GetCurrentGamepadName(); // Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
}; 



