#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Lobby.LobbyPlayerStateActorInfo
// Size: 0x18(Inherited: 0xC) 
struct FLobbyPlayerStateActorInfo : public FFastArraySerializerItem
{
	char pad_12[4];  // 0xC(0x4)
	struct ALobbyBeaconPlayerState* LobbyPlayerState;  // 0x10(0x8)

}; 
// Function Lobby.LobbyBeaconClient.ClientLoginComplete
// Size: 0x38(Inherited: 0x0) 
struct FClientLoginComplete
{
	struct FUniqueNetIdRepl InUniqueId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct Lobby.LobbyPlayerStateInfoArray
// Size: 0x120(Inherited: 0x108) 
struct FLobbyPlayerStateInfoArray : public FFastArraySerializer
{
	struct TArray<struct FLobbyPlayerStateActorInfo> Players;  // 0x108(0x10)
	struct ALobbyBeaconState* ParentState;  // 0x118(0x8)

}; 
// Function Lobby.LobbyBeaconClient.ClientSetInviteFlags
// Size: 0x14(Inherited: 0x0) 
struct FClientSetInviteFlags
{
	struct FJoinabilitySettings Settings;  // 0x0(0x14)

}; 
// Function Lobby.LobbyBeaconClient.ClientPlayerLeft
// Size: 0x30(Inherited: 0x0) 
struct FClientPlayerLeft
{
	struct FUniqueNetIdRepl InUniqueId;  // 0x0(0x30)

}; 
// Function Lobby.LobbyBeaconClient.ClientPlayerJoined
// Size: 0x48(Inherited: 0x0) 
struct FClientPlayerJoined
{
	struct FText NewPlayerName;  // 0x0(0x18)
	struct FUniqueNetIdRepl InUniqueId;  // 0x18(0x30)

}; 
// Function Lobby.LobbyBeaconClient.ClientWasKicked
// Size: 0x18(Inherited: 0x0) 
struct FClientWasKicked
{
	struct FText KickReason;  // 0x0(0x18)

}; 
// Function Lobby.LobbyBeaconClient.ServerCheat
// Size: 0x10(Inherited: 0x0) 
struct FServerCheat
{
	struct FString Msg;  // 0x0(0x10)

}; 
// Function Lobby.LobbyBeaconClient.ServerSetPartyOwner
// Size: 0x60(Inherited: 0x0) 
struct FServerSetPartyOwner
{
	struct FUniqueNetIdRepl InUniqueId;  // 0x0(0x30)
	struct FUniqueNetIdRepl InPartyOwnerId;  // 0x30(0x30)

}; 
// Function Lobby.LobbyBeaconClient.ServerKickPlayer
// Size: 0x48(Inherited: 0x0) 
struct FServerKickPlayer
{
	struct FUniqueNetIdRepl PlayerToKick;  // 0x0(0x30)
	struct FText Reason;  // 0x30(0x18)

}; 
// Function Lobby.LobbyBeaconClient.ServerLoginPlayer
// Size: 0x50(Inherited: 0x0) 
struct FServerLoginPlayer
{
	struct FString InSessionId;  // 0x0(0x10)
	struct FUniqueNetIdRepl InUniqueId;  // 0x10(0x30)
	struct FString UrlString;  // 0x40(0x10)

}; 
