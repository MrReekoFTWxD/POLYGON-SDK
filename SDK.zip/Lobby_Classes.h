#pragma once 
#include <Lobby_Structs.h>
 
 
 
// Class Lobby.LobbyBeaconClient
// Size: 0x390(Inherited: 0x308) 
struct ALobbyBeaconClient : public AOnlineBeaconClient
{
	struct ALobbyBeaconState* LobbyState;  // 0x308(0x8)
	struct ALobbyBeaconPlayerState* PlayerState;  // 0x310(0x8)
	char pad_792[1];  // 0x318(0x1)
	uint8_t  LobbyJoinServerState;  // 0x319(0x1)
	char pad_794[118];  // 0x31A(0x76)

	void ServerSetPartyOwner(struct FUniqueNetIdRepl InUniqueId, struct FUniqueNetIdRepl InPartyOwnerId); // Function Lobby.LobbyBeaconClient.ServerSetPartyOwner
	void ServerNotifyJoiningServer(); // Function Lobby.LobbyBeaconClient.ServerNotifyJoiningServer
	void ServerLoginPlayer(struct FString InSessionId, struct FUniqueNetIdRepl InUniqueId, struct FString UrlString); // Function Lobby.LobbyBeaconClient.ServerLoginPlayer
	void ServerKickPlayer(struct FUniqueNetIdRepl PlayerToKick, struct FText Reason); // Function Lobby.LobbyBeaconClient.ServerKickPlayer
	void ServerDisconnectFromLobby(); // Function Lobby.LobbyBeaconClient.ServerDisconnectFromLobby
	void ServerCheat(struct FString Msg); // Function Lobby.LobbyBeaconClient.ServerCheat
	void ClientWasKicked(struct FText KickReason); // Function Lobby.LobbyBeaconClient.ClientWasKicked
	void ClientSetInviteFlags(struct FJoinabilitySettings Settings); // Function Lobby.LobbyBeaconClient.ClientSetInviteFlags
	void ClientPlayerLeft(struct FUniqueNetIdRepl InUniqueId); // Function Lobby.LobbyBeaconClient.ClientPlayerLeft
	void ClientPlayerJoined(struct FText NewPlayerName, struct FUniqueNetIdRepl InUniqueId); // Function Lobby.LobbyBeaconClient.ClientPlayerJoined
	void ClientLoginComplete(struct FUniqueNetIdRepl InUniqueId, bool bWasSuccessful); // Function Lobby.LobbyBeaconClient.ClientLoginComplete
	void ClientJoinGame(); // Function Lobby.LobbyBeaconClient.ClientJoinGame
	void ClientAckJoiningServer(); // Function Lobby.LobbyBeaconClient.ClientAckJoiningServer
}; 



// Class Lobby.LobbyBeaconHost
// Size: 0x2D8(Inherited: 0x2A0) 
struct ALobbyBeaconHost : public AOnlineBeaconHostObject
{
	char pad_672[8];  // 0x2A0(0x8)
	struct TSoftClassPtr<UObject> LobbyStateClass;  // 0x2A8(0x28)
	struct ALobbyBeaconState* LobbyState;  // 0x2D0(0x8)

}; 



// Class Lobby.LobbyBeaconPlayerState
// Size: 0x348(Inherited: 0x278) 
struct ALobbyBeaconPlayerState : public AInfo
{
	struct FText DisplayName;  // 0x278(0x18)
	struct FUniqueNetIdRepl UniqueId;  // 0x290(0x30)
	struct FUniqueNetIdRepl PartyOwnerUniqueId;  // 0x2C0(0x30)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool bInLobby : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct AOnlineBeaconClient* ClientActor;  // 0x2F8(0x8)
	char pad_768[72];  // 0x300(0x48)

	void OnRep_UniqueId(); // Function Lobby.LobbyBeaconPlayerState.OnRep_UniqueId
	void OnRep_PartyOwner(); // Function Lobby.LobbyBeaconPlayerState.OnRep_PartyOwner
	void OnRep_InLobby(); // Function Lobby.LobbyBeaconPlayerState.OnRep_InLobby
}; 



// Class Lobby.LobbyBeaconState
// Size: 0x420(Inherited: 0x278) 
struct ALobbyBeaconState : public AInfo
{
	int32_t MaxPlayers;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	ALobbyBeaconPlayerState* LobbyBeaconPlayerStateClass;  // 0x280(0x8)
	char pad_648[8];  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bLobbyStarted : 1;  // 0x290(0x1)
	char pad_657[3];  // 0x291(0x3)
	float WaitForPlayersTimeRemaining;  // 0x294(0x4)
	struct FLobbyPlayerStateInfoArray Players;  // 0x298(0x120)
	char pad_952[104];  // 0x3B8(0x68)

	void OnRep_WaitForPlayersTimeRemaining(); // Function Lobby.LobbyBeaconState.OnRep_WaitForPlayersTimeRemaining
	void OnRep_LobbyStarted(); // Function Lobby.LobbyBeaconState.OnRep_LobbyStarted
}; 



