#pragma once 
#include <CameraShake_FootStep_Left_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_FootStep_Left.CameraShake_FootStep_Left_C
// Size: 0x230(Inherited: 0x230) 
struct UCameraShake_FootStep_Left_C : public UMatineeCameraShake
{

}; 



