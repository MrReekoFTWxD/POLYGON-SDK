#pragma once 
#include <BP_PG_PlayerController_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C
// Size: 0x858(Inherited: 0x820) 
struct ABP_PG_PlayerController_Game_C : public APG_PlayerController_Game
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x820(0x8)
	struct UBP_FOVManagerComponent_Game_C* BP_FOVManagerComponent_Game;  // 0x828(0x8)
	struct UUI_GeneralGameScreen_C* UI_GeneralGameScreen;  // 0x830(0x8)
	struct UUI_InteractionTime_C* UI_InteractionTime;  // 0x838(0x8)
	struct UUI_DarkenScreen_C* UI_DarkenScreen;  // 0x840(0x8)
	struct UUI_CaptureProcess_C* UI_CaptureProcess;  // 0x848(0x8)
	struct UUI_KillCam_C* UI_KillerInfo;  // 0x850(0x8)

	void Reset(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.Reset
	void ToggleVisibilityInterface(bool ForceVisible); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ToggleVisibilityInterface
	void InpActEvt_Escape_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Escape_K2Node_InputKeyEvent_3
	void InpActEvt_Scoreboard_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Scoreboard_K2Node_InputActionEvent_5
	void InpActEvt_Scoreboard_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Scoreboard_K2Node_InputActionEvent_4
	void InpActEvt_ChatAll_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_ChatAll_K2Node_InputActionEvent_3
	void InpActEvt_ChatTeam_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_ChatTeam_K2Node_InputActionEvent_2
	void InpActEvt_HideInterface_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_HideInterface_K2Node_InputActionEvent_1
	void InpActEvt_N_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_N_K2Node_InputKeyEvent_2
	void InpActEvt_MiddleMouseButton_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_MiddleMouseButton_K2Node_InputKeyEvent_1
	void SetPlayerState(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.SetPlayerState
	void OnAddedGameScore_Event(struct TArray<struct FScoreInfoBlueprint>& ScoreInfos); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OnAddedGameScore_Event
	void OpenScoreboard(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OpenScoreboard
	void CloseScoreboard(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.CloseScoreboard
	void ReceiveBeginPlay(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ReceiveBeginPlay
	void DisplayMessageToChatEvent(struct FGameChatMessage Message); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.DisplayMessageToChatEvent
	void StartInteractionEvent(float interactionTime); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.StartInteractionEvent
	void StopInteractionEvent(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.StopInteractionEvent
	void EventClientReset(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.EventClientReset
	void OnPossessedPawnChanged_Event(struct APawn* OldPawn, struct APawn* NewPawn); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OnPossessedPawnChanged_Event
	void OnIsAlive_Event(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OnIsAlive_Event
	void OnSetCharacterHiddenInGame_Event(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OnSetCharacterHiddenInGame_Event
	void ExecuteUbergraph_BP_PG_PlayerController_Game(int32_t EntryPoint); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ExecuteUbergraph_BP_PG_PlayerController_Game
}; 



