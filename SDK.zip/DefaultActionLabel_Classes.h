#pragma once 
#include <DefaultActionLabel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultActionLabel.DefaultActionLabel_C
// Size: 0x328(Inherited: 0x328) 
struct UDefaultActionLabel_C : public UActionLabel
{

}; 



