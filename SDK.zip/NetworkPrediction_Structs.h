#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NetworkPrediction.NetworkPredictionProxy
// Size: 0xB0(Inherited: 0x0) 
struct FNetworkPredictionProxy
{
	char pad_0[160];  // 0x0(0xA0)
	struct UNetworkPredictionWorldManager* WorldManager;  // 0xA0(0x8)
	char pad_168[8];  // 0xA8(0x8)

}; 
// Function NetworkPrediction.NetworkPredictionComponent.ServerReceiveClientInput
// Size: 0x18(Inherited: 0x0) 
struct FServerReceiveClientInput
{
	struct FServerReplicationRPCParameter ProxyParameter;  // 0x0(0x18)

}; 
// ScriptStruct NetworkPrediction.ServerReplicationRPCParameter
// Size: 0x18(Inherited: 0x0) 
struct FServerReplicationRPCParameter
{
	char pad_0[24];  // 0x0(0x18)

}; 
// ScriptStruct NetworkPrediction.NetworkPhysicsState
// Size: 0x90(Inherited: 0x0) 
struct FNetworkPhysicsState
{
	char pad_0[144];  // 0x0(0x90)

}; 
// ScriptStruct NetworkPrediction.ReplicationProxy
// Size: 0x50(Inherited: 0x0) 
struct FReplicationProxy
{
	char pad_0[80];  // 0x0(0x50)

}; 
// Function NetworkPrediction.NetworkPhysicsComponent.GetNetworkPredictionLOD
// Size: 0x4(Inherited: 0x0) 
struct FGetNetworkPredictionLOD
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct NetworkPrediction.NetworkPredictionDevHUD
// Size: 0x28(Inherited: 0x0) 
struct FNetworkPredictionDevHUD
{
	struct FString HUDName;  // 0x0(0x10)
	struct TArray<struct FNetworkPredictionDevHUDItem> Items;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bRequirePIE : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bRequireNotPIE : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// ScriptStruct NetworkPrediction.NetworkPredictionAsyncProxy
// Size: 0x10(Inherited: 0x0) 
struct FNetworkPredictionAsyncProxy
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct NetworkPrediction.NetworkPredictionSettings
// Size: 0x28(Inherited: 0x0) 
struct FNetworkPredictionSettings
{
	uint8_t  PreferredTickingPolicy;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	ANetworkPredictionReplicatedManager* ReplicatedManagerClassOverride;  // 0x8(0x8)
	int32_t FixedTickFrameRate;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bForceEngineFixTickForcePhysics : 1;  // 0x14(0x1)
	uint8_t  SimulatedProxyNetworkLOD;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t FixedTickInterpolationBufferedMS;  // 0x18(0x4)
	int32_t IndependentTickInterpolationBufferedMS;  // 0x1C(0x4)
	int32_t IndependentTickInterpolationMaxBufferedMS;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct NetworkPrediction.SharedPackageMapItem
// Size: 0x28(Inherited: 0x0) 
struct FSharedPackageMapItem
{
	struct TSoftObjectPtr<UObject> SoftPtr;  // 0x0(0x28)

}; 
// ScriptStruct NetworkPrediction.SharedPackageMap
// Size: 0x10(Inherited: 0x0) 
struct FSharedPackageMap
{
	struct TArray<struct FSharedPackageMapItem> Items;  // 0x0(0x10)

}; 
// ScriptStruct NetworkPrediction.NetworkPredictionDevHUDItem
// Size: 0x28(Inherited: 0x0) 
struct FNetworkPredictionDevHUDItem
{
	struct FString DisplayName;  // 0x0(0x10)
	struct FString ExecCommand;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bAutoBack : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bRequirePIE : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bRequireNotPIE : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
