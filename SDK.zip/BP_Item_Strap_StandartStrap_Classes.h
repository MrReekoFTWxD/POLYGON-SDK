#pragma once 
#include <BP_Item_Strap_StandartStrap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_StandartStrap.BP_Item_Strap_StandartStrap_C
// Size: 0x2E8(Inherited: 0x2E8) 
struct ABP_Item_Strap_StandartStrap_C : public AItem_Module_Strap
{

}; 



