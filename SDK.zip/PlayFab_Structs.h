#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct PlayFab.AdminCheckLimitedEditionItemAvailabilityResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminCheckLimitedEditionItemAvailabilityResult : public FPlayFabResultCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction PlayFab.OnPlayFabAdminRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabAdminRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.OnPlayFabDataRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabDataRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.SetGameServerInstanceState
// Size: 0x50(Inherited: 0x0) 
struct FSetGameServerInstanceState
{
	struct FServerSetGameServerInstanceStateRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetAccountInfo
// Size: 0x78(Inherited: 0x0) 
struct FGetAccountInfo
{
	struct FClientGetAccountInfoRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabAuthenticationAPI.HelperDelete
// Size: 0x50(Inherited: 0x0) 
struct FHelperDelete
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.OnPlayFabCloudScriptRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabCloudScriptRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetPlayerSecret
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetPlayerSecret
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminAddLocalizedNewsResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminAddLocalizedNewsResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetFriendTags
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetFriendTags
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUpdateBansResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeUpdateBansResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUpdateBansResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetRandomResultTables__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetRandomResultTables__DelegateSignature
{
	struct FServerGetRandomResultTablesResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRegisterPlayFabUser__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FDelegateOnSuccessRegisterPlayFabUser__DelegateSignature
{
	struct FClientRegisterPlayFabUserResult Result;  // 0x0(0x48)
	struct UObject* customData;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateCloudScript
// Size: 0x68(Inherited: 0x0) 
struct FUpdateCloudScript
{
	struct FAdminUpdateCloudScriptRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.PlayFabBaseModel
// Size: 0x40(Inherited: 0x0) 
struct FPlayFabBaseModel
{
	struct FPlayFabError responseError;  // 0x0(0x38)
	struct UPlayFabJsonObject* responseData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.AdminGetTaskInstancesResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetTaskInstancesResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Summaries;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabExperimentationAPI.CreateExclusionGroup
// Size: 0x60(Inherited: 0x0) 
struct FCreateExclusionGroup
{
	struct FExperimentationCreateExclusionGroupRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetGameServerInstanceState__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetGameServerInstanceState__DelegateSignature
{
	struct FServerSetGameServerInstanceStateResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperReviewItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperReviewItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetPlayerIdFromAuthTokenResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayerIdFromAuthTokenResult : public FPlayFabResultCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.DataFinalizeFileUploadsRequest
// Size: 0x30(Inherited: 0x8) 
struct FDataFinalizeFileUploadsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString FileNames;  // 0x18(0x10)
	int32_t ProfileVersion;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct PlayFab.AdminEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FAdminEmptyResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeEmptyResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeEmptyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerEmptyResult ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.OnPlayFabAuthenticationRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabAuthenticationRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMultiplayerServerDetailsResponseResponse
// Size: 0xC0(Inherited: 0x0) 
struct FdecodeGetMultiplayerServerDetailsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetMultiplayerServerDetailsResponse ReturnValue;  // 0x8(0xB8)

}; 
// ScriptStruct PlayFab.ClientGetCharacterInventoryResult
// Size: 0x38(Inherited: 0x8) 
struct FClientGetCharacterInventoryResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Inventory;  // 0x18(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x28(0x8)
	struct UPlayFabJsonObject* VirtualCurrencyRechargeTimes;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminCreateActionsOnPlayerSegmentTaskRequest
// Size: 0x50(Inherited: 0x8) 
struct FAdminCreateActionsOnPlayerSegmentTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool IsActive : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString Name;  // 0x28(0x10)
	struct UPlayFabJsonObject* Parameter;  // 0x38(0x8)
	struct FString Schedule;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ServerRemovePlayerTagRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerRemovePlayerTagRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString TagName;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetLeaderboardAroundCharacter
// Size: 0x80(Inherited: 0x0) 
struct FGetLeaderboardAroundCharacter
{
	struct FServerGetLeaderboardAroundCharacterRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientGetFriendsListResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetFriendsListResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Friends;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildWithCustomContainerResponse
// Size: 0xF0(Inherited: 0x8) 
struct FMultiplayerCreateBuildWithCustomContainerResponse : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildId;  // 0x10(0x10)
	struct FString BuildName;  // 0x20(0x10)
	uint8_t  ContainerFlavor;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString ContainerRunCommand;  // 0x38(0x10)
	struct FString CreationTime;  // 0x48(0x10)
	struct UPlayFabJsonObject* CustomGameContainerImage;  // 0x58(0x8)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x60(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x70(0x10)
	struct UPlayFabJsonObject* LinuxInstrumentationConfiguration;  // 0x80(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x88(0x8)
	struct UPlayFabJsonObject* MonitoringApplicationConfiguration;  // 0x90(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FString OsPlatform;  // 0xA0(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0xB0(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0xC0(0x10)
	struct UPlayFabJsonObject* ServerResourceConstraints;  // 0xD0(0x8)
	struct FString ServerType;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool UseStreamingForAssetDownloads : 1;  // 0xE8(0x1)
	uint8_t  VmSize;  // 0xE9(0x1)
	char pad_234[6];  // 0xEA(0x6)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromFacebookInstantGamesIds
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromFacebookInstantGamesIds
{
	struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserData__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserData__DelegateSignature
{
	struct FServerGetUserDataResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetLimitsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeInsightsGetLimitsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FInsightsInsightsGetLimitsResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardAroundCharacterResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetLeaderboardAroundCharacterResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetLeaderboardAroundCharacterResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.PlayFabError
// Size: 0x38(Inherited: 0x0) 
struct FPlayFabError
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool HasError : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ErrorCode;  // 0x4(0x4)
	struct FString ErrorName;  // 0x8(0x10)
	struct FString ErrorMessage;  // 0x18(0x10)
	struct FString ErrorDetails;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperListGroupApplications
// Size: 0x50(Inherited: 0x0) 
struct FHelperListGroupApplications
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.AddPlayerTag
// Size: 0x60(Inherited: 0x0) 
struct FAddPlayerTag
{
	struct FServerAddPlayerTagRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientReportAdActivityRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientReportAdActivityRequest : public FPlayFabRequestCommon
{
	uint8_t  Activity;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString PlacementId;  // 0x18(0x10)
	struct FString RewardId;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabClientRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabClientRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeStartPurchaseResultResponse
// Size: 0x48(Inherited: 0x0) 
struct FdecodeStartPurchaseResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientStartPurchaseResult ReturnValue;  // 0x8(0x40)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetAllSegments
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetAllSegments
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerLoginWithXboxIdRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerLoginWithXboxIdRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x18(0x8)
	struct FString Sandbox;  // 0x20(0x10)
	struct FString XboxId;  // 0x30(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateActionsOnPlayersInSegmentTask__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateActionsOnPlayersInSegmentTask__DelegateSignature
{
	struct FAdminCreateTaskResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateUserInternalDataRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminUpdateUserInternalDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabEconomyRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabEconomyRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.PlayFabResultCommon
// Size: 0x8(Inherited: 0x0) 
struct FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Request;  // 0x0(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemsResponse
// Size: 0x18(Inherited: 0x8) 
struct FEconomyGetItemsResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkNintendoSwitchDeviceIdResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkNintendoSwitchDeviceIdResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkNintendoSwitchDeviceIdResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteMasterPlayerAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminDeleteMasterPlayerAccountRequest : public FPlayFabRequestCommon
{
	struct FString MetaData;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabEventsRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabEventsRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCharacterLeaderboard
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCharacterLeaderboard
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddPlayerTag__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddPlayerTag__DelegateSignature
{
	struct FServerAddPlayerTagResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkCustomIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkCustomIDResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeSetGlobalPolicyResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetGlobalPolicyResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesSetGlobalPolicyResponse ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerRemoveMemberFromLobbyRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerRemoveMemberFromLobbyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)
	struct UPlayFabJsonObject* MemberEntity;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool PreventRejoin : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.RevokeAllBansForUser
// Size: 0x48(Inherited: 0x0) 
struct FRevokeAllBansForUser
{
	struct FServerRevokeAllBansForUserRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.MatchmakerAuthUserRequest
// Size: 0x18(Inherited: 0x8) 
struct FMatchmakerAuthUserRequest : public FPlayFabRequestCommon
{
	struct FString AuthorizationTicket;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeModifyItemUsesResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeModifyItemUsesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerModifyItemUsesResult ReturnValue;  // 0x8(0x20)

}; 
// ScriptStruct PlayFab.AdminCreateCloudScriptTaskRequest
// Size: 0x50(Inherited: 0x8) 
struct FAdminCreateCloudScriptTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool IsActive : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString Name;  // 0x28(0x10)
	struct UPlayFabJsonObject* Parameter;  // 0x38(0x8)
	struct FString Schedule;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperCreateGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.OnPlayFabExperimentationRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabExperimentationRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListContainerImageTags
// Size: 0x50(Inherited: 0x0) 
struct FHelperListContainerImageTags
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminAddLocalizedNewsRequest
// Size: 0x50(Inherited: 0x8) 
struct FAdminAddLocalizedNewsRequest : public FPlayFabRequestCommon
{
	struct FString Body;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Language;  // 0x20(0x10)
	struct FString NewsId;  // 0x30(0x10)
	struct FString Title;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GrantItemsToUsers
// Size: 0x60(Inherited: 0x0) 
struct FGrantItemsToUsers
{
	struct FServerGrantItemsToUsersRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperListMembershipOpportunities
// Size: 0x50(Inherited: 0x0) 
struct FHelperListMembershipOpportunities
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkKongregate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkKongregate__DelegateSignature
{
	struct FClientLinkKongregateAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessBanUsers__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessBanUsers__DelegateSignature
{
	struct FServerBanUsersResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.OnPlayFabGroupsRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabGroupsRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.OnPlayFabInsightsRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabInsightsRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddVirtualCurrencyTypes__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddVirtualCurrencyTypes__DelegateSignature
{
	struct FAdminBlankResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetMultiplayerServerDetailsRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerGetMultiplayerServerDetailsRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Region;  // 0x20(0x10)
	struct FString SessionId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.MatchmakerPlayerLeftResponse
// Size: 0x8(Inherited: 0x8) 
struct FMatchmakerPlayerLeftResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabJsonValue.ConstructJsonValueBool
// Size: 0x18(Inherited: 0x0) 
struct FConstructJsonValueBool
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool InValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonValue* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerUnlockContainerItemRequest
// Size: 0x50(Inherited: 0x8) 
struct FServerUnlockContainerItemRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct FString ContainerItemId;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)
	struct FString PlayFabId;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserReadOnlyData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserReadOnlyData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperSetTitleDataAndOverrides
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetTitleDataAndOverrides
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.OnPlayFabLocalizationRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabLocalizationRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientRemoveContactEmailRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientRemoveContactEmailRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminAddPlayerTagRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminAddPlayerTagRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString TagName;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeInventoryItems__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRevokeInventoryItems__DelegateSignature
{
	struct FServerRevokeInventoryItemsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkGooglePlayGamesServicesAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkGooglePlayGamesServicesAccount__DelegateSignature
{
	struct FClientUnlinkGooglePlayGamesServicesAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListContainerImagesResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListContainerImagesResponse : public FPlayFabResultCommon
{
	struct FString Images;  // 0x8(0x10)
	int32_t PageSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCheckLimitedEditionItemAvailability__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessCheckLimitedEditionItemAvailability__DelegateSignature
{
	struct FAdminCheckLimitedEditionItemAvailabilityResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ClientGetSharedGroupDataResult
// Size: 0x20(Inherited: 0x8) 
struct FClientGetSharedGroupDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)
	struct FString Members;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerTagsResult
// Size: 0x28(Inherited: 0x8) 
struct FClientGetPlayerTagsResult : public FPlayFabResultCommon
{
	struct FString PlayFabId;  // 0x8(0x10)
	struct FString Tags;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.AdminAbortTaskInstanceRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminAbortTaskInstanceRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString TaskInstanceId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.AddMembers
// Size: 0x68(Inherited: 0x0) 
struct FAddMembers
{
	struct FGroupsAddMembersRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerTagsRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminGetPlayerTagsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Namespace;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.ListGroupApplications
// Size: 0x48(Inherited: 0x0) 
struct FListGroupApplications
{
	struct FGroupsListGroupApplicationsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRegisterForIOSPushNotificationResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRegisterForIOSPushNotificationResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRegisterForIOSPushNotificationResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPublisherDataRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPublisherDataRequest : public FPlayFabRequestCommon
{
	struct FString Keys;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabMatchmakerRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabMatchmakerRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientConsumeItemRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientConsumeItemRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	int32_t ConsumeCount;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString ItemInstanceId;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabMultiplayerRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabMultiplayerRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserPublisherInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserPublisherInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateIOSReceipt__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessValidateIOSReceipt__DelegateSignature
{
	struct FClientValidateIOSReceiptResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerSendCustomAccountRecoveryEmailRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerSendCustomAccountRecoveryEmailRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Email;  // 0x10(0x10)
	struct FString EmailTemplateId;  // 0x20(0x10)
	struct FString Username;  // 0x30(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabProfilesRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabProfilesRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetExclusionGroups__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetExclusionGroups__DelegateSignature
{
	struct FExperimentationGetExclusionGroupsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminCheckLimitedEditionItemAvailabilityRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminCheckLimitedEditionItemAvailabilityRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString ItemId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperUpdateExclusionGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateExclusionGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetPlayerStatisticVersionsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayerStatisticVersionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> StatisticVersions;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.OnPlayFabServerRequestCompleted__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPlayFabServerRequestCompleted__DelegateSignature
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientAcceptTradeRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientAcceptTradeRequest : public FPlayFabRequestCommon
{
	struct FString AcceptedInventoryInstanceIds;  // 0x8(0x10)
	struct FString OfferingPlayerId;  // 0x18(0x10)
	struct FString TradeId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.AdminCreateInsightsScheduledScalingTaskRequest
// Size: 0x50(Inherited: 0x8) 
struct FAdminCreateInsightsScheduledScalingTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool IsActive : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString Name;  // 0x28(0x10)
	struct UPlayFabJsonObject* Parameter;  // 0x38(0x8)
	struct FString Schedule;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeGetObjectsResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetObjectsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataGetObjectsResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperSetMembershipOverride
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetMembershipOverride
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LinkApple
// Size: 0x58(Inherited: 0x0) 
struct FLinkApple
{
	struct FClientLinkAppleRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.AbortTaskInstance
// Size: 0x50(Inherited: 0x0) 
struct FAbortTaskInstance
{
	struct FAdminAbortTaskInstanceRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetPublisherData
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetPublisherData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnFailurePlayFabError__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnFailurePlayFabError__DelegateSignature
{
	struct FPlayFabError Error;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabEventsAPI.WriteEvents
// Size: 0x50(Inherited: 0x0) 
struct FWriteEvents
{
	struct FEventsWriteEventsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabEventsAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAbortTaskInstance__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAbortTaskInstance__DelegateSignature
{
	struct FAdminEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkGameCenterAccount
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkGameCenterAccount
{
	struct FClientUnlinkGameCenterAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptGetFunctionRequest
// Size: 0x20(Inherited: 0x8) 
struct FCloudScriptGetFunctionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FunctionName;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerGetStoreItemsResult
// Size: 0x48(Inherited: 0x8) 
struct FServerGetStoreItemsResult : public FPlayFabResultCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* MarketingData;  // 0x18(0x8)
	uint8_t  Source;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct UPlayFabJsonObject*> Store;  // 0x28(0x10)
	struct FString StoreId;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.PlayFabRequestCommon
// Size: 0x8(Inherited: 0x0) 
struct FPlayFabRequestCommon
{
	struct UPlayFabAuthenticationContext* AuthenticationContext;  // 0x0(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResetCharacterStatistics__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessResetCharacterStatistics__DelegateSignature
{
	struct FAdminResetCharacterStatisticsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminRemovePlayerTagRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminRemovePlayerTagRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString TagName;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetPlayerSecret__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetPlayerSecret__DelegateSignature
{
	struct FServerSetPlayerSecretResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientRemoveSharedGroupMembersResult
// Size: 0x8(Inherited: 0x8) 
struct FClientRemoveSharedGroupMembersResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperRefundPurchase
// Size: 0x50(Inherited: 0x0) 
struct FHelperRefundPurchase
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.SetStoreItems
// Size: 0x78(Inherited: 0x0) 
struct FSetStoreItems
{
	struct FAdminUpdateStoreItemsRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperDeleteRole
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteRole
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUnsubscribeFromLobbyResource
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnsubscribeFromLobbyResource
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.AddLocalizedNews
// Size: 0x80(Inherited: 0x0) 
struct FAddLocalizedNews
{
	struct FAdminAddLocalizedNewsRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListVirtualMachineSummariesRequest
// Size: 0x48(Inherited: 0x8) 
struct FMultiplayerListVirtualMachineSummariesRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	int32_t PageSize;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString Region;  // 0x28(0x10)
	struct FString SkipToken;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetDraftItems
// Size: 0x68(Inherited: 0x0) 
struct FGetDraftItems
{
	struct FEconomyGetDraftItemsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeListOpenIdConnectionResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListOpenIdConnectionResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminListOpenIdConnectionResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeBanUsersResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeBanUsersResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerBanUsersResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientConsumeItemResult
// Size: 0x20(Inherited: 0x8) 
struct FClientConsumeItemResult : public FPlayFabResultCommon
{
	struct FString ItemInstanceId;  // 0x8(0x10)
	int32_t RemainingUses;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRedeemMatchmakerTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperRedeemMatchmakerTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AuthenticationValidateEntityTokenRequest
// Size: 0x20(Inherited: 0x8) 
struct FAuthenticationValidateEntityTokenRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString EntityToken;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.GetCloudScriptRevision
// Size: 0x40(Inherited: 0x0) 
struct FGetCloudScriptRevision
{
	struct FAdminGetCloudScriptRevisionRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromFacebookIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromFacebookIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminModifyUserVirtualCurrencyResult
// Size: 0x30(Inherited: 0x8) 
struct FAdminModifyUserVirtualCurrencyResult : public FPlayFabResultCommon
{
	int32_t Balance;  // 0x8(0x4)
	int32_t BalanceChange;  // 0xC(0x4)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString VirtualCurrency;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientGetStoreItemsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientGetStoreItemsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString StoreId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.GetTaskInstances
// Size: 0x68(Inherited: 0x0) 
struct FGetTaskInstances
{
	struct FAdminGetTaskInstancesRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddLocalizedNews__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddLocalizedNews__DelegateSignature
{
	struct FAdminAddLocalizedNewsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromNintendoSwitchDeviceIds
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromNintendoSwitchDeviceIds
{
	struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminBlankResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminBlankResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminGetPlayerStatisticVersionsRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminGetPlayerStatisticVersionsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString StatisticName;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.UnlockContainerInstance
// Size: 0x90(Inherited: 0x0) 
struct FUnlockContainerInstance
{
	struct FServerUnlockContainerInstanceRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x88(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.SetMembershipOverride
// Size: 0x70(Inherited: 0x0) 
struct FSetMembershipOverride
{
	struct FAdminSetMembershipOverrideRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateOpenIdConnection__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateOpenIdConnection__DelegateSignature
{
	struct FAdminEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminAddNewsRequest
// Size: 0x40(Inherited: 0x8) 
struct FAdminAddNewsRequest : public FPlayFabRequestCommon
{
	struct FString Body;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Timestamp;  // 0x20(0x10)
	struct FString Title;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest : public FPlayFabRequestCommon
{
	struct FString NintendoSwitchDeviceIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.AddNews
// Size: 0x70(Inherited: 0x0) 
struct FAddNews
{
	struct FAdminAddNewsRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayerTags
// Size: 0x60(Inherited: 0x0) 
struct FGetPlayerTags
{
	struct FServerGetPlayerTagsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.AdminRunTaskRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminRunTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Identifier;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAddPlayerTag
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddPlayerTag
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateInsightsScheduledScalingTask__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateInsightsScheduledScalingTask__DelegateSignature
{
	struct FAdminCreateTaskResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetEntityItemReview
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetEntityItemReview
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateMatchmakingTicket__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateMatchmakingTicket__DelegateSignature
{
	struct FMultiplayerCreateMatchmakingTicketResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.ConsumePS5Entitlements
// Size: 0x58(Inherited: 0x0) 
struct FConsumePS5Entitlements
{
	struct FClientConsumePS5EntitlementsRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddNews__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessAddNews__DelegateSignature
{
	struct FAdminAddNewsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetTitleMultiplayerServersQuotasResponse
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetTitleMultiplayerServersQuotasResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Quotas;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CancelAllMatchmakingTicketsForPlayer
// Size: 0x58(Inherited: 0x0) 
struct FCancelAllMatchmakingTicketsForPlayer
{
	struct FMultiplayerCancelAllMatchmakingTicketsForPlayerRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeBlankResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeBlankResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminBlankResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetBuild
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetBuild
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetPlayerStatisticVersionsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayerStatisticVersionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> StatisticVersions;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.RequestMultiplayerServer
// Size: 0x98(Inherited: 0x0) 
struct FRequestMultiplayerServer
{
	struct FMultiplayerRequestMultiplayerServerRequest Request;  // 0x0(0x68)
	struct FDelegate onSuccess;  // 0x68(0x10)
	struct FDelegate onFailure;  // 0x78(0x10)
	struct UObject* customData;  // 0x88(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x90(0x8)

}; 
// ScriptStruct PlayFab.AdminAddNewsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminAddNewsResult : public FPlayFabResultCommon
{
	struct FString NewsId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCharacterData__DelegateSignature
{
	struct FServerUpdateCharacterDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.RunTask
// Size: 0x48(Inherited: 0x0) 
struct FRunTask
{
	struct FAdminRunTaskRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRemoveGenericID
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveGenericID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkFacebookInstantGamesIdResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkFacebookInstantGamesIdResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkFacebookInstantGamesIdResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminAddPlayerTagResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminAddPlayerTagResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabClientAPI.RemoveContactEmail
// Size: 0x40(Inherited: 0x0) 
struct FRemoveContactEmail
{
	struct FClientRemoveContactEmailRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.AddUserVirtualCurrency
// Size: 0x68(Inherited: 0x0) 
struct FAddUserVirtualCurrency
{
	struct FServerAddUserVirtualCurrencyRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromTwitchIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromTwitchIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromTwitchIDsResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetMembershipOverride__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetMembershipOverride__DelegateSignature
{
	struct FAdminSetMembershipOverrideResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessAddUserVirtualCurrency__DelegateSignature
{
	struct FServerModifyUserVirtualCurrencyResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminAddUserVirtualCurrencyRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminAddUserVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString VirtualCurrency;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.AdminIncrementPlayerStatisticVersionResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminIncrementPlayerStatisticVersionResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* StatisticVersion;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithNintendoServiceAccountRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithNintendoServiceAccountRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct FString IdentityToken;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature
{
	struct FServerGetPlayerStatisticVersionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetCloudScriptTaskInstanceResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetCloudScriptTaskInstanceResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetCloudScriptTaskInstanceResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAwardSteamAchievement__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessAwardSteamAchievement__DelegateSignature
{
	struct FServerAwardSteamAchievementResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.AddCharacterVirtualCurrency
// Size: 0x78(Inherited: 0x0) 
struct FAddCharacterVirtualCurrency
{
	struct FServerAddCharacterVirtualCurrencyRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.AddVirtualCurrencyTypes
// Size: 0x48(Inherited: 0x0) 
struct FAddVirtualCurrencyTypes
{
	struct FAdminAddVirtualCurrencyTypesRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminAddVirtualCurrencyTypesRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminAddVirtualCurrencyTypesRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> VirtualCurrencies;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.BanUsers
// Size: 0x50(Inherited: 0x0) 
struct FBanUsers
{
	struct FServerBanUsersRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.AdminGetContentUploadUrlRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetContentUploadUrlRequest : public FPlayFabRequestCommon
{
	struct FString ContentType;  // 0x8(0x10)
	struct FString Key;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGrantCharacterToUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperGrantCharacterToUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayedTitleList__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayedTitleList__DelegateSignature
{
	struct FAdminGetPlayedTitleListResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListTitleMultiplayerServersQuotaChangesResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListTitleMultiplayerServersQuotaChangesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListTitleMultiplayerServersQuotaChangesResponse ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerUpdateUserInternalDataRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerUpdateUserInternalDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetFriendLeaderboardAroundPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetFriendLeaderboardAroundPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminIncrementLimitedEditionItemAvailabilityRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminIncrementLimitedEditionItemAvailabilityRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString CatalogVersion;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString ItemId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithApple
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithApple
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminUpdateUserTitleDisplayNameRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminUpdateUserTitleDisplayNameRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DisplayName;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.AdminBanUsersResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminBanUsersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerMoveItemToCharacterFromCharacterRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerMoveItemToCharacterFromCharacterRequest : public FPlayFabRequestCommon
{
	struct FString GivingCharacterId;  // 0x8(0x10)
	struct FString ItemInstanceId;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)
	struct FString ReceivingCharacterId;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.ExportMasterPlayerData
// Size: 0x48(Inherited: 0x0) 
struct FExportMasterPlayerData
{
	struct FAdminExportMasterPlayerDataRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkApple__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkApple__DelegateSignature
{
	struct FClientEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminCreateTaskResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminCreateTaskResult : public FPlayFabResultCommon
{
	struct FString TaskId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRevokeAllBansForUserResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRevokeAllBansForUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRevokeAllBansForUserResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.AdminGetAllSegmentsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetAllSegmentsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Segments;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTitleNews__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitleNews__DelegateSignature
{
	struct FServerGetTitleNewsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRemoveVirtualCurrencyTypes__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveVirtualCurrencyTypes__DelegateSignature
{
	struct FAdminBlankResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminBanUsersRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminBanUsersRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Bans;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.CheckLimitedEditionItemAvailability
// Size: 0x58(Inherited: 0x0) 
struct FCheckLimitedEditionItemAvailability
{
	struct FAdminCheckLimitedEditionItemAvailabilityRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserPublisherInternalData__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserPublisherInternalData__DelegateSignature
{
	struct FServerGetUserDataResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationStopExperimentRequest
// Size: 0x20(Inherited: 0x8) 
struct FExperimentationStopExperimentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExperimentId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.AdminGetActionsOnPlayersInSegmentTaskInstanceResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetActionsOnPlayersInSegmentTaskInstanceResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Parameter;  // 0x8(0x8)
	struct UPlayFabJsonObject* Summary;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.AdminCreateSegmentRequest
// Size: 0x10(Inherited: 0x8) 
struct FAdminCreateSegmentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* SegmentModel;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.CreateActionsOnPlayersInSegmentTask
// Size: 0x80(Inherited: 0x0) 
struct FCreateActionsOnPlayersInSegmentTask
{
	struct FAdminCreateActionsOnPlayerSegmentTaskRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetEntityDraftItemsResponse
// Size: 0x28(Inherited: 0x8) 
struct FEconomyGetEntityDraftItemsResponse : public FPlayFabResultCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.MoveItemToUserFromCharacter
// Size: 0x68(Inherited: 0x0) 
struct FMoveItemToUserFromCharacter
{
	struct FServerMoveItemToUserFromCharacterRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.CreateCloudScriptTask
// Size: 0x80(Inherited: 0x0) 
struct FCreateCloudScriptTask
{
	struct FAdminCreateCloudScriptTaskRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperResolvePurchaseDispute
// Size: 0x50(Inherited: 0x0) 
struct FHelperResolvePurchaseDispute
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromFacebookInstantGamesIds
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromFacebookInstantGamesIds
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetSegmentExport
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetSegmentExport
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperMoveItemToCharacterFromUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperMoveItemToCharacterFromUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateCloudScriptTask__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateCloudScriptTask__DelegateSignature
{
	struct FAdminCreateTaskResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerSegments__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerSegments__DelegateSignature
{
	struct FServerGetPlayerSegmentsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromKongregateIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromKongregateIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.CreateInsightsScheduledScalingTask
// Size: 0x80(Inherited: 0x0) 
struct FCreateInsightsScheduledScalingTask
{
	struct FAdminCreateInsightsScheduledScalingTaskRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptExecuteFunctionResult
// Size: 0x38(Inherited: 0x8) 
struct FCloudScriptExecuteFunctionResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Error;  // 0x8(0x8)
	int32_t ExecutionTimeMilliseconds;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString FunctionName;  // 0x18(0x10)
	struct UPlayFabJsonObject* FunctionResult;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool FunctionResultTooLarge : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteTitle
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteTitle
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerGetContainerRegistryCredentialsResponse
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerGetContainerRegistryCredentialsResponse : public FPlayFabResultCommon
{
	struct FString DnsName;  // 0x8(0x10)
	struct FString Password;  // 0x18(0x10)
	struct FString Username;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessPublishDraftItem__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPublishDraftItem__DelegateSignature
{
	struct FEconomyPublishDraftItemResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.CreateOpenIdConnection
// Size: 0x88(Inherited: 0x0) 
struct FCreateOpenIdConnection
{
	struct FAdminCreateOpenIdConnectionRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.AdminExportMasterPlayerDataResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminExportMasterPlayerDataResult : public FPlayFabResultCommon
{
	struct FString JobReceiptId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessFindFriendLobbies__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessFindFriendLobbies__DelegateSignature
{
	struct FMultiplayerFindFriendLobbiesResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientAndroidDevicePushNotificationRegistrationResult
// Size: 0x8(Inherited: 0x8) 
struct FClientAndroidDevicePushNotificationRegistrationResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateOpenIdConnection__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessCreateOpenIdConnection__DelegateSignature
{
	struct FAdminEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGrantItemsToUsersResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGrantItemsToUsersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> ItemGrantResults;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperModifyServerBuild
// Size: 0x50(Inherited: 0x0) 
struct FHelperModifyServerBuild
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListTitleMultiplayerServersQuotaChanges
// Size: 0x50(Inherited: 0x0) 
struct FHelperListTitleMultiplayerServersQuotaChanges
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListContainerImageTags__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListContainerImageTags__DelegateSignature
{
	struct FMultiplayerListContainerImageTagsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetContentUploadUrl__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetContentUploadUrl__DelegateSignature
{
	struct FAdminGetContentUploadUrlResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.ListMembershipOpportunities
// Size: 0x48(Inherited: 0x0) 
struct FListMembershipOpportunities
{
	struct FGroupsListMembershipOpportunitiesRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeUpdateDraftItemResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeUpdateDraftItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyUpdateDraftItemResponse ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateSharedGroupData__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateSharedGroupData__DelegateSignature
{
	struct FServerUpdateSharedGroupDataResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminCreateOpenIdConnectionRequest
// Size: 0x58(Inherited: 0x8) 
struct FAdminCreateOpenIdConnectionRequest : public FPlayFabRequestCommon
{
	struct FString ClientId;  // 0x8(0x10)
	struct FString ClientSecret;  // 0x18(0x10)
	struct FString ConnectionId;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool IgnoreNonce : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString IssuerDiscoveryUrl;  // 0x40(0x10)
	struct UPlayFabJsonObject* IssuerInformation;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.CreatePlayerSharedSecret
// Size: 0x48(Inherited: 0x0) 
struct FCreatePlayerSharedSecret
{
	struct FAdminCreatePlayerSharedSecretRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperIncrementPlayerStatisticVersion
// Size: 0x50(Inherited: 0x0) 
struct FHelperIncrementPlayerStatisticVersion
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminUpdateUserDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FAdminUpdateUserDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	uint8_t  Permission;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.AdminCreatePlayerSharedSecretResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminCreatePlayerSharedSecretResult : public FPlayFabResultCommon
{
	struct FString SecretKey;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientOpenTradeResponse
// Size: 0x10(Inherited: 0x8) 
struct FClientOpenTradeResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Trade;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddSharedGroupMembers__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddSharedGroupMembers__DelegateSignature
{
	struct FServerAddSharedGroupMembersResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserPublisherReadOnlyData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserPublisherReadOnlyData__DelegateSignature
{
	struct FServerUpdateUserDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeSendAccountRecoveryEmailResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSendAccountRecoveryEmailResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientSendAccountRecoveryEmailResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUnlinkServerCustomId
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkServerCustomId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreatePlayerStatisticDefinition
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreatePlayerStatisticDefinition
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperRemoveMember
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveMember
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreatePlayerSharedSecret__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreatePlayerSharedSecret__DelegateSignature
{
	struct FAdminCreatePlayerSharedSecretResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeRequestMultiplayerServerResponseResponse
// Size: 0xC0(Inherited: 0x0) 
struct FdecodeRequestMultiplayerServerResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerRequestMultiplayerServerResponse ReturnValue;  // 0x8(0xB8)

}; 
// ScriptStruct PlayFab.ServerLoginWithSteamIdRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerLoginWithSteamIdRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x18(0x8)
	struct FString SteamID;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.AdminGetPlayersSegmentsRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminGetPlayersSegmentsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.AdminCreatePlayerSharedSecretRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminCreatePlayerSharedSecretRequest : public FPlayFabRequestCommon
{
	struct FString FriendlyName;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItems__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetItems__DelegateSignature
{
	struct FEconomyGetItemsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.CreatePlayerStatisticDefinition
// Size: 0x60(Inherited: 0x0) 
struct FCreatePlayerStatisticDefinition
{
	struct FAdminCreatePlayerStatisticDefinitionRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.AdminLookupUserAccountInfoRequest
// Size: 0x48(Inherited: 0x8) 
struct FAdminLookupUserAccountInfoRequest : public FPlayFabRequestCommon
{
	struct FString Email;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString TitleDisplayName;  // 0x28(0x10)
	struct FString Username;  // 0x38(0x10)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForScheduledTask__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPostFunctionResultForScheduledTask__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreatePlayerStatisticDefinition__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessCreatePlayerStatisticDefinition__DelegateSignature
{
	struct FAdminCreatePlayerStatisticDefinitionResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkNintendoServiceAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkNintendoServiceAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientRegisterForIOSPushNotificationResult
// Size: 0x8(Inherited: 0x8) 
struct FClientRegisterForIOSPushNotificationResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminCreatePlayerStatisticDefinitionResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminCreatePlayerStatisticDefinitionResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Statistic;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminRevokeInventoryItemsRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminRevokeInventoryItemsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ExperimentationGetLatestScorecardRequest
// Size: 0x20(Inherited: 0x8) 
struct FExperimentationGetLatestScorecardRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExperimentId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabAuthenticationAPI.ValidateEntityToken
// Size: 0x50(Inherited: 0x0) 
struct FValidateEntityToken
{
	struct FAuthenticationValidateEntityTokenRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabAuthenticationAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.AdminCreatePlayerStatisticDefinitionRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminCreatePlayerStatisticDefinitionRequest : public FPlayFabRequestCommon
{
	uint8_t  AggregationMethod;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString StatisticName;  // 0x18(0x10)
	uint8_t  VersionChangeInterval;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperRunTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperRunTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientRegisterForIOSPushNotificationRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientRegisterForIOSPushNotificationRequest : public FPlayFabRequestCommon
{
	struct FString ConfirmationMessage;  // 0x8(0x10)
	struct FString DeviceToken;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool SendPushNotificationConfirmation : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperCreateSharedGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateSharedGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminDeletePlayerResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeletePlayerResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerUnlinkXboxAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FServerUnlinkXboxAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.CreateSegment
// Size: 0x40(Inherited: 0x0) 
struct FCreateSegment
{
	struct FAdminCreateSegmentRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientStartPurchaseRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientStartPurchaseRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x20(0x10)
	struct FString StoreId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.AdminRefundPurchaseResponse
// Size: 0x18(Inherited: 0x8) 
struct FAdminRefundPurchaseResponse : public FPlayFabResultCommon
{
	struct FString PurchaseStatus;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreateOpenIdConnection
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateOpenIdConnection
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateSegment__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessCreateSegment__DelegateSignature
{
	struct FAdminCreateSegmentResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ServerSendPushNotificationRequest
// Size: 0x68(Inherited: 0x8) 
struct FServerSendPushNotificationRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> AdvancedPlatformDelivery;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Message;  // 0x20(0x10)
	struct UPlayFabJsonObject* Package;  // 0x30(0x8)
	struct FString Recipient;  // 0x38(0x10)
	struct FString Subject;  // 0x48(0x10)
	struct FString TargetPlatforms;  // 0x58(0x10)

}; 
// ScriptStruct PlayFab.AdminGetRandomResultTablesRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetRandomResultTablesRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromFacebookIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromFacebookIDsRequest : public FPlayFabRequestCommon
{
	struct FString FacebookIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminCreateSegmentResponse
// Size: 0x28(Inherited: 0x8) 
struct FAdminCreateSegmentResponse : public FPlayFabResultCommon
{
	struct FString ErrorMessage;  // 0x8(0x10)
	struct FString SegmentId;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlockContainerInstance__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FDelegateOnSuccessUnlockContainerInstance__DelegateSignature
{
	struct FServerUnlockContainerItemResult Result;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.GroupsRemoveMembersRequest
// Size: 0x38(Inherited: 0x8) 
struct FGroupsRemoveMembersRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x18(0x10)
	struct FString RoleId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetTasks
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTasks
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateRandomResultTables
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateRandomResultTables
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteContent__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteContent__DelegateSignature
{
	struct FAdminBlankResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromNintendoServiceAccountIds
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromNintendoServiceAccountIds
{
	struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCharacterInventory
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCharacterInventory
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteMasterPlayerAccount__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteMasterPlayerAccount__DelegateSignature
{
	struct FAdminDeleteMasterPlayerAccountResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteMasterPlayerAccountResult
// Size: 0x28(Inherited: 0x8) 
struct FAdminDeleteMasterPlayerAccountResult : public FPlayFabResultCommon
{
	struct FString JobReceiptId;  // 0x8(0x10)
	struct FString TitleIds;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteTitleDataOverride__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteTitleDataOverride__DelegateSignature
{
	struct FAdminDeleteTitleDataOverrideResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.GroupsDeleteGroupRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsDeleteGroupRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.SubscribeToLobbyResource
// Size: 0x70(Inherited: 0x0) 
struct FSubscribeToLobbyResource
{
	struct FMultiplayerSubscribeToLobbyResourceRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetPlayerIdFromAuthToken
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerIdFromAuthToken
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateLobby__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateLobby__DelegateSignature
{
	struct FMultiplayerLobbyEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteMembershipSubscription__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteMembershipSubscription__DelegateSignature
{
	struct FAdminDeleteMembershipSubscriptionResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteMembershipSubscriptionResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeleteMembershipSubscriptionResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabJsonObject.SetBoolField
// Size: 0x18(Inherited: 0x0) 
struct FSetBoolField
{
	struct FString FieldName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool InValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct PlayFab.AdminDeleteStoreResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeleteStoreResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteOpenIdConnection__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteOpenIdConnection__DelegateSignature
{
	struct FAdminEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkFacebookInstantGamesId__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkFacebookInstantGamesId__DelegateSignature
{
	struct FClientUnlinkFacebookInstantGamesIdResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeletePlayer__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeletePlayer__DelegateSignature
{
	struct FServerDeletePlayerResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.AttributeInstall
// Size: 0x58(Inherited: 0x0) 
struct FAttributeInstall
{
	struct FClientAttributeInstallRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetCloudScriptRevision
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCloudScriptRevision
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeletePlayerSharedSecret__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeletePlayerSharedSecret__DelegateSignature
{
	struct FAdminDeletePlayerSharedSecretResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserPublisherInternalData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserPublisherInternalData__DelegateSignature
{
	struct FServerUpdateUserDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetEntityItemReviewRequest
// Size: 0x30(Inherited: 0x8) 
struct FEconomyGetEntityItemReviewRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ID;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.AdminDeletePlayerSharedSecretResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeletePlayerSharedSecretResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.RedeemCoupon
// Size: 0x80(Inherited: 0x0) 
struct FRedeemCoupon
{
	struct FServerRedeemCouponRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteSegment__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteSegment__DelegateSignature
{
	struct FAdminDeleteSegmentsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.NotifyMatchmakerPlayerLeft
// Size: 0x60(Inherited: 0x0) 
struct FNotifyMatchmakerPlayerLeft
{
	struct FServerNotifyMatchmakerPlayerLeftRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayerProfile
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerProfile
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteSegment
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteSegment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabJsonValue.AsObject
// Size: 0x8(Inherited: 0x0) 
struct FAsObject
{
	struct UPlayFabJsonObject* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteSegmentsResponse
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeleteSegmentsResponse : public FPlayFabResultCommon
{
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserPublisherReadOnlyData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserPublisherReadOnlyData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromFacebookIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromFacebookIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromFacebookIDsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCharacterInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetStoreItems__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetStoreItems__DelegateSignature
{
	struct FAdminUpdateStoreItemsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.DataSetObjectsRequest
// Size: 0x30(Inherited: 0x8) 
struct FDataSetObjectsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	int32_t ExpectedProfileVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct UPlayFabJsonObject*> Objects;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetQueueStatistics__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetQueueStatistics__DelegateSignature
{
	struct FMultiplayerGetQueueStatisticsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayerCombinedInfoRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientGetPlayerCombinedInfoRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x10(0x8)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkXboxAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkXboxAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.GetActionsOnPlayersInSegmentTaskInstance
// Size: 0x48(Inherited: 0x0) 
struct FGetActionsOnPlayersInSegmentTaskInstance
{
	struct FAdminGetTaskInstanceRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteStore__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteStore__DelegateSignature
{
	struct FAdminDeleteStoreResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGrantItemsToCharacterResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGrantItemsToCharacterResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGrantItemsToCharacterResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGameCenterIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGameCenterIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.GetSegments
// Size: 0x48(Inherited: 0x0) 
struct FGetSegments
{
	struct FAdminGetSegmentsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientListUsersCharactersRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientListUsersCharactersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkKongregateAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkKongregateAccountResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkCustomID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkCustomID__DelegateSignature
{
	struct FClientLinkCustomIDResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessExecuteEntityCloudScript__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FDelegateOnSuccessExecuteEntityCloudScript__DelegateSignature
{
	struct FCloudScriptExecuteCloudScriptResult Result;  // 0x0(0x60)
	struct UObject* customData;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ServerUnlockContainerInstanceRequest
// Size: 0x60(Inherited: 0x8) 
struct FServerUnlockContainerInstanceRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct FString ContainerItemInstanceId;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)
	struct FString KeyItemInstanceId;  // 0x40(0x10)
	struct FString PlayFabId;  // 0x50(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteTask__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteTask__DelegateSignature
{
	struct FAdminEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientAddFriendRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientAddFriendRequest : public FPlayFabRequestCommon
{
	struct FString FriendEmail;  // 0x8(0x10)
	struct FString FriendPlayFabId;  // 0x18(0x10)
	struct FString FriendTitleDisplayName;  // 0x28(0x10)
	struct FString FriendUsername;  // 0x38(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteTitle__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteTitle__DelegateSignature
{
	struct FAdminDeleteTitleResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessSetProfilePolicy__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessSetProfilePolicy__DelegateSignature
{
	struct FProfilesSetEntityProfilePolicyResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetLeaderboardAroundCharacter
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLeaderboardAroundCharacter
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LinkTwitch
// Size: 0x58(Inherited: 0x0) 
struct FLinkTwitch
{
	struct FClientLinkTwitchAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteTitleResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeleteTitleResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkPSNAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkPSNAccount__DelegateSignature
{
	struct FServerUnlinkPSNAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateAvatarUrl
// Size: 0x58(Inherited: 0x0) 
struct FUpdateAvatarUrl
{
	struct FServerUpdateAvatarUrlRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListCertificateSummariesResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListCertificateSummariesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListCertificateSummariesResponse ReturnValue;  // 0x8(0x30)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkFacebookAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkFacebookAccount__DelegateSignature
{
	struct FClientLinkFacebookAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteTitleDataOverrideResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeleteTitleDataOverrideResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.MultiplayerListQosServersForTitleResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListQosServersForTitleResponse : public FPlayFabResultCommon
{
	int32_t PageSize;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UPlayFabJsonObject*> QosServers;  // 0x10(0x10)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetContentList__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetContentList__DelegateSignature
{
	struct FAdminGetContentListResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessExportMasterPlayerData__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessExportMasterPlayerData__DelegateSignature
{
	struct FAdminExportMasterPlayerDataResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperDeletePlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeletePlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminUpdateOpenIdConnectionRequest
// Size: 0x50(Inherited: 0x8) 
struct FAdminUpdateOpenIdConnectionRequest : public FPlayFabRequestCommon
{
	struct FString ClientId;  // 0x8(0x10)
	struct FString ClientSecret;  // 0x18(0x10)
	struct FString ConnectionId;  // 0x28(0x10)
	struct FString IssuerDiscoveryUrl;  // 0x38(0x10)
	struct UPlayFabJsonObject* IssuerInformation;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessCancelTrade__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessCancelTrade__DelegateSignature
{
	struct FClientCancelTradeResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerFindLobbiesRequest
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerFindLobbiesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Filter;  // 0x10(0x10)
	struct FString OrderBy;  // 0x20(0x10)
	struct UPlayFabJsonObject* Pagination;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabEventsModelDecoder.decodeWriteEventsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeWriteEventsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEventsWriteEventsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeOpenTradeResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeOpenTradeResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientOpenTradeResponse ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessExportPlayersInSegment__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessExportPlayersInSegment__DelegateSignature
{
	struct FAdminExportPlayersInSegmentResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListServerBackfillTicketsForPlayer__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListServerBackfillTicketsForPlayer__DelegateSignature
{
	struct FMultiplayerListServerBackfillTicketsForPlayerResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithGameCenter__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithGameCenter__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminExportPlayersInSegmentResult
// Size: 0x28(Inherited: 0x8) 
struct FAdminExportPlayersInSegmentResult : public FPlayFabResultCommon
{
	struct FString ExportId;  // 0x8(0x10)
	struct FString SegmentId;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetActionsOnPlayersInSegmentTaskInstance__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetActionsOnPlayersInSegmentTaskInstance__DelegateSignature
{
	struct FAdminGetActionsOnPlayersInSegmentTaskInstanceResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayersInSegment
// Size: 0x68(Inherited: 0x0) 
struct FGetPlayersInSegment
{
	struct FServerGetPlayersInSegmentRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteTitleDataOverride
// Size: 0x48(Inherited: 0x0) 
struct FDeleteTitleDataOverride
{
	struct FAdminDeleteTitleDataOverrideRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetAllSegments__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetAllSegments__DelegateSignature
{
	struct FServerGetAllSegmentsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.GroupsListGroupMembersRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupMembersRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.AddFriend
// Size: 0x88(Inherited: 0x0) 
struct FAddFriend
{
	struct FServerAddFriendRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x80(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteTitle
// Size: 0x38(Inherited: 0x0) 
struct FDeleteTitle
{
	struct FAdminDeleteTitleRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkFacebookInstantGamesId__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkFacebookInstantGamesId__DelegateSignature
{
	struct FClientLinkFacebookInstantGamesIdResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessSetStorageRetention__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessSetStorageRetention__DelegateSignature
{
	struct FInsightsInsightsOperationResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCatalogItems__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetCatalogItems__DelegateSignature
{
	struct FServerGetCatalogItemsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminGetCatalogItemsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetCatalogItemsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Catalog;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessWriteTitleEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessWriteTitleEvent__DelegateSignature
{
	struct FServerWriteEventResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterReadOnlyData__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetCharacterReadOnlyData__DelegateSignature
{
	struct FServerGetCharacterDataResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperSetStoreItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetStoreItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerListBuildSummariesRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListBuildSummariesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t PageSize;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString SkipToken;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.AdminGetUserBansResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetUserBansResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserInventory
// Size: 0x50(Inherited: 0x0) 
struct FGetUserInventory
{
	struct FServerGetUserInventoryRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientMatchmakeRequest
// Size: 0x70(Inherited: 0x8) 
struct FClientMatchmakeRequest : public FPlayFabRequestCommon
{
	struct FString BuildVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString GameMode;  // 0x30(0x10)
	struct FString LobbyId;  // 0x40(0x10)
	uint8_t  Region;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool StartNewIfNoneFound : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct FString StatisticName;  // 0x58(0x10)
	struct UPlayFabJsonObject* TagFilter;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessGetGroup__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FDelegateOnSuccessGetGroup__DelegateSignature
{
	struct FGroupsGetGroupResponse Result;  // 0x0(0x60)
	struct UObject* customData;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCloudScriptRevision__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetCloudScriptRevision__DelegateSignature
{
	struct FAdminGetCloudScriptRevisionResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdatePlayerStatistics
// Size: 0x68(Inherited: 0x0) 
struct FUpdatePlayerStatistics
{
	struct FServerUpdatePlayerStatisticsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateServerMatchmakingTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateServerMatchmakingTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetCloudScriptRevisionResult
// Size: 0x38(Inherited: 0x8) 
struct FAdminGetCloudScriptRevisionResult : public FPlayFabResultCommon
{
	struct FString CreatedAt;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Files;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool IsPublished : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Revision;  // 0x2C(0x4)
	int32_t Version;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCloudScriptTaskInstance__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetCloudScriptTaskInstance__DelegateSignature
{
	struct FAdminGetCloudScriptTaskInstanceResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessApplyToGroup__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessApplyToGroup__DelegateSignature
{
	struct FGroupsApplyToGroupResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateRandomResultTablesResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminUpdateRandomResultTablesResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.HelperLinkXboxAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkXboxAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetTitleData
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetTitleData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerGrantItemsToCharacterResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGrantItemsToCharacterResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> ItemGrantResults;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminGetCloudScriptTaskInstanceResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetCloudScriptTaskInstanceResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Parameter;  // 0x8(0x8)
	struct UPlayFabJsonObject* Summary;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperPurchaseItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperPurchaseItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.HelperPlayerJoined
// Size: 0x50(Inherited: 0x0) 
struct FHelperPlayerJoined
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperResetPassword
// Size: 0x50(Inherited: 0x0) 
struct FHelperResetPassword
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSubtractUserVirtualCurrency
// Size: 0x50(Inherited: 0x0) 
struct FHelperSubtractUserVirtualCurrency
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerJoinArrangedLobbyRequest
// Size: 0x48(Inherited: 0x8) 
struct FMultiplayerJoinArrangedLobbyRequest : public FPlayFabRequestCommon
{
	uint8_t  AccessPolicy;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString ArrangementString;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	int32_t MaxPlayers;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UPlayFabJsonObject* MemberData;  // 0x30(0x8)
	struct UPlayFabJsonObject* MemberEntity;  // 0x38(0x8)
	uint8_t  OwnerMigrationPolicy;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool UseConnections : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)

}; 
// Function PlayFab.PlayFabServerAPI.HelperExecuteCloudScript
// Size: 0x50(Inherited: 0x0) 
struct FHelperExecuteCloudScript
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCloudScriptVersions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetCloudScriptVersions__DelegateSignature
{
	struct FAdminGetCloudScriptVersionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetFriendLeaderboard__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetFriendLeaderboard__DelegateSignature
{
	struct FServerGetLeaderboardResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminGetCloudScriptVersionsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetCloudScriptVersionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Versions;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminGetContentListResult
// Size: 0x20(Inherited: 0x8) 
struct FAdminGetContentListResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Contents;  // 0x8(0x10)
	int32_t ItemCount;  // 0x18(0x4)
	int32_t TotalSize;  // 0x1C(0x4)

}; 
// Function PlayFab.PlayFabAdminAPI.ListOpenIdConnection
// Size: 0x38(Inherited: 0x0) 
struct FListOpenIdConnection
{
	struct FAdminListOpenIdConnectionRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListBuildAliasesResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListBuildAliasesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BuildAliases;  // 0x8(0x10)
	int32_t PageSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.AdminGetContentUploadUrlResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetContentUploadUrlResult : public FPlayFabResultCommon
{
	struct FString URL;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetDataReport__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetDataReport__DelegateSignature
{
	struct FAdminGetDataReportResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserPublisherReadOnlyData
// Size: 0x70(Inherited: 0x0) 
struct FUpdateUserPublisherReadOnlyData
{
	struct FServerUpdateUserDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemReviews__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetItemReviews__DelegateSignature
{
	struct FEconomyGetItemReviewsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.AdminGetDataReportResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetDataReportResult : public FPlayFabResultCommon
{
	struct FString DownloadUrl;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.EconomyUpdateCatalogConfigRequest
// Size: 0x18(Inherited: 0x8) 
struct FEconomyUpdateCatalogConfigRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Config;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetMatchmakerGameInfo__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FDelegateOnSuccessGetMatchmakerGameInfo__DelegateSignature
{
	struct FAdminGetMatchmakerGameInfoResult Result;  // 0x0(0xB8)
	struct UObject* customData;  // 0xB8(0x8)

}; 
// ScriptStruct PlayFab.ClientAttributeInstallResult
// Size: 0x8(Inherited: 0x8) 
struct FClientAttributeInstallResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.GetContentList
// Size: 0x48(Inherited: 0x0) 
struct FGetContentList
{
	struct FAdminGetContentListRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminGetMatchmakerGameInfoResult
// Size: 0xB8(Inherited: 0x8) 
struct FAdminGetMatchmakerGameInfoResult : public FPlayFabResultCommon
{
	struct FString BuildVersion;  // 0x8(0x10)
	struct FString EndTime;  // 0x18(0x10)
	struct FString LobbyId;  // 0x28(0x10)
	struct FString Mode;  // 0x38(0x10)
	struct FString Players;  // 0x48(0x10)
	uint8_t  Region;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FString ServerIPV4Address;  // 0x60(0x10)
	struct FString ServerIPV6Address;  // 0x70(0x10)
	int32_t ServerPort;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct FString ServerPublicDNSName;  // 0x88(0x10)
	struct FString StartTime;  // 0x98(0x10)
	struct FString TitleId;  // 0xA8(0x10)

}; 
// ScriptStruct PlayFab.AdminSetPublishedRevisionResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSetPublishedRevisionResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.GetPlayedTitleList
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayedTitleList
{
	struct FAdminGetPlayedTitleListRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPhotonAuthenticationTokenRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPhotonAuthenticationTokenRequest : public FPlayFabRequestCommon
{
	struct FString PhotonApplicationId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetMatchmakerGameModes__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetMatchmakerGameModes__DelegateSignature
{
	struct FAdminGetMatchmakerGameModesResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMultiplayerSessionLogsBySessionId__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetMultiplayerSessionLogsBySessionId__DelegateSignature
{
	struct FMultiplayerGetMultiplayerServerLogsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminGetMatchmakerGameModesResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetMatchmakerGameModesResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> GameModes;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.UnlinkXboxAccount
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkXboxAccount
{
	struct FServerUnlinkXboxAccountRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateLobbyRequest
// Size: 0x58(Inherited: 0x8) 
struct FMultiplayerCreateLobbyRequest : public FPlayFabRequestCommon
{
	uint8_t  AccessPolicy;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* LobbyData;  // 0x18(0x8)
	int32_t MaxPlayers;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x28(0x10)
	struct UPlayFabJsonObject* Owner;  // 0x38(0x8)
	uint8_t  OwnerMigrationPolicy;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UPlayFabJsonObject* SearchData;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool UseConnections : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// ScriptStruct PlayFab.AdminGetPlayedTitleListResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayedTitleListResult : public FPlayFabResultCommon
{
	struct FString TitleIds;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdatePlayerStatisticDefinition__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdatePlayerStatisticDefinition__DelegateSignature
{
	struct FAdminUpdatePlayerStatisticDefinitionResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptModelDecoder.decodeListHttpFunctionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListHttpFunctionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FCloudScriptListHttpFunctionsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.AdminGetPlayerSegmentsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayerSegmentsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Segments;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperFindFriendLobbies
// Size: 0x50(Inherited: 0x0) 
struct FHelperFindFriendLobbies
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.RevokeInventoryItem
// Size: 0x68(Inherited: 0x0) 
struct FRevokeInventoryItem
{
	struct FServerRevokeInventoryItemRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithSteam
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithSteam
{
	struct FClientLoginWithSteamRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromFacebookInstantGamesIdsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromFacebookInstantGamesIdsRequest : public FPlayFabRequestCommon
{
	struct FString FacebookInstantGamesIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkApple
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkApple
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerSetGameServerInstanceStateRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerSetGameServerInstanceStateRequest : public FPlayFabRequestCommon
{
	struct FString LobbyId;  // 0x8(0x10)
	uint8_t  State;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.MoveItemToCharacterFromUser
// Size: 0x68(Inherited: 0x0) 
struct FMoveItemToCharacterFromUser
{
	struct FServerMoveItemToCharacterFromUserRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromSteamIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromSteamIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerIdFromAuthToken__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerIdFromAuthToken__DelegateSignature
{
	struct FAdminGetPlayerIdFromAuthTokenResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerProfile__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerProfile__DelegateSignature
{
	struct FServerGetPlayerProfileResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.RemoveFriend
// Size: 0x58(Inherited: 0x0) 
struct FRemoveFriend
{
	struct FServerRemoveFriendRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkOpenIdConnect__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkOpenIdConnect__DelegateSignature
{
	struct FClientEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeDeleteItemResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyDeleteItemResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LinkAndroidDeviceID
// Size: 0x78(Inherited: 0x0) 
struct FLinkAndroidDeviceID
{
	struct FClientLinkAndroidDeviceIDRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessCreateSharedGroup__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateSharedGroup__DelegateSignature
{
	struct FServerCreateSharedGroupResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerProfileResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminGetPlayerProfileResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* PlayerProfile;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerSharedSecrets__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerSharedSecrets__DelegateSignature
{
	struct FAdminGetPlayerSharedSecretsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerSharedSecretsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayerSharedSecretsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> SharedSecrets;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkTwitchAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkTwitchAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientUpdateAvatarUrlRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientUpdateAvatarUrlRequest : public FPlayFabRequestCommon
{
	struct FString ImageUrl;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.GroupsAcceptGroupInvitationRequest
// Size: 0x20(Inherited: 0x8) 
struct FGroupsAcceptGroupInvitationRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRestoreIOSPurchases__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRestoreIOSPurchases__DelegateSignature
{
	struct FClientRestoreIOSPurchasesResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminResetPasswordRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminResetPasswordRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Password;  // 0x10(0x10)
	struct FString Token;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayersInSegment__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayersInSegment__DelegateSignature
{
	struct FServerGetPlayersInSegmentResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserAccountInfo
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserAccountInfo
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.GroupsInviteToGroupResponse
// Size: 0x40(Inherited: 0x8) 
struct FGroupsInviteToGroupResponse : public FPlayFabResultCommon
{
	struct FString Expires;  // 0x8(0x10)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)
	struct UPlayFabJsonObject* InvitedByEntity;  // 0x20(0x8)
	struct UPlayFabJsonObject* InvitedEntity;  // 0x28(0x8)
	struct FString RoleId;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabInsightsAPI.HelperSetPerformance
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetPerformance
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeGetEntityProfileResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetEntityProfileResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesGetEntityProfileResponse ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerStatisticsRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetPlayerStatisticsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString StatisticNames;  // 0x10(0x10)
	struct TArray<struct UPlayFabJsonObject*> StatisticNameVersions;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteOpenIdConnection
// Size: 0x48(Inherited: 0x0) 
struct FDeleteOpenIdConnection
{
	struct FAdminDeleteOpenIdConnectionRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ServerAddSharedGroupMembersResult
// Size: 0x8(Inherited: 0x8) 
struct FServerAddSharedGroupMembersResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminGetPlayersInSegmentResult
// Size: 0x30(Inherited: 0x8) 
struct FAdminGetPlayersInSegmentResult : public FPlayFabResultCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> PlayerProfiles;  // 0x18(0x10)
	int32_t ProfilesInSegment;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct PlayFab.AdminRevokeInventoryResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminRevokeInventoryResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListBuildAliases__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListBuildAliases__DelegateSignature
{
	struct FMultiplayerListBuildAliasesResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.LoginWithXbox
// Size: 0x60(Inherited: 0x0) 
struct FLoginWithXbox
{
	struct FServerLoginWithXboxRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FClientEmptyResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperResetUserStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperResetUserStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerStatisticDefinitions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerStatisticDefinitions__DelegateSignature
{
	struct FAdminGetPlayerStatisticDefinitionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminSetPublishedRevisionRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminSetPublishedRevisionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t Revision;  // 0x10(0x4)
	int32_t Version;  // 0x14(0x4)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserInventory__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserInventory__DelegateSignature
{
	struct FServerGetUserInventoryResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerStatisticDefinitionsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayerStatisticDefinitionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Statistics;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessDeleteExperiment__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteExperiment__DelegateSignature
{
	struct FExperimentationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateRandomResultTables
// Size: 0x60(Inherited: 0x0) 
struct FUpdateRandomResultTables
{
	struct FAdminUpdateRandomResultTablesRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.GetTasks
// Size: 0x40(Inherited: 0x0) 
struct FGetTasks
{
	struct FAdminGetTasksRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.CreateSharedGroup
// Size: 0x48(Inherited: 0x0) 
struct FCreateSharedGroup
{
	struct FServerCreateSharedGroupRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperPayForPurchase
// Size: 0x50(Inherited: 0x0) 
struct FHelperPayForPurchase
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerTags__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerTags__DelegateSignature
{
	struct FServerGetPlayerTagsResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPublisherData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPublisherData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetCharacterStatistics
// Size: 0x58(Inherited: 0x0) 
struct FGetCharacterStatistics
{
	struct FServerGetCharacterStatisticsRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPublisherDataResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminGetPublisherDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerTagsResult
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetPlayerTagsResult : public FPlayFabResultCommon
{
	struct FString PlayFabId;  // 0x8(0x10)
	struct FString Tags;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.AdminRevokeBansResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminRevokeBansResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.LocalizationGetLanguageListResponse
// Size: 0x18(Inherited: 0x8) 
struct FLocalizationGetLanguageListResponse : public FPlayFabResultCommon
{
	struct FString LanguageList;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPolicy__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetPolicy__DelegateSignature
{
	struct FAdminGetPolicyResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPolicyResponse
// Size: 0x30(Inherited: 0x8) 
struct FAdminGetPolicyResponse : public FPlayFabResultCommon
{
	struct FString PolicyName;  // 0x8(0x10)
	int32_t PolicyVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct UPlayFabJsonObject*> Statements;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerProfileRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientGetPlayerProfileRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerLobbyEmptyResult
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerLobbyEmptyResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPublisherData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetPublisherData__DelegateSignature
{
	struct FServerGetPublisherDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerSendPushNotificationResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSendPushNotificationResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminGetRandomResultTablesResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminGetRandomResultTablesResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Tables;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkSteamAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkSteamAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString SteamTicket;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetSegmentExport__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetSegmentExport__DelegateSignature
{
	struct FAdminGetPlayersInSegmentExportResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperAddNews
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddNews
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetPlayersInSegmentExportResponse
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetPlayersInSegmentExportResponse : public FPlayFabResultCommon
{
	struct FString IndexUrl;  // 0x8(0x10)
	struct FString State;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetSegments__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetSegments__DelegateSignature
{
	struct FAdminGetSegmentsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LinkGameCenterAccount
// Size: 0x98(Inherited: 0x0) 
struct FLinkGameCenterAccount
{
	struct FClientLinkGameCenterAccountRequest Request;  // 0x0(0x68)
	struct FDelegate onSuccess;  // 0x68(0x10)
	struct FDelegate onFailure;  // 0x78(0x10)
	struct UObject* customData;  // 0x88(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x90(0x8)

}; 
// ScriptStruct PlayFab.AdminGetSegmentsResponse
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetSegmentsResponse : public FPlayFabResultCommon
{
	struct FString ErrorMessage;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Segments;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.RevokeBans
// Size: 0x48(Inherited: 0x0) 
struct FRevokeBans
{
	struct FServerRevokeBansRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithAndroidDeviceID
// Size: 0xA0(Inherited: 0x0) 
struct FLoginWithAndroidDeviceID
{
	struct FClientLoginWithAndroidDeviceIDRequest Request;  // 0x0(0x70)
	struct FDelegate onSuccess;  // 0x70(0x10)
	struct FDelegate onFailure;  // 0x80(0x10)
	struct UObject* customData;  // 0x90(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x98(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetStoreItems__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FDelegateOnSuccessGetStoreItems__DelegateSignature
{
	struct FServerGetStoreItemsResult Result;  // 0x0(0x48)
	struct UObject* customData;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.AdminGetStoreItemsResult
// Size: 0x48(Inherited: 0x8) 
struct FAdminGetStoreItemsResult : public FPlayFabResultCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* MarketingData;  // 0x18(0x8)
	uint8_t  Source;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct UPlayFabJsonObject*> Store;  // 0x28(0x10)
	struct FString StoreId;  // 0x38(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTitleInternalData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitleInternalData__DelegateSignature
{
	struct FServerGetTitleDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetPhotonAuthenticationToken
// Size: 0x48(Inherited: 0x0) 
struct FGetPhotonAuthenticationToken
{
	struct FClientGetPhotonAuthenticationTokenRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientGetAccountInfoRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientGetAccountInfoRequest : public FPlayFabRequestCommon
{
	struct FString Email;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString TitleDisplayName;  // 0x28(0x10)
	struct FString Username;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateServerMatchmakingTicket
// Size: 0x68(Inherited: 0x0) 
struct FCreateServerMatchmakingTicket
{
	struct FMultiplayerCreateServerMatchmakingTicketRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessCreateExperiment__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateExperiment__DelegateSignature
{
	struct FExperimentationCreateExperimentResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetTaskInstances__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetTaskInstances__DelegateSignature
{
	struct FAdminGetTaskInstancesResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationUpdateExclusionGroupRequest
// Size: 0x40(Inherited: 0x8) 
struct FExperimentationUpdateExclusionGroupRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	struct FString ExclusionGroupId;  // 0x20(0x10)
	struct FString Name;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerUpdateBuildAliasRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerUpdateBuildAliasRequest : public FPlayFabRequestCommon
{
	struct FString AliasId;  // 0x8(0x10)
	struct FString AliasName;  // 0x18(0x10)
	struct TArray<struct UPlayFabJsonObject*> BuildSelectionCriteria;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserInternalData
// Size: 0x60(Inherited: 0x0) 
struct FGetUserInternalData
{
	struct FServerGetUserDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetTasks__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetTasks__DelegateSignature
{
	struct FAdminGetTasksResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminGetTasksResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetTasksResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Tasks;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientAcceptTradeResponse
// Size: 0x10(Inherited: 0x8) 
struct FClientAcceptTradeResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Trade;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGameServerRegionsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGameServerRegionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Regions;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTitleData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitleData__DelegateSignature
{
	struct FServerGetTitleDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkGameCenterAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkGameCenterAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsRequest : public FPlayFabRequestCommon
{
	struct FString GooglePlayGamesPlayerIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminGetTitleDataResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminGetTitleDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCharacterStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCharacterStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumePS5Entitlements__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessConsumePS5Entitlements__DelegateSignature
{
	struct FClientConsumePS5EntitlementsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetCloudScriptTaskInstance
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCloudScriptTaskInstance
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetTaskInstanceRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetTaskInstanceRequest : public FPlayFabRequestCommon
{
	struct FString TaskInstanceId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayerStatistics
// Size: 0x70(Inherited: 0x0) 
struct FGetPlayerStatistics
{
	struct FServerGetPlayerStatisticsRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientReportAdActivityResult
// Size: 0x8(Inherited: 0x8) 
struct FClientReportAdActivityResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminSetTitleDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminSetTitleDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetQueueStatistics
// Size: 0x50(Inherited: 0x0) 
struct FGetQueueStatistics
{
	struct FMultiplayerGetQueueStatisticsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetTitlePublicKeyResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetTitlePublicKeyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetTitlePublicKeyResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserAccountInfo__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserAccountInfo__DelegateSignature
{
	struct FServerGetUserAccountInfoResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.ExportPlayersInSegment
// Size: 0x48(Inherited: 0x0) 
struct FExportPlayersInSegment
{
	struct FAdminExportPlayersInSegmentRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminLookupUserAccountInfoResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminLookupUserAccountInfoResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* UserInfo;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserBans__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserBans__DelegateSignature
{
	struct FServerGetUserBansResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAttributeInstall__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAttributeInstall__DelegateSignature
{
	struct FClientAttributeInstallResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGetUserDataResult
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetUserDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)
	int32_t DataVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithSteam__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithSteam__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserInternalData__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserInternalData__DelegateSignature
{
	struct FServerGetUserDataResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateRemoteUserResponse
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerCreateRemoteUserResponse : public FPlayFabResultCommon
{
	struct FString ExpirationTime;  // 0x8(0x10)
	struct FString Password;  // 0x18(0x10)
	struct FString Username;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.AdminGetUserInventoryResult
// Size: 0x38(Inherited: 0x8) 
struct FAdminGetUserInventoryResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Inventory;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x28(0x8)
	struct UPlayFabJsonObject* VirtualCurrencyRechargeTimes;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdatePlayerSharedSecretResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminUpdatePlayerSharedSecretResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerDeleteSharedGroupRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerDeleteSharedGroupRequest : public FPlayFabRequestCommon
{
	struct FString SharedGroupId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserPublisherData__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserPublisherData__DelegateSignature
{
	struct FServerGetUserDataResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.GroupsListGroupMembersResponse
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupMembersResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.EconomyDeleteEntityItemReviewsResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyDeleteEntityItemReviewsResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.GetTime
// Size: 0x38(Inherited: 0x0) 
struct FGetTime
{
	struct FServerGetTimeRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.GetPlayerIdFromAuthToken
// Size: 0x50(Inherited: 0x0) 
struct FGetPlayerIdFromAuthToken
{
	struct FAdminGetPlayerIdFromAuthTokenRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdatePolicy
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdatePolicy
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.GetPlayerStatisticDefinitions
// Size: 0x38(Inherited: 0x0) 
struct FGetPlayerStatisticDefinitions
{
	struct FAdminGetPlayerStatisticDefinitionsRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.ClientRestoreIOSPurchasesResult
// Size: 0x18(Inherited: 0x8) 
struct FClientRestoreIOSPurchasesResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Fulfillments;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature
{
	struct FServerGetUserDataResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeEvaluateRandomResultTableResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeEvaluateRandomResultTableResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerEvaluateRandomResultTableResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserReadOnlyData__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetUserReadOnlyData__DelegateSignature
{
	struct FServerGetUserDataResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkAndroidDeviceIDRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkAndroidDeviceIDRequest : public FPlayFabRequestCommon
{
	struct FString AndroidDeviceId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantItemsToUsers__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGrantItemsToUsers__DelegateSignature
{
	struct FServerGrantItemsToUsersResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteLobby__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteLobby__DelegateSignature
{
	struct FMultiplayerLobbyEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetBuildResponse
// Size: 0x108(Inherited: 0x8) 
struct FMultiplayerGetBuildResponse : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildId;  // 0x10(0x10)
	struct FString BuildName;  // 0x20(0x10)
	struct FString BuildStatus;  // 0x30(0x10)
	uint8_t  ContainerFlavor;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString ContainerRunCommand;  // 0x48(0x10)
	struct FString CreationTime;  // 0x58(0x10)
	struct UPlayFabJsonObject* CustomGameContainerImage;  // 0x68(0x8)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x70(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x80(0x10)
	struct UPlayFabJsonObject* InstrumentationConfiguration;  // 0x90(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x98(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FString OsPlatform;  // 0xA8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0xB8(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0xC8(0x10)
	struct UPlayFabJsonObject* ServerResourceConstraints;  // 0xD8(0x8)
	struct FString ServerType;  // 0xE0(0x10)
	struct FString StartMultiplayerServerCommand;  // 0xF0(0x10)
	uint8_t  VmSize;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetServerCustomIDsFromPlayFabIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetServerCustomIDsFromPlayFabIDs
{
	struct FServerGetServerCustomIDsFromPlayFabIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.RemovePlayerTag
// Size: 0x60(Inherited: 0x0) 
struct FRemovePlayerTag
{
	struct FServerRemovePlayerTagRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientGrantCharacterToUserResult
// Size: 0x30(Inherited: 0x8) 
struct FClientGrantCharacterToUserResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString CharacterType;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Result : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessIncrementLimitedEditionItemAvailability__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessIncrementLimitedEditionItemAvailability__DelegateSignature
{
	struct FAdminIncrementLimitedEditionItemAvailabilityResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateUserTitleDisplayNameResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminUpdateUserTitleDisplayNameResult : public FPlayFabResultCommon
{
	struct FString DisplayName;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperLeaveLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperLeaveLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminIncrementLimitedEditionItemAvailabilityResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminIncrementLimitedEditionItemAvailabilityResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessWriteCharacterEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessWriteCharacterEvent__DelegateSignature
{
	struct FServerWriteEventResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetSharedGroupDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetSharedGroupDataRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool GetMembers : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Keys;  // 0x10(0x10)
	struct FString SharedGroupId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateCatalogItems
// Size: 0x68(Inherited: 0x0) 
struct FUpdateCatalogItems
{
	struct FAdminUpdateCatalogItemsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessIncrementPlayerStatisticVersion__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessIncrementPlayerStatisticVersion__DelegateSignature
{
	struct FAdminIncrementPlayerStatisticVersionResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.AdminSetMembershipOverrideResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSetMembershipOverrideResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessBlockEntity__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessBlockEntity__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerCombinedInfo__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerCombinedInfo__DelegateSignature
{
	struct FServerGetPlayerCombinedInfoResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.EconomyDeleteItemResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyDeleteItemResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeMoveItemToUserFromCharacterResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeMoveItemToUserFromCharacterResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerMoveItemToUserFromCharacterResult ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessListOpenIdConnection__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListOpenIdConnection__DelegateSignature
{
	struct FAdminListOpenIdConnectionResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperDeleteSharedGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteSharedGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteAsset
// Size: 0x50(Inherited: 0x0) 
struct FDeleteAsset
{
	struct FMultiplayerDeleteAssetRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.AdminListOpenIdConnectionResponse
// Size: 0x18(Inherited: 0x8) 
struct FAdminListOpenIdConnectionResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Connections;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminUpdateCloudScriptResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminUpdateCloudScriptResult : public FPlayFabResultCommon
{
	int32_t Revision;  // 0x8(0x4)
	int32_t Version;  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.AdminResetUserStatisticsRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminResetUserStatisticsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdatePlayerStatisticDefinition
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdatePlayerStatisticDefinition
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ExperimentationGetExclusionGroupsRequest
// Size: 0x10(Inherited: 0x8) 
struct FExperimentationGetExclusionGroupsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.GroupsRemoveGroupInvitationRequest
// Size: 0x20(Inherited: 0x8) 
struct FGroupsRemoveGroupInvitationRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessListVirtualCurrencyTypes__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListVirtualCurrencyTypes__DelegateSignature
{
	struct FAdminListVirtualCurrencyTypesResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminSetPlayerSecretResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSetPlayerSecretResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminListVirtualCurrencyTypesResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminListVirtualCurrencyTypesResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> VirtualCurrencies;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateBans__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateBans__DelegateSignature
{
	struct FServerUpdateBansResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.IncrementLimitedEditionItemAvailability
// Size: 0x68(Inherited: 0x0) 
struct FIncrementLimitedEditionItemAvailability
{
	struct FAdminIncrementLimitedEditionItemAvailabilityRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationUpdateExperimentRequest
// Size: 0xA8(Inherited: 0x8) 
struct FExperimentationUpdateExperimentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	struct FString EndDate;  // 0x20(0x10)
	struct FString ExclusionGroupId;  // 0x30(0x10)
	int32_t ExclusionGroupTrafficAllocation;  // 0x40(0x4)
	uint8_t  ExperimentType;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FString ID;  // 0x48(0x10)
	struct FString Name;  // 0x58(0x10)
	struct FString SegmentId;  // 0x68(0x10)
	struct FString StartDate;  // 0x78(0x10)
	struct FString TitlePlayerAccountTestIds;  // 0x88(0x10)
	struct TArray<struct UPlayFabJsonObject*> Variants;  // 0x98(0x10)

}; 
// ScriptStruct PlayFab.MatchmakerUserInfoResponse
// Size: 0x70(Inherited: 0x8) 
struct FMatchmakerUserInfoResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Inventory;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool IsDeveloper : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString PlayFabId;  // 0x20(0x10)
	struct FString SteamID;  // 0x30(0x10)
	struct FString TitleDisplayName;  // 0x40(0x10)
	struct FString Username;  // 0x50(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x60(0x8)
	struct UPlayFabJsonObject* VirtualCurrencyRechargeTimes;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.GetMatchmakerGameModes
// Size: 0x48(Inherited: 0x0) 
struct FGetMatchmakerGameModes
{
	struct FAdminGetMatchmakerGameModesRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessModifyServerBuild__DelegateSignature
// Size: 0x90(Inherited: 0x0) 
struct FDelegateOnSuccessModifyServerBuild__DelegateSignature
{
	struct FAdminModifyServerBuildResult Result;  // 0x0(0x88)
	struct UObject* customData;  // 0x88(0x8)

}; 
// ScriptStruct PlayFab.AdminGetAllSegmentsRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminGetAllSegmentsRequest : public FPlayFabRequestCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetCloudScriptVersions
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCloudScriptVersions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperDeleteCharacterFromUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteCharacterFromUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminModifyServerBuildResult
// Size: 0x88(Inherited: 0x8) 
struct FAdminModifyServerBuildResult : public FPlayFabResultCommon
{
	struct FString ActiveRegions;  // 0x8(0x10)
	struct FString BuildId;  // 0x18(0x10)
	struct FString CommandLineTemplate;  // 0x28(0x10)
	struct FString Comment;  // 0x38(0x10)
	struct FString ExecutablePath;  // 0x48(0x10)
	int32_t MaxGamesPerHost;  // 0x58(0x4)
	int32_t MinFreeGameSlots;  // 0x5C(0x4)
	uint8_t  Status;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString Timestamp;  // 0x68(0x10)
	struct FString TitleId;  // 0x78(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetContentList
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetContentList
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRefundPurchase__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRefundPurchase__DelegateSignature
{
	struct FAdminRefundPurchaseResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientConsumeMicrosoftStoreEntitlementsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientConsumeMicrosoftStoreEntitlementsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* MarketplaceSpecificData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientAndroidDevicePushNotificationRegistrationRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientAndroidDevicePushNotificationRegistrationRequest : public FPlayFabRequestCommon
{
	struct FString ConfirmationMessage;  // 0x8(0x10)
	struct FString DeviceToken;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool SendPushNotificationConfirmation : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkSteamAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkSteamAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLinkNintendoServiceAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkNintendoServiceAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString IdentityToken;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemovePlayerTag__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemovePlayerTag__DelegateSignature
{
	struct FServerRemovePlayerTagResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGrantItemsToUsersRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminGrantItemsToUsersRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct TArray<struct UPlayFabJsonObject*> ItemGrants;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.CloudScriptGetFunctionResult
// Size: 0x48(Inherited: 0x8) 
struct FCloudScriptGetFunctionResult : public FPlayFabResultCommon
{
	struct FString ConnectionString;  // 0x8(0x10)
	struct FString FunctionUrl;  // 0x18(0x10)
	struct FString QueueName;  // 0x28(0x10)
	struct FString TriggerType;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.AdminRemovePlayerTagResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminRemovePlayerTagResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetTaskInstances
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTaskInstances
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminResetCharacterStatisticsResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminResetCharacterStatisticsResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabClientAPI.HelperMatchmake
// Size: 0x50(Inherited: 0x0) 
struct FHelperMatchmake
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerGetMultiplayerServerLogsRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetMultiplayerServerLogsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ServerId;  // 0x10(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserInventoryItemCustomData__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserInventoryItemCustomData__DelegateSignature
{
	struct FServerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResetPassword__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessResetPassword__DelegateSignature
{
	struct FAdminResetPasswordResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetContainerRegistryCredentials
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetContainerRegistryCredentials
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListBuildAliases
// Size: 0x50(Inherited: 0x0) 
struct FHelperListBuildAliases
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListBuildAliasesResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListBuildAliasesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListBuildAliasesResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserPublisherReadOnlyData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserPublisherReadOnlyData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListVirtualMachineSummaries
// Size: 0x50(Inherited: 0x0) 
struct FHelperListVirtualMachineSummaries
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminResetPasswordResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminResetPasswordResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientGetTitleNewsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetTitleNewsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> News;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminGetCatalogItemsRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetCatalogItemsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithEmailAddress
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithEmailAddress
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResetUserStatistics__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessResetUserStatistics__DelegateSignature
{
	struct FAdminResetUserStatisticsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAuthenticationAPI.Delete
// Size: 0x48(Inherited: 0x0) 
struct FDelete
{
	struct FAuthenticationDeleteRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAuthenticationAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminGetUserBansRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetUserBansRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperRemoveGroupApplication
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveGroupApplication
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminResetUserStatisticsResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminResetUserStatisticsResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientGetUserDataResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetUserDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)
	int32_t DataVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct PlayFab.ClientUpdateUserTitleDisplayNameRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUpdateUserTitleDisplayNameRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DisplayName;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithNintendoSwitchDeviceId
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithNintendoSwitchDeviceId
{
	struct FClientLoginWithNintendoSwitchDeviceIdRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResolvePurchaseDispute__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessResolvePurchaseDispute__DelegateSignature
{
	struct FAdminResolvePurchaseDisputeResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetCloudScriptVersionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetCloudScriptVersionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetCloudScriptVersionsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientSetFriendTagsResult
// Size: 0x8(Inherited: 0x8) 
struct FClientSetFriendTagsResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminGetMatchmakerGameInfoRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetMatchmakerGameInfoRequest : public FPlayFabRequestCommon
{
	struct FString LobbyId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminResolvePurchaseDisputeResponse
// Size: 0x18(Inherited: 0x8) 
struct FAdminResolvePurchaseDisputeResponse : public FPlayFabResultCommon
{
	struct FString PurchaseStatus;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeAllBansForUser__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRevokeAllBansForUser__DelegateSignature
{
	struct FServerRevokeAllBansForUserResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessReportItem__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessReportItem__DelegateSignature
{
	struct FEconomyReportItemResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperAndroidDevicePushNotificationRegistration
// Size: 0x50(Inherited: 0x0) 
struct FHelperAndroidDevicePushNotificationRegistration
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminRevokeAllBansForUserResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminRevokeAllBansForUserResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerJoinLobbyResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerJoinLobbyResult : public FPlayFabResultCommon
{
	struct FString LobbyId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientModifyUserVirtualCurrencyResult
// Size: 0x30(Inherited: 0x8) 
struct FClientModifyUserVirtualCurrencyResult : public FPlayFabResultCommon
{
	int32_t Balance;  // 0x8(0x4)
	int32_t BalanceChange;  // 0xC(0x4)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString VirtualCurrency;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeBans__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRevokeBans__DelegateSignature
{
	struct FServerRevokeBansResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabInsightsAPI.HelperGetLimits
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLimits
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetActionsOnPlayersInSegmentTaskInstance
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetActionsOnPlayersInSegmentTaskInstance
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperListVirtualCurrencyTypes
// Size: 0x50(Inherited: 0x0) 
struct FHelperListVirtualCurrencyTypes
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLinkOpenIdConnectRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientLinkOpenIdConnectRequest : public FPlayFabRequestCommon
{
	struct FString ConnectionId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString IdToken;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeMatchmakeResultResponse
// Size: 0x88(Inherited: 0x0) 
struct FdecodeMatchmakeResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientMatchmakeResult ReturnValue;  // 0x8(0x80)

}; 
// Function PlayFab.PlayFabServerAPI.GetCharacterReadOnlyData
// Size: 0x70(Inherited: 0x0) 
struct FGetCharacterReadOnlyData
{
	struct FServerGetCharacterDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeInventoryItem__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRevokeInventoryItem__DelegateSignature
{
	struct FServerRevokeInventoryResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminRevokeInventoryItemsResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminRevokeInventoryItemsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Errors;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerFindFriendLobbiesRequest
// Size: 0x50(Inherited: 0x8) 
struct FMultiplayerFindFriendLobbiesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ExcludeFacebookFriends : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ExcludeSteamFriends : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FString Filter;  // 0x18(0x10)
	struct FString OrderBy;  // 0x28(0x10)
	struct UPlayFabJsonObject* Pagination;  // 0x38(0x8)
	struct FString XboxToken;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkCustomIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkCustomIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkCustomIDResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.GroupsCreateGroupRoleRequest
// Size: 0x38(Inherited: 0x8) 
struct FGroupsCreateGroupRoleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)
	struct FString RoleId;  // 0x18(0x10)
	struct FString RoleName;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRunTask__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRunTask__DelegateSignature
{
	struct FAdminRunTaskResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessDeleteEntityItemReviews__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteEntityItemReviews__DelegateSignature
{
	struct FEconomyDeleteEntityItemReviewsResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUnlockContainerItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlockContainerItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetQueueStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetQueueStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromKongregateIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromKongregateIDs__DelegateSignature
{
	struct FClientGetPlayFabIDsFromKongregateIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessAbortFileUploads__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessAbortFileUploads__DelegateSignature
{
	struct FDataAbortFileUploadsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRevokeInventoryResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRevokeInventoryResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRevokeInventoryResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserPublisherData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserPublisherData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminRunTaskResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminRunTaskResult : public FPlayFabResultCommon
{
	struct FString TaskInstanceId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabUtilities.getPhotonAppId
// Size: 0x18(Inherited: 0x0) 
struct FgetPhotonAppId
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Realtime : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Chat : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Turnbased : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessSendAccountRecoveryEmail__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSendAccountRecoveryEmail__DelegateSignature
{
	struct FClientSendAccountRecoveryEmailResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeJoinLobbyResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeJoinLobbyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerJoinLobbyResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromGenericIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromGenericIDsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> GenericIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.EconomyTakedownItemReviewsRequest
// Size: 0x20(Inherited: 0x8) 
struct FEconomyTakedownItemReviewsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct TArray<struct UPlayFabJsonObject*> Reviews;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.AdminSendAccountRecoveryEmailResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSendAccountRecoveryEmailResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperCreateDraftItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateDraftItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetCatalogItems__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetCatalogItems__DelegateSignature
{
	struct FAdminUpdateCatalogItemsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardForUsersCharactersResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetLeaderboardForUsersCharactersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminUpdateCatalogItemsResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminUpdateCatalogItemsResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.GetUserBans
// Size: 0x48(Inherited: 0x0) 
struct FGetUserBans
{
	struct FServerGetUserBansRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetPublishedRevision__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetPublishedRevision__DelegateSignature
{
	struct FAdminSetPublishedRevisionResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetPublisherData__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetPublisherData__DelegateSignature
{
	struct FServerSetPublisherDataResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAwardSteamAchievement
// Size: 0x50(Inherited: 0x0) 
struct FHelperAwardSteamAchievement
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminSetPublisherDataResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSetPublisherDataResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterLeaderboard__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetCharacterLeaderboard__DelegateSignature
{
	struct FServerGetCharacterLeaderboardResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperRequestMultiplayerServer
// Size: 0x50(Inherited: 0x0) 
struct FHelperRequestMultiplayerServer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetTitleDataRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetTitleDataRequest : public FPlayFabRequestCommon
{
	struct FString Keys;  // 0x8(0x10)
	struct FString OverrideLabel;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetCurrentGames
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCurrentGames
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkApple__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkApple__DelegateSignature
{
	struct FClientEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateStoreItemsResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminUpdateStoreItemsResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerGetPlayerStatisticsRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGetPlayerStatisticsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString StatisticNames;  // 0x20(0x10)
	struct TArray<struct UPlayFabJsonObject*> StatisticNameVersions;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.AdminGetPlayersInSegmentExportRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayersInSegmentExportRequest : public FPlayFabRequestCommon
{
	struct FString ExportId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromGenericIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromGenericIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabEventsAPI.DelegateOnSuccessWriteEvents__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessWriteEvents__DelegateSignature
{
	struct FEventsWriteEventsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SetGameServerInstanceData
// Size: 0x58(Inherited: 0x0) 
struct FSetGameServerInstanceData
{
	struct FServerSetGameServerInstanceDataRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.EconomyReportItemReviewRequest
// Size: 0x58(Inherited: 0x8) 
struct FEconomyReportItemReviewRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	uint8_t  ConcernCategory;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x20(0x8)
	struct FString ItemId;  // 0x28(0x10)
	struct FString Reason;  // 0x38(0x10)
	struct FString ReviewId;  // 0x48(0x10)

}; 
// ScriptStruct PlayFab.AdminDeleteMembershipSubscriptionRequest
// Size: 0x40(Inherited: 0x8) 
struct FAdminDeleteMembershipSubscriptionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString MembershipId;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)
	struct FString SubscriptionId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerLoginWithXboxRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerLoginWithXboxRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x18(0x8)
	struct FString XboxToken;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetContentDownloadUrl
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetContentDownloadUrl
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithPSN__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithPSN__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetTitleData__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetTitleData__DelegateSignature
{
	struct FServerSetTitleDataResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGameCenterIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromGameCenterIDs__DelegateSignature
{
	struct FClientGetPlayFabIDsFromGameCenterIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGooglePlayGamesPlayerIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromGooglePlayGamesPlayerIDs__DelegateSignature
{
	struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardForUsersCharactersRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetLeaderboardForUsersCharactersRequest : public FPlayFabRequestCommon
{
	struct FString StatisticName;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminUpdateCatalogItemsRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminUpdateCatalogItemsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Catalog;  // 0x8(0x10)
	struct FString CatalogVersion;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool SetAsDefaultCatalog : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct PlayFab.AdminSetTitleDataResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSetTitleDataResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteMembershipSubscriptionResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteMembershipSubscriptionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeleteMembershipSubscriptionResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UnlinkServerCustomId
// Size: 0x60(Inherited: 0x0) 
struct FUnlinkServerCustomId
{
	struct FServerUnlinkServerCustomIdRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUploadCertificate
// Size: 0x50(Inherited: 0x0) 
struct FHelperUploadCertificate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayerProfile
// Size: 0x58(Inherited: 0x0) 
struct FGetPlayerProfile
{
	struct FServerGetPlayerProfileRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetTitleDataAndOverrides__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetTitleDataAndOverrides__DelegateSignature
{
	struct FAdminSetTitleDataAndOverridesResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyReviewItemRequest
// Size: 0x38(Inherited: 0x8) 
struct FEconomyReviewItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ID;  // 0x20(0x10)
	struct UPlayFabJsonObject* Review;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayerTags
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerTags
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerEmptyResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAuthenticationAPI.HelperValidateEntityToken
// Size: 0x50(Inherited: 0x0) 
struct FHelperValidateEntityToken
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerCreateSharedGroupRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerCreateSharedGroupRequest : public FPlayFabRequestCommon
{
	struct FString SharedGroupId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminSetTitleDataAndOverridesResult
// Size: 0x8(Inherited: 0x8) 
struct FAdminSetTitleDataAndOverridesResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.IncrementPlayerStatisticVersion
// Size: 0x50(Inherited: 0x0) 
struct FIncrementPlayerStatisticVersion
{
	struct FAdminIncrementPlayerStatisticVersionRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetTitleInternalData__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetTitleInternalData__DelegateSignature
{
	struct FServerSetTitleDataResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetupPushNotification__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessSetupPushNotification__DelegateSignature
{
	struct FAdminSetupPushNotificationResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreateInsightsScheduledScalingTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateInsightsScheduledScalingTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminSetupPushNotificationResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminSetupPushNotificationResult : public FPlayFabResultCommon
{
	struct FString ARN;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ExperimentationCreateExclusionGroupRequest
// Size: 0x30(Inherited: 0x8) 
struct FExperimentationCreateExclusionGroupRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	struct FString Name;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientGetCharacterInventoryRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetCharacterInventoryRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkOpenIdConnect__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkOpenIdConnect__DelegateSignature
{
	struct FClientEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptPostFunctionResultForPlayerTriggeredActionRequest
// Size: 0x30(Inherited: 0x8) 
struct FCloudScriptPostFunctionResultForPlayerTriggeredActionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* FunctionResult;  // 0x18(0x8)
	struct UPlayFabJsonObject* PlayerProfile;  // 0x20(0x8)
	struct UPlayFabJsonObject* PlayStreamEventEnvelope;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature
{
	struct FServerModifyUserVirtualCurrencyResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminListOpenIdConnectionRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminListOpenIdConnectionRequest : public FPlayFabRequestCommon
{

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperSetProfileLanguage
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetProfileLanguage
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminUpdateBansResult
// Size: 0x18(Inherited: 0x8) 
struct FAdminUpdateBansResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateCatalogItems__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCatalogItems__DelegateSignature
{
	struct FAdminUpdateCatalogItemsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerModifyCharacterVirtualCurrencyResult
// Size: 0x20(Inherited: 0x8) 
struct FServerModifyCharacterVirtualCurrencyResult : public FPlayFabResultCommon
{
	int32_t Balance;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString VirtualCurrency;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromPSNAccountIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromPSNAccountIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetTreatmentAssignment__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTreatmentAssignment__DelegateSignature
{
	struct FExperimentationGetTreatmentAssignmentResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateCloudScript__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCloudScript__DelegateSignature
{
	struct FAdminUpdateCloudScriptResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerUpdatePlayerStatisticsResult
// Size: 0x8(Inherited: 0x8) 
struct FServerUpdatePlayerStatisticsResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.MultiplayerListBuildSummariesResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListBuildSummariesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BuildSummaries;  // 0x8(0x10)
	int32_t PageSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromSteamIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromSteamIDs__DelegateSignature
{
	struct FServerGetPlayFabIDsFromSteamIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteTitleDataOverride
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteTitleDataOverride
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithGoogleAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithGoogleAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.HelperAuthUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperAuthUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdatePlayerSharedSecret__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdatePlayerSharedSecret__DelegateSignature
{
	struct FAdminUpdatePlayerSharedSecretResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGetCloudScriptVersionsRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminGetCloudScriptVersionsRequest : public FPlayFabRequestCommon
{

}; 
// ScriptStruct PlayFab.AdminUpdatePlayerStatisticDefinitionResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminUpdatePlayerStatisticDefinitionResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Statistic;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdatePolicy__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessUpdatePolicy__DelegateSignature
{
	struct FAdminUpdatePolicyResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ServerModifyUserVirtualCurrencyResult
// Size: 0x30(Inherited: 0x8) 
struct FServerModifyUserVirtualCurrencyResult : public FPlayFabResultCommon
{
	int32_t Balance;  // 0x8(0x4)
	int32_t BalanceChange;  // 0xC(0x4)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString VirtualCurrency;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserData
// Size: 0x60(Inherited: 0x0) 
struct FGetUserData
{
	struct FServerGetUserDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdatePolicyResponse
// Size: 0x28(Inherited: 0x8) 
struct FAdminUpdatePolicyResponse : public FPlayFabResultCommon
{
	struct FString PolicyName;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Statements;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientCurrentGamesRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientCurrentGamesRequest : public FPlayFabRequestCommon
{
	struct FString BuildVersion;  // 0x8(0x10)
	struct FString GameMode;  // 0x18(0x10)
	uint8_t  Region;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString StatisticName;  // 0x30(0x10)
	struct UPlayFabJsonObject* TagFilter;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetSharedGroupData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetSharedGroupData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.DeregisterGame
// Size: 0x50(Inherited: 0x0) 
struct FDeregisterGame
{
	struct FServerDeregisterGameRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateRandomResultTables__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateRandomResultTables__DelegateSignature
{
	struct FAdminUpdateRandomResultTablesResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetDetails__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FDelegateOnSuccessGetDetails__DelegateSignature
{
	struct FInsightsInsightsGetDetailsResponse Result;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientGetTradeStatusRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientGetTradeStatusRequest : public FPlayFabRequestCommon
{
	struct FString OfferingPlayerId;  // 0x8(0x10)
	struct FString TradeId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreatePlayerSharedSecret
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreatePlayerSharedSecret
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateSegment__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateSegment__DelegateSignature
{
	struct FAdminUpdateSegmentResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabLocalizationAPI.DelegateOnSuccessGetLanguageList__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetLanguageList__DelegateSignature
{
	struct FLocalizationGetLanguageListResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateSegmentResponse
// Size: 0x28(Inherited: 0x8) 
struct FAdminUpdateSegmentResponse : public FPlayFabResultCommon
{
	struct FString ErrorMessage;  // 0x8(0x10)
	struct FString SegmentId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.AdminSendAccountRecoveryEmailRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminSendAccountRecoveryEmailRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Email;  // 0x10(0x10)
	struct FString EmailTemplateId;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateStoreItems__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateStoreItems__DelegateSignature
{
	struct FAdminUpdateStoreItemsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientAddUsernamePasswordResult
// Size: 0x18(Inherited: 0x8) 
struct FClientAddUsernamePasswordResult : public FPlayFabResultCommon
{
	struct FString Username;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateTask__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateTask__DelegateSignature
{
	struct FAdminEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessFinalizeFileUploads__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessFinalizeFileUploads__DelegateSignature
{
	struct FDataFinalizeFileUploadsResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayerCombinedInfo
// Size: 0x58(Inherited: 0x0) 
struct FGetPlayerCombinedInfo
{
	struct FServerGetPlayerCombinedInfoRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserData__DelegateSignature
{
	struct FServerUpdateUserDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateUserDataResult
// Size: 0x10(Inherited: 0x8) 
struct FAdminUpdateUserDataResult : public FPlayFabResultCommon
{
	int32_t DataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCharacterData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserInternalData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserInternalData__DelegateSignature
{
	struct FServerUpdateUserDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperAcceptGroupApplication
// Size: 0x50(Inherited: 0x0) 
struct FHelperAcceptGroupApplication
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGrantItemsToUserResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGrantItemsToUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGrantItemsToUserResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserPublisherData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserPublisherData__DelegateSignature
{
	struct FServerUpdateUserDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.GroupsCreateGroupRoleResponse
// Size: 0x30(Inherited: 0x8) 
struct FGroupsCreateGroupRoleResponse : public FPlayFabResultCommon
{
	int32_t ProfileVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString RoleId;  // 0x10(0x10)
	struct FString RoleName;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserReadOnlyData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserReadOnlyData__DelegateSignature
{
	struct FServerUpdateUserDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateUserTitleDisplayName__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateUserTitleDisplayName__DelegateSignature
{
	struct FClientUpdateUserTitleDisplayNameResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetTimeRequest
// Size: 0x8(Inherited: 0x8) 
struct FClientGetTimeRequest : public FPlayFabRequestCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteStore
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteStore
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteContent
// Size: 0x48(Inherited: 0x0) 
struct FDeleteContent
{
	struct FAdminDeleteContentRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteContentRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeleteContentRequest : public FPlayFabRequestCommon
{
	struct FString Key;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForPlayerTriggeredAction
// Size: 0x50(Inherited: 0x0) 
struct FHelperPostFunctionResultForPlayerTriggeredAction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerRolloverContainerRegistryCredentialsResponse
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerRolloverContainerRegistryCredentialsResponse : public FPlayFabResultCommon
{
	struct FString DnsName;  // 0x8(0x10)
	struct FString Password;  // 0x18(0x10)
	struct FString Username;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRevokeInventoryItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperRevokeInventoryItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.EconomyCreateUploadUrlsRequest
// Size: 0x20(Inherited: 0x8) 
struct FEconomyCreateUploadUrlsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct TArray<struct UPlayFabJsonObject*> Files;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperChangeMemberRole
// Size: 0x50(Inherited: 0x0) 
struct FHelperChangeMemberRole
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetBuildAlias
// Size: 0x50(Inherited: 0x0) 
struct FGetBuildAlias
{
	struct FMultiplayerGetBuildAliasRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetTitleData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitleData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.AddGenericID
// Size: 0x50(Inherited: 0x0) 
struct FAddGenericID
{
	struct FServerAddGenericIDRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteMasterPlayerAccount
// Size: 0x58(Inherited: 0x0) 
struct FDeleteMasterPlayerAccount
{
	struct FAdminDeleteMasterPlayerAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.DataAbortFileUploadsRequest
// Size: 0x30(Inherited: 0x8) 
struct FDataAbortFileUploadsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString FileNames;  // 0x18(0x10)
	int32_t ProfileVersion;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct PlayFab.ClientUnlockContainerItemResult
// Size: 0x40(Inherited: 0x8) 
struct FClientUnlockContainerItemResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> GrantedItems;  // 0x8(0x10)
	struct FString UnlockedItemInstanceId;  // 0x18(0x10)
	struct FString UnlockedWithItemInstanceId;  // 0x28(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.JoinArrangedLobby
// Size: 0x78(Inherited: 0x0) 
struct FJoinArrangedLobby
{
	struct FMultiplayerJoinArrangedLobbyRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteMembershipSubscription
// Size: 0x70(Inherited: 0x0) 
struct FDeleteMembershipSubscription
{
	struct FAdminDeleteMembershipSubscriptionRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteOpenIdConnectionRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeleteOpenIdConnectionRequest : public FPlayFabRequestCommon
{
	struct FString ConnectionId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeListMembershipResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListMembershipResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsListMembershipResponse ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.AdminSetPublisherDataRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminSetPublisherDataRequest : public FPlayFabRequestCommon
{
	struct FString Key;  // 0x8(0x10)
	struct FString Value;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.DeletePlayer
// Size: 0x48(Inherited: 0x0) 
struct FDeletePlayer
{
	struct FServerDeletePlayerRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPlayerTrades
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerTrades
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.GroupsGetGroupRequest
// Size: 0x28(Inherited: 0x8) 
struct FGroupsGetGroupRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)
	struct FString GroupName;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.AdminDeletePlayerRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeletePlayerRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardAroundUserResult
// Size: 0x30(Inherited: 0x8) 
struct FServerGetLeaderboardAroundUserResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)
	struct FString NextReset;  // 0x18(0x10)
	int32_t Version;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct PlayFab.MultiplayerUploadCertificateRequest
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerUploadCertificateRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* GameCertificate;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.DeletePlayerSharedSecret
// Size: 0x48(Inherited: 0x0) 
struct FDeletePlayerSharedSecret
{
	struct FAdminDeletePlayerSharedSecretRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetMatchmakerGameInfo
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMatchmakerGameInfo
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminDeletePlayerSharedSecretRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeletePlayerSharedSecretRequest : public FPlayFabRequestCommon
{
	struct FString SecretKey;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteMembershipSubscription
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteMembershipSubscription
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteSegment
// Size: 0x48(Inherited: 0x0) 
struct FDeleteSegment
{
	struct FAdminDeleteSegmentRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessRegisterQueuedFunction__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRegisterQueuedFunction__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithPSNRequest
// Size: 0x68(Inherited: 0x8) 
struct FClientLoginWithPSNRequest : public FPlayFabRequestCommon
{
	struct FString AuthCode;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CreateAccount : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EncryptedRequest;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	int32_t IssuerId;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString PlayerSecret;  // 0x48(0x10)
	struct FString RedirectUri;  // 0x58(0x10)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSetItemModerationState__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetItemModerationState__DelegateSignature
{
	struct FEconomySetItemModerationStateResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteSegmentRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeleteSegmentRequest : public FPlayFabRequestCommon
{
	struct FString SegmentId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteStore
// Size: 0x60(Inherited: 0x0) 
struct FDeleteStore
{
	struct FAdminDeleteStoreRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkTwitch__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkTwitch__DelegateSignature
{
	struct FClientUnlinkTwitchAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteStoreRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminDeleteStoreRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString StoreId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.DeleteTask
// Size: 0x40(Inherited: 0x0) 
struct FDeleteTask
{
	struct FAdminDeleteTaskRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.AdminDeleteTaskRequest
// Size: 0x10(Inherited: 0x8) 
struct FAdminDeleteTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Identifier;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelAllMatchmakingTicketsForPlayer__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessCancelAllMatchmakingTicketsForPlayer__DelegateSignature
{
	struct FMultiplayerCancelAllMatchmakingTicketsForPlayerResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithEmailAddress__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithEmailAddress__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdatePolicyRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminUpdatePolicyRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool OverwritePolicy : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString PolicyName;  // 0x10(0x10)
	int32_t PolicyVersion;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct UPlayFabJsonObject*> Statements;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.AdminDeleteTitleRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminDeleteTitleRequest : public FPlayFabRequestCommon
{

}; 
// ScriptStruct PlayFab.AdminDeleteTitleDataOverrideRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminDeleteTitleDataOverrideRequest : public FPlayFabRequestCommon
{
	struct FString OverrideLabel;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminExportMasterPlayerDataRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminExportMasterPlayerDataRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminExportPlayersInSegmentRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminExportPlayersInSegmentRequest : public FPlayFabRequestCommon
{
	struct FString SegmentId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetPlayerSharedSecrets
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerSharedSecrets
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetAllSegments
// Size: 0x38(Inherited: 0x0) 
struct FGetAllSegments
{
	struct FServerGetAllSegmentsRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetCatalogItems
// Size: 0x48(Inherited: 0x0) 
struct FGetCatalogItems
{
	struct FServerGetCatalogItemsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminGetCloudScriptRevisionRequest
// Size: 0x10(Inherited: 0x8) 
struct FAdminGetCloudScriptRevisionRequest : public FPlayFabRequestCommon
{
	int32_t Revision;  // 0x8(0x4)
	int32_t Version;  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.ExperimentationDeleteExclusionGroupRequest
// Size: 0x20(Inherited: 0x8) 
struct FExperimentationDeleteExclusionGroupRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExclusionGroupId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetRemoteLoginEndpointResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetRemoteLoginEndpointResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetRemoteLoginEndpointResponse ReturnValue;  // 0x8(0x20)

}; 
// ScriptStruct PlayFab.AdminUpdateStoreItemsRequest
// Size: 0x48(Inherited: 0x8) 
struct FAdminUpdateStoreItemsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* MarketingData;  // 0x20(0x8)
	struct TArray<struct UPlayFabJsonObject*> Store;  // 0x28(0x10)
	struct FString StoreId;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetAssetUploadUrl
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetAssetUploadUrl
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetMultiplayerServerLogs
// Size: 0x50(Inherited: 0x0) 
struct FGetMultiplayerServerLogs
{
	struct FMultiplayerGetMultiplayerServerLogsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.GetCloudScriptTaskInstance
// Size: 0x48(Inherited: 0x0) 
struct FGetCloudScriptTaskInstance
{
	struct FAdminGetTaskInstanceRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.GetCloudScriptVersions
// Size: 0x38(Inherited: 0x0) 
struct FGetCloudScriptVersions
{
	struct FAdminGetCloudScriptVersionsRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetPlayedTitleList
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayedTitleList
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminRemoveVirtualCurrencyTypesRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminRemoveVirtualCurrencyTypesRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> VirtualCurrencies;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientLoginWithNintendoSwitchDeviceIdRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithNintendoSwitchDeviceIdRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x28(0x8)
	struct FString NintendoSwitchDeviceId;  // 0x30(0x10)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildWithManagedContainerRequest
// Size: 0xC8(Inherited: 0x8) 
struct FMultiplayerCreateBuildWithManagedContainerRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildName;  // 0x10(0x10)
	uint8_t  ContainerFlavor;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x30(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x40(0x10)
	struct FString GameWorkingDirectory;  // 0x50(0x10)
	struct UPlayFabJsonObject* InstrumentationConfiguration;  // 0x60(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x68(0x8)
	struct UPlayFabJsonObject* MonitoringApplicationConfiguration;  // 0x70(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0x80(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0x90(0x10)
	struct UPlayFabJsonObject* ServerResourceConstraints;  // 0xA0(0x8)
	struct FString StartMultiplayerServerCommand;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool UseStreamingForAssetDownloads : 1;  // 0xB8(0x1)
	uint8_t  VmSize;  // 0xB9(0x1)
	char pad_186[6];  // 0xBA(0x6)
	struct UPlayFabJsonObject* WindowsCrashDumpConfiguration;  // 0xC0(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessAcceptGroupApplication__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAcceptGroupApplication__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessUnblockEntity__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnblockEntity__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetAccountInfo
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetAccountInfo
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetCatalogItemsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetCatalogItemsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Catalog;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserBans
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserBans
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.GroupsApplyToGroupRequest
// Size: 0x28(Inherited: 0x8) 
struct FGroupsApplyToGroupRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AutoAcceptOutstandingInvite : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct UPlayFabJsonObject* Group;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.AdminGetContentListRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetContentListRequest : public FPlayFabRequestCommon
{
	struct FString Prefix;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.GetContentUploadUrl
// Size: 0x58(Inherited: 0x0) 
struct FGetContentUploadUrl
{
	struct FAdminGetContentUploadUrlRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreateActionsOnPlayersInSegmentTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateActionsOnPlayersInSegmentTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithGooglePlayGamesServices
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithGooglePlayGamesServices
{
	struct FClientLoginWithGooglePlayGamesServicesRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteBuild
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteBuild
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupApplicationsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListGroupApplicationsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsListGroupApplicationsResponse ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerUpdateCharacterDataRequest
// Size: 0x50(Inherited: 0x8) 
struct FServerUpdateCharacterDataRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Data;  // 0x20(0x8)
	struct FString KeysToRemove;  // 0x28(0x10)
	uint8_t  Permission;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString PlayFabId;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerListCertificateSummariesResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListCertificateSummariesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> CertificateSummaries;  // 0x8(0x10)
	int32_t PageSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.GetDataReport
// Size: 0x58(Inherited: 0x0) 
struct FGetDataReport
{
	struct FAdminGetDataReportRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildWithProcessBasedServerResponse
// Size: 0xF8(Inherited: 0x8) 
struct FMultiplayerCreateBuildWithProcessBasedServerResponse : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildId;  // 0x10(0x10)
	struct FString BuildName;  // 0x20(0x10)
	uint8_t  ContainerFlavor;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CreationTime;  // 0x38(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x48(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x58(0x10)
	struct FString GameWorkingDirectory;  // 0x68(0x10)
	struct UPlayFabJsonObject* InstrumentationConfiguration;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool IsOSPreview : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UPlayFabJsonObject* MetaData;  // 0x88(0x8)
	struct UPlayFabJsonObject* MonitoringApplicationConfiguration;  // 0x90(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FString OsPlatform;  // 0xA0(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0xB0(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0xC0(0x10)
	struct FString ServerType;  // 0xD0(0x10)
	struct FString StartMultiplayerServerCommand;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool UseStreamingForAssetDownloads : 1;  // 0xF0(0x1)
	uint8_t  VmSize;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetPolicy
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPolicy
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetDataReportRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetDataReportRequest : public FPlayFabRequestCommon
{
	int32_t Day;  // 0x8(0x4)
	int32_t Month;  // 0xC(0x4)
	struct FString ReportName;  // 0x10(0x10)
	int32_t Year;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function PlayFab.PlayFabAdminAPI.GetMatchmakerGameInfo
// Size: 0x48(Inherited: 0x0) 
struct FGetMatchmakerGameInfo
{
	struct FAdminGetMatchmakerGameInfoRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.GroupsUpdateGroupRoleResponse
// Size: 0x20(Inherited: 0x8) 
struct FGroupsUpdateGroupRoleResponse : public FPlayFabResultCommon
{
	struct FString OperationReason;  // 0x8(0x10)
	int32_t ProfileVersion;  // 0x18(0x4)
	uint8_t  SetResult;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// ScriptStruct PlayFab.AdminGetMatchmakerGameModesRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetMatchmakerGameModesRequest : public FPlayFabRequestCommon
{
	struct FString BuildVersion;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.StartPurchase
// Size: 0x70(Inherited: 0x0) 
struct FStartPurchase
{
	struct FClientStartPurchaseRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.RefundPurchase
// Size: 0x68(Inherited: 0x0) 
struct FRefundPurchase
{
	struct FAdminRefundPurchaseRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeValidateWindowsReceiptResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeValidateWindowsReceiptResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientValidateWindowsReceiptResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.AdminGetPlayedTitleListRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPlayedTitleListRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetStoreItemsResult
// Size: 0x48(Inherited: 0x8) 
struct FClientGetStoreItemsResult : public FPlayFabResultCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* MarketingData;  // 0x18(0x8)
	uint8_t  Source;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct UPlayFabJsonObject*> Store;  // 0x28(0x10)
	struct FString StoreId;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.AdminGetTaskInstancesRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminGetTaskInstancesRequest : public FPlayFabRequestCommon
{
	struct FString StartedAtRangeFrom;  // 0x8(0x10)
	struct FString StartedAtRangeTo;  // 0x18(0x10)
	uint8_t  StatusFilter;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UPlayFabJsonObject* TaskIdentifier;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdatePlayerSharedSecret
// Size: 0x60(Inherited: 0x0) 
struct FUpdatePlayerSharedSecret
{
	struct FAdminUpdatePlayerSharedSecretRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerIdFromAuthTokenRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminGetPlayerIdFromAuthTokenRequest : public FPlayFabRequestCommon
{
	struct FString Token;  // 0x8(0x10)
	uint8_t  TokenType;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAcceptTrade__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessAcceptTrade__DelegateSignature
{
	struct FClientAcceptTradeResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerProfileRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetPlayerProfileRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientGetFriendLeaderboardAroundPlayerResult
// Size: 0x30(Inherited: 0x8) 
struct FClientGetFriendLeaderboardAroundPlayerResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)
	struct FString NextReset;  // 0x18(0x10)
	int32_t Version;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayerSegments
// Size: 0x50(Inherited: 0x0) 
struct FGetPlayerSegments
{
	struct FServerGetPlayersSegmentsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetFriendsList
// Size: 0x70(Inherited: 0x0) 
struct FGetFriendsList
{
	struct FServerGetFriendsListRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.GetPlayerSharedSecrets
// Size: 0x38(Inherited: 0x0) 
struct FGetPlayerSharedSecrets
{
	struct FAdminGetPlayerSharedSecretsRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkTwitchAccountRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkTwitchAccountRequest : public FPlayFabRequestCommon
{
	struct FString AccessToken;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerSharedSecretsRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminGetPlayerSharedSecretsRequest : public FPlayFabRequestCommon
{

}; 
// ScriptStruct PlayFab.ServerAddSharedGroupMembersRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerAddSharedGroupMembersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabIds;  // 0x8(0x10)
	struct FString SharedGroupId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.AdminGetPlayersInSegmentRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminGetPlayersInSegmentRequest : public FPlayFabRequestCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	int32_t MaxBatchSize;  // 0x20(0x4)
	int32_t SecondsToLive;  // 0x24(0x4)
	struct FString SegmentId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkNintendoServiceAccount
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkNintendoServiceAccount
{
	struct FClientUnlinkNintendoServiceAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPlayerStatisticDefinitionsRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminGetPlayerStatisticDefinitionsRequest : public FPlayFabRequestCommon
{

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperCreateExperiment
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateExperiment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserReadOnlyData
// Size: 0x60(Inherited: 0x0) 
struct FGetUserReadOnlyData
{
	struct FServerGetUserDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.ReviewItem
// Size: 0x68(Inherited: 0x0) 
struct FReviewItem
{
	struct FEconomyReviewItemRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGrantItemsToUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperGrantItemsToUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkFacebookAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkFacebookAccount__DelegateSignature
{
	struct FClientUnlinkFacebookAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayerStatisticVersions
// Size: 0x50(Inherited: 0x0) 
struct FGetPlayerStatisticVersions
{
	struct FServerGetPlayerStatisticVersionsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.SetNumberArrayField
// Size: 0x20(Inherited: 0x0) 
struct FSetNumberArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<float> NumberArray;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.InsightsInsightsEmptyRequest
// Size: 0x10(Inherited: 0x8) 
struct FInsightsInsightsEmptyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperSetupPushNotification
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetupPushNotification
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRegisterForIOSPushNotification__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRegisterForIOSPushNotification__DelegateSignature
{
	struct FClientRegisterForIOSPushNotificationResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.WriteCharacterEvent
// Size: 0x88(Inherited: 0x0) 
struct FWriteCharacterEvent
{
	struct FServerWriteServerCharacterEventRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x80(0x8)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetExperimentsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetExperimentsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationGetExperimentsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminAPI.GetPolicy
// Size: 0x48(Inherited: 0x0) 
struct FGetPolicy
{
	struct FAdminGetPolicyRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminGetPolicyRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetPolicyRequest : public FPlayFabRequestCommon
{
	struct FString PolicyName;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessValidateEntityToken__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessValidateEntityToken__DelegateSignature
{
	struct FAuthenticationValidateEntityTokenResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetOperationStatusResponseResponse
// Size: 0x88(Inherited: 0x0) 
struct FdecodeInsightsGetOperationStatusResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FInsightsInsightsGetOperationStatusResponse ReturnValue;  // 0x8(0x80)

}; 
// ScriptStruct PlayFab.ClientValidateAmazonReceiptResult
// Size: 0x18(Inherited: 0x8) 
struct FClientValidateAmazonReceiptResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Fulfillments;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerListPartyQosServersResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListPartyQosServersResponse : public FPlayFabResultCommon
{
	int32_t PageSize;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UPlayFabJsonObject*> QosServers;  // 0x10(0x10)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRevokeBansResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRevokeBansResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRevokeBansResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.GetPublisherData
// Size: 0x48(Inherited: 0x0) 
struct FGetPublisherData
{
	struct FServerGetPublisherDataRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ProfilesGetEntityProfileResponse
// Size: 0x10(Inherited: 0x8) 
struct FProfilesGetEntityProfileResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Profile;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetRandomResultTables
// Size: 0x58(Inherited: 0x0) 
struct FGetRandomResultTables
{
	struct FServerGetRandomResultTablesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientWriteTitleEventRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientWriteTitleEventRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Body;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EventName;  // 0x18(0x10)
	struct FString Timestamp;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.GetSegmentExport
// Size: 0x48(Inherited: 0x0) 
struct FGetSegmentExport
{
	struct FAdminGetPlayersInSegmentExportRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteContainerImageRepository
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteContainerImageRepository
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCatalogItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCatalogItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayerCombinedInfo
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerCombinedInfo
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminGetSegmentsRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminGetSegmentsRequest : public FPlayFabRequestCommon
{
	struct FString SegmentIds;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboardForUserCharacters__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetLeaderboardForUserCharacters__DelegateSignature
{
	struct FServerGetLeaderboardForUsersCharactersResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetStoreItems
// Size: 0x70(Inherited: 0x0) 
struct FGetStoreItems
{
	struct FServerGetStoreItemsServerRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminGetStoreItemsRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminGetStoreItemsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString StoreId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.SetStringArrayField
// Size: 0x20(Inherited: 0x0) 
struct FSetStringArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<struct FString> StringArray;  // 0x10(0x10)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessUnregisterFunction__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnregisterFunction__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminGetTasksRequest
// Size: 0x10(Inherited: 0x8) 
struct FAdminGetTasksRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Identifier;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetTitleData
// Size: 0x58(Inherited: 0x0) 
struct FGetTitleData
{
	struct FServerGetTitleDataRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkAndroidDeviceIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkAndroidDeviceIDResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CancelServerBackfillTicket
// Size: 0x60(Inherited: 0x0) 
struct FCancelServerBackfillTicket
{
	struct FMultiplayerCancelServerBackfillTicketRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetTitleInternalData
// Size: 0x58(Inherited: 0x0) 
struct FGetTitleInternalData
{
	struct FServerGetTitleDataRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteOpenIdConnection
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteOpenIdConnection
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListMultiplayerServersResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListMultiplayerServersResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListMultiplayerServersResponse ReturnValue;  // 0x8(0x30)

}; 
// ScriptStruct PlayFab.EconomySubmitItemReviewVoteRequest
// Size: 0x48(Inherited: 0x8) 
struct FEconomySubmitItemReviewVoteRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ItemId;  // 0x20(0x10)
	struct FString ReviewId;  // 0x30(0x10)
	uint8_t  Vote;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserAccountInfo
// Size: 0x48(Inherited: 0x0) 
struct FGetUserAccountInfo
{
	struct FServerGetUserAccountInfoRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.AdminGetUserDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminGetUserDataRequest : public FPlayFabRequestCommon
{
	int32_t IfChangedFromDataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Keys;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.AdminGetUserInventoryRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminGetUserInventoryRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.DataGetObjectsRequest
// Size: 0x20(Inherited: 0x8) 
struct FDataGetObjectsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool EscapeObject : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserPublisherData
// Size: 0x60(Inherited: 0x0) 
struct FGetUserPublisherData
{
	struct FServerGetUserDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.DeleteFiles
// Size: 0x60(Inherited: 0x0) 
struct FDeleteFiles
{
	struct FDataDeleteFilesRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserPublisherInternalData
// Size: 0x60(Inherited: 0x0) 
struct FGetUserPublisherInternalData
{
	struct FServerGetUserDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetUserPublisherReadOnlyData
// Size: 0x60(Inherited: 0x0) 
struct FGetUserPublisherReadOnlyData
{
	struct FServerGetUserDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperAbortTaskInstance
// Size: 0x50(Inherited: 0x0) 
struct FHelperAbortTaskInstance
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetCharacterLeaderboardRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetCharacterLeaderboardRequest : public FPlayFabRequestCommon
{
	struct FString CharacterType;  // 0x8(0x10)
	int32_t MaxResultsCount;  // 0x18(0x4)
	int32_t StartPosition;  // 0x1C(0x4)
	struct FString StatisticName;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.SetPublishedRevision
// Size: 0x48(Inherited: 0x0) 
struct FSetPublishedRevision
{
	struct FAdminSetPublishedRevisionRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeWriteEventResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeWriteEventResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerWriteEventResponse ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdatePlayerStatistics__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdatePlayerStatistics__DelegateSignature
{
	struct FServerUpdatePlayerStatisticsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemReviewSummaryResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetItemReviewSummaryResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetItemReviewSummaryResponse ReturnValue;  // 0x8(0x28)

}; 
// ScriptStruct PlayFab.ServerGetFriendsListResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetFriendsListResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Friends;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperAddLocalizedNews
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddLocalizedNews
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetItems
// Size: 0x68(Inherited: 0x0) 
struct FGetItems
{
	struct FEconomyGetItemsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAddUserVirtualCurrency
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddUserVirtualCurrency
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperAddVirtualCurrencyTypes
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddVirtualCurrencyTypes
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLinkNintendoSwitchDeviceIdResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkNintendoSwitchDeviceIdResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.HelperBanUsers
// Size: 0x50(Inherited: 0x0) 
struct FHelperBanUsers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabInsightsAPI.GetDetails
// Size: 0x40(Inherited: 0x0) 
struct FGetDetails
{
	struct FInsightsInsightsEmptyRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabInsightsAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCheckLimitedEditionItemAvailability
// Size: 0x50(Inherited: 0x0) 
struct FHelperCheckLimitedEditionItemAvailability
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperResetCharacterStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperResetCharacterStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.GroupsListGroupApplicationsResponse
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupApplicationsResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Applications;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkPSNAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkPSNAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreateCloudScriptTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateCloudScriptTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientSetFriendTagsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientSetFriendTagsRequest : public FPlayFabRequestCommon
{
	struct FString FriendPlayFabId;  // 0x8(0x10)
	struct FString Tags;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemReviewSummary__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetItemReviewSummary__DelegateSignature
{
	struct FEconomyGetItemReviewSummaryResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.CreateGroup
// Size: 0x58(Inherited: 0x0) 
struct FCreateGroup
{
	struct FGroupsCreateGroupRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkKongregate
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkKongregate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.ListGroupBlocks
// Size: 0x48(Inherited: 0x0) 
struct FListGroupBlocks
{
	struct FGroupsListGroupBlocksRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperCreateSegment
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateSegment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.LoginWithSteamId
// Size: 0x60(Inherited: 0x0) 
struct FLoginWithSteamId
{
	struct FServerLoginWithSteamIdRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.AdminRevokeBansRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminRevokeBansRequest : public FPlayFabRequestCommon
{
	struct FString BanIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.SetTitleData
// Size: 0x60(Inherited: 0x0) 
struct FSetTitleData
{
	struct FServerSetTitleDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteContent
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteContent
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteMasterPlayerAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteMasterPlayerAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetAllUsersCharacters
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetAllUsersCharacters
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientEmptyResult
// Size: 0x8(Inherited: 0x8) 
struct FClientEmptyResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeletePlayerSharedSecret
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeletePlayerSharedSecret
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperDeleteTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperRemoveVirtualCurrencyTypes
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveVirtualCurrencyTypes
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerGrantItemsToUsersRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerGrantItemsToUsersRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct TArray<struct UPlayFabJsonObject*> ItemGrants;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboardAroundCharacter__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetLeaderboardAroundCharacter__DelegateSignature
{
	struct FServerGetLeaderboardAroundCharacterResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperExportMasterPlayerData
// Size: 0x50(Inherited: 0x0) 
struct FHelperExportMasterPlayerData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeValidateAmazonReceiptResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeValidateAmazonReceiptResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientValidateAmazonReceiptResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkIOSDeviceIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkIOSDeviceIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkIOSDeviceIDResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCancelAllServerBackfillTicketsForPlayerResult
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerCancelAllServerBackfillTicketsForPlayerResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.HelperExportPlayersInSegment
// Size: 0x50(Inherited: 0x0) 
struct FHelperExportPlayersInSegment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetContentUploadUrl
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetContentUploadUrl
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLoginWithSteamRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithSteamRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x28(0x8)
	struct FString PlayerSecret;  // 0x30(0x10)
	struct FString SteamTicket;  // 0x40(0x10)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItem__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetItem__DelegateSignature
{
	struct FEconomyGetItemResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetMultiplayerServerLogs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMultiplayerServerLogs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetCharacterLeaderboard
// Size: 0x60(Inherited: 0x0) 
struct FGetCharacterLeaderboard
{
	struct FServerGetCharacterLeaderboardRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetDataReport
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetDataReport
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeMoveItemToCharacterFromUserResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeMoveItemToCharacterFromUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerMoveItemToCharacterFromUserResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetMatchmakerGameModes
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMatchmakerGameModes
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayerSegments
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerSegments
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteCertificate
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteCertificate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayersInSegment
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayersInSegment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetPlayerStatisticDefinitions
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerStatisticDefinitions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerCancelMatchmakingTicketResult
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerCancelMatchmakingTicketResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerGetPlayersInSegmentResult
// Size: 0x30(Inherited: 0x8) 
struct FServerGetPlayersInSegmentResult : public FPlayFabResultCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> PlayerProfiles;  // 0x18(0x10)
	int32_t ProfilesInSegment;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessIsMember__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessIsMember__DelegateSignature
{
	struct FGroupsIsMemberResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayerStatisticVersions
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerStatisticVersions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkKongregate
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkKongregate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateCatalogItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCatalogItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessRemoveMember__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveMember__DelegateSignature
{
	struct FMultiplayerLobbyEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetRandomResultTables
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetRandomResultTables
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSavePushNotificationTemplate
// Size: 0x50(Inherited: 0x0) 
struct FHelperSavePushNotificationTemplate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperGetSegments
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetSegments
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithXboxId__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithXboxId__DelegateSignature
{
	struct FServerServerLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetAssetUploadUrlResponse
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerGetAssetUploadUrlResponse : public FPlayFabResultCommon
{
	struct FString AssetUploadUrl;  // 0x8(0x10)
	struct FString Filename;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetStoreItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetStoreItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperIncrementLimitedEditionItemAvailability
// Size: 0x50(Inherited: 0x0) 
struct FHelperIncrementLimitedEditionItemAvailability
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetTitleInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitleInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.RewardAdActivity
// Size: 0x60(Inherited: 0x0) 
struct FRewardAdActivity
{
	struct FClientRewardAdActivityRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.SetBoolArrayField
// Size: 0x20(Inherited: 0x0) 
struct FSetBoolArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<bool> BoolArray;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRemovePlayerTagResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRemovePlayerTagResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRemovePlayerTagResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListTitleMultiplayerServersQuotaChanges
// Size: 0x40(Inherited: 0x0) 
struct FListTitleMultiplayerServersQuotaChanges
{
	struct FMultiplayerListTitleMultiplayerServersQuotaChangesRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperConsumeMicrosoftStoreEntitlements
// Size: 0x50(Inherited: 0x0) 
struct FHelperConsumeMicrosoftStoreEntitlements
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserInventory
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserInventory
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessMoveItemToCharacterFromUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessMoveItemToCharacterFromUser__DelegateSignature
{
	struct FServerMoveItemToCharacterFromUserResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPaymentTokenResult
// Size: 0x28(Inherited: 0x8) 
struct FClientGetPaymentTokenResult : public FPlayFabResultCommon
{
	struct FString OrderID;  // 0x8(0x10)
	struct FString ProviderToken;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.Matchmake
// Size: 0xA0(Inherited: 0x0) 
struct FMatchmake
{
	struct FClientMatchmakeRequest Request;  // 0x0(0x70)
	struct FDelegate onSuccess;  // 0x70(0x10)
	struct FDelegate onFailure;  // 0x80(0x10)
	struct UObject* customData;  // 0x90(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x98(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserPublisherData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserPublisherData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperDeleteExclusionGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteExclusionGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteCertificate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteCertificate__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserReadOnlyData
// Size: 0x70(Inherited: 0x0) 
struct FUpdateUserReadOnlyData
{
	struct FServerUpdateUserDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserPublisherInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserPublisherInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateBuildAlias
// Size: 0x60(Inherited: 0x0) 
struct FCreateBuildAlias
{
	struct FMultiplayerCreateBuildAliasRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithGameCenter
// Size: 0xC0(Inherited: 0x0) 
struct FLoginWithGameCenter
{
	struct FClientLoginWithGameCenterRequest Request;  // 0x0(0x90)
	struct FDelegate onSuccess;  // 0x90(0x10)
	struct FDelegate onFailure;  // 0xA0(0x10)
	struct UObject* customData;  // 0xB0(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0xB8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteRemoteUserRequest
// Size: 0x50(Inherited: 0x8) 
struct FMultiplayerDeleteRemoteUserRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Region;  // 0x20(0x10)
	struct FString Username;  // 0x30(0x10)
	struct FString VmId;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetUserReadOnlyData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetUserReadOnlyData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetLeaderboard
// Size: 0x70(Inherited: 0x0) 
struct FGetLeaderboard
{
	struct FServerGetLeaderboardRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromFacebookIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromFacebookIDs__DelegateSignature
{
	struct FServerGetPlayFabIDsFromFacebookIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGrantItemsToUsers
// Size: 0x50(Inherited: 0x0) 
struct FHelperGrantItemsToUsers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientSubtractUserVirtualCurrencyRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientSubtractUserVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString VirtualCurrency;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRemovePlayerTag
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemovePlayerTag
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperListOpenIdConnection
// Size: 0x50(Inherited: 0x0) 
struct FHelperListOpenIdConnection
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetMultiplayerServerDetails
// Size: 0x70(Inherited: 0x0) 
struct FGetMultiplayerServerDetails
{
	struct FMultiplayerGetMultiplayerServerDetailsRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromFacebookIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromFacebookIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.ResolvePurchaseDispute
// Size: 0x70(Inherited: 0x0) 
struct FResolvePurchaseDispute
{
	struct FAdminResolvePurchaseDisputeRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromFacebookInstantGamesIdsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromFacebookInstantGamesIdsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRevokeAllBansForUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperRevokeAllBansForUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRevokeBans
// Size: 0x50(Inherited: 0x0) 
struct FHelperRevokeBans
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRevokeInventoryItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperRevokeInventoryItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithAndroidDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithAndroidDeviceID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperSendAccountRecoveryEmail
// Size: 0x50(Inherited: 0x0) 
struct FHelperSendAccountRecoveryEmail
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessPlayerJoined__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPlayerJoined__DelegateSignature
{
	struct FMatchmakerPlayerJoinedResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkAndroidDeviceIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkAndroidDeviceIDResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientGetFriendLeaderboardRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientGetFriendLeaderboardRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IncludeFacebookFriends : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IncludeSteamFriends : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t MaxResultsCount;  // 0x14(0x4)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x18(0x8)
	int32_t StartPosition;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString StatisticName;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool UseSpecificVersion : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t Version;  // 0x3C(0x4)
	struct FString XboxToken;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.EconomyGetEntityItemReviewResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyGetEntityItemReviewResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Review;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.MergeJsonObject
// Size: 0x10(Inherited: 0x0) 
struct FMergeJsonObject
{
	struct UPlayFabJsonObject* InJsonObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Overwrite : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperSetCatalogItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetCatalogItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeCreateExclusionGroupResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateExclusionGroupResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationCreateExclusionGroupResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.AuthenticationGetEntityTokenResponse
// Size: 0x30(Inherited: 0x8) 
struct FAuthenticationGetEntityTokenResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	struct FString EntityToken;  // 0x10(0x10)
	struct FString TokenExpiration;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessStopExperiment__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessStopExperiment__DelegateSignature
{
	struct FExperimentationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperSetPublishedRevision
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetPublishedRevision
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessDelete__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDelete__DelegateSignature
{
	struct FAuthenticationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyCreateDraftItemResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyCreateDraftItemResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Item;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetTitleInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetTitleInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientConsumeMicrosoftStoreEntitlementsResponse
// Size: 0x18(Inherited: 0x8) 
struct FClientConsumeMicrosoftStoreEntitlementsResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGetLeaderboardRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t MaxResultsCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x18(0x8)
	int32_t StartPosition;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString StatisticName;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool UseSpecificVersion : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t Version;  // 0x3C(0x4)

}; 
// Function PlayFab.PlayFabClientAPI.ConsumePSNEntitlements
// Size: 0x58(Inherited: 0x0) 
struct FConsumePSNEntitlements
{
	struct FClientConsumePSNEntitlementsRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateBans
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateBans
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminRevokeAllBansForUserRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminRevokeAllBansForUserRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessReportPlayer__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessReportPlayer__DelegateSignature
{
	struct FServerReportPlayerServerResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateCloudScript
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCloudScript
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerJoinLobbyRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerJoinLobbyRequest : public FPlayFabRequestCommon
{
	struct FString ConnectionString;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* MemberData;  // 0x20(0x8)
	struct UPlayFabJsonObject* MemberEntity;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteContainerImageRepository__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteContainerImageRepository__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyPublishDraftItemRequest
// Size: 0x40(Inherited: 0x8) 
struct FEconomyPublishDraftItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ETag;  // 0x20(0x10)
	struct FString ID;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateOpenIdConnection
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateOpenIdConnection
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetDraftItems__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetDraftItems__DelegateSignature
{
	struct FEconomyGetDraftItemsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerRequestMultiplayerServerResponse
// Size: 0xB8(Inherited: 0x8) 
struct FMultiplayerRequestMultiplayerServerResponse : public FPlayFabResultCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> ConnectedPlayers;  // 0x18(0x10)
	struct FString FQDN;  // 0x28(0x10)
	struct FString IPV4Address;  // 0x38(0x10)
	struct FString LastStateTransitionTime;  // 0x48(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0x58(0x10)
	struct FString Region;  // 0x68(0x10)
	struct FString ServerId;  // 0x78(0x10)
	struct FString SessionId;  // 0x88(0x10)
	struct FString State;  // 0x98(0x10)
	struct FString VmId;  // 0xA8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerSegmentsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayerSegmentsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Segments;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGrantCharacterToUserResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGrantCharacterToUserResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdatePlayerSharedSecret
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdatePlayerSharedSecret
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkGoogleAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkGoogleAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkGoogleAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateSegment
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateSegment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateStoreItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateStoreItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkIOSDeviceID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkIOSDeviceID__DelegateSignature
{
	struct FClientLinkIOSDeviceIDResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.HelperUpdateTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessGetFunction__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FDelegateOnSuccessGetFunction__DelegateSignature
{
	struct FCloudScriptGetFunctionResult Result;  // 0x0(0x48)
	struct UObject* customData;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessPlayerLeft__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPlayerLeft__DelegateSignature
{
	struct FMatchmakerPlayerLeftResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminResetCharacterStatisticsRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminResetCharacterStatisticsRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUpdateUserTitleDisplayName
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserTitleDisplayName
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.HelperPlayerLeft
// Size: 0x50(Inherited: 0x0) 
struct FHelperPlayerLeft
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminIncrementPlayerStatisticVersionRequest
// Size: 0x20(Inherited: 0x8) 
struct FAdminIncrementPlayerStatisticVersionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString StatisticName;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.ConsumeMicrosoftStoreEntitlements
// Size: 0x58(Inherited: 0x0) 
struct FConsumeMicrosoftStoreEntitlements
{
	struct FClientConsumeMicrosoftStoreEntitlementsRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.ListVirtualCurrencyTypes
// Size: 0x38(Inherited: 0x0) 
struct FListVirtualCurrencyTypes
{
	struct FAdminListVirtualCurrencyTypesRequest Request;  // 0x0(0x8)
	struct FDelegate onSuccess;  // 0x8(0x10)
	struct FDelegate onFailure;  // 0x18(0x10)
	struct UObject* customData;  // 0x28(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AdminSetPlayerSecretRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminSetPlayerSecretRequest : public FPlayFabRequestCommon
{
	struct FString PlayerSecret;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetCharacterData
// Size: 0x70(Inherited: 0x0) 
struct FGetCharacterData
{
	struct FServerGetCharacterDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkOpenIdConnect
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkOpenIdConnect
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabInsightsAPI.GetOperationStatus
// Size: 0x50(Inherited: 0x0) 
struct FGetOperationStatus
{
	struct FInsightsInsightsGetOperationStatusRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabInsightsAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.AdminListVirtualCurrencyTypesRequest
// Size: 0x8(Inherited: 0x8) 
struct FAdminListVirtualCurrencyTypesRequest : public FPlayFabRequestCommon
{

}; 
// Function PlayFab.PlayFabAdminAPI.ModifyServerBuild
// Size: 0xA8(Inherited: 0x0) 
struct FModifyServerBuild
{
	struct FAdminModifyServerBuildRequest Request;  // 0x0(0x78)
	struct FDelegate onSuccess;  // 0x78(0x10)
	struct FDelegate onFailure;  // 0x88(0x10)
	struct UObject* customData;  // 0x98(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0xA0(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithFacebook__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithFacebook__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminModifyServerBuildRequest
// Size: 0x78(Inherited: 0x8) 
struct FAdminModifyServerBuildRequest : public FPlayFabRequestCommon
{
	struct FString ActiveRegions;  // 0x8(0x10)
	struct FString BuildId;  // 0x18(0x10)
	struct FString CommandLineTemplate;  // 0x28(0x10)
	struct FString Comment;  // 0x38(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x48(0x8)
	struct FString ExecutablePath;  // 0x50(0x10)
	int32_t MaxGamesPerHost;  // 0x60(0x4)
	int32_t MinFreeGameSlots;  // 0x64(0x4)
	struct FString Timestamp;  // 0x68(0x10)

}; 
// ScriptStruct PlayFab.ServerUpdateSharedGroupDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerUpdateSharedGroupDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	uint8_t  Permission;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString SharedGroupId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.AdminRefundPurchaseRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminRefundPurchaseRequest : public FPlayFabRequestCommon
{
	struct FString OrderID;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString Reason;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabAdminAPI.RemoveVirtualCurrencyTypes
// Size: 0x48(Inherited: 0x0) 
struct FRemoveVirtualCurrencyTypes
{
	struct FAdminRemoveVirtualCurrencyTypesRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAndroidDevicePushNotificationRegistrationResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAndroidDevicePushNotificationRegistrationResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAndroidDevicePushNotificationRegistrationResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.ResetCharacterStatistics
// Size: 0x60(Inherited: 0x0) 
struct FResetCharacterStatistics
{
	struct FAdminResetCharacterStatisticsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.ResetPassword
// Size: 0x60(Inherited: 0x0) 
struct FResetPassword
{
	struct FAdminResetPasswordRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.EconomyUpdateDraftItemResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyUpdateDraftItemResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Item;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.ResetUserStatistics
// Size: 0x50(Inherited: 0x0) 
struct FResetUserStatistics
{
	struct FAdminResetUserStatisticsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetTitleEnabledForMultiplayerServersStatusRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithGooglePlayGamesServices
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithGooglePlayGamesServices
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessMoveItemToUserFromCharacter__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessMoveItemToUserFromCharacter__DelegateSignature
{
	struct FServerMoveItemToUserFromCharacterResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.AdminResolvePurchaseDisputeRequest
// Size: 0x40(Inherited: 0x8) 
struct FAdminResolvePurchaseDisputeRequest : public FPlayFabRequestCommon
{
	struct FString OrderID;  // 0x8(0x10)
	uint8_t  Outcome;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString PlayFabId;  // 0x20(0x10)
	struct FString Reason;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUnlinkXboxAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkXboxAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetContentUploadUrlResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetContentUploadUrlResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetContentUploadUrlResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithCustomID__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithCustomID__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminRevokeInventoryItemRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminRevokeInventoryItemRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString ItemInstanceId;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.RevokeInventoryItems
// Size: 0x48(Inherited: 0x0) 
struct FRevokeInventoryItems
{
	struct FServerRevokeInventoryItemsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateTitleMultiplayerServersQuotaChange
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateTitleMultiplayerServersQuotaChange
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientConsumePS5EntitlementsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientConsumePS5EntitlementsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* MarketplaceSpecificData;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.SendAccountRecoveryEmail
// Size: 0x60(Inherited: 0x0) 
struct FSendAccountRecoveryEmail
{
	struct FClientSendAccountRecoveryEmailRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCancelServerBackfillTicketRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerCancelServerBackfillTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString QueueName;  // 0x10(0x10)
	struct FString TicketId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LinkNintendoServiceAccount
// Size: 0x58(Inherited: 0x0) 
struct FLinkNintendoServiceAccount
{
	struct FClientLinkNintendoServiceAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.SetCatalogItems
// Size: 0x68(Inherited: 0x0) 
struct FSetCatalogItems
{
	struct FAdminUpdateCatalogItemsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.AdminSetMembershipOverrideRequest
// Size: 0x40(Inherited: 0x8) 
struct FAdminSetMembershipOverrideRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExpirationTime;  // 0x10(0x10)
	struct FString MembershipId;  // 0x20(0x10)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerLinkServerCustomIdResult
// Size: 0x8(Inherited: 0x8) 
struct FServerLinkServerCustomIdResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ProfilesSetEntityProfilePolicyRequest
// Size: 0x28(Inherited: 0x8) 
struct FProfilesSetEntityProfilePolicyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct TArray<struct UPlayFabJsonObject*> Statements;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkGameCenterAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkGameCenterAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerGetUserBansResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetUserBansResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.SetPlayerSecret
// Size: 0x58(Inherited: 0x0) 
struct FSetPlayerSecret
{
	struct FServerSetPlayerSecretRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SetPublisherData
// Size: 0x58(Inherited: 0x0) 
struct FSetPublisherData
{
	struct FServerSetPublisherDataRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkTwitchAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkTwitchAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.HelperGrantItemsToCharacter
// Size: 0x50(Inherited: 0x0) 
struct FHelperGrantItemsToCharacter
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabDataAPI.HelperDeleteFiles
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteFiles
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.AcceptTrade
// Size: 0x68(Inherited: 0x0) 
struct FAcceptTrade
{
	struct FClientAcceptTradeRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.SetTitleDataAndOverrides
// Size: 0x60(Inherited: 0x0) 
struct FSetTitleDataAndOverrides
{
	struct FAdminSetTitleDataAndOverridesRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.AdminSetTitleDataAndOverridesRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminSetTitleDataAndOverridesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct TArray<struct UPlayFabJsonObject*> KeyValues;  // 0x10(0x10)
	struct FString OverrideLabel;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumePSNEntitlements__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessConsumePSNEntitlements__DelegateSignature
{
	struct FClientConsumePSNEntitlementsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SetTitleInternalData
// Size: 0x60(Inherited: 0x0) 
struct FSetTitleInternalData
{
	struct FServerSetTitleDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessUserInfo__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FDelegateOnSuccessUserInfo__DelegateSignature
{
	struct FMatchmakerUserInfoResponse Result;  // 0x0(0x70)
	struct UObject* customData;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterLeaderboardResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetCharacterLeaderboardResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetCharacterLeaderboardResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeSetTitleDataAndOverridesResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetTitleDataAndOverridesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminSetTitleDataAndOverridesResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.SetupPushNotification
// Size: 0x70(Inherited: 0x0) 
struct FSetupPushNotification
{
	struct FAdminSetupPushNotificationRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.AdminSetupPushNotificationRequest
// Size: 0x40(Inherited: 0x8) 
struct FAdminSetupPushNotificationRequest : public FPlayFabRequestCommon
{
	struct FString Credential;  // 0x8(0x10)
	struct FString Key;  // 0x18(0x10)
	struct FString Name;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool OverwriteOldARN : 1;  // 0x38(0x1)
	uint8_t  Platform;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateTask
// Size: 0x90(Inherited: 0x0) 
struct FUpdateTask
{
	struct FAdminUpdateTaskRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x88(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserInternalData
// Size: 0x68(Inherited: 0x0) 
struct FUpdateUserInternalData
{
	struct FServerUpdateUserInternalDataRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessCreateGroup__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FDelegateOnSuccessCreateGroup__DelegateSignature
{
	struct FGroupsCreateGroupResponse Result;  // 0x0(0x60)
	struct UObject* customData;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SubtractUserVirtualCurrency
// Size: 0x68(Inherited: 0x0) 
struct FSubtractUserVirtualCurrency
{
	struct FServerSubtractUserVirtualCurrencyRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.AdminSubtractUserVirtualCurrencyRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminSubtractUserVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString VirtualCurrency;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateBans
// Size: 0x48(Inherited: 0x0) 
struct FUpdateBans
{
	struct FServerUpdateBansRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.ConsumeXboxEntitlements
// Size: 0x60(Inherited: 0x0) 
struct FConsumeXboxEntitlements
{
	struct FClientConsumeXboxEntitlementsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperLinkServerCustomId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkServerCustomId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientWriteEventResponse
// Size: 0x18(Inherited: 0x8) 
struct FClientWriteEventResponse : public FPlayFabResultCommon
{
	struct FString EventId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkIOSDeviceIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkIOSDeviceIDResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientUnlinkGameCenterAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkGameCenterAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.AdminUpdateBansRequest
// Size: 0x18(Inherited: 0x8) 
struct FAdminUpdateBansRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Bans;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminUpdateCloudScriptRequest
// Size: 0x38(Inherited: 0x8) 
struct FAdminUpdateCloudScriptRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DeveloperPlayFabId;  // 0x10(0x10)
	struct TArray<struct UPlayFabJsonObject*> Files;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Publish : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateOpenIdConnection
// Size: 0x80(Inherited: 0x0) 
struct FUpdateOpenIdConnection
{
	struct FAdminUpdateOpenIdConnectionRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdatePlayerSharedSecretRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminUpdatePlayerSharedSecretRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Disabled : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString FriendlyName;  // 0x10(0x10)
	struct FString SecretKey;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperModifyItemUses
// Size: 0x50(Inherited: 0x0) 
struct FHelperModifyItemUses
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.ReportItem
// Size: 0x78(Inherited: 0x0) 
struct FReportItem
{
	struct FEconomyReportItemRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdatePlayerStatisticDefinition
// Size: 0x58(Inherited: 0x0) 
struct FUpdatePlayerStatisticDefinition
{
	struct FAdminUpdatePlayerStatisticDefinitionRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTime__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetTime__DelegateSignature
{
	struct FServerGetTimeResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdatePlayerStatisticDefinitionRequest
// Size: 0x28(Inherited: 0x8) 
struct FAdminUpdatePlayerStatisticDefinitionRequest : public FPlayFabRequestCommon
{
	uint8_t  AggregationMethod;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString StatisticName;  // 0x10(0x10)
	uint8_t  VersionChangeInterval;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct PlayFab.DataDeleteFilesResponse
// Size: 0x18(Inherited: 0x8) 
struct FDataDeleteFilesResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	int32_t ProfileVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetTitleMultiplayerServersQuotas
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitleMultiplayerServersQuotas
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdatePolicy
// Size: 0x68(Inherited: 0x0) 
struct FUpdatePolicy
{
	struct FAdminUpdatePolicyRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkPSNAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkPSNAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperGetProfiles
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetProfiles
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientPayForPurchaseResult
// Size: 0x78(Inherited: 0x8) 
struct FClientPayForPurchaseResult : public FPlayFabResultCommon
{
	int32_t CreditApplied;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString OrderID;  // 0x10(0x10)
	struct FString ProviderData;  // 0x20(0x10)
	struct FString ProviderToken;  // 0x30(0x10)
	struct FString PurchaseConfirmationPageURL;  // 0x40(0x10)
	struct FString PurchaseCurrency;  // 0x50(0x10)
	int32_t PurchasePrice;  // 0x60(0x4)
	uint8_t  Status;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct UPlayFabJsonObject* VCAmount;  // 0x68(0x8)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.AdminUpdateRandomResultTablesRequest
// Size: 0x30(Inherited: 0x8) 
struct FAdminUpdateRandomResultTablesRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct TArray<struct UPlayFabJsonObject*> Tables;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildWithCustomContainer__DelegateSignature
// Size: 0xF8(Inherited: 0x0) 
struct FDelegateOnSuccessCreateBuildWithCustomContainer__DelegateSignature
{
	struct FMultiplayerCreateBuildWithCustomContainerResponse Result;  // 0x0(0xF0)
	struct UObject* customData;  // 0xF0(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithPlayFabRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientLoginWithPlayFabRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x10(0x8)
	struct FString Password;  // 0x18(0x10)
	struct FString Username;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerStatisticVersionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayerStatisticVersionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayerStatisticVersionsResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkGameCenterAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkGameCenterAccount__DelegateSignature
{
	struct FClientLinkGameCenterAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateSegment
// Size: 0x40(Inherited: 0x0) 
struct FUpdateSegment
{
	struct FAdminUpdateSegmentRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientCreateSharedGroupRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientCreateSharedGroupRequest : public FPlayFabRequestCommon
{
	struct FString SharedGroupId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.AdminUpdateSegmentRequest
// Size: 0x10(Inherited: 0x8) 
struct FAdminUpdateSegmentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* SegmentModel;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeServerLoginResultResponse
// Size: 0x70(Inherited: 0x0) 
struct FdecodeServerLoginResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerServerLoginResult ReturnValue;  // 0x8(0x68)

}; 
// Function PlayFab.PlayFabAdminAPI.UpdateStoreItems
// Size: 0x78(Inherited: 0x0) 
struct FUpdateStoreItems
{
	struct FAdminUpdateStoreItemsRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabAdminAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGoogleIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromGoogleIDs
{
	struct FClientGetPlayFabIDsFromGoogleIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperRemoveGroupInvitation
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveGroupInvitation
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AdminUpdateTaskRequest
// Size: 0x60(Inherited: 0x8) 
struct FAdminUpdateTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	struct UPlayFabJsonObject* Identifier;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool IsActive : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString Name;  // 0x30(0x10)
	struct UPlayFabJsonObject* Parameter;  // 0x40(0x8)
	struct FString Schedule;  // 0x48(0x10)
	uint8_t  Type;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserData
// Size: 0x70(Inherited: 0x0) 
struct FUpdateUserData
{
	struct FServerUpdateUserDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserPublisherData
// Size: 0x70(Inherited: 0x0) 
struct FUpdateUserPublisherData
{
	struct FServerUpdateUserDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetDraftItemResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyGetDraftItemResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Item;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkCustomIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkCustomIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkCustomIDResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserPublisherInternalData
// Size: 0x68(Inherited: 0x0) 
struct FUpdateUserPublisherInternalData
{
	struct FServerUpdateUserInternalDataRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.SetArrayField
// Size: 0x20(Inherited: 0x0) 
struct FSetArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<struct UPlayFabJsonValue*> inArray;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.UpdateUserTitleDisplayName
// Size: 0x50(Inherited: 0x0) 
struct FUpdateUserTitleDisplayName
{
	struct FClientUpdateUserTitleDisplayNameRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCancelAllMatchmakingTicketsForPlayerResult
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerCancelAllMatchmakingTicketsForPlayerResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientLinkFacebookAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkFacebookAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperGetLatestScorecard
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLatestScorecard
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AuthenticationEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FAuthenticationEmptyResponse : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessGetEntityToken__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetEntityToken__DelegateSignature
{
	struct FAuthenticationGetEntityTokenResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.AuthenticationValidateEntityTokenResponse
// Size: 0x30(Inherited: 0x8) 
struct FAuthenticationValidateEntityTokenResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	uint8_t  IdentifiedDeviceType;  // 0x10(0x1)
	uint8_t  IdentityProvider;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FString IdentityProviderIssuedId;  // 0x18(0x10)
	struct UPlayFabJsonObject* Lineage;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUnsubscribeFromLobbyResource__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnsubscribeFromLobbyResource__DelegateSignature
{
	struct FMultiplayerLobbyEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyDeleteEntityItemReviewsRequest
// Size: 0x18(Inherited: 0x8) 
struct FEconomyDeleteEntityItemReviewsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.AuthenticationDeleteRequest
// Size: 0x18(Inherited: 0x8) 
struct FAuthenticationDeleteRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetProfiles__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetProfiles__DelegateSignature
{
	struct FProfilesGetEntityProfilesResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkGoogleAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkGoogleAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientPurchaseItemRequest
// Size: 0x68(Inherited: 0x8) 
struct FClientPurchaseItemRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString ItemId;  // 0x30(0x10)
	int32_t Price;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString StoreId;  // 0x48(0x10)
	struct FString VirtualCurrency;  // 0x58(0x10)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessDeleteFiles__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteFiles__DelegateSignature
{
	struct FDataDeleteFilesResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientCancelTradeResponse
// Size: 0x10(Inherited: 0x8) 
struct FClientCancelTradeResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Trade;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAuthenticationAPI.GetEntityToken
// Size: 0x48(Inherited: 0x0) 
struct FGetEntityToken
{
	struct FAuthenticationGetEntityTokenRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabAuthenticationAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemoveSharedGroupMembers__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveSharedGroupMembers__DelegateSignature
{
	struct FServerRemoveSharedGroupMembersResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyCreateDraftItemRequest
// Size: 0x20(Inherited: 0x8) 
struct FEconomyCreateDraftItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Publish : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetServerBackfillTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetServerBackfillTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabInsightsAPI.HelperSetStorageRetention
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetStorageRetention
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.AuthenticationGetEntityTokenRequest
// Size: 0x18(Inherited: 0x8) 
struct FAuthenticationGetEntityTokenRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperAcceptTrade
// Size: 0x50(Inherited: 0x0) 
struct FHelperAcceptTrade
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAddUsernamePasswordResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeAddUsernamePasswordResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAddUsernamePasswordResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.GroupsListMembershipOpportunitiesResponse
// Size: 0x28(Inherited: 0x8) 
struct FGroupsListMembershipOpportunitiesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Applications;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Invitations;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabAuthenticationAPI.HelperGetEntityToken
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetEntityToken
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddFriend__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddFriend__DelegateSignature
{
	struct FServerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientAddFriendResult
// Size: 0x10(Inherited: 0x8) 
struct FClientAddFriendResult : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Created : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeTakedownItemReviewsResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeTakedownItemReviewsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyTakedownItemReviewsResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateRemoteUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateRemoteUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddGenericID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddGenericID__DelegateSignature
{
	struct FServerEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessTakedownItemReviews__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessTakedownItemReviews__DelegateSignature
{
	struct FEconomyTakedownItemReviewsResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEventsAPI.DelegateOnSuccessWriteTelemetryEvents__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessWriteTelemetryEvents__DelegateSignature
{
	struct FEventsWriteEventsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromFacebookInstantGamesIdsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromFacebookInstantGamesIdsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientAddGenericIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientAddGenericIDResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.UpdateSharedGroupData
// Size: 0x70(Inherited: 0x0) 
struct FUpdateSharedGroupData
{
	struct FServerUpdateSharedGroupDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkKongregateAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkKongregateAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientAddGenericIDRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientAddGenericIDRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* GenericId;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListBuildAliasesRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListBuildAliasesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t PageSize;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString SkipToken;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.AddOrUpdateContactEmail
// Size: 0x50(Inherited: 0x0) 
struct FAddOrUpdateContactEmail
{
	struct FClientAddOrUpdateContactEmailRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkAppleRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkAppleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerRegisterGameRequest
// Size: 0x90(Inherited: 0x8) 
struct FServerRegisterGameRequest : public FPlayFabRequestCommon
{
	struct FString Build;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString GameMode;  // 0x20(0x10)
	struct FString LobbyId;  // 0x30(0x10)
	uint8_t  Region;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString ServerIPV4Address;  // 0x48(0x10)
	struct FString ServerIPV6Address;  // 0x58(0x10)
	struct FString ServerPort;  // 0x68(0x10)
	struct FString ServerPublicDNSName;  // 0x78(0x10)
	struct UPlayFabJsonObject* Tags;  // 0x88(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddOrUpdateContactEmail__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddOrUpdateContactEmail__DelegateSignature
{
	struct FClientAddOrUpdateContactEmailResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientAddOrUpdateContactEmailResult
// Size: 0x8(Inherited: 0x8) 
struct FClientAddOrUpdateContactEmailResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.ReportPlayer
// Size: 0x70(Inherited: 0x0) 
struct FReportPlayer
{
	struct FServerReportPlayerServerRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRewardAdActivity__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FDelegateOnSuccessRewardAdActivity__DelegateSignature
{
	struct FClientRewardAdActivityResult Result;  // 0x0(0x58)
	struct UObject* customData;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientAddOrUpdateContactEmailRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientAddOrUpdateContactEmailRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString EmailAddress;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeDeletePushNotificationTemplateResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeletePushNotificationTemplateResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerDeletePushNotificationTemplateResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.AddSharedGroupMembers
// Size: 0x58(Inherited: 0x0) 
struct FAddSharedGroupMembers
{
	struct FServerAddSharedGroupMembersRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForEntityTriggeredAction__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPostFunctionResultForEntityTriggeredAction__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateLobby__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessCreateLobby__DelegateSignature
{
	struct FMultiplayerCreateLobbyResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ClientAddSharedGroupMembersResult
// Size: 0x8(Inherited: 0x8) 
struct FClientAddSharedGroupMembersResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkTwitch
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkTwitch
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperEnableMultiplayerServersForTitle
// Size: 0x50(Inherited: 0x0) 
struct FHelperEnableMultiplayerServersForTitle
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientAddSharedGroupMembersRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientAddSharedGroupMembersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabIds;  // 0x8(0x10)
	struct FString SharedGroupId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.AddUsernamePassword
// Size: 0x70(Inherited: 0x0) 
struct FAddUsernamePassword
{
	struct FClientAddUsernamePasswordRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeCreateDraftItemResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeCreateDraftItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyCreateDraftItemResponse ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddUsernamePassword__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessAddUsernamePassword__DelegateSignature
{
	struct FClientAddUsernamePasswordResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientAddUsernamePasswordRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientAddUsernamePasswordRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Email;  // 0x10(0x10)
	struct FString Password;  // 0x20(0x10)
	struct FString Username;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerListMatchmakingTicketsForPlayerResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerListMatchmakingTicketsForPlayerResult : public FPlayFabResultCommon
{
	struct FString TicketIds;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientAddUserVirtualCurrencyRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientAddUserVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString VirtualCurrency;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.AndroidDevicePushNotificationRegistration
// Size: 0x60(Inherited: 0x0) 
struct FAndroidDevicePushNotificationRegistration
{
	struct FClientAndroidDevicePushNotificationRegistrationRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAndroidDevicePushNotificationRegistration__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAndroidDevicePushNotificationRegistration__DelegateSignature
{
	struct FClientAndroidDevicePushNotificationRegistrationResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientValidateWindowsReceiptResult
// Size: 0x18(Inherited: 0x8) 
struct FClientValidateWindowsReceiptResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Fulfillments;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientAttributeInstallRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientAttributeInstallRequest : public FPlayFabRequestCommon
{
	struct FString Adid;  // 0x8(0x10)
	struct FString Idfa;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildWithProcessBasedServer__DelegateSignature
// Size: 0x100(Inherited: 0x0) 
struct FDelegateOnSuccessCreateBuildWithProcessBasedServer__DelegateSignature
{
	struct FMultiplayerCreateBuildWithProcessBasedServerResponse Result;  // 0x0(0xF8)
	struct UObject* customData;  // 0xF8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.CancelTrade
// Size: 0x48(Inherited: 0x0) 
struct FCancelTrade
{
	struct FClientCancelTradeRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkKongregate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkKongregate__DelegateSignature
{
	struct FClientUnlinkKongregateAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCancelMatchmakingTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperCancelMatchmakingTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetQueueStatisticsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetQueueStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetQueueStatisticsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientCancelTradeRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientCancelTradeRequest : public FPlayFabRequestCommon
{
	struct FString TradeId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.ConfirmPurchase
// Size: 0x50(Inherited: 0x0) 
struct FConfirmPurchase
{
	struct FClientConfirmPurchaseRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConfirmPurchase__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessConfirmPurchase__DelegateSignature
{
	struct FClientConfirmPurchaseResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetTitleMultiplayerServersQuotas
// Size: 0x40(Inherited: 0x0) 
struct FGetTitleMultiplayerServersQuotas
{
	struct FMultiplayerGetTitleMultiplayerServersQuotasRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetMultiplayerSessionLogsBySessionId
// Size: 0x50(Inherited: 0x0) 
struct FGetMultiplayerSessionLogsBySessionId
{
	struct FMultiplayerGetMultiplayerSessionLogsBySessionIdRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetLobbyRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetLobbyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientConfirmPurchaseResult
// Size: 0x38(Inherited: 0x8) 
struct FClientConfirmPurchaseResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)
	struct FString OrderID;  // 0x18(0x10)
	struct FString PurchaseDate;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.RedeemMatchmakerTicket
// Size: 0x60(Inherited: 0x0) 
struct FRedeemMatchmakerTicket
{
	struct FServerRedeemMatchmakerTicketRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetLeaderboardForUserCharacters
// Size: 0x58(Inherited: 0x0) 
struct FGetLeaderboardForUserCharacters
{
	struct FServerGetLeaderboardForUsersCharactersRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientConfirmPurchaseRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientConfirmPurchaseRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString OrderID;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientUpdateUserTitleDisplayNameResult
// Size: 0x18(Inherited: 0x8) 
struct FClientUpdateUserTitleDisplayNameResult : public FPlayFabResultCommon
{
	struct FString DisplayName;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.ConsumeItem
// Size: 0x78(Inherited: 0x0) 
struct FConsumeItem
{
	struct FServerConsumeItemRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessStartExperiment__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessStartExperiment__DelegateSignature
{
	struct FExperimentationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterStatistics__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCharacterStatistics__DelegateSignature
{
	struct FServerUpdateCharacterStatisticsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessConsumeItem__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessConsumeItem__DelegateSignature
{
	struct FServerConsumeItemResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardAroundPlayerResult
// Size: 0x30(Inherited: 0x8) 
struct FClientGetLeaderboardAroundPlayerResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)
	struct FString NextReset;  // 0x18(0x10)
	int32_t Version;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumeMicrosoftStoreEntitlements__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessConsumeMicrosoftStoreEntitlements__DelegateSignature
{
	struct FClientConsumeMicrosoftStoreEntitlementsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetLobbyResult
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetLobbyResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Lobby;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientConsumePS5EntitlementsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientConsumePS5EntitlementsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerCancelServerBackfillTicketResult
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerCancelServerBackfillTicketResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientConsumePSNEntitlementsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientConsumePSNEntitlementsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> ItemsGranted;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabInsightsAPI.GetPendingOperations
// Size: 0x50(Inherited: 0x0) 
struct FGetPendingOperations
{
	struct FInsightsInsightsGetPendingOperationsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabInsightsAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientConsumePSNEntitlementsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientConsumePSNEntitlementsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	int32_t ServiceLabel;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSubmitItemReviewVote__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSubmitItemReviewVote__DelegateSignature
{
	struct FEconomySubmitItemReviewVoteResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumeXboxEntitlements__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessConsumeXboxEntitlements__DelegateSignature
{
	struct FClientConsumeXboxEntitlementsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeResetUserStatisticsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeResetUserStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminResetUserStatisticsResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientConsumeXboxEntitlementsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientConsumeXboxEntitlementsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetCatalogItemsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetCatalogItemsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientConsumeXboxEntitlementsRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientConsumeXboxEntitlementsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString XboxToken;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientCreateSharedGroupResult
// Size: 0x18(Inherited: 0x8) 
struct FClientCreateSharedGroupResult : public FPlayFabResultCommon
{
	struct FString SharedGroupId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessExecuteCloudScript__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FDelegateOnSuccessExecuteCloudScript__DelegateSignature
{
	struct FServerExecuteCloudScriptResult Result;  // 0x0(0x60)
	struct UObject* customData;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkGooglePlayGamesServicesAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkGooglePlayGamesServicesAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString ServerAuthCode;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientExecuteCloudScriptResult
// Size: 0x60(Inherited: 0x8) 
struct FClientExecuteCloudScriptResult : public FPlayFabResultCommon
{
	int32_t APIRequestsIssued;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* Error;  // 0x10(0x8)
	int32_t ExecutionTimeSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString FunctionName;  // 0x20(0x10)
	struct UPlayFabJsonObject* FunctionResult;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool FunctionResultTooLarge : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t HttpRequestsIssued;  // 0x3C(0x4)
	struct TArray<struct UPlayFabJsonObject*> Logs;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool LogsTooLarge : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t MemoryConsumedBytes;  // 0x54(0x4)
	int32_t ProcessorTimeSeconds;  // 0x58(0x4)
	int32_t Revision;  // 0x5C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetAccountInfo__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetAccountInfo__DelegateSignature
{
	struct FClientGetAccountInfoResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkGooglePlayGamesServicesAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkGooglePlayGamesServicesAccount__DelegateSignature
{
	struct FClientLinkGooglePlayGamesServicesAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGetAccountInfoResult
// Size: 0x10(Inherited: 0x8) 
struct FClientGetAccountInfoResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* AccountInfo;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetAdPlacements__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetAdPlacements__DelegateSignature
{
	struct FClientGetAdPlacementsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdateSharedGroupDataResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUpdateSharedGroupDataResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientGetAdPlacementsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetAdPlacementsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> AdPlacements;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperSubscribeToLobbyResource
// Size: 0x50(Inherited: 0x0) 
struct FHelperSubscribeToLobbyResource
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetUserInventoryResult
// Size: 0x28(Inherited: 0x8) 
struct FClientGetUserInventoryResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Inventory;  // 0x8(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x18(0x8)
	struct UPlayFabJsonObject* VirtualCurrencyRechargeTimes;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.GetFiles
// Size: 0x48(Inherited: 0x0) 
struct FGetFiles
{
	struct FDataGetFilesRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetAllUsersCharacters__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetAllUsersCharacters__DelegateSignature
{
	struct FServerListUsersCharactersResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientListUsersCharactersResult
// Size: 0x18(Inherited: 0x8) 
struct FClientListUsersCharactersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Characters;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetTitleDataRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientGetTitleDataRequest : public FPlayFabRequestCommon
{
	struct FString Keys;  // 0x8(0x10)
	struct FString OverrideLabel;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeReportItemReviewResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeReportItemReviewResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyReportItemReviewResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeAddLocalizedNewsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAddLocalizedNewsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminAddLocalizedNewsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperShutdownMultiplayerServer
// Size: 0x50(Inherited: 0x0) 
struct FHelperShutdownMultiplayerServer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPhotonAuthenticationToken
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPhotonAuthenticationToken
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterData__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetCharacterData__DelegateSignature
{
	struct FServerGetCharacterDataResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabInsightsAPI.HelperGetOperationStatus
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetOperationStatus
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAddGenericID
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddGenericID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetCharacterDataResult
// Size: 0x28(Inherited: 0x8) 
struct FClientGetCharacterDataResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* Data;  // 0x18(0x8)
	int32_t DataVersion;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSendCustomAccountRecoveryEmailResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSendCustomAccountRecoveryEmailResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSendCustomAccountRecoveryEmailResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.GroupsAddMembersRequest
// Size: 0x38(Inherited: 0x8) 
struct FGroupsAddMembersRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x18(0x10)
	struct FString RoleId;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterInventory__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FDelegateOnSuccessGetCharacterInventory__DelegateSignature
{
	struct FServerGetCharacterInventoryResult Result;  // 0x0(0x48)
	struct UObject* customData;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientGetCharacterLeaderboardResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetCharacterLeaderboardResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessOpenTrade__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessOpenTrade__DelegateSignature
{
	struct FClientOpenTradeResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterStatistics__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetCharacterStatistics__DelegateSignature
{
	struct FServerGetCharacterStatisticsResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetMultiplayerSessionLogsBySessionIdRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetMultiplayerSessionLogsBySessionIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString SessionId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientGetTitlePublicKeyRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetTitlePublicKeyRequest : public FPlayFabRequestCommon
{
	struct FString TitleSharedSecret;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperReportAdActivity
// Size: 0x50(Inherited: 0x0) 
struct FHelperReportAdActivity
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithFacebookInstantGamesId__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithFacebookInstantGamesId__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientGetCharacterStatisticsResult
// Size: 0x10(Inherited: 0x8) 
struct FClientGetCharacterStatisticsResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* CharacterStatistics;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetTitleEnabledForMultiplayerServersStatus__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitleEnabledForMultiplayerServersStatus__DelegateSignature
{
	struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkOpenIdConnect
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkOpenIdConnect
{
	struct FClientUnlinkOpenIdConnectRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperSearchItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperSearchItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetContentDownloadUrl__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetContentDownloadUrl__DelegateSignature
{
	struct FServerGetContentDownloadUrlResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetContentDownloadUrlResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetContentDownloadUrlResult : public FPlayFabResultCommon
{
	struct FString URL;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerUpdateUserDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerUpdateUserDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	uint8_t  Permission;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.RemoveGenericID
// Size: 0x50(Inherited: 0x0) 
struct FRemoveGenericID
{
	struct FServerRemoveGenericIDRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptExecuteCloudScriptResult
// Size: 0x60(Inherited: 0x8) 
struct FCloudScriptExecuteCloudScriptResult : public FPlayFabResultCommon
{
	int32_t APIRequestsIssued;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* Error;  // 0x10(0x8)
	int32_t ExecutionTimeSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString FunctionName;  // 0x20(0x10)
	struct UPlayFabJsonObject* FunctionResult;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool FunctionResultTooLarge : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t HttpRequestsIssued;  // 0x3C(0x4)
	struct TArray<struct UPlayFabJsonObject*> Logs;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool LogsTooLarge : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t MemoryConsumedBytes;  // 0x54(0x4)
	int32_t ProcessorTimeSeconds;  // 0x58(0x4)
	int32_t Revision;  // 0x5C(0x4)

}; 
// ScriptStruct PlayFab.MultiplayerGetServerBackfillTicketRequest
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerGetServerBackfillTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool EscapeObject : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString QueueName;  // 0x18(0x10)
	struct FString TicketId;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCurrentGames__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetCurrentGames__DelegateSignature
{
	struct FClientCurrentGamesResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ClientCurrentGamesResult
// Size: 0x28(Inherited: 0x8) 
struct FClientCurrentGamesResult : public FPlayFabResultCommon
{
	int32_t GameCount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UPlayFabJsonObject*> Games;  // 0x10(0x10)
	int32_t PlayerCount;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardResult
// Size: 0x30(Inherited: 0x8) 
struct FClientGetLeaderboardResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)
	struct FString NextReset;  // 0x18(0x10)
	int32_t Version;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessUpdateRole__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateRole__DelegateSignature
{
	struct FGroupsUpdateGroupRoleResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupInvitationsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListGroupInvitationsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsListGroupInvitationsResponse ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetFriendLeaderboardAroundPlayer__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetFriendLeaderboardAroundPlayer__DelegateSignature
{
	struct FClientGetFriendLeaderboardAroundPlayerResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetFriendLeaderboard
// Size: 0x90(Inherited: 0x0) 
struct FGetFriendLeaderboard
{
	struct FServerGetFriendLeaderboardRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x88(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetFriendsList__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetFriendsList__DelegateSignature
{
	struct FServerGetFriendsListResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.GetField
// Size: 0x18(Inherited: 0x0) 
struct FGetField
{
	struct FString FieldName;  // 0x0(0x10)
	struct UPlayFabJsonValue* ReturnValue;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithTwitch__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithTwitch__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetGameServerRegions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetGameServerRegions__DelegateSignature
{
	struct FClientGameServerRegionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboard__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetLeaderboard__DelegateSignature
{
	struct FServerGetLeaderboardResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCharacterData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCharacterData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardAroundCharacterResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetLeaderboardAroundCharacterResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkAndroidDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkAndroidDeviceID
{
	struct FClientUnlinkAndroidDeviceIDRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetLeaderboardAroundPlayer__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetLeaderboardAroundPlayer__DelegateSignature
{
	struct FClientGetLeaderboardAroundPlayerResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildWithManagedContainerResponse
// Size: 0xF8(Inherited: 0x8) 
struct FMultiplayerCreateBuildWithManagedContainerResponse : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildId;  // 0x10(0x10)
	struct FString BuildName;  // 0x20(0x10)
	uint8_t  ContainerFlavor;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CreationTime;  // 0x38(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x48(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x58(0x10)
	struct FString GameWorkingDirectory;  // 0x68(0x10)
	struct UPlayFabJsonObject* InstrumentationConfiguration;  // 0x78(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x80(0x8)
	struct UPlayFabJsonObject* MonitoringApplicationConfiguration;  // 0x88(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FString OsPlatform;  // 0x98(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0xA8(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0xB8(0x10)
	struct UPlayFabJsonObject* ServerResourceConstraints;  // 0xC8(0x8)
	struct FString ServerType;  // 0xD0(0x10)
	struct FString StartMultiplayerServerCommand;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool UseStreamingForAssetDownloads : 1;  // 0xF0(0x1)
	uint8_t  VmSize;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPaymentToken__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetPaymentToken__DelegateSignature
{
	struct FClientGetPaymentTokenResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPhotonAuthenticationToken__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPhotonAuthenticationToken__DelegateSignature
{
	struct FClientGetPhotonAuthenticationTokenResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPhotonAuthenticationTokenResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPhotonAuthenticationTokenResult : public FPlayFabResultCommon
{
	struct FString PhotonCustomAuthenticationToken;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerCombinedInfoResult
// Size: 0x20(Inherited: 0x8) 
struct FClientGetPlayerCombinedInfoResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* InfoResultPayload;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerProfileResult
// Size: 0x10(Inherited: 0x8) 
struct FClientGetPlayerProfileResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* PlayerProfile;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerStatistics__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerStatistics__DelegateSignature
{
	struct FServerGetPlayerStatisticsResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayerStatisticsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayerStatisticsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Statistics;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerTrades__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayerTrades__DelegateSignature
{
	struct FClientGetPlayerTradesResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerTagsResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetPlayerTagsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayerTagsResult ReturnValue;  // 0x8(0x28)

}; 
// ScriptStruct PlayFab.ClientGetPlayerTradesResponse
// Size: 0x28(Inherited: 0x8) 
struct FClientGetPlayerTradesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> AcceptedTrades;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> OpenedTrades;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.ListGroupMembers
// Size: 0x48(Inherited: 0x0) 
struct FListGroupMembers
{
	struct FGroupsListGroupMembersRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromFacebookIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromFacebookIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.ReportItemReview
// Size: 0x88(Inherited: 0x0) 
struct FReportItemReview
{
	struct FEconomyReportItemReviewRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.ServerGetAllSegmentsRequest
// Size: 0x8(Inherited: 0x8) 
struct FServerGetAllSegmentsRequest : public FPlayFabRequestCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateSharedGroupData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateSharedGroupData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperAttributeInstall
// Size: 0x50(Inherited: 0x0) 
struct FHelperAttributeInstall
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromFacebookInstantGamesIds__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromFacebookInstantGamesIds__DelegateSignature
{
	struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromGenericIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromGenericIDs__DelegateSignature
{
	struct FServerGetPlayFabIDsFromGenericIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.HelperFinalizeFileUploads
// Size: 0x50(Inherited: 0x0) 
struct FHelperFinalizeFileUploads
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabProfilesAPI.GetProfiles
// Size: 0x58(Inherited: 0x0) 
struct FGetProfiles
{
	struct FProfilesGetEntityProfilesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGenericIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGenericIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperDeleteGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetAssetUploadUrl__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetAssetUploadUrl__DelegateSignature
{
	struct FMultiplayerGetAssetUploadUrlResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGoogleIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromGoogleIDs__DelegateSignature
{
	struct FClientGetPlayFabIDsFromGoogleIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGoogleIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGoogleIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromNintendoServiceAccountIds__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromNintendoServiceAccountIds__DelegateSignature
{
	struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerAddPlayerTagResult
// Size: 0x8(Inherited: 0x8) 
struct FServerAddPlayerTagResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.DataGetFilesRequest
// Size: 0x18(Inherited: 0x8) 
struct FDataGetFilesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabEventsAPI.HelperWriteEvents
// Size: 0x50(Inherited: 0x0) 
struct FHelperWriteEvents
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetLobby
// Size: 0x50(Inherited: 0x0) 
struct FGetLobby
{
	struct FMultiplayerGetLobbyRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromNintendoServiceAccountIdsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromNintendoServiceAccountIdsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromNintendoSwitchDeviceIds__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromNintendoSwitchDeviceIds__DelegateSignature
{
	struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromNintendoSwitchDeviceIdsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromNintendoSwitchDeviceIdsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerJoinMatchmakingTicketRequest
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerJoinMatchmakingTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Member;  // 0x10(0x8)
	struct FString QueueName;  // 0x18(0x10)
	struct FString TicketId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperConsumePSNEntitlements
// Size: 0x50(Inherited: 0x0) 
struct FHelperConsumePSNEntitlements
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromPSNAccountIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromPSNAccountIDs__DelegateSignature
{
	struct FServerGetPlayFabIDsFromPSNAccountIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromSteamIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromSteamIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperCreateUploadUrls
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateUploadUrls
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromTwitchIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromTwitchIDs__DelegateSignature
{
	struct FServerGetPlayFabIDsFromTwitchIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSavePushNotificationTemplateResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeSavePushNotificationTemplateResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSavePushNotificationTemplateResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientGetPlayerStatisticVersionsRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientGetPlayerStatisticVersionsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString StatisticName;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithPlayFab
// Size: 0x68(Inherited: 0x0) 
struct FLoginWithPlayFab
{
	struct FClientLoginWithPlayFabRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.GetExclusionGroups
// Size: 0x40(Inherited: 0x0) 
struct FGetExclusionGroups
{
	struct FExperimentationGetExclusionGroupsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromTwitchIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromTwitchIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromXboxLiveIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPlayFabIDsFromXboxLiveIDs__DelegateSignature
{
	struct FServerGetPlayFabIDsFromXboxLiveIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemReviewSummaryResponse
// Size: 0x28(Inherited: 0x8) 
struct FEconomyGetItemReviewSummaryResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* LeastFavorableReview;  // 0x8(0x8)
	struct UPlayFabJsonObject* MostFavorableReview;  // 0x10(0x8)
	struct UPlayFabJsonObject* Rating;  // 0x18(0x8)
	int32_t ReviewsCount;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListServerBackfillTicketsForPlayerResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListServerBackfillTicketsForPlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListServerBackfillTicketsForPlayerResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromXboxLiveIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromXboxLiveIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ExperimentationGetTreatmentAssignmentResult
// Size: 0x10(Inherited: 0x8) 
struct FExperimentationGetTreatmentAssignmentResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* TreatmentAssignment;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPublisherDataResult
// Size: 0x10(Inherited: 0x8) 
struct FClientGetPublisherDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPurchase__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FDelegateOnSuccessGetPurchase__DelegateSignature
{
	struct FClientGetPurchaseResult Result;  // 0x0(0x58)
	struct UObject* customData;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeRolloverContainerRegistryCredentialsResponseResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeRolloverContainerRegistryCredentialsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerRolloverContainerRegistryCredentialsResponse ReturnValue;  // 0x8(0x38)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetServerBackfillTicket__DelegateSignature
// Size: 0x90(Inherited: 0x0) 
struct FDelegateOnSuccessGetServerBackfillTicket__DelegateSignature
{
	struct FMultiplayerGetServerBackfillTicketResult Result;  // 0x0(0x88)
	struct UObject* customData;  // 0x88(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPurchaseResult
// Size: 0x58(Inherited: 0x8) 
struct FClientGetPurchaseResult : public FPlayFabResultCommon
{
	struct FString OrderID;  // 0x8(0x10)
	struct FString PaymentProvider;  // 0x18(0x10)
	struct FString PurchaseDate;  // 0x28(0x10)
	struct FString TransactionId;  // 0x38(0x10)
	struct FString TransactionStatus;  // 0x48(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperLoginWithServerCustomId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithServerCustomId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetSharedGroupData__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetSharedGroupData__DelegateSignature
{
	struct FServerGetSharedGroupDataResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientGetTimeResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetTimeResult : public FPlayFabResultCommon
{
	struct FString time;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetTitleDataResult
// Size: 0x10(Inherited: 0x8) 
struct FClientGetTitleDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkFacebookAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkFacebookAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkFacebookAccountResult ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTitlePublicKey__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitlePublicKey__DelegateSignature
{
	struct FClientGetTitlePublicKeyResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetTitlePublicKeyResult
// Size: 0x18(Inherited: 0x8) 
struct FClientGetTitlePublicKeyResult : public FPlayFabResultCommon
{
	struct FString RSAPublicKey;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTradeStatus__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTradeStatus__DelegateSignature
{
	struct FClientGetTradeStatusResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ClientGetTradeStatusResponse
// Size: 0x10(Inherited: 0x8) 
struct FClientGetTradeStatusResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Trade;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantCharacterToUser__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGrantCharacterToUser__DelegateSignature
{
	struct FServerGrantCharacterToUserResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.DeleteRole
// Size: 0x58(Inherited: 0x0) 
struct FDeleteRole
{
	struct FGroupsDeleteRoleRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkAndroidDeviceID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkAndroidDeviceID__DelegateSignature
{
	struct FClientLinkAndroidDeviceIDResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetTaskInstancesResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetTaskInstancesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetTaskInstancesResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientLinkFacebookInstantGamesIdResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkFacebookInstantGamesIdResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkGoogleAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkGoogleAccount__DelegateSignature
{
	struct FClientLinkGoogleAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemReviewSummaryRequest
// Size: 0x28(Inherited: 0x8) 
struct FEconomyGetItemReviewSummaryRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString ID;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAddFriend
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddFriend
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLinkGooglePlayGamesServicesAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkGooglePlayGamesServicesAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientLinkIOSDeviceIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkIOSDeviceIDResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkNintendoServiceAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkNintendoServiceAccount__DelegateSignature
{
	struct FClientEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessRolloverContainerRegistryCredentials__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessRolloverContainerRegistryCredentials__DelegateSignature
{
	struct FMultiplayerRolloverContainerRegistryCredentialsResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkNintendoSwitchDeviceId__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkNintendoSwitchDeviceId__DelegateSignature
{
	struct FClientLinkNintendoSwitchDeviceIdResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkPSNAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkPSNAccount__DelegateSignature
{
	struct FServerLinkPSNAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGameCenterIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromGameCenterIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPlayFabIDsFromGameCenterIDsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientLinkPSNAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkPSNAccountResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupApplications__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListGroupApplications__DelegateSignature
{
	struct FGroupsListGroupApplicationsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkSteamAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkSteamAccount__DelegateSignature
{
	struct FClientLinkSteamAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromSteamIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromSteamIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabJsonValue.ConstructJsonValueNumber
// Size: 0x18(Inherited: 0x0) 
struct FConstructJsonValueNumber
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	float Number;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonValue* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkSteamAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientLinkSteamAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.MultiplayerListAssetSummariesResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListAssetSummariesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> AssetSummaries;  // 0x8(0x10)
	int32_t PageSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessRegisterHttpFunction__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRegisterHttpFunction__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperUpdateDraftItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateDraftItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientExecuteCloudScriptRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientExecuteCloudScriptRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FunctionName;  // 0x10(0x10)
	struct UPlayFabJsonObject* FunctionParameter;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool GeneratePlayStreamEvent : 1;  // 0x28(0x1)
	uint8_t  RevisionSelection;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t SpecificRevision;  // 0x2C(0x4)

}; 
// ScriptStruct PlayFab.ClientSetPlayerSecretResult
// Size: 0x8(Inherited: 0x8) 
struct FClientSetPlayerSecretResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkTwitch__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkTwitch__DelegateSignature
{
	struct FClientLinkTwitchAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkGooglePlayGamesServicesAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkGooglePlayGamesServicesAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkXboxAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkXboxAccount__DelegateSignature
{
	struct FServerLinkXboxAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithAndroidDeviceID__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithAndroidDeviceID__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.PlayFabLoginResultCommon
// Size: 0x10(Inherited: 0x8) 
struct FPlayFabLoginResultCommon : public FPlayFabResultCommon
{
	struct UPlayFabAuthenticationContext* AuthenticationContext;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabUtilities.setPlayFabSettings
// Size: 0x60(Inherited: 0x0) 
struct FsetPlayFabSettings
{
	struct FString GameTitleId;  // 0x0(0x10)
	struct FString PlayFabSecretApiKey;  // 0x10(0x10)
	struct FString ProductionUrl;  // 0x20(0x10)
	struct FString PhotonRealtimeAppId;  // 0x30(0x10)
	struct FString PhotonTurnbasedAppId;  // 0x40(0x10)
	struct FString PhotonChatAppId;  // 0x50(0x10)

}; 
// ScriptStruct PlayFab.CloudScriptRegisterHttpFunctionRequest
// Size: 0x30(Inherited: 0x8) 
struct FCloudScriptRegisterHttpFunctionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FunctionName;  // 0x10(0x10)
	struct FString FunctionUrl;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientLoginResult
// Size: 0x68(Inherited: 0x10) 
struct FClientLoginResult : public FPlayFabLoginResultCommon
{
	struct UPlayFabJsonObject* EntityToken;  // 0x10(0x8)
	struct UPlayFabJsonObject* InfoResultPayload;  // 0x18(0x8)
	struct FString LastLoginTime;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool NewlyCreated : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString PlayFabId;  // 0x38(0x10)
	struct FString SessionTicket;  // 0x48(0x10)
	struct UPlayFabJsonObject* SettingsForUser;  // 0x58(0x8)
	struct UPlayFabJsonObject* TreatmentAssignment;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithApple__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithApple__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListServerBackfillTicketsForPlayerResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerListServerBackfillTicketsForPlayerResult : public FPlayFabResultCommon
{
	struct FString TicketIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.UpdateRole
// Size: 0x70(Inherited: 0x0) 
struct FUpdateRole
{
	struct FGroupsUpdateGroupRoleRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardAroundCharacterRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientGetLeaderboardAroundCharacterRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString CharacterType;  // 0x18(0x10)
	int32_t MaxResultsCount;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString StatisticName;  // 0x30(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithGoogleAccount__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithGoogleAccount__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemModerationStateResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyGetItemModerationStateResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* State;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkCustomIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkCustomIDResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListContainerImages
// Size: 0x50(Inherited: 0x0) 
struct FHelperListContainerImages
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithGooglePlayGamesServices__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithGooglePlayGamesServices__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ServerWriteServerCharacterEventRequest
// Size: 0x58(Inherited: 0x8) 
struct FServerWriteServerCharacterEventRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Body;  // 0x8(0x8)
	struct FString CharacterId;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EventName;  // 0x28(0x10)
	struct FString PlayFabId;  // 0x38(0x10)
	struct FString Timestamp;  // 0x48(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithIOSDeviceID__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithIOSDeviceID__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateLobbyResult
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerCreateLobbyResult : public FPlayFabResultCommon
{
	struct FString ConnectionString;  // 0x8(0x10)
	struct FString LobbyId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperListQueuedFunctions
// Size: 0x50(Inherited: 0x0) 
struct FHelperListQueuedFunctions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithKongregate__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithKongregate__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetItemReviews
// Size: 0x80(Inherited: 0x0) 
struct FGetItemReviews
{
	struct FEconomyGetItemReviewsRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithNintendoServiceAccount__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithNintendoServiceAccount__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.ExecuteCloudScript
// Size: 0x78(Inherited: 0x0) 
struct FExecuteCloudScript
{
	struct FServerExecuteCloudScriptServerRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMultiplayerServerDetails__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FDelegateOnSuccessGetMultiplayerServerDetails__DelegateSignature
{
	struct FMultiplayerGetMultiplayerServerDetailsResponse Result;  // 0x0(0xB8)
	struct UObject* customData;  // 0xB8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithNintendoSwitchDeviceId__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithNintendoSwitchDeviceId__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithOpenIdConnect__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithOpenIdConnect__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithPlayFab__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithPlayFab__DelegateSignature
{
	struct FClientLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ServerAwardSteamAchievementRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerAwardSteamAchievementRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Achievements;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithXbox__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithXbox__DelegateSignature
{
	struct FServerServerLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayerSegmentsRequest
// Size: 0x8(Inherited: 0x8) 
struct FClientGetPlayerSegmentsRequest : public FPlayFabRequestCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessMatchmake__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FDelegateOnSuccessMatchmake__DelegateSignature
{
	struct FClientMatchmakeResult Result;  // 0x0(0x80)
	struct UObject* customData;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.ClientMatchmakeResult
// Size: 0x80(Inherited: 0x8) 
struct FClientMatchmakeResult : public FPlayFabResultCommon
{
	struct FString Expires;  // 0x8(0x10)
	struct FString LobbyId;  // 0x18(0x10)
	int32_t PollWaitTimeMS;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString ServerIPV4Address;  // 0x30(0x10)
	struct FString ServerIPV6Address;  // 0x40(0x10)
	int32_t ServerPort;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString ServerPublicDNSName;  // 0x58(0x10)
	uint8_t  Status;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FString Ticket;  // 0x70(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodePurchaseItemResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodePurchaseItemResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientPurchaseItemResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetTitleEnabledForMultiplayerServersStatus
// Size: 0x40(Inherited: 0x0) 
struct FGetTitleEnabledForMultiplayerServersStatus
{
	struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessPayForPurchase__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FDelegateOnSuccessPayForPurchase__DelegateSignature
{
	struct FClientPayForPurchaseResult Result;  // 0x0(0x78)
	struct UObject* customData;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetAssetUploadUrl
// Size: 0x50(Inherited: 0x0) 
struct FGetAssetUploadUrl
{
	struct FMultiplayerGetAssetUploadUrlRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessPurchaseItem__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessPurchaseItem__DelegateSignature
{
	struct FClientPurchaseItemResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkAndroidDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkAndroidDeviceID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUpdateUserDataResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeUpdateUserDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUpdateUserDataResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetSegmentsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetSegmentsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetSegmentsResponse ReturnValue;  // 0x8(0x28)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGenericIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGenericIDsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> GenericIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientPurchaseItemResult
// Size: 0x18(Inherited: 0x8) 
struct FClientPurchaseItemResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessGetObjects__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetObjects__DelegateSignature
{
	struct FDataGetObjectsResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRedeemCoupon__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRedeemCoupon__DelegateSignature
{
	struct FServerRedeemCouponResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientRedeemCouponResult
// Size: 0x18(Inherited: 0x8) 
struct FClientRedeemCouponResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> GrantedItems;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRefreshPSNAuthToken__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRefreshPSNAuthToken__DelegateSignature
{
	struct FClientEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerWriteServerPlayerEventRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerWriteServerPlayerEventRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Body;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EventName;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)
	struct FString Timestamp;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetAllUsersCharacters
// Size: 0x48(Inherited: 0x0) 
struct FGetAllUsersCharacters
{
	struct FServerListUsersCharactersRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientRegisterPlayFabUserResult
// Size: 0x48(Inherited: 0x8) 
struct FClientRegisterPlayFabUserResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* EntityToken;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString SessionTicket;  // 0x20(0x10)
	struct UPlayFabJsonObject* SettingsForUser;  // 0x30(0x8)
	struct FString Username;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeExportMasterPlayerDataResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeExportMasterPlayerDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminExportMasterPlayerDataResult ReturnValue;  // 0x8(0x18)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkServerCustomId__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLinkServerCustomId__DelegateSignature
{
	struct FServerLinkServerCustomIdResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientRewardAdActivityResult
// Size: 0x58(Inherited: 0x8) 
struct FClientRewardAdActivityResult : public FPlayFabResultCommon
{
	struct FString AdActivityEventId;  // 0x8(0x10)
	struct FString DebugResults;  // 0x18(0x10)
	struct FString PlacementId;  // 0x28(0x10)
	struct FString PlacementName;  // 0x38(0x10)
	int32_t PlacementViewsRemaining;  // 0x48(0x4)
	int32_t PlacementViewsResetMinutes;  // 0x4C(0x4)
	struct UPlayFabJsonObject* RewardResults;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateAmazonIAPReceipt__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessValidateAmazonIAPReceipt__DelegateSignature
{
	struct FClientValidateAmazonReceiptResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRemoveContactEmail__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveContactEmail__DelegateSignature
{
	struct FClientRemoveContactEmailResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientRemoveFriendResult
// Size: 0x8(Inherited: 0x8) 
struct FClientRemoveFriendResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientRemoveContactEmailResult
// Size: 0x8(Inherited: 0x8) 
struct FClientRemoveContactEmailResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessJoinMatchmakingTicket__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessJoinMatchmakingTicket__DelegateSignature
{
	struct FMultiplayerJoinMatchmakingTicketResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateMatchmakingTicket
// Size: 0x70(Inherited: 0x0) 
struct FCreateMatchmakingTicket
{
	struct FMultiplayerCreateMatchmakingTicketRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ClientRemoveGenericIDResult
// Size: 0x8(Inherited: 0x8) 
struct FClientRemoveGenericIDResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeCreatePlayerStatisticDefinitionResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeCreatePlayerStatisticDefinitionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminCreatePlayerStatisticDefinitionResult ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemoveFriend__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveFriend__DelegateSignature
{
	struct FServerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemoveGenericID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveGenericID__DelegateSignature
{
	struct FServerEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeLinkXboxAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkXboxAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerLinkXboxAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromKongregateIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromKongregateIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPlayFabIDsFromKongregateIDsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromXboxLiveIDsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromXboxLiveIDsRequest : public FPlayFabRequestCommon
{
	struct FString Sandbox;  // 0x8(0x10)
	struct FString XboxLiveAccountIDs;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.CreateRole
// Size: 0x68(Inherited: 0x0) 
struct FCreateRole
{
	struct FGroupsCreateGroupRoleRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessReportAdActivity__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessReportAdActivity__DelegateSignature
{
	struct FClientReportAdActivityResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetPolicyResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetPolicyResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetPolicyResponse ReturnValue;  // 0x8(0x30)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessReportDeviceInfo__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessReportDeviceInfo__DelegateSignature
{
	struct FClientEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessRequestMultiplayerServer__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FDelegateOnSuccessRequestMultiplayerServer__DelegateSignature
{
	struct FMultiplayerRequestMultiplayerServerResponse Result;  // 0x0(0xB8)
	struct UObject* customData;  // 0xB8(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromTwitchIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromTwitchIDsRequest : public FPlayFabRequestCommon
{
	struct FString TwitchIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.AcceptGroupInvitation
// Size: 0x50(Inherited: 0x0) 
struct FAcceptGroupInvitation
{
	struct FGroupsAcceptGroupInvitationRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.InsightsInsightsGetPendingOperationsResponse
// Size: 0x18(Inherited: 0x8) 
struct FInsightsInsightsGetPendingOperationsResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> PendingOperations;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientReportPlayerClientResult
// Size: 0x10(Inherited: 0x8) 
struct FClientReportPlayerClientResult : public FPlayFabResultCommon
{
	int32_t SubmissionsRemaining;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.ClientSendAccountRecoveryEmailResult
// Size: 0x8(Inherited: 0x8) 
struct FClientSendAccountRecoveryEmailResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.SendPushNotification
// Size: 0x98(Inherited: 0x0) 
struct FSendPushNotification
{
	struct FServerSendPushNotificationRequest Request;  // 0x0(0x68)
	struct FDelegate onSuccess;  // 0x68(0x10)
	struct FDelegate onFailure;  // 0x78(0x10)
	struct UObject* customData;  // 0x88(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x90(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationGetExperimentsRequest
// Size: 0x10(Inherited: 0x8) 
struct FExperimentationGetExperimentsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetFriendTags__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetFriendTags__DelegateSignature
{
	struct FServerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessStartPurchase__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FDelegateOnSuccessStartPurchase__DelegateSignature
{
	struct FClientStartPurchaseResult Result;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetLeaderboardAroundPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLeaderboardAroundPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientStartPurchaseResult
// Size: 0x40(Inherited: 0x8) 
struct FClientStartPurchaseResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Contents;  // 0x8(0x10)
	struct FString OrderID;  // 0x18(0x10)
	struct TArray<struct UPlayFabJsonObject*> PaymentOptions;  // 0x28(0x10)
	struct UPlayFabJsonObject* VirtualCurrencyBalances;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperGetTreatmentAssignment
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTreatmentAssignment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientUpdateCharacterStatisticsResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUpdateCharacterStatisticsResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkAndroidDeviceID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkAndroidDeviceID__DelegateSignature
{
	struct FClientUnlinkAndroidDeviceIDResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkCustomID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkCustomID__DelegateSignature
{
	struct FClientUnlinkCustomIDResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdateUserDataResult
// Size: 0x10(Inherited: 0x8) 
struct FClientUpdateUserDataResult : public FPlayFabResultCommon
{
	int32_t DataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.ClientUnlinkFacebookAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkFacebookAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGooglePlayGamesPlayerIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromGooglePlayGamesPlayerIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkNintendoServiceAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkNintendoServiceAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientUnlinkFacebookInstantGamesIdResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkFacebookInstantGamesIdResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkGameCenterAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkGameCenterAccount__DelegateSignature
{
	struct FClientUnlinkGameCenterAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetRemoteLoginEndpointResponse
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetRemoteLoginEndpointResponse : public FPlayFabResultCommon
{
	struct FString IPV4Address;  // 0x8(0x10)
	int32_t Port;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperSetProfilePolicy
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetProfilePolicy
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkGoogleAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkGoogleAccount__DelegateSignature
{
	struct FClientUnlinkGoogleAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerBanUsersResult
// Size: 0x18(Inherited: 0x8) 
struct FServerBanUsersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkGoogleAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkGoogleAccountResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabJsonObject.SetObjectArrayField
// Size: 0x20(Inherited: 0x0) 
struct FSetObjectArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<struct UPlayFabJsonObject*> ObjectArray;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkGooglePlayGamesServicesAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkGooglePlayGamesServicesAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientSendAccountRecoveryEmailRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientSendAccountRecoveryEmailRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Email;  // 0x10(0x10)
	struct FString EmailTemplateId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LinkCustomID
// Size: 0x58(Inherited: 0x0) 
struct FLinkCustomID
{
	struct FClientLinkCustomIDRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetCharacterInventory
// Size: 0x70(Inherited: 0x0) 
struct FGetCharacterInventory
{
	struct FServerGetCharacterInventoryRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessUpdateDraftItem__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateDraftItem__DelegateSignature
{
	struct FEconomyUpdateDraftItemResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkIOSDeviceID__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkIOSDeviceID__DelegateSignature
{
	struct FClientUnlinkIOSDeviceIDResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithApple
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithApple
{
	struct FClientLoginWithAppleRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkNintendoServiceAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkNintendoServiceAccount__DelegateSignature
{
	struct FClientEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetPurchase
// Size: 0x48(Inherited: 0x0) 
struct FGetPurchase
{
	struct FClientGetPurchaseRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetFriendsList
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetFriendsList
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSubtractCharacterVirtualCurrency__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessSubtractCharacterVirtualCurrency__DelegateSignature
{
	struct FServerModifyCharacterVirtualCurrencyResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientGetUserInventoryRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientGetUserInventoryRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkNintendoSwitchDeviceId__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkNintendoSwitchDeviceId__DelegateSignature
{
	struct FClientUnlinkNintendoSwitchDeviceIdResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGetAdPlacementsRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientGetAdPlacementsRequest : public FPlayFabRequestCommon
{
	struct FString AppID;  // 0x8(0x10)
	struct UPlayFabJsonObject* Identifier;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerGetTimeResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetTimeResult : public FPlayFabResultCommon
{
	struct FString time;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientUnlinkNintendoSwitchDeviceIdResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkNintendoSwitchDeviceIdResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkSteamAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkSteamAccount__DelegateSignature
{
	struct FClientUnlinkSteamAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ProfilesGetGlobalPolicyResponse
// Size: 0x18(Inherited: 0x8) 
struct FProfilesGetGlobalPolicyResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Permissions;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperWritePlayerEvent
// Size: 0x50(Inherited: 0x0) 
struct FHelperWritePlayerEvent
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientUnlinkSteamAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkSteamAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.InsightsInsightsGetDetailsResponse
// Size: 0x40(Inherited: 0x8) 
struct FInsightsInsightsGetDetailsResponse : public FPlayFabResultCommon
{
	int32_t DataUsageMb;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString ErrorMessage;  // 0x10(0x10)
	struct UPlayFabJsonObject* Limits;  // 0x20(0x8)
	struct TArray<struct UPlayFabJsonObject*> PendingOperations;  // 0x28(0x10)
	int32_t PerformanceLevel;  // 0x38(0x4)
	int32_t RetentionDays;  // 0x3C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkXboxAccount__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkXboxAccount__DelegateSignature
{
	struct FServerUnlinkXboxAccountResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdateSharedGroupDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientUpdateSharedGroupDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	uint8_t  Permission;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString SharedGroupId;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetServerBackfillTicket
// Size: 0x68(Inherited: 0x0) 
struct FGetServerBackfillTicket
{
	struct FMultiplayerGetServerBackfillTicketRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkXboxAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUnlinkXboxAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientUnlinkFacebookInstantGamesIdRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkFacebookInstantGamesIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FacebookInstantGamesId;  // 0x10(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlockContainerItem__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FDelegateOnSuccessUnlockContainerItem__DelegateSignature
{
	struct FServerUnlockContainerItemResult Result;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateAvatarUrl__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateAvatarUrl__DelegateSignature
{
	struct FServerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperStartPurchase
// Size: 0x50(Inherited: 0x0) 
struct FHelperStartPurchase
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.EconomyGetDraftItemRequest
// Size: 0x30(Inherited: 0x8) 
struct FEconomyGetDraftItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ID;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientUpdateCharacterDataResult
// Size: 0x10(Inherited: 0x8) 
struct FClientUpdateCharacterDataResult : public FPlayFabResultCommon
{
	int32_t DataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.ClientUpdatePlayerStatisticsResult
// Size: 0x8(Inherited: 0x8) 
struct FClientUpdatePlayerStatisticsResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeUpdateCatalogConfigResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdateCatalogConfigResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyUpdateCatalogConfigResponse ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerUnlinkServerCustomIdRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerUnlinkServerCustomIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString ServerCustomId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.IsMember
// Size: 0x60(Inherited: 0x0) 
struct FIsMember
{
	struct FGroupsIsMemberRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SendEmailFromTemplate
// Size: 0x60(Inherited: 0x0) 
struct FSendEmailFromTemplate
{
	struct FServerSendEmailFromTemplateRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateGooglePlayPurchase__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessValidateGooglePlayPurchase__DelegateSignature
{
	struct FClientValidateGooglePlayPurchaseResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromNintendoServiceAccountIdsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromNintendoServiceAccountIdsRequest : public FPlayFabRequestCommon
{
	struct FString NintendoAccountIds;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientValidateGooglePlayPurchaseResult
// Size: 0x18(Inherited: 0x8) 
struct FClientValidateGooglePlayPurchaseResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Fulfillments;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientValidateIOSReceiptResult
// Size: 0x18(Inherited: 0x8) 
struct FClientValidateIOSReceiptResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Fulfillments;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardAroundPlayerRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientGetLeaderboardAroundPlayerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t MaxResultsCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x28(0x8)
	struct FString StatisticName;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool UseSpecificVersion : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Version;  // 0x44(0x4)

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperGetTitlePlayersFromMasterPlayerAccountIds
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitlePlayersFromMasterPlayerAccountIds
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateWindowsStoreReceipt__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessValidateWindowsStoreReceipt__DelegateSignature
{
	struct FClientValidateWindowsReceiptResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetGameServerRegions
// Size: 0x48(Inherited: 0x0) 
struct FGetGameServerRegions
{
	struct FClientGameServerRegionsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessWritePlayerEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessWritePlayerEvent__DelegateSignature
{
	struct FServerWriteEventResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetItemPublishStatus
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetItemPublishStatus
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.GetAdPlacements
// Size: 0x50(Inherited: 0x0) 
struct FGetAdPlacements
{
	struct FClientGetAdPlacementsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LinkSteamAccount
// Size: 0x58(Inherited: 0x0) 
struct FLinkSteamAccount
{
	struct FClientLinkSteamAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientRemoveSharedGroupMembersRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientRemoveSharedGroupMembersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabIds;  // 0x8(0x10)
	struct FString SharedGroupId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperRolloverContainerRegistryCredentials
// Size: 0x50(Inherited: 0x0) 
struct FHelperRolloverContainerRegistryCredentials
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLoginResultResponse
// Size: 0x70(Inherited: 0x0) 
struct FdecodeLoginResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLoginResult ReturnValue;  // 0x8(0x68)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ShutdownMultiplayerServer
// Size: 0x50(Inherited: 0x0) 
struct FShutdownMultiplayerServer
{
	struct FMultiplayerShutdownMultiplayerServerRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetFriendLeaderboard
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetFriendLeaderboard
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetCharacterDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientGetCharacterDataRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	int32_t IfChangedFromDataVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Keys;  // 0x20(0x10)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ClientGetCharacterStatisticsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetCharacterStatisticsRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetTitleEnabledForMultiplayerServersStatus
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitleEnabledForMultiplayerServersStatus
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetContentDownloadUrl
// Size: 0x60(Inherited: 0x0) 
struct FGetContentDownloadUrl
{
	struct FServerGetContentDownloadUrlRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.ListQueuedFunctions
// Size: 0x40(Inherited: 0x0) 
struct FListQueuedFunctions
{
	struct FCloudScriptListFunctionsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientGetContentDownloadUrlRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetContentDownloadUrlRequest : public FPlayFabRequestCommon
{
	struct FString HttpMethod;  // 0x8(0x10)
	struct FString Key;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ThruCDN : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetDraftItem__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetDraftItem__DelegateSignature
{
	struct FEconomyGetDraftItemResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetCurrentGames
// Size: 0x78(Inherited: 0x0) 
struct FGetCurrentGames
{
	struct FClientCurrentGamesRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerUpdateBuildNameRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerUpdateBuildNameRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct FString BuildName;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetFriendLeaderboardAroundPlayer
// Size: 0x88(Inherited: 0x0) 
struct FGetFriendLeaderboardAroundPlayer
{
	struct FClientGetFriendLeaderboardAroundPlayerRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.DataSetObjectsResponse
// Size: 0x20(Inherited: 0x8) 
struct FDataSetObjectsResponse : public FPlayFabResultCommon
{
	int32_t ProfileVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UPlayFabJsonObject*> SetResults;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteAsset
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteAsset
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetFriendLeaderboardAroundPlayerRequest
// Size: 0x58(Inherited: 0x8) 
struct FClientGetFriendLeaderboardAroundPlayerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IncludeFacebookFriends : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IncludeSteamFriends : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t MaxResultsCount;  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x28(0x8)
	struct FString StatisticName;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool UseSpecificVersion : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Version;  // 0x44(0x4)
	struct FString XboxToken;  // 0x48(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.AcceptGroupApplication
// Size: 0x50(Inherited: 0x0) 
struct FAcceptGroupApplication
{
	struct FGroupsAcceptGroupApplicationRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientGetFriendsListRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetFriendsListRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IncludeFacebookFriends : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IncludeSteamFriends : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x18(0x8)
	struct FString XboxToken;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkGameCenterAccountRequest
// Size: 0x68(Inherited: 0x8) 
struct FClientLinkGameCenterAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString GameCenterId;  // 0x18(0x10)
	struct FString PublicKeyUrl;  // 0x28(0x10)
	struct FString Salt;  // 0x38(0x10)
	struct FString Signature;  // 0x48(0x10)
	struct FString Timestamp;  // 0x58(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkServerCustomIdResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkServerCustomIdResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUnlinkServerCustomIdResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientGameServerRegionsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGameServerRegionsRequest : public FPlayFabRequestCommon
{
	struct FString BuildVersion;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetLeaderboardRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientGetLeaderboardRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t MaxResultsCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x18(0x8)
	int32_t StartPosition;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString StatisticName;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool UseSpecificVersion : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t Version;  // 0x3C(0x4)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCancelServerBackfillTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperCancelServerBackfillTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteSegmentsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeDeleteSegmentsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeleteSegmentsResponse ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.CloudScriptRegisterQueuedFunctionRequest
// Size: 0x40(Inherited: 0x8) 
struct FCloudScriptRegisterQueuedFunctionRequest : public FPlayFabRequestCommon
{
	struct FString ConnectionString;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString FunctionName;  // 0x20(0x10)
	struct FString QueueName;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.GetLeaderboardAroundPlayer
// Size: 0x78(Inherited: 0x0) 
struct FGetLeaderboardAroundPlayer
{
	struct FClientGetLeaderboardAroundPlayerRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.GroupsIsMemberResponse
// Size: 0x10(Inherited: 0x8) 
struct FGroupsIsMemberResponse : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsMember : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.GetPaymentToken
// Size: 0x48(Inherited: 0x0) 
struct FGetPaymentToken
{
	struct FClientGetPaymentTokenRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.DataGetObjectsResponse
// Size: 0x20(Inherited: 0x8) 
struct FDataGetObjectsResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	struct UPlayFabJsonObject* Objects;  // 0x10(0x8)
	int32_t ProfileVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct PlayFab.ClientGetPaymentTokenRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPaymentTokenRequest : public FPlayFabRequestCommon
{
	struct FString TokenProvider;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayerTagsRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetPlayerTagsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Namespace;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.GetPlayerTrades
// Size: 0x40(Inherited: 0x0) 
struct FGetPlayerTrades
{
	struct FClientGetPlayerTradesRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayerTradesRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientGetPlayerTradesRequest : public FPlayFabRequestCommon
{
	uint8_t  StatusFilter;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromFacebookIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromFacebookIDs
{
	struct FServerGetPlayFabIDsFromFacebookIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessDeleteRole__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteRole__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.WriteTitleEvent
// Size: 0x68(Inherited: 0x0) 
struct FWriteTitleEvent
{
	struct FServerWriteTitleEventRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGameCenterIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromGameCenterIDs
{
	struct FClientGetPlayFabIDsFromGameCenterIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkKongregateAccountRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientLinkKongregateAccountRequest : public FPlayFabRequestCommon
{
	struct FString AuthTicket;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString KongregateId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGameCenterIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGameCenterIDsRequest : public FPlayFabRequestCommon
{
	struct FString GameCenterIDs;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromGenericIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromGenericIDs
{
	struct FServerGetPlayFabIDsFromGenericIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperReportDeviceInfo
// Size: 0x50(Inherited: 0x0) 
struct FHelperReportDeviceInfo
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromGoogleIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromGoogleIDsRequest : public FPlayFabRequestCommon
{
	struct FString GoogleIDs;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGooglePlayGamesPlayerIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromGooglePlayGamesPlayerIDs
{
	struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromKongregateIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromKongregateIDs
{
	struct FClientGetPlayFabIDsFromKongregateIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCancelAllMatchmakingTicketsForPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperCancelAllMatchmakingTicketsForPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromKongregateIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromKongregateIDsRequest : public FPlayFabRequestCommon
{
	struct FString KongregateIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.CloudScriptExecuteFunctionRequest
// Size: 0x38(Inherited: 0x8) 
struct FCloudScriptExecuteFunctionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString FunctionName;  // 0x18(0x10)
	struct UPlayFabJsonObject* FunctionParameter;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool GeneratePlayStreamEvent : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromPSNAccountIDs
// Size: 0x50(Inherited: 0x0) 
struct FGetPlayFabIDsFromPSNAccountIDs
{
	struct FServerGetPlayFabIDsFromPSNAccountIDsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessRemoveGroupApplication__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveGroupApplication__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteBuildAlias
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteBuildAlias
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperConsumeItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperConsumeItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromPSNAccountIDsRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromPSNAccountIDsRequest : public FPlayFabRequestCommon
{
	int32_t IssuerId;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString PSNAccountIDs;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperReportPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperReportPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromSteamIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromSteamIDs
{
	struct FServerGetPlayFabIDsFromSteamIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPlayFabIDsFromSteamIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPlayFabIDsFromSteamIDsRequest : public FPlayFabRequestCommon
{
	struct FString SteamStringIDs;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromTwitchIDs
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayFabIDsFromTwitchIDs
{
	struct FServerGetPlayFabIDsFromTwitchIDsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperCancelTrade
// Size: 0x50(Inherited: 0x0) 
struct FHelperCancelTrade
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkAndroidDeviceIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkAndroidDeviceIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkAndroidDeviceIDResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromXboxLiveIDs
// Size: 0x58(Inherited: 0x0) 
struct FGetPlayFabIDsFromXboxLiveIDs
{
	struct FServerGetPlayFabIDsFromXboxLiveIDsRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateUserInventoryItemCustomData
// Size: 0x88(Inherited: 0x0) 
struct FUpdateUserInventoryItemCustomData
{
	struct FServerUpdateUserInventoryItemDataRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationGetTreatmentAssignmentRequest
// Size: 0x18(Inherited: 0x8) 
struct FExperimentationGetTreatmentAssignmentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ClientGetPublisherDataRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPublisherDataRequest : public FPlayFabRequestCommon
{
	struct FString Keys;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientGetPurchaseRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientGetPurchaseRequest : public FPlayFabRequestCommon
{
	struct FString OrderID;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetSharedGroupData
// Size: 0x60(Inherited: 0x0) 
struct FGetSharedGroupData
{
	struct FServerGetSharedGroupDataRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.GetTitleNews
// Size: 0x40(Inherited: 0x0) 
struct FGetTitleNews
{
	struct FServerGetTitleNewsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientGetTitleNewsRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientGetTitleNewsRequest : public FPlayFabRequestCommon
{
	int32_t Count;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessLeaveLobby__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessLeaveLobby__DelegateSignature
{
	struct FMultiplayerLobbyEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetTitlePublicKey
// Size: 0x48(Inherited: 0x0) 
struct FGetTitlePublicKey
{
	struct FClientGetTitlePublicKeyRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.GetTradeStatus
// Size: 0x58(Inherited: 0x0) 
struct FGetTradeStatus
{
	struct FClientGetTradeStatusRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientGetUserDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientGetUserDataRequest : public FPlayFabRequestCommon
{
	int32_t IfChangedFromDataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Keys;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GrantCharacterToUser
// Size: 0x70(Inherited: 0x0) 
struct FGrantCharacterToUser
{
	struct FServerGrantCharacterToUserRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.InitiateFileUploads
// Size: 0x60(Inherited: 0x0) 
struct FInitiateFileUploads
{
	struct FDataInitiateFileUploadsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientGrantCharacterToUserRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientGrantCharacterToUserRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterName;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString ItemId;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkNintendoServiceAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkNintendoServiceAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperAddOrUpdateContactEmail
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddOrUpdateContactEmail
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAddSharedGroupMembers
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddSharedGroupMembers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperAddUsernamePassword
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddUsernamePassword
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListMembershipOpportunities__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessListMembershipOpportunities__DelegateSignature
{
	struct FGroupsListMembershipOpportunitiesResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperConfirmPurchase
// Size: 0x50(Inherited: 0x0) 
struct FHelperConfirmPurchase
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperConsumePS5Entitlements
// Size: 0x50(Inherited: 0x0) 
struct FHelperConsumePS5Entitlements
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperConsumeXboxEntitlements
// Size: 0x50(Inherited: 0x0) 
struct FHelperConsumeXboxEntitlements
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetAdPlacements
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetAdPlacements
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCharacterReadOnlyData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCharacterReadOnlyData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetGameServerRegions
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetGameServerRegions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetLeaderboard
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLeaderboard
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptModelDecoder.decodeListFunctionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListFunctionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FCloudScriptListFunctionsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetLeaderboardForUserCharacters
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLeaderboardForUserCharacters
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPaymentToken
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPaymentToken
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayerStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayerStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGameCenterIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromGameCenterIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGoogleIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromGoogleIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromKongregateIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromKongregateIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromNintendoServiceAccountIds
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromNintendoServiceAccountIds
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromNintendoSwitchDeviceIds
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromNintendoSwitchDeviceIds
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerMoveItemToCharacterFromUserResult
// Size: 0x8(Inherited: 0x8) 
struct FServerMoveItemToCharacterFromUserResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteBuildRegion
// Size: 0x60(Inherited: 0x0) 
struct FDeleteBuildRegion
{
	struct FMultiplayerDeleteBuildRegionRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromPSNAccountIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromPSNAccountIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLoginWithGooglePlayGamesServicesRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithGooglePlayGamesServicesRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x28(0x8)
	struct FString PlayerSecret;  // 0x30(0x10)
	struct FString ServerAuthCode;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromTwitchIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromTwitchIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessSetObjects__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessSetObjects__DelegateSignature
{
	struct FDataSetObjectsResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromXboxLiveIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPlayFabIDsFromXboxLiveIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetLimits__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetLimits__DelegateSignature
{
	struct FInsightsInsightsGetLimitsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetPurchase
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPurchase
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessSetProfileLanguage__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessSetProfileLanguage__DelegateSignature
{
	struct FProfilesSetProfileLanguageResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetTime
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTime
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterInternalData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCharacterInternalData__DelegateSignature
{
	struct FServerUpdateCharacterDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetTitleNews
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitleNews
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetTitlePublicKey
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitlePublicKey
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperGetTradeStatus
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTradeStatus
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptModelDecoder.decodeGetFunctionResultResponse
// Size: 0x50(Inherited: 0x0) 
struct FdecodeGetFunctionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FCloudScriptGetFunctionResult ReturnValue;  // 0x8(0x48)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkApple
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkApple
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkCustomID
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkCustomID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkFacebookAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkFacebookAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetCatalogConfig
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCatalogConfig
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerRemovePlayerTagResult
// Size: 0x8(Inherited: 0x8) 
struct FServerRemovePlayerTagResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkFacebookInstantGamesId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkFacebookInstantGamesId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateCatalogItemsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdateCatalogItemsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdateCatalogItemsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkGameCenterAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkGameCenterAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkGoogleAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkGoogleAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkIOSDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkIOSDeviceID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.InsightsInsightsSetStorageRetentionRequest
// Size: 0x18(Inherited: 0x8) 
struct FInsightsInsightsSetStorageRetentionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t RetentionDays;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkNintendoSwitchDeviceId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkNintendoSwitchDeviceId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperLinkPSNAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkPSNAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithTwitch
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithTwitch
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLinkTwitch
// Size: 0x50(Inherited: 0x0) 
struct FHelperLinkTwitch
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerListVirtualMachineSummariesResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListVirtualMachineSummariesResponse : public FPlayFabResultCommon
{
	int32_t PageSize;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString SkipToken;  // 0x10(0x10)
	struct TArray<struct UPlayFabJsonObject*> VirtualMachines;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.UnblockEntity
// Size: 0x50(Inherited: 0x0) 
struct FUnblockEntity
{
	struct FGroupsUnblockEntityRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeModifyUserVirtualCurrencyResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeModifyUserVirtualCurrencyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerModifyUserVirtualCurrencyResult ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithCustomID
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithCustomID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithFacebook
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithFacebook
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGoogleIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromGoogleIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPlayFabIDsFromGoogleIDsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithFacebookInstantGamesId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithFacebookInstantGamesId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerLeaveLobbyRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerLeaveLobbyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)
	struct UPlayFabJsonObject* MemberEntity;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithGameCenter
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithGameCenter
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperRemoveMembers
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveMembers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithIOSDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithIOSDeviceID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.RegisterHttpFunction
// Size: 0x60(Inherited: 0x0) 
struct FRegisterHttpFunction
{
	struct FCloudScriptRegisterHttpFunctionRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeReportPlayerServerResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeReportPlayerServerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerReportPlayerServerResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterStatisticsResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetCharacterStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetCharacterStatisticsResult ReturnValue;  // 0x8(0x30)

}; 
// ScriptStruct PlayFab.LocalizationGetLanguageListRequest
// Size: 0x10(Inherited: 0x8) 
struct FLocalizationGetLanguageListRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetContentDownloadUrlResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetContentDownloadUrlResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetContentDownloadUrlResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerGetSharedGroupDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerGetSharedGroupDataRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool GetMembers : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Keys;  // 0x10(0x10)
	struct FString SharedGroupId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithKongregate
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithKongregate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithNintendoServiceAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithNintendoServiceAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LinkIOSDeviceID
// Size: 0x78(Inherited: 0x0) 
struct FLinkIOSDeviceID
{
	struct FClientLinkIOSDeviceIDRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithNintendoSwitchDeviceId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithNintendoSwitchDeviceId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithOpenIdConnect
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithOpenIdConnect
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithPlayFab
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithPlayFab
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithPSN
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithPSN
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperLoginWithSteam
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithSteam
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLoginWithCustomIDRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithCustomIDRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString CustomId;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EncryptedRequest;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetBuildAlias
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetBuildAlias
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperLoginWithXbox
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithXbox
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperOpenTrade
// Size: 0x50(Inherited: 0x0) 
struct FHelperOpenTrade
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetMatchmakingTicket
// Size: 0x68(Inherited: 0x0) 
struct FGetMatchmakingTicket
{
	struct FMultiplayerGetMatchmakingTicketRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRedeemCoupon
// Size: 0x50(Inherited: 0x0) 
struct FHelperRedeemCoupon
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperRefreshPSNAuthToken
// Size: 0x50(Inherited: 0x0) 
struct FHelperRefreshPSNAuthToken
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetMultiplayerServerDetails
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMultiplayerServerDetails
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperRegisterForIOSPushNotification
// Size: 0x50(Inherited: 0x0) 
struct FHelperRegisterForIOSPushNotification
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperRegisterPlayFabUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperRegisterPlayFabUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperRemoveContactEmail
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveContactEmail
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRemoveFriend
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveFriend
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerListTitleMultiplayerServersQuotaChangesResponse
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerListTitleMultiplayerServersQuotaChangesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Changes;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetContainerRegistryCredentials
// Size: 0x40(Inherited: 0x0) 
struct FGetContainerRegistryCredentials
{
	struct FMultiplayerGetContainerRegistryCredentialsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRemoveSharedGroupMembers
// Size: 0x50(Inherited: 0x0) 
struct FHelperRemoveSharedGroupMembers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerMoveItemToUserFromCharacterRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerMoveItemToUserFromCharacterRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString ItemInstanceId;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperRestoreIOSPurchases
// Size: 0x50(Inherited: 0x0) 
struct FHelperRestoreIOSPurchases
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetFriendLeaderboardAroundPlayerResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetFriendLeaderboardAroundPlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetFriendLeaderboardAroundPlayerResult ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabClientAPI.HelperRewardAdActivity
// Size: 0x50(Inherited: 0x0) 
struct FHelperRewardAdActivity
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkAndroidDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkAndroidDeviceID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkCustomID
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkCustomID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkFacebookAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkFacebookAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkFacebookInstantGamesId
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkFacebookInstantGamesId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerUnlinkXboxAccountRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerUnlinkXboxAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkGameCenterAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkGameCenterAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetItem
// Size: 0x60(Inherited: 0x0) 
struct FGetItem
{
	struct FEconomyGetItemRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeValidateIOSReceiptResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeValidateIOSReceiptResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientValidateIOSReceiptResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRegisterPlayFabUserResultResponse
// Size: 0x50(Inherited: 0x0) 
struct FdecodeRegisterPlayFabUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRegisterPlayFabUserResult ReturnValue;  // 0x8(0x48)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkGoogleAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkGoogleAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerListTitleMultiplayerServersQuotaChangesRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerListTitleMultiplayerServersQuotaChangesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkGooglePlayGamesServicesAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkGooglePlayGamesServicesAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabDataAPI.SetObjects
// Size: 0x60(Inherited: 0x0) 
struct FSetObjects
{
	struct FDataSetObjectsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkIOSDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkIOSDeviceID
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkNintendoSwitchDeviceId
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkNintendoSwitchDeviceId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetEntityItemReview__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetEntityItemReview__DelegateSignature
{
	struct FEconomyGetEntityItemReviewResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.SearchItems
// Size: 0xA0(Inherited: 0x0) 
struct FSearchItems
{
	struct FEconomySearchItemsRequest Request;  // 0x0(0x70)
	struct FDelegate onSuccess;  // 0x70(0x10)
	struct FDelegate onFailure;  // 0x80(0x10)
	struct UObject* customData;  // 0x90(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x98(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkOpenIdConnect
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkOpenIdConnect
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperDeleteEntityItemReviews
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteEntityItemReviews
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteBuildRegion
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteBuildRegion
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUnlinkPSNAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkPSNAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperUnlinkSteamAccount
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlinkSteamAccount
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUnlockContainerInstance
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnlockContainerInstance
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateAvatarUrl
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateAvatarUrl
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCharacterStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdatePlayerStatistics
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdatePlayerStatistics
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperValidateAmazonIAPReceipt
// Size: 0x50(Inherited: 0x0) 
struct FHelperValidateAmazonIAPReceipt
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetMatchmakingTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMatchmakingTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperValidateGooglePlayPurchase
// Size: 0x50(Inherited: 0x0) 
struct FHelperValidateGooglePlayPurchase
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.DeleteExclusionGroup
// Size: 0x50(Inherited: 0x0) 
struct FDeleteExclusionGroup
{
	struct FExperimentationDeleteExclusionGroupRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.HelperValidateIOSReceipt
// Size: 0x50(Inherited: 0x0) 
struct FHelperValidateIOSReceipt
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerGetTitleMultiplayerServersQuotaChangeResponse
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetTitleMultiplayerServersQuotaChangeResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Change;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListAssetSummariesRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListAssetSummariesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t PageSize;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString SkipToken;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkFacebookInstantGamesIdRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkFacebookInstantGamesIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FacebookInstantGamesSignature;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.HelperValidateWindowsStoreReceipt
// Size: 0x50(Inherited: 0x0) 
struct FHelperValidateWindowsStoreReceipt
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperDeleteItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperWriteCharacterEvent
// Size: 0x50(Inherited: 0x0) 
struct FHelperWriteCharacterEvent
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperWriteTitleEvent
// Size: 0x50(Inherited: 0x0) 
struct FHelperWriteTitleEvent
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientLinkAndroidDeviceIDRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientLinkAndroidDeviceIDRequest : public FPlayFabRequestCommon
{
	struct FString AndroidDevice;  // 0x8(0x10)
	struct FString AndroidDeviceId;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ForceLink : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString OS;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkAppleRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkAppleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString IdentityToken;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkCustomIDRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkCustomIDRequest : public FPlayFabRequestCommon
{
	struct FString CustomId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LinkFacebookAccount
// Size: 0x58(Inherited: 0x0) 
struct FLinkFacebookAccount
{
	struct FClientLinkFacebookAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCancelAllMatchmakingTicketsForPlayerRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerCancelAllMatchmakingTicketsForPlayerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString QueueName;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkFacebookAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkFacebookAccountRequest : public FPlayFabRequestCommon
{
	struct FString AccessToken;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LinkFacebookInstantGamesId
// Size: 0x58(Inherited: 0x0) 
struct FLinkFacebookInstantGamesId
{
	struct FClientLinkFacebookInstantGamesIdRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.AuthUser
// Size: 0x48(Inherited: 0x0) 
struct FAuthUser
{
	struct FMatchmakerAuthUserRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabMatchmakerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetRemoteLoginEndpoint__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetRemoteLoginEndpoint__DelegateSignature
{
	struct FMultiplayerGetRemoteLoginEndpointResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LinkGoogleAccount
// Size: 0x58(Inherited: 0x0) 
struct FLinkGoogleAccount
{
	struct FClientLinkGoogleAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkGoogleAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkGoogleAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString ServerAuthCode;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LinkGooglePlayGamesServicesAccount
// Size: 0x58(Inherited: 0x0) 
struct FLinkGooglePlayGamesServicesAccount
{
	struct FClientLinkGooglePlayGamesServicesAccountRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateTitleMultiplayerServersQuotaChangeResponse
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeResponse : public FPlayFabResultCommon
{
	struct FString RequestId;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool WasApproved : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct PlayFab.ClientLinkIOSDeviceIDRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientLinkIOSDeviceIDRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DeviceID;  // 0x10(0x10)
	struct FString DeviceModel;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ForceLink : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString OS;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LinkKongregate
// Size: 0x68(Inherited: 0x0) 
struct FLinkKongregate
{
	struct FClientLinkKongregateAccountRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperListGroupBlocks
// Size: 0x50(Inherited: 0x0) 
struct FHelperListGroupBlocks
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerGetMatchResult
// Size: 0x50(Inherited: 0x8) 
struct FMultiplayerGetMatchResult : public FPlayFabResultCommon
{
	struct FString ArrangementString;  // 0x8(0x10)
	struct FString MatchID;  // 0x18(0x10)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x28(0x10)
	struct FString RegionPreferences;  // 0x38(0x10)
	struct UPlayFabJsonObject* ServerDetails;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LinkNintendoSwitchDeviceId
// Size: 0x58(Inherited: 0x0) 
struct FLinkNintendoSwitchDeviceId
{
	struct FClientLinkNintendoSwitchDeviceIdRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkNintendoSwitchDeviceIdRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkNintendoSwitchDeviceIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString NintendoSwitchDeviceId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteRemoteUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteRemoteUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.LinkOpenIdConnect
// Size: 0x68(Inherited: 0x0) 
struct FLinkOpenIdConnect
{
	struct FClientLinkOpenIdConnectRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.LinkPSNAccount
// Size: 0x78(Inherited: 0x0) 
struct FLinkPSNAccount
{
	struct FServerLinkPSNAccountRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkPSNAccountRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientLinkPSNAccountRequest : public FPlayFabRequestCommon
{
	struct FString AuthCode;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t IssuerId;  // 0x24(0x4)
	struct FString RedirectUri;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ClientLinkTwitchAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkTwitchAccountRequest : public FPlayFabRequestCommon
{
	struct FString AccessToken;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.LinkXboxAccount
// Size: 0x68(Inherited: 0x0) 
struct FLinkXboxAccount
{
	struct FServerLinkXboxAccountRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientLinkXboxAccountRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientLinkXboxAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString XboxToken;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetDraftItem
// Size: 0x60(Inherited: 0x0) 
struct FGetDraftItem
{
	struct FEconomyGetDraftItemRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithAndroidDeviceIDRequest
// Size: 0x70(Inherited: 0x8) 
struct FClientLoginWithAndroidDeviceIDRequest : public FPlayFabRequestCommon
{
	struct FString AndroidDevice;  // 0x8(0x10)
	struct FString AndroidDeviceId;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CreateAccount : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x30(0x8)
	struct FString EncryptedRequest;  // 0x38(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x48(0x8)
	struct FString OS;  // 0x50(0x10)
	struct FString PlayerSecret;  // 0x60(0x10)

}; 
// ScriptStruct PlayFab.ClientLoginWithAppleRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithAppleRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct FString IdentityToken;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithCustomID
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithCustomID
{
	struct FClientLoginWithCustomIDRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithEmailAddress
// Size: 0x68(Inherited: 0x0) 
struct FLoginWithEmailAddress
{
	struct FClientLoginWithEmailAddressRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithEmailAddressRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientLoginWithEmailAddressRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Email;  // 0x10(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x20(0x8)
	struct FString Password;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetPendingOperations__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetPendingOperations__DelegateSignature
{
	struct FInsightsInsightsGetPendingOperationsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithFacebook
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithFacebook
{
	struct FClientLoginWithFacebookRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithFacebookRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithFacebookRequest : public FPlayFabRequestCommon
{
	struct FString AccessToken;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CreateAccount : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EncryptedRequest;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithFacebookInstantGamesId
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithFacebookInstantGamesId
{
	struct FClientLoginWithFacebookInstantGamesIdRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithFacebookInstantGamesIdRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithFacebookInstantGamesIdRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct FString FacebookInstantGamesSignature;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ClientLoginWithGameCenterRequest
// Size: 0x90(Inherited: 0x8) 
struct FClientLoginWithGameCenterRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x28(0x8)
	struct FString PlayerId;  // 0x30(0x10)
	struct FString PlayerSecret;  // 0x40(0x10)
	struct FString PublicKeyUrl;  // 0x50(0x10)
	struct FString Salt;  // 0x60(0x10)
	struct FString Signature;  // 0x70(0x10)
	struct FString Timestamp;  // 0x80(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperAddMembers
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddMembers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeSetMembershipOverrideResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetMembershipOverrideResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminSetMembershipOverrideResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.ChangeMemberRole
// Size: 0x78(Inherited: 0x0) 
struct FChangeMemberRole
{
	struct FGroupsChangeMemberRoleRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithGoogleAccount
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithGoogleAccount
{
	struct FClientLoginWithGoogleAccountRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptUnregisterFunctionRequest
// Size: 0x20(Inherited: 0x8) 
struct FCloudScriptUnregisterFunctionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FunctionName;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerGetBuildRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetBuildRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithGoogleAccountRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithGoogleAccountRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x28(0x8)
	struct FString PlayerSecret;  // 0x30(0x10)
	struct FString ServerAuthCode;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithIOSDeviceID
// Size: 0xA0(Inherited: 0x0) 
struct FLoginWithIOSDeviceID
{
	struct FClientLoginWithIOSDeviceIDRequest Request;  // 0x0(0x70)
	struct FDelegate onSuccess;  // 0x70(0x10)
	struct FDelegate onFailure;  // 0x80(0x10)
	struct UObject* customData;  // 0x90(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x98(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithIOSDeviceIDRequest
// Size: 0x70(Inherited: 0x8) 
struct FClientLoginWithIOSDeviceIDRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString DeviceID;  // 0x18(0x10)
	struct FString DeviceModel;  // 0x28(0x10)
	struct FString EncryptedRequest;  // 0x38(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x48(0x8)
	struct FString OS;  // 0x50(0x10)
	struct FString PlayerSecret;  // 0x60(0x10)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessUpdateExclusionGroup__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateExclusionGroup__DelegateSignature
{
	struct FExperimentationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithKongregate
// Size: 0x90(Inherited: 0x0) 
struct FLoginWithKongregate
{
	struct FClientLoginWithKongregateRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x88(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithKongregateRequest
// Size: 0x60(Inherited: 0x8) 
struct FClientLoginWithKongregateRequest : public FPlayFabRequestCommon
{
	struct FString AuthTicket;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CreateAccount : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EncryptedRequest;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString KongregateId;  // 0x40(0x10)
	struct FString PlayerSecret;  // 0x50(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithNintendoServiceAccount
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithNintendoServiceAccount
{
	struct FClientLoginWithNintendoServiceAccountRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientValidateGooglePlayPurchaseRequest
// Size: 0x58(Inherited: 0x8) 
struct FClientValidateGooglePlayPurchaseRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CurrencyCode;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	int32_t PurchasePrice;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString ReceiptJson;  // 0x38(0x10)
	struct FString Signature;  // 0x48(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithOpenIdConnect
// Size: 0x90(Inherited: 0x0) 
struct FLoginWithOpenIdConnect
{
	struct FClientLoginWithOpenIdConnectRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x88(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithOpenIdConnectRequest
// Size: 0x60(Inherited: 0x8) 
struct FClientLoginWithOpenIdConnectRequest : public FPlayFabRequestCommon
{
	struct FString ConnectionId;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CreateAccount : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EncryptedRequest;  // 0x28(0x10)
	struct FString IdToken;  // 0x38(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x48(0x8)
	struct FString PlayerSecret;  // 0x50(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithPSN
// Size: 0x98(Inherited: 0x0) 
struct FLoginWithPSN
{
	struct FClientLoginWithPSNRequest Request;  // 0x0(0x68)
	struct FDelegate onSuccess;  // 0x68(0x10)
	struct FDelegate onFailure;  // 0x78(0x10)
	struct UObject* customData;  // 0x88(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x90(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.LoginWithTwitch
// Size: 0x80(Inherited: 0x0) 
struct FLoginWithTwitch
{
	struct FClientLoginWithTwitchRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientLoginWithTwitchRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithTwitchRequest : public FPlayFabRequestCommon
{
	struct FString AccessToken;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CreateAccount : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EncryptedRequest;  // 0x28(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x38(0x8)
	struct FString PlayerSecret;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ClientLoginWithXboxRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientLoginWithXboxRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EncryptedRequest;  // 0x18(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x28(0x8)
	struct FString PlayerSecret;  // 0x30(0x10)
	struct FString XboxToken;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.OpenTrade
// Size: 0x68(Inherited: 0x0) 
struct FOpenTrade
{
	struct FClientOpenTradeRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlockContainerInstanceRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientUnlockContainerInstanceRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct FString ContainerItemInstanceId;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)
	struct FString KeyItemInstanceId;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ClientOpenTradeRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientOpenTradeRequest : public FPlayFabRequestCommon
{
	struct FString AllowedPlayerIds;  // 0x8(0x10)
	struct FString OfferedInventoryInstanceIds;  // 0x18(0x10)
	struct FString RequestedCatalogItemIds;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeListUsersCharactersResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListUsersCharactersResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerListUsersCharactersResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientAPI.PayForPurchase
// Size: 0x80(Inherited: 0x0) 
struct FPayForPurchase
{
	struct FClientPayForPurchaseRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperAcceptGroupInvitation
// Size: 0x50(Inherited: 0x0) 
struct FHelperAcceptGroupInvitation
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientPayForPurchaseRequest
// Size: 0x50(Inherited: 0x8) 
struct FClientPayForPurchaseRequest : public FPlayFabRequestCommon
{
	struct FString Currency;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString OrderID;  // 0x20(0x10)
	struct FString ProviderName;  // 0x30(0x10)
	struct FString ProviderTransactionId;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.PurchaseItem
// Size: 0x98(Inherited: 0x0) 
struct FPurchaseItem
{
	struct FClientPurchaseItemRequest Request;  // 0x0(0x68)
	struct FDelegate onSuccess;  // 0x68(0x10)
	struct FDelegate onFailure;  // 0x78(0x10)
	struct UObject* customData;  // 0x88(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x90(0x8)

}; 
// ScriptStruct PlayFab.ClientRedeemCouponRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientRedeemCouponRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct FString CouponCode;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateServerBackfillTicket__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateServerBackfillTicket__DelegateSignature
{
	struct FMultiplayerCreateServerBackfillTicketResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.RefreshPSNAuthToken
// Size: 0x60(Inherited: 0x0) 
struct FRefreshPSNAuthToken
{
	struct FClientRefreshPSNAuthTokenRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ClientRefreshPSNAuthTokenRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientRefreshPSNAuthTokenRequest : public FPlayFabRequestCommon
{
	struct FString AuthCode;  // 0x8(0x10)
	int32_t IssuerId;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString RedirectUri;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.RegisterForIOSPushNotification
// Size: 0x60(Inherited: 0x0) 
struct FRegisterForIOSPushNotification
{
	struct FClientRegisterForIOSPushNotificationRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.RegisterPlayFabUser
// Size: 0xB0(Inherited: 0x0) 
struct FRegisterPlayFabUser
{
	struct FClientRegisterPlayFabUserRequest Request;  // 0x0(0x80)
	struct FDelegate onSuccess;  // 0x80(0x10)
	struct FDelegate onFailure;  // 0x90(0x10)
	struct UObject* customData;  // 0xA0(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0xA8(0x8)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeCreateGroupResponseResponse
// Size: 0x68(Inherited: 0x0) 
struct FdecodeCreateGroupResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsCreateGroupResponse ReturnValue;  // 0x8(0x60)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeResolvePurchaseDisputeResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeResolvePurchaseDisputeResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminResolvePurchaseDisputeResponse ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ClientRewardAdActivityRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientRewardAdActivityRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlacementId;  // 0x10(0x10)
	struct FString RewardId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ClientRegisterPlayFabUserRequest
// Size: 0x80(Inherited: 0x8) 
struct FClientRegisterPlayFabUserRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DisplayName;  // 0x10(0x10)
	struct FString Email;  // 0x20(0x10)
	struct FString EncryptedRequest;  // 0x30(0x10)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x40(0x8)
	struct FString Password;  // 0x48(0x10)
	struct FString PlayerSecret;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool RequireBothUsernameAndEmail : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FString Username;  // 0x70(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListMultiplayerServers
// Size: 0x50(Inherited: 0x0) 
struct FHelperListMultiplayerServers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientRemoveFriendRequest
// Size: 0x18(Inherited: 0x8) 
struct FClientRemoveFriendRequest : public FPlayFabRequestCommon
{
	struct FString FriendPlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientRemoveGenericIDRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientRemoveGenericIDRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* GenericId;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.RemoveSharedGroupMembers
// Size: 0x58(Inherited: 0x0) 
struct FRemoveSharedGroupMembers
{
	struct FServerRemoveSharedGroupMembersRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.ReportAdActivity
// Size: 0x68(Inherited: 0x0) 
struct FReportAdActivity
{
	struct FClientReportAdActivityRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.ReportDeviceInfo
// Size: 0x40(Inherited: 0x0) 
struct FReportDeviceInfo
{
	struct FClientDeviceInfoRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientDeviceInfoRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientDeviceInfoRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Info;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientReportPlayerClientRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientReportPlayerClientRequest : public FPlayFabRequestCommon
{
	struct FString Comment;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString ReporteeId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.RestoreIOSPurchases
// Size: 0x60(Inherited: 0x0) 
struct FRestoreIOSPurchases
{
	struct FClientRestoreIOSPurchasesRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessInviteToGroup__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FDelegateOnSuccessInviteToGroup__DelegateSignature
{
	struct FGroupsInviteToGroupResponse Result;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ClientRestoreIOSPurchasesRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientRestoreIOSPurchasesRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString ReceiptData;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.DataAbortFileUploadsResponse
// Size: 0x18(Inherited: 0x8) 
struct FDataAbortFileUploadsResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	int32_t ProfileVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetFriendsListResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetFriendsListResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetFriendsListResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperRegisterHttpFunction
// Size: 0x50(Inherited: 0x0) 
struct FHelperRegisterHttpFunction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabInsightsAPI.SetStorageRetention
// Size: 0x48(Inherited: 0x0) 
struct FSetStorageRetention
{
	struct FInsightsInsightsSetStorageRetentionRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabInsightsAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SetFriendTags
// Size: 0x68(Inherited: 0x0) 
struct FSetFriendTags
{
	struct FServerSetFriendTagsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientSetPlayerSecretRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientSetPlayerSecretRequest : public FPlayFabRequestCommon
{
	struct FString EncryptedRequest;  // 0x8(0x10)
	struct FString PlayerSecret;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkApple
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkApple
{
	struct FClientUnlinkAppleRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetLatestScorecard__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetLatestScorecard__DelegateSignature
{
	struct FExperimentationGetLatestScorecardResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListCertificateSummaries__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListCertificateSummaries__DelegateSignature
{
	struct FMultiplayerListCertificateSummariesResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkCustomID
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkCustomID
{
	struct FClientUnlinkCustomIDRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeleteCharacterFromUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteCharacterFromUser__DelegateSignature
{
	struct FServerDeleteCharacterFromUserResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkCustomIDRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkCustomIDRequest : public FPlayFabRequestCommon
{
	struct FString CustomId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.EconomyPublishDraftItemResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyPublishDraftItemResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.EconomyGetItemRequest
// Size: 0x30(Inherited: 0x8) 
struct FEconomyGetItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ID;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkFacebookAccount
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkFacebookAccount
{
	struct FClientUnlinkFacebookAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkFacebookAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkFacebookAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdateUserDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FClientUpdateUserDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Data;  // 0x10(0x8)
	struct FString KeysToRemove;  // 0x18(0x10)
	uint8_t  Permission;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkFacebookInstantGamesId
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkFacebookInstantGamesId
{
	struct FClientUnlinkFacebookInstantGamesIdRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkGoogleAccount
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkGoogleAccount
{
	struct FClientUnlinkGoogleAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptListQueuedFunctionsResult
// Size: 0x18(Inherited: 0x8) 
struct FCloudScriptListQueuedFunctionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Functions;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerGetAssetUploadUrlRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetAssetUploadUrlRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Filename;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerBanUsersRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerBanUsersRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Bans;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkGoogleAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkGoogleAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkGooglePlayGamesServicesAccount
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkGooglePlayGamesServicesAccount
{
	struct FClientUnlinkGooglePlayGamesServicesAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkGooglePlayGamesServicesAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkGooglePlayGamesServicesAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkIOSDeviceID
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkIOSDeviceID
{
	struct FClientUnlinkIOSDeviceIDRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperSubmitItemReviewVote
// Size: 0x50(Inherited: 0x0) 
struct FHelperSubmitItemReviewVote
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerInviteToLobbyRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerInviteToLobbyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* InviteeEntity;  // 0x10(0x8)
	struct FString LobbyId;  // 0x18(0x10)
	struct UPlayFabJsonObject* MemberEntity;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ServerDeleteCharacterFromUserResult
// Size: 0x8(Inherited: 0x8) 
struct FServerDeleteCharacterFromUserResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientUnlinkIOSDeviceIDRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkIOSDeviceIDRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DeviceID;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkKongregate
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkKongregate
{
	struct FClientUnlinkKongregateAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkKongregateAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkKongregateAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessCreateUploadUrls__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateUploadUrls__DelegateSignature
{
	struct FEconomyCreateUploadUrlsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.LeaveLobby
// Size: 0x58(Inherited: 0x0) 
struct FLeaveLobby
{
	struct FMultiplayerLeaveLobbyRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkNintendoSwitchDeviceId
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkNintendoSwitchDeviceId
{
	struct FClientUnlinkNintendoSwitchDeviceIdRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ServerGetTimeRequest
// Size: 0x8(Inherited: 0x8) 
struct FServerGetTimeRequest : public FPlayFabRequestCommon
{

}; 
// ScriptStruct PlayFab.ClientUnlinkNintendoSwitchDeviceIdRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkNintendoSwitchDeviceIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString NintendoSwitchDeviceId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildAlias
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateBuildAlias
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelMatchmakingTicketResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeCancelMatchmakingTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCancelMatchmakingTicketResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkOpenIdConnectRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUnlinkOpenIdConnectRequest : public FPlayFabRequestCommon
{
	struct FString ConnectionId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetDraftItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetDraftItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUntagContainerImage
// Size: 0x50(Inherited: 0x0) 
struct FHelperUntagContainerImage
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.UnlinkPSNAccount
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkPSNAccount
{
	struct FServerUnlinkPSNAccountRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkSteamAccount
// Size: 0x40(Inherited: 0x0) 
struct FUnlinkSteamAccount
{
	struct FClientUnlinkSteamAccountRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkSteamAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkSteamAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupMembers__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListGroupMembers__DelegateSignature
{
	struct FGroupsListGroupMembersResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientAPI.UnlinkTwitch
// Size: 0x50(Inherited: 0x0) 
struct FUnlinkTwitch
{
	struct FClientUnlinkTwitchAccountRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ClientUnlinkXboxAccountRequest
// Size: 0x10(Inherited: 0x8) 
struct FClientUnlinkXboxAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeDeleteFilesResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeDeleteFilesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataDeleteFilesResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.UnlockContainerItem
// Size: 0x80(Inherited: 0x0) 
struct FUnlockContainerItem
{
	struct FServerUnlockContainerItemRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetBuildAlias__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetBuildAlias__DelegateSignature
{
	struct FMultiplayerBuildAliasDetailsResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ServerGetCharacterLeaderboardRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerGetCharacterLeaderboardRequest : public FPlayFabRequestCommon
{
	struct FString CharacterType;  // 0x8(0x10)
	int32_t MaxResultsCount;  // 0x18(0x4)
	int32_t StartPosition;  // 0x1C(0x4)
	struct FString StatisticName;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.EconomySubmitItemReviewVoteResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomySubmitItemReviewVoteResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ClientUnlockContainerItemRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientUnlockContainerItemRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct FString ContainerItemId;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.DataInitiateFileUploadsRequest
// Size: 0x30(Inherited: 0x8) 
struct FDataInitiateFileUploadsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString FileNames;  // 0x18(0x10)
	int32_t ProfileVersion;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function PlayFab.PlayFabEconomyAPI.DeleteEntityItemReviews
// Size: 0x48(Inherited: 0x0) 
struct FDeleteEntityItemReviews
{
	struct FEconomyDeleteEntityItemReviewsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateCharacterData
// Size: 0x80(Inherited: 0x0) 
struct FUpdateCharacterData
{
	struct FServerUpdateCharacterDataRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdateCharacterDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FClientUpdateCharacterDataRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Data;  // 0x20(0x8)
	struct FString KeysToRemove;  // 0x28(0x10)
	uint8_t  Permission;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateCharacterStatistics
// Size: 0x68(Inherited: 0x0) 
struct FUpdateCharacterStatistics
{
	struct FServerUpdateCharacterStatisticsRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdateCharacterStatisticsRequest
// Size: 0x28(Inherited: 0x8) 
struct FClientUpdateCharacterStatisticsRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CharacterStatistics;  // 0x18(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ClientUpdatePlayerStatisticsRequest
// Size: 0x20(Inherited: 0x8) 
struct FClientUpdatePlayerStatisticsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct TArray<struct UPlayFabJsonObject*> Statistics;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.ValidateAmazonIAPReceipt
// Size: 0x88(Inherited: 0x0) 
struct FValidateAmazonIAPReceipt
{
	struct FClientValidateAmazonReceiptRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x80(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.RemoveField
// Size: 0x10(Inherited: 0x0) 
struct FRemoveField
{
	struct FString FieldName;  // 0x0(0x10)

}; 
// ScriptStruct PlayFab.ClientValidateAmazonReceiptRequest
// Size: 0x58(Inherited: 0x8) 
struct FClientValidateAmazonReceiptRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CurrencyCode;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	int32_t PurchasePrice;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString ReceiptId;  // 0x38(0x10)
	struct FString UserId;  // 0x48(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateBuildWithCustomContainer
// Size: 0xE8(Inherited: 0x0) 
struct FCreateBuildWithCustomContainer
{
	struct FMultiplayerCreateBuildWithCustomContainerRequest Request;  // 0x0(0xB8)
	struct FDelegate onSuccess;  // 0xB8(0x10)
	struct FDelegate onFailure;  // 0xC8(0x10)
	struct UObject* customData;  // 0xD8(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0xE0(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForPlayerTriggeredAction
// Size: 0x60(Inherited: 0x0) 
struct FPostFunctionResultForPlayerTriggeredAction
{
	struct FCloudScriptPostFunctionResultForPlayerTriggeredActionRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.EconomyReviewItemResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyReviewItemResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabClientAPI.ValidateGooglePlayPurchase
// Size: 0x88(Inherited: 0x0) 
struct FValidateGooglePlayPurchase
{
	struct FClientValidateGooglePlayPurchaseRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.ServerAddGenericIDRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerAddGenericIDRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* GenericId;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.ValidateIOSReceipt
// Size: 0x78(Inherited: 0x0) 
struct FValidateIOSReceipt
{
	struct FClientValidateIOSReceiptRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ClientValidateIOSReceiptRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientValidateIOSReceiptRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CurrencyCode;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	int32_t PurchasePrice;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString ReceiptData;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabClientAPI.ValidateWindowsStoreReceipt
// Size: 0x78(Inherited: 0x0) 
struct FValidateWindowsStoreReceipt
{
	struct FClientValidateWindowsReceiptRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabClientAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ClientValidateWindowsReceiptRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientValidateWindowsReceiptRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CurrencyCode;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	int32_t PurchasePrice;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString Receipt;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperListGroupInvitations
// Size: 0x50(Inherited: 0x0) 
struct FHelperListGroupInvitations
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ClientWriteClientCharacterEventRequest
// Size: 0x48(Inherited: 0x8) 
struct FClientWriteClientCharacterEventRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Body;  // 0x8(0x8)
	struct FString CharacterId;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString EventName;  // 0x28(0x10)
	struct FString Timestamp;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.WritePlayerEvent
// Size: 0x78(Inherited: 0x0) 
struct FWritePlayerEvent
{
	struct FServerWriteServerPlayerEventRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ServerRegisterGameResponse
// Size: 0x18(Inherited: 0x8) 
struct FServerRegisterGameResponse : public FPlayFabResultCommon
{
	struct FString LobbyId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ClientWriteClientPlayerEventRequest
// Size: 0x38(Inherited: 0x8) 
struct FClientWriteClientPlayerEventRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Body;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EventName;  // 0x18(0x10)
	struct FString Timestamp;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendPushNotificationFromTemplate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSendPushNotificationFromTemplate__DelegateSignature
{
	struct FServerSendPushNotificationResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessExecuteFunction__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessExecuteFunction__DelegateSignature
{
	struct FCloudScriptExecuteFunctionResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessListFunctions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListFunctions__DelegateSignature
{
	struct FCloudScriptListFunctionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptListFunctionsResult
// Size: 0x18(Inherited: 0x8) 
struct FCloudScriptListFunctionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Functions;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerGetMatchmakingTicketRequest
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerGetMatchmakingTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool EscapeObject : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString QueueName;  // 0x18(0x10)
	struct FString TicketId;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessListHttpFunctions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListHttpFunctions__DelegateSignature
{
	struct FCloudScriptListHttpFunctionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerAddCharacterVirtualCurrencyRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerAddCharacterVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString CharacterId;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString PlayFabId;  // 0x28(0x10)
	struct FString VirtualCurrency;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.CloudScriptListHttpFunctionsResult
// Size: 0x18(Inherited: 0x8) 
struct FCloudScriptListHttpFunctionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Functions;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessListQueuedFunctions__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListQueuedFunctions__DelegateSignature
{
	struct FCloudScriptListQueuedFunctionsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptEmptyResult
// Size: 0x8(Inherited: 0x8) 
struct FCloudScriptEmptyResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForFunctionExecution__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPostFunctionResultForFunctionExecution__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetSharedGroupDataResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetSharedGroupDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetSharedGroupDataResult ReturnValue;  // 0x8(0x20)

}; 
// ScriptStruct PlayFab.ServerDeregisterGameResponse
// Size: 0x8(Inherited: 0x8) 
struct FServerDeregisterGameResponse : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForPlayerTriggeredAction__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessPostFunctionResultForPlayerTriggeredAction__DelegateSignature
{
	struct FCloudScriptEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.ExecuteEntityCloudScript
// Size: 0x68(Inherited: 0x0) 
struct FExecuteEntityCloudScript
{
	struct FCloudScriptExecuteEntityCloudScriptRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupBlocksResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListGroupBlocksResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsListGroupBlocksResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.HelperMoveItemToCharacterFromCharacter
// Size: 0x50(Inherited: 0x0) 
struct FHelperMoveItemToCharacterFromCharacter
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.CloudScriptExecuteEntityCloudScriptRequest
// Size: 0x38(Inherited: 0x8) 
struct FCloudScriptExecuteEntityCloudScriptRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString FunctionName;  // 0x18(0x10)
	struct UPlayFabJsonObject* FunctionParameter;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool GeneratePlayStreamEvent : 1;  // 0x30(0x1)
	uint8_t  RevisionSelection;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	int32_t SpecificRevision;  // 0x34(0x4)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.ExecuteFunction
// Size: 0x68(Inherited: 0x0) 
struct FExecuteFunction
{
	struct FCloudScriptExecuteFunctionRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetAssetDownloadUrl__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetAssetDownloadUrl__DelegateSignature
{
	struct FMultiplayerGetAssetDownloadUrlResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.GetFunction
// Size: 0x50(Inherited: 0x0) 
struct FGetFunction
{
	struct FCloudScriptGetFunctionRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerShutdownMultiplayerServerRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerShutdownMultiplayerServerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString SessionId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperExecuteEntityCloudScript
// Size: 0x50(Inherited: 0x0) 
struct FHelperExecuteEntityCloudScript
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperExecuteFunction
// Size: 0x50(Inherited: 0x0) 
struct FHelperExecuteFunction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetRemoteLoginEndpoint
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetRemoteLoginEndpoint
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.JoinLobby
// Size: 0x60(Inherited: 0x0) 
struct FJoinLobby
{
	struct FMultiplayerJoinLobbyRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperGetFunction
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetFunction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRefreshGameServerInstanceHeartbeatResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRefreshGameServerInstanceHeartbeatResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRefreshGameServerInstanceHeartbeatResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperListFunctions
// Size: 0x50(Inherited: 0x0) 
struct FHelperListFunctions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperListHttpFunctions
// Size: 0x50(Inherited: 0x0) 
struct FHelperListHttpFunctions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForEntityTriggeredAction
// Size: 0x50(Inherited: 0x0) 
struct FHelperPostFunctionResultForEntityTriggeredAction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetDraftItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetDraftItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForFunctionExecution
// Size: 0x50(Inherited: 0x0) 
struct FHelperPostFunctionResultForFunctionExecution
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForScheduledTask
// Size: 0x50(Inherited: 0x0) 
struct FHelperPostFunctionResultForScheduledTask
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerGetPlayerStatisticsResult
// Size: 0x28(Inherited: 0x8) 
struct FServerGetPlayerStatisticsResult : public FPlayFabResultCommon
{
	struct FString PlayFabId;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Statistics;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperRegisterQueuedFunction
// Size: 0x50(Inherited: 0x0) 
struct FHelperRegisterQueuedFunction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.HelperUnregisterFunction
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnregisterFunction
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.RemoveGroupInvitation
// Size: 0x50(Inherited: 0x0) 
struct FRemoveGroupInvitation
{
	struct FGroupsRemoveGroupInvitationRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.ListFunctions
// Size: 0x40(Inherited: 0x0) 
struct FListFunctions
{
	struct FCloudScriptListFunctionsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.FinalizeFileUploads
// Size: 0x60(Inherited: 0x0) 
struct FFinalizeFileUploads
{
	struct FDataFinalizeFileUploadsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptListFunctionsRequest
// Size: 0x10(Inherited: 0x8) 
struct FCloudScriptListFunctionsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.ListHttpFunctions
// Size: 0x40(Inherited: 0x0) 
struct FListHttpFunctions
{
	struct FCloudScriptListFunctionsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateCharacterReadOnlyData
// Size: 0x80(Inherited: 0x0) 
struct FUpdateCharacterReadOnlyData
{
	struct FServerUpdateCharacterDataRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromNintendoSwitchDeviceIdsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForEntityTriggeredAction
// Size: 0x50(Inherited: 0x0) 
struct FPostFunctionResultForEntityTriggeredAction
{
	struct FCloudScriptPostFunctionResultForEntityTriggeredActionRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptPostFunctionResultForEntityTriggeredActionRequest
// Size: 0x20(Inherited: 0x8) 
struct FCloudScriptPostFunctionResultForEntityTriggeredActionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* FunctionResult;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.RemoveGroupApplication
// Size: 0x50(Inherited: 0x0) 
struct FRemoveGroupApplication
{
	struct FGroupsRemoveGroupApplicationRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForFunctionExecution
// Size: 0x50(Inherited: 0x0) 
struct FPostFunctionResultForFunctionExecution
{
	struct FCloudScriptPostFunctionResultForFunctionExecutionRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptPostFunctionResultForFunctionExecutionRequest
// Size: 0x20(Inherited: 0x8) 
struct FCloudScriptPostFunctionResultForFunctionExecutionRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* FunctionResult;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForScheduledTask
// Size: 0x58(Inherited: 0x0) 
struct FPostFunctionResultForScheduledTask
{
	struct FCloudScriptPostFunctionResultForScheduledTaskRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.CloudScriptPostFunctionResultForScheduledTaskRequest
// Size: 0x28(Inherited: 0x8) 
struct FCloudScriptPostFunctionResultForScheduledTaskRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* FunctionResult;  // 0x18(0x8)
	struct UPlayFabJsonObject* ScheduledTaskId;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.RegisterQueuedFunction
// Size: 0x70(Inherited: 0x0) 
struct FRegisterQueuedFunction
{
	struct FCloudScriptRegisterQueuedFunctionRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabCloudScriptAPI.UnregisterFunction
// Size: 0x50(Inherited: 0x0) 
struct FUnregisterFunction
{
	struct FCloudScriptUnregisterFunctionRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabCloudScriptAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.AbortFileUploads
// Size: 0x60(Inherited: 0x0) 
struct FAbortFileUploads
{
	struct FDataAbortFileUploadsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.DataFinalizeFileUploadsResponse
// Size: 0x20(Inherited: 0x8) 
struct FDataFinalizeFileUploadsResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x10(0x8)
	int32_t ProfileVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessGetFiles__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetFiles__DelegateSignature
{
	struct FDataGetFilesResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.DataGetFilesResponse
// Size: 0x20(Inherited: 0x8) 
struct FDataGetFilesResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x10(0x8)
	int32_t ProfileVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetAssetDownloadUrlResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetAssetDownloadUrlResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetAssetDownloadUrlResponse ReturnValue;  // 0x8(0x28)

}; 
// ScriptStruct PlayFab.ServerRevokeAllBansForUserRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerRevokeAllBansForUserRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessInitiateFileUploads__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessInitiateFileUploads__DelegateSignature
{
	struct FDataInitiateFileUploadsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.DataInitiateFileUploadsResponse
// Size: 0x28(Inherited: 0x8) 
struct FDataInitiateFileUploadsResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	int32_t ProfileVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct UPlayFabJsonObject*> UploadDetails;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerGetFriendLeaderboardRequest
// Size: 0x60(Inherited: 0x8) 
struct FServerGetFriendLeaderboardRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IncludeFacebookFriends : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IncludeSteamFriends : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t MaxResultsCount;  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x28(0x8)
	int32_t StartPosition;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString StatisticName;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool UseSpecificVersion : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t Version;  // 0x4C(0x4)
	struct FString XboxToken;  // 0x50(0x10)

}; 
// ScriptStruct PlayFab.DataDeleteFilesRequest
// Size: 0x30(Inherited: 0x8) 
struct FDataDeleteFilesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString FileNames;  // 0x18(0x10)
	int32_t ProfileVersion;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function PlayFab.PlayFabDataAPI.GetObjects
// Size: 0x50(Inherited: 0x0) 
struct FGetObjects
{
	struct FDataGetObjectsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabDataAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.HelperAbortFileUploads
// Size: 0x50(Inherited: 0x0) 
struct FHelperAbortFileUploads
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabDataAPI.HelperGetFiles
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetFiles
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListQosServersForTitle
// Size: 0x48(Inherited: 0x0) 
struct FListQosServersForTitle
{
	struct FMultiplayerListQosServersForTitleRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabDataAPI.HelperGetObjects
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetObjects
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabDataAPI.HelperInitiateFileUploads
// Size: 0x50(Inherited: 0x0) 
struct FHelperInitiateFileUploads
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabDataAPI.HelperSetObjects
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetObjects
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.CreateDraftItem
// Size: 0x50(Inherited: 0x0) 
struct FCreateDraftItem
{
	struct FEconomyCreateDraftItemRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabInsightsAPI.GetLimits
// Size: 0x40(Inherited: 0x0) 
struct FGetLimits
{
	struct FInsightsInsightsEmptyRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabInsightsAPI* ReturnValue;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessCreateDraftItem__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessCreateDraftItem__DelegateSignature
{
	struct FEconomyCreateDraftItemResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRefreshGameServerInstanceHeartbeat
// Size: 0x50(Inherited: 0x0) 
struct FHelperRefreshGameServerInstanceHeartbeat
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.CreateUploadUrls
// Size: 0x50(Inherited: 0x0) 
struct FCreateUploadUrls
{
	struct FEconomyCreateUploadUrlsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.EconomyCreateUploadUrlsResponse
// Size: 0x18(Inherited: 0x8) 
struct FEconomyCreateUploadUrlsResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> UploadUrls;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteBuildRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerDeleteBuildRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.RemoveMember
// Size: 0x60(Inherited: 0x0) 
struct FRemoveMember
{
	struct FMultiplayerRemoveMemberFromLobbyRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessDeleteItem__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteItem__DelegateSignature
{
	struct FEconomyDeleteItemResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeReviewItemResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeReviewItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyReviewItemResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.ListGroupInvitations
// Size: 0x48(Inherited: 0x0) 
struct FListGroupInvitations
{
	struct FGroupsListGroupInvitationsRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetCatalogConfig__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetCatalogConfig__DelegateSignature
{
	struct FEconomyGetCatalogConfigResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildWithProcessBasedServerRequest
// Size: 0xC8(Inherited: 0x8) 
struct FMultiplayerCreateBuildWithProcessBasedServerRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildName;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x28(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x38(0x10)
	struct FString GameWorkingDirectory;  // 0x48(0x10)
	struct UPlayFabJsonObject* InstrumentationConfiguration;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool IsOSPreview : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UPlayFabJsonObject* MetaData;  // 0x68(0x8)
	struct UPlayFabJsonObject* MonitoringApplicationConfiguration;  // 0x70(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FString OsPlatform;  // 0x80(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0x90(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0xA0(0x10)
	struct FString StartMultiplayerServerCommand;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool UseStreamingForAssetDownloads : 1;  // 0xC0(0x1)
	uint8_t  VmSize;  // 0xC1(0x1)
	char pad_194[6];  // 0xC2(0x6)

}; 
// ScriptStruct PlayFab.EconomyGetCatalogConfigResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyGetCatalogConfigResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Config;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetDraftItemsResponse
// Size: 0x28(Inherited: 0x8) 
struct FEconomyGetDraftItemsResponse : public FPlayFabResultCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetEntityDraftItems__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessGetEntityDraftItems__DelegateSignature
{
	struct FEconomyGetEntityDraftItemsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemResponse
// Size: 0x10(Inherited: 0x8) 
struct FEconomyGetItemResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Item;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListQosServersForTitle
// Size: 0x50(Inherited: 0x0) 
struct FHelperListQosServersForTitle
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemModerationState__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetItemModerationState__DelegateSignature
{
	struct FEconomyGetItemModerationStateResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemPublishStatus__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetItemPublishStatus__DelegateSignature
{
	struct FEconomyGetItemPublishStatusResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemPublishStatusResponse
// Size: 0x20(Inherited: 0x8) 
struct FEconomyGetItemPublishStatusResponse : public FPlayFabResultCommon
{
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString StatusMessage;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.EconomyGetItemReviewsResponse
// Size: 0x28(Inherited: 0x8) 
struct FEconomyGetItemReviewsResponse : public FPlayFabResultCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Reviews;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.EconomyReportItemResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyReportItemResponse : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessReportItemReview__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessReportItemReview__DelegateSignature
{
	struct FEconomyReportItemReviewResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyReportItemReviewResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyReportItemReviewResponse : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessReviewItem__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessReviewItem__DelegateSignature
{
	struct FEconomyReviewItemResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetMultiplayerSessionLogsBySessionId
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMultiplayerSessionLogsBySessionId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabLocalizationModelDecoder.decodeGetLanguageListResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetLanguageListResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FLocalizationGetLanguageListResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.HelperLoginWithSteamId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithSteamId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSearchItems__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessSearchItems__DelegateSignature
{
	struct FEconomySearchItemsResponse Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.GroupsCreateGroupResponse
// Size: 0x60(Inherited: 0x8) 
struct FGroupsCreateGroupResponse : public FPlayFabResultCommon
{
	struct FString AdminRoleId;  // 0x8(0x10)
	struct FString Created;  // 0x18(0x10)
	struct UPlayFabJsonObject* Group;  // 0x28(0x8)
	struct FString GroupName;  // 0x30(0x10)
	struct FString MemberRoleId;  // 0x40(0x10)
	int32_t ProfileVersion;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct UPlayFabJsonObject* Roles;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.EconomySearchItemsResponse
// Size: 0x28(Inherited: 0x8) 
struct FEconomySearchItemsResponse : public FPlayFabResultCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeConsumeXboxEntitlementsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeConsumeXboxEntitlementsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientConsumeXboxEntitlementsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabEconomyAPI.UpdateDraftItem
// Size: 0x50(Inherited: 0x0) 
struct FUpdateDraftItem
{
	struct FEconomyUpdateDraftItemRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.EconomySetItemModerationStateResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomySetItemModerationStateResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.EconomyTakedownItemReviewsResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyTakedownItemReviewsResponse : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessUpdateCatalogConfig__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCatalogConfig__DelegateSignature
{
	struct FEconomyUpdateCatalogConfigResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetTreatmentAssignmentResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetTreatmentAssignmentResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationGetTreatmentAssignmentResult ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.EconomyUpdateCatalogConfigResponse
// Size: 0x8(Inherited: 0x8) 
struct FEconomyUpdateCatalogConfigResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ExperimentationDeleteExperimentRequest
// Size: 0x20(Inherited: 0x8) 
struct FExperimentationDeleteExperimentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExperimentId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetGameServerInstanceData
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetGameServerInstanceData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperBlockEntity
// Size: 0x50(Inherited: 0x0) 
struct FHelperBlockEntity
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeLinkPSNAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkPSNAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerLinkPSNAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.DeleteItem
// Size: 0x60(Inherited: 0x0) 
struct FDeleteItem
{
	struct FEconomyDeleteItemRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessAddMembers__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAddMembers__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyDeleteItemRequest
// Size: 0x30(Inherited: 0x8) 
struct FEconomyDeleteItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ID;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetServerCustomIDsFromPlayFabIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetServerCustomIDsFromPlayFabIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetServerCustomIDsFromPlayFabIDsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetCatalogConfig
// Size: 0x40(Inherited: 0x0) 
struct FGetCatalogConfig
{
	struct FEconomyGetCatalogConfigRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetCatalogConfigRequest
// Size: 0x10(Inherited: 0x8) 
struct FEconomyGetCatalogConfigRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessEnableMultiplayerServersForTitle__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessEnableMultiplayerServersForTitle__DelegateSignature
{
	struct FMultiplayerEnableMultiplayerServersForTitleResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSendEmailFromTemplateResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSendEmailFromTemplateResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSendEmailFromTemplateResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetDraftItemsRequest
// Size: 0x38(Inherited: 0x8) 
struct FEconomyGetDraftItemsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> AlternateIds;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x20(0x8)
	struct FString Ids;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetEntityDraftItems
// Size: 0x60(Inherited: 0x0) 
struct FGetEntityDraftItems
{
	struct FEconomyGetEntityDraftItemsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetEntityDraftItemsRequest
// Size: 0x30(Inherited: 0x8) 
struct FEconomyGetEntityDraftItemsRequest : public FPlayFabRequestCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	int32_t Count;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetEntityItemReview
// Size: 0x60(Inherited: 0x0) 
struct FGetEntityItemReview
{
	struct FEconomyGetEntityItemReviewRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkGooglePlayGamesServicesAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkGooglePlayGamesServicesAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkGooglePlayGamesServicesAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetItemModerationState
// Size: 0x58(Inherited: 0x0) 
struct FGetItemModerationState
{
	struct FEconomyGetItemModerationStateRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateTitleMultiplayerServersQuotaChange__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessCreateTitleMultiplayerServersQuotaChange__DelegateSignature
{
	struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemModerationStateRequest
// Size: 0x28(Inherited: 0x8) 
struct FEconomyGetItemModerationStateRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString ID;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAddCharacterVirtualCurrency
// Size: 0x50(Inherited: 0x0) 
struct FHelperAddCharacterVirtualCurrency
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetItemPublishStatus
// Size: 0x60(Inherited: 0x0) 
struct FGetItemPublishStatus
{
	struct FEconomyGetItemPublishStatusRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemPublishStatusRequest
// Size: 0x30(Inherited: 0x8) 
struct FEconomyGetItemPublishStatusRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct FString ID;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.EconomyGetItemReviewsRequest
// Size: 0x50(Inherited: 0x8) 
struct FEconomyGetItemReviewsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct FString ContinuationToken;  // 0x10(0x10)
	int32_t Count;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString ID;  // 0x30(0x10)
	struct FString OrderBy;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ServerUpdateAvatarUrlRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerUpdateAvatarUrlRequest : public FPlayFabRequestCommon
{
	struct FString ImageUrl;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.GetItemReviewSummary
// Size: 0x58(Inherited: 0x0) 
struct FGetItemReviewSummary
{
	struct FEconomyGetItemReviewSummaryRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.EconomyGetItemsRequest
// Size: 0x38(Inherited: 0x8) 
struct FEconomyGetItemsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> AlternateIds;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x20(0x8)
	struct FString Ids;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetEntityDraftItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetEntityDraftItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildAlias
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateBuildAlias
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetItemModerationState
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetItemModerationState
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetItemReviews
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetItemReviews
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetItemReviewSummary
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetItemReviewSummary
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperGetItems
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetItems
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperPublishDraftItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperPublishDraftItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerSubtractCharacterVirtualCurrencyRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerSubtractCharacterVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString CharacterId;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString PlayFabId;  // 0x28(0x10)
	struct FString VirtualCurrency;  // 0x38(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperReportItem
// Size: 0x50(Inherited: 0x0) 
struct FHelperReportItem
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerUpdateBuildRegionsRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerUpdateBuildRegionsRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> BuildRegions;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperInviteToGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperInviteToGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperReportItemReview
// Size: 0x50(Inherited: 0x0) 
struct FHelperReportItemReview
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkSteamAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkSteamAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkSteamAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperSetItemModerationState
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetItemModerationState
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperTakedownItemReviews
// Size: 0x50(Inherited: 0x0) 
struct FHelperTakedownItemReviews
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.HelperUpdateCatalogConfig
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCatalogConfig
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabEconomyAPI.PublishDraftItem
// Size: 0x70(Inherited: 0x0) 
struct FPublishDraftItem
{
	struct FEconomyPublishDraftItemRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.EconomyReportItemRequest
// Size: 0x48(Inherited: 0x8) 
struct FEconomyReportItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	uint8_t  ConcernCategory;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x20(0x8)
	struct FString ID;  // 0x28(0x10)
	struct FString Reason;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.EconomySearchItemsRequest
// Size: 0x70(Inherited: 0x8) 
struct FEconomySearchItemsRequest : public FPlayFabRequestCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	int32_t Count;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x28(0x8)
	struct FString Filter;  // 0x30(0x10)
	struct FString OrderBy;  // 0x40(0x10)
	struct FString Search;  // 0x50(0x10)
	struct FString Select;  // 0x60(0x10)

}; 
// Function PlayFab.PlayFabEconomyAPI.SetItemModerationState
// Size: 0x70(Inherited: 0x0) 
struct FSetItemModerationState
{
	struct FEconomySetItemModerationStateRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.EconomySetItemModerationStateRequest
// Size: 0x40(Inherited: 0x8) 
struct FEconomySetItemModerationStateRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* AlternateId;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString ID;  // 0x18(0x10)
	struct FString Reason;  // 0x28(0x10)
	uint8_t  Status;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGrantCharacterToUserResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGrantCharacterToUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGrantCharacterToUserResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabEconomyAPI.SubmitItemReviewVote
// Size: 0x78(Inherited: 0x0) 
struct FSubmitItemReviewVote
{
	struct FEconomySubmitItemReviewVoteRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.TakedownItemReviews
// Size: 0x50(Inherited: 0x0) 
struct FTakedownItemReviews
{
	struct FEconomyTakedownItemReviewsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabEconomyAPI.UpdateCatalogConfig
// Size: 0x48(Inherited: 0x0) 
struct FUpdateCatalogConfig
{
	struct FEconomyUpdateCatalogConfigRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabEconomyAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.EconomyUpdateDraftItemRequest
// Size: 0x20(Inherited: 0x8) 
struct FEconomyUpdateDraftItemRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Publish : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeGetTitlePlayersFromMasterPlayerAccountIdsResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetTitlePlayersFromMasterPlayerAccountIdsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsResponse ReturnValue;  // 0x8(0x20)

}; 
// ScriptStruct PlayFab.EventsWriteEventsResponse
// Size: 0x18(Inherited: 0x8) 
struct FEventsWriteEventsResponse : public FPlayFabResultCommon
{
	struct FString AssignedEventIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEventsAPI.HelperWriteTelemetryEvents
// Size: 0x50(Inherited: 0x0) 
struct FHelperWriteTelemetryEvents
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.EventsWriteEventsRequest
// Size: 0x20(Inherited: 0x8) 
struct FEventsWriteEventsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct TArray<struct UPlayFabJsonObject*> Events;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabEventsAPI.WriteTelemetryEvents
// Size: 0x50(Inherited: 0x0) 
struct FWriteTelemetryEvents
{
	struct FEventsWriteEventsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabEventsAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessCreateExclusionGroup__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateExclusionGroup__DelegateSignature
{
	struct FExperimentationCreateExclusionGroupResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeCurrentGamesResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeCurrentGamesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientCurrentGamesResult ReturnValue;  // 0x8(0x28)

}; 
// ScriptStruct PlayFab.ExperimentationCreateExclusionGroupResult
// Size: 0x18(Inherited: 0x8) 
struct FExperimentationCreateExclusionGroupResult : public FPlayFabResultCommon
{
	struct FString ExclusionGroupId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabExperimentationAPI.DeleteExperiment
// Size: 0x50(Inherited: 0x0) 
struct FDeleteExperiment
{
	struct FExperimentationDeleteExperimentRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.CreateExperiment
// Size: 0xC8(Inherited: 0x0) 
struct FCreateExperiment
{
	struct FExperimentationCreateExperimentRequest Request;  // 0x0(0x98)
	struct FDelegate onSuccess;  // 0x98(0x10)
	struct FDelegate onFailure;  // 0xA8(0x10)
	struct UObject* customData;  // 0xB8(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0xC0(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationCreateExperimentResult
// Size: 0x18(Inherited: 0x8) 
struct FExperimentationCreateExperimentResult : public FPlayFabResultCommon
{
	struct FString ExperimentId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.InsightsInsightsGetOperationStatusResponse
// Size: 0x80(Inherited: 0x8) 
struct FInsightsInsightsGetOperationStatusResponse : public FPlayFabResultCommon
{
	struct FString Message;  // 0x8(0x10)
	struct FString OperationCompletedTime;  // 0x18(0x10)
	struct FString OperationId;  // 0x28(0x10)
	struct FString OperationLastUpdated;  // 0x38(0x10)
	struct FString OperationStartedTime;  // 0x48(0x10)
	struct FString OperationType;  // 0x58(0x10)
	int32_t OperationValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FString Status;  // 0x70(0x10)

}; 
// DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessSetPerformance__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessSetPerformance__DelegateSignature
{
	struct FInsightsInsightsOperationResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationCreateExperimentRequest
// Size: 0x98(Inherited: 0x8) 
struct FExperimentationCreateExperimentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Description;  // 0x10(0x10)
	struct FString EndDate;  // 0x20(0x10)
	struct FString ExclusionGroupId;  // 0x30(0x10)
	int32_t ExclusionGroupTrafficAllocation;  // 0x40(0x4)
	uint8_t  ExperimentType;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FString Name;  // 0x48(0x10)
	struct FString SegmentId;  // 0x58(0x10)
	struct FString StartDate;  // 0x68(0x10)
	struct FString TitlePlayerAccountTestIds;  // 0x78(0x10)
	struct TArray<struct UPlayFabJsonObject*> Variants;  // 0x88(0x10)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessDeleteExclusionGroup__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteExclusionGroup__DelegateSignature
{
	struct FExperimentationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMatchmakerModelDecoder.decodePlayerLeftResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodePlayerLeftResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMatchmakerPlayerLeftResponse ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerRevokeBansResult
// Size: 0x18(Inherited: 0x8) 
struct FServerRevokeBansResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ExperimentationEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FExperimentationEmptyResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ExperimentationGetExclusionGroupsResult
// Size: 0x18(Inherited: 0x8) 
struct FExperimentationGetExclusionGroupsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> ExclusionGroups;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.DeletePushNotificationTemplate
// Size: 0x48(Inherited: 0x0) 
struct FDeletePushNotificationTemplate
{
	struct FServerDeletePushNotificationTemplateRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetExclusionGroupTraffic__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetExclusionGroupTraffic__DelegateSignature
{
	struct FExperimentationGetExclusionGroupTrafficResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateBuildWithManagedContainer
// Size: 0xF8(Inherited: 0x0) 
struct FCreateBuildWithManagedContainer
{
	struct FMultiplayerCreateBuildWithManagedContainerRequest Request;  // 0x0(0xC8)
	struct FDelegate onSuccess;  // 0xC8(0x10)
	struct FDelegate onFailure;  // 0xD8(0x10)
	struct UObject* customData;  // 0xE8(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0xF0(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationGetExclusionGroupTrafficResult
// Size: 0x18(Inherited: 0x8) 
struct FExperimentationGetExclusionGroupTrafficResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> TrafficAllocations;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerGetBuildAliasRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetBuildAliasRequest : public FPlayFabRequestCommon
{
	struct FString AliasId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetExperiments__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetExperiments__DelegateSignature
{
	struct FExperimentationGetExperimentsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationGetExperimentsResult
// Size: 0x18(Inherited: 0x8) 
struct FExperimentationGetExperimentsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Experiments;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperFindLobbies
// Size: 0x50(Inherited: 0x0) 
struct FHelperFindLobbies
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperStopExperiment
// Size: 0x50(Inherited: 0x0) 
struct FHelperStopExperiment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerCreateMatchmakingTicketRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerCreateMatchmakingTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Creator;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	int32_t GiveUpAfterSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct UPlayFabJsonObject*> MembersToMatchWith;  // 0x20(0x10)
	struct FString QueueName;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ExperimentationGetLatestScorecardResult
// Size: 0x10(Inherited: 0x8) 
struct FExperimentationGetLatestScorecardResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Scorecard;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessUpdateExperiment__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateExperiment__DelegateSignature
{
	struct FExperimentationEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.GetExclusionGroupTraffic
// Size: 0x50(Inherited: 0x0) 
struct FGetExclusionGroupTraffic
{
	struct FExperimentationGetExclusionGroupTrafficRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerSharedSecretsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayerSharedSecretsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetPlayerSharedSecretsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSendCustomAccountRecoveryEmail
// Size: 0x50(Inherited: 0x0) 
struct FHelperSendCustomAccountRecoveryEmail
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ExperimentationGetExclusionGroupTrafficRequest
// Size: 0x20(Inherited: 0x8) 
struct FExperimentationGetExclusionGroupTrafficRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExclusionGroupId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabExperimentationAPI.GetExperiments
// Size: 0x40(Inherited: 0x0) 
struct FGetExperiments
{
	struct FExperimentationGetExperimentsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.GetLatestScorecard
// Size: 0x50(Inherited: 0x0) 
struct FGetLatestScorecard
{
	struct FExperimentationGetLatestScorecardRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.GetTreatmentAssignment
// Size: 0x48(Inherited: 0x0) 
struct FGetTreatmentAssignment
{
	struct FExperimentationGetTreatmentAssignmentRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperCreateExclusionGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateExclusionGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperDeleteExperiment
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteExperiment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperGetExclusionGroups
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetExclusionGroups
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperGetExclusionGroupTraffic
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetExclusionGroupTraffic
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerRevokeInventoryResult
// Size: 0x8(Inherited: 0x8) 
struct FServerRevokeInventoryResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperGetExperiments
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetExperiments
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAddGenericIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAddGenericIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAddGenericIDResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperStartExperiment
// Size: 0x50(Inherited: 0x0) 
struct FHelperStartExperiment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.HelperUpdateExperiment
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateExperiment
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabExperimentationAPI.StartExperiment
// Size: 0x50(Inherited: 0x0) 
struct FStartExperiment
{
	struct FExperimentationStartExperimentRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.ListMembership
// Size: 0x48(Inherited: 0x0) 
struct FListMembership
{
	struct FGroupsListMembershipRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ExperimentationStartExperimentRequest
// Size: 0x20(Inherited: 0x8) 
struct FExperimentationStartExperimentRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ExperimentId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabExperimentationAPI.StopExperiment
// Size: 0x50(Inherited: 0x0) 
struct FStopExperiment
{
	struct FExperimentationStopExperimentRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.UpdateExclusionGroup
// Size: 0x70(Inherited: 0x0) 
struct FUpdateExclusionGroup
{
	struct FExperimentationUpdateExclusionGroupRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabExperimentationAPI.UpdateExperiment
// Size: 0xD8(Inherited: 0x0) 
struct FUpdateExperiment
{
	struct FExperimentationUpdateExperimentRequest Request;  // 0x0(0xA8)
	struct FDelegate onSuccess;  // 0xA8(0x10)
	struct FDelegate onFailure;  // 0xB8(0x10)
	struct UObject* customData;  // 0xC8(0x8)
	struct UPlayFabExperimentationAPI* ReturnValue;  // 0xD0(0x8)

}; 
// ScriptStruct PlayFab.GroupsEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FGroupsEmptyResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.MatchmakerPlayerJoinedResponse
// Size: 0x8(Inherited: 0x8) 
struct FMatchmakerPlayerJoinedResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.GroupsAcceptGroupApplicationRequest
// Size: 0x20(Inherited: 0x8) 
struct FGroupsAcceptGroupApplicationRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessAcceptGroupInvitation__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessAcceptGroupInvitation__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.ApplyToGroup
// Size: 0x58(Inherited: 0x0) 
struct FApplyToGroup
{
	struct FGroupsApplyToGroupRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.GroupsApplyToGroupResponse
// Size: 0x28(Inherited: 0x8) 
struct FGroupsApplyToGroupResponse : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Entity;  // 0x8(0x8)
	struct FString Expires;  // 0x10(0x10)
	struct UPlayFabJsonObject* Group;  // 0x20(0x8)

}; 
// DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetOperationStatus__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FDelegateOnSuccessGetOperationStatus__DelegateSignature
{
	struct FInsightsInsightsGetOperationStatusResponse Result;  // 0x0(0x80)
	struct UObject* customData;  // 0x80(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.BlockEntity
// Size: 0x50(Inherited: 0x0) 
struct FBlockEntity
{
	struct FGroupsBlockEntityRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.GroupsBlockEntityRequest
// Size: 0x20(Inherited: 0x8) 
struct FGroupsBlockEntityRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessChangeMemberRole__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessChangeMemberRole__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.GroupsChangeMemberRoleRequest
// Size: 0x48(Inherited: 0x8) 
struct FGroupsChangeMemberRoleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString DestinationRoleId;  // 0x10(0x10)
	struct UPlayFabJsonObject* Group;  // 0x20(0x8)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x28(0x10)
	struct FString OriginRoleId;  // 0x38(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListMultiplayerServers__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListMultiplayerServers__DelegateSignature
{
	struct FMultiplayerListMultiplayerServersResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.GroupsCreateGroupRequest
// Size: 0x28(Inherited: 0x8) 
struct FGroupsCreateGroupRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString GroupName;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessCreateRole__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessCreateRole__DelegateSignature
{
	struct FGroupsCreateGroupRoleResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessDeleteGroup__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteGroup__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.InsightsInsightsOperationResponse
// Size: 0x38(Inherited: 0x8) 
struct FInsightsInsightsOperationResponse : public FPlayFabResultCommon
{
	struct FString Message;  // 0x8(0x10)
	struct FString OperationId;  // 0x18(0x10)
	struct FString OperationType;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.GroupsGetGroupResponse
// Size: 0x60(Inherited: 0x8) 
struct FGroupsGetGroupResponse : public FPlayFabResultCommon
{
	struct FString AdminRoleId;  // 0x8(0x10)
	struct FString Created;  // 0x18(0x10)
	struct UPlayFabJsonObject* Group;  // 0x28(0x8)
	struct FString GroupName;  // 0x30(0x10)
	struct FString MemberRoleId;  // 0x40(0x10)
	int32_t ProfileVersion;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct UPlayFabJsonObject* Roles;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPurchaseResultResponse
// Size: 0x60(Inherited: 0x0) 
struct FdecodeGetPurchaseResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPurchaseResult ReturnValue;  // 0x8(0x58)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupBlocks__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListGroupBlocks__DelegateSignature
{
	struct FGroupsListGroupBlocksResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.GroupsListGroupBlocksResponse
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupBlocksResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BlockedEntities;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupInvitations__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListGroupInvitations__DelegateSignature
{
	struct FGroupsListGroupInvitationsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.GroupsListGroupInvitationsResponse
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupInvitationsResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Invitations;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListMembership__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListMembership__DelegateSignature
{
	struct FGroupsListMembershipResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.GroupsListMembershipResponse
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListMembershipResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Groups;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerProfileResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetPlayerProfileResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayerProfileResult ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessRemoveGroupInvitation__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveGroupInvitation__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetTitleMultiplayerServersQuotasRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetTitleMultiplayerServersQuotasRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessRemoveMembers__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRemoveMembers__DelegateSignature
{
	struct FGroupsEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessUpdateGroup__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateGroup__DelegateSignature
{
	struct FGroupsUpdateGroupResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.GroupsUpdateGroupResponse
// Size: 0x20(Inherited: 0x8) 
struct FGroupsUpdateGroupResponse : public FPlayFabResultCommon
{
	struct FString OperationReason;  // 0x8(0x10)
	int32_t ProfileVersion;  // 0x18(0x4)
	uint8_t  SetResult;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// ScriptStruct PlayFab.MultiplayerListMultiplayerServersResponse
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerListMultiplayerServersResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> MultiplayerServerSummaries;  // 0x8(0x10)
	int32_t PageSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SkipToken;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.DeleteGroup
// Size: 0x48(Inherited: 0x0) 
struct FDeleteGroup
{
	struct FGroupsDeleteGroupRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelMatchmakingTicket__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessCancelMatchmakingTicket__DelegateSignature
{
	struct FMultiplayerCancelMatchmakingTicketResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.InsightsInsightsGetOperationStatusRequest
// Size: 0x20(Inherited: 0x8) 
struct FInsightsInsightsGetOperationStatusRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString OperationId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.GroupsDeleteRoleRequest
// Size: 0x28(Inherited: 0x8) 
struct FGroupsDeleteRoleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)
	struct FString RoleId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.GetGroup
// Size: 0x58(Inherited: 0x0) 
struct FGetGroup
{
	struct FGroupsGetGroupRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ServerGetCharacterLeaderboardResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetCharacterLeaderboardResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperApplyToGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperApplyToGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayersInSegmentResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetPlayersInSegmentResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayersInSegmentResult ReturnValue;  // 0x8(0x30)

}; 
// ScriptStruct PlayFab.ServerGetPlayerProfileResult
// Size: 0x10(Inherited: 0x8) 
struct FServerGetPlayerProfileResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* PlayerProfile;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperCreateRole
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateRole
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperGetGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperIsMember
// Size: 0x50(Inherited: 0x0) 
struct FHelperIsMember
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperListGroupMembers
// Size: 0x50(Inherited: 0x0) 
struct FHelperListGroupMembers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperListMembership
// Size: 0x50(Inherited: 0x0) 
struct FHelperListMembership
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperUnblockEntity
// Size: 0x50(Inherited: 0x0) 
struct FHelperUnblockEntity
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperUpdateGroup
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateGroup
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabInsightsAPI.HelperGetDetails
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetDetails
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.HelperUpdateRole
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateRole
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.InviteToGroup
// Size: 0x68(Inherited: 0x0) 
struct FInviteToGroup
{
	struct FGroupsInviteToGroupRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.GroupsInviteToGroupRequest
// Size: 0x38(Inherited: 0x8) 
struct FGroupsInviteToGroupRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AutoAcceptOutstandingApplication : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)
	struct UPlayFabJsonObject* Group;  // 0x20(0x8)
	struct FString RoleId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.GroupsIsMemberRequest
// Size: 0x30(Inherited: 0x8) 
struct FGroupsIsMemberRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)
	struct FString RoleId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.GroupsListGroupApplicationsRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupApplicationsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetMatch
// Size: 0x70(Inherited: 0x0) 
struct FGetMatch
{
	struct FMultiplayerGetMatchRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ServerExecuteCloudScriptServerRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerExecuteCloudScriptServerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString FunctionName;  // 0x10(0x10)
	struct UPlayFabJsonObject* FunctionParameter;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool GeneratePlayStreamEvent : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString PlayFabId;  // 0x30(0x10)
	uint8_t  RevisionSelection;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t SpecificRevision;  // 0x44(0x4)

}; 
// ScriptStruct PlayFab.GroupsListGroupBlocksRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupBlocksRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerGetSharedGroupDataResult
// Size: 0x20(Inherited: 0x8) 
struct FServerGetSharedGroupDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)
	struct FString Members;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.GroupsListGroupInvitationsRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListGroupInvitationsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Group;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CancelAllServerBackfillTicketsForPlayer
// Size: 0x58(Inherited: 0x0) 
struct FCancelAllServerBackfillTicketsForPlayer
{
	struct FMultiplayerCancelAllServerBackfillTicketsForPlayerRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.GroupsListMembershipRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListMembershipRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerGetTitleDataResult
// Size: 0x10(Inherited: 0x8) 
struct FServerGetTitleDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.GroupsListMembershipOpportunitiesRequest
// Size: 0x18(Inherited: 0x8) 
struct FGroupsListMembershipOpportunitiesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.GroupsRemoveGroupApplicationRequest
// Size: 0x20(Inherited: 0x8) 
struct FGroupsRemoveGroupApplicationRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabGroupsAPI.RemoveMembers
// Size: 0x68(Inherited: 0x0) 
struct FRemoveMembers
{
	struct FGroupsRemoveMembersRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.GroupsUnblockEntityRequest
// Size: 0x20(Inherited: 0x8) 
struct FGroupsUnblockEntityRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRedeemCouponResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRedeemCouponResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRedeemCouponResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperInviteToLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperInviteToLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabGroupsAPI.UpdateGroup
// Size: 0x80(Inherited: 0x0) 
struct FUpdateGroup
{
	struct FGroupsUpdateGroupRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabGroupsAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListMultiplayerServersRequest
// Size: 0x48(Inherited: 0x8) 
struct FMultiplayerListMultiplayerServersRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	int32_t PageSize;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString Region;  // 0x28(0x10)
	struct FString SkipToken;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.GroupsUpdateGroupRequest
// Size: 0x50(Inherited: 0x8) 
struct FGroupsUpdateGroupRequest : public FPlayFabRequestCommon
{
	struct FString AdminRoleId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	int32_t ExpectedProfileVersion;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UPlayFabJsonObject* Group;  // 0x28(0x8)
	struct FString GroupName;  // 0x30(0x10)
	struct FString MemberRoleId;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.GroupsUpdateGroupRoleRequest
// Size: 0x40(Inherited: 0x8) 
struct FGroupsUpdateGroupRoleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t ExpectedProfileVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UPlayFabJsonObject* Group;  // 0x18(0x8)
	struct FString RoleId;  // 0x20(0x10)
	struct FString RoleName;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabProfilesAPI.GetProfile
// Size: 0x50(Inherited: 0x0) 
struct FGetProfile
{
	struct FProfilesGetEntityProfileRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.InsightsInsightsGetLimitsResponse
// Size: 0x28(Inherited: 0x8) 
struct FInsightsInsightsGetLimitsResponse : public FPlayFabResultCommon
{
	int32_t DefaultPerformanceLevel;  // 0x8(0x4)
	int32_t DefaultStorageRetentionDays;  // 0xC(0x4)
	int32_t StorageMaxRetentionDays;  // 0x10(0x4)
	int32_t StorageMinRetentionDays;  // 0x14(0x4)
	struct TArray<struct UPlayFabJsonObject*> SubMeters;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.InsightsInsightsGetPendingOperationsRequest
// Size: 0x20(Inherited: 0x8) 
struct FInsightsInsightsGetPendingOperationsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString OperationType;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabInsightsAPI.HelperGetPendingOperations
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetPendingOperations
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerGetTitleMultiplayerServersQuotaChangeRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetTitleMultiplayerServersQuotaChangeRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString RequestId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateServerBackfillTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateServerBackfillTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteAsset__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteAsset__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabInsightsAPI.SetPerformance
// Size: 0x48(Inherited: 0x0) 
struct FSetPerformance
{
	struct FInsightsInsightsSetPerformanceRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabInsightsAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.InsightsInsightsSetPerformanceRequest
// Size: 0x18(Inherited: 0x8) 
struct FInsightsInsightsSetPerformanceRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t PerformanceLevel;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function PlayFab.PlayFabLocalizationAPI.GetLanguageList
// Size: 0x40(Inherited: 0x0) 
struct FGetLanguageList
{
	struct FLocalizationGetLanguageListRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabLocalizationAPI* ReturnValue;  // 0x38(0x8)

}; 
// Function PlayFab.PlayFabLocalizationAPI.HelperGetLanguageList
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLanguageList
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessAuthUser__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessAuthUser__DelegateSignature
{
	struct FMatchmakerAuthUserResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetMultiplayerServerLogsResponse
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerGetMultiplayerServerLogsResponse : public FPlayFabResultCommon
{
	struct FString LogDownloadUrl;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MatchmakerAuthUserResponse
// Size: 0x20(Inherited: 0x8) 
struct FMatchmakerAuthUserResponse : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Authorized : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.HelperUserInfo
// Size: 0x50(Inherited: 0x0) 
struct FHelperUserInfo
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.PlayerJoined
// Size: 0x60(Inherited: 0x0) 
struct FPlayerJoined
{
	struct FMatchmakerPlayerJoinedRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMatchmakerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.MatchmakerPlayerJoinedRequest
// Size: 0x30(Inherited: 0x8) 
struct FMatchmakerPlayerJoinedRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.PlayerLeft
// Size: 0x60(Inherited: 0x0) 
struct FPlayerLeft
{
	struct FMatchmakerPlayerLeftRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMatchmakerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.MatchmakerPlayerLeftRequest
// Size: 0x30(Inherited: 0x8) 
struct FMatchmakerPlayerLeftRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabMatchmakerAPI.UserInfo
// Size: 0x58(Inherited: 0x0) 
struct FUserInfo
{
	struct FMatchmakerUserInfoRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMatchmakerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterDataResultResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeGetCharacterDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetCharacterDataResult ReturnValue;  // 0x8(0x38)

}; 
// ScriptStruct PlayFab.MatchmakerUserInfoRequest
// Size: 0x28(Inherited: 0x8) 
struct FMatchmakerUserInfoRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t MinCatalogVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUpdateSharedGroupDataResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdateSharedGroupDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUpdateSharedGroupDataResult ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelAllServerBackfillTicketsForPlayer__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessCancelAllServerBackfillTicketsForPlayer__DelegateSignature
{
	struct FMultiplayerCancelAllServerBackfillTicketsForPlayerResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCancelAllServerBackfillTicketsForPlayerRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerCancelAllServerBackfillTicketsForPlayerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString QueueName;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildName__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateBuildName__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CancelMatchmakingTicket
// Size: 0x60(Inherited: 0x0) 
struct FCancelMatchmakingTicket
{
	struct FMultiplayerCancelMatchmakingTicketRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCancelMatchmakingTicketRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerCancelMatchmakingTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString QueueName;  // 0x10(0x10)
	struct FString TicketId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerSendCustomAccountRecoveryEmailResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSendCustomAccountRecoveryEmailResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteLobby
// Size: 0x50(Inherited: 0x0) 
struct FDeleteLobby
{
	struct FMultiplayerDeleteLobbyRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelServerBackfillTicket__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessCancelServerBackfillTicket__DelegateSignature
{
	struct FMultiplayerCancelServerBackfillTicketResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeSetItemModerationStateResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetItemModerationStateResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomySetItemModerationStateResponse ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildAlias__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessCreateBuildAlias__DelegateSignature
{
	struct FMultiplayerBuildAliasDetailsResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerBuildAliasDetailsResponse
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerBuildAliasDetailsResponse : public FPlayFabResultCommon
{
	struct FString AliasId;  // 0x8(0x10)
	struct FString AliasName;  // 0x18(0x10)
	struct TArray<struct UPlayFabJsonObject*> BuildSelectionCriteria;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildAliasRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerCreateBuildAliasRequest : public FPlayFabRequestCommon
{
	struct FString AliasName;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> BuildSelectionCriteria;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateBuildWithCustomContainerRequest
// Size: 0xB8(Inherited: 0x8) 
struct FMultiplayerCreateBuildWithCustomContainerRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool AreAssetsReadonly : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString BuildName;  // 0x10(0x10)
	uint8_t  ContainerFlavor;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UPlayFabJsonObject* ContainerImageReference;  // 0x28(0x8)
	struct FString ContainerRunCommand;  // 0x30(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x40(0x8)
	struct TArray<struct UPlayFabJsonObject*> GameAssetReferences;  // 0x48(0x10)
	struct TArray<struct UPlayFabJsonObject*> GameCertificateReferences;  // 0x58(0x10)
	struct UPlayFabJsonObject* LinuxInstrumentationConfiguration;  // 0x68(0x8)
	struct UPlayFabJsonObject* MetaData;  // 0x70(0x8)
	struct UPlayFabJsonObject* MonitoringApplicationConfiguration;  // 0x78(0x8)
	int32_t MultiplayerServerCountPerVm;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0x88(0x10)
	struct TArray<struct UPlayFabJsonObject*> RegionConfigurations;  // 0x98(0x10)
	struct UPlayFabJsonObject* ServerResourceConstraints;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool UseStreamingForAssetDownloads : 1;  // 0xB0(0x1)
	uint8_t  VmSize;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildWithManagedContainer__DelegateSignature
// Size: 0x100(Inherited: 0x0) 
struct FDelegateOnSuccessCreateBuildWithManagedContainer__DelegateSignature
{
	struct FMultiplayerCreateBuildWithManagedContainerResponse Result;  // 0x0(0xF8)
	struct UObject* customData;  // 0xF8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateBuildWithProcessBasedServer
// Size: 0xF8(Inherited: 0x0) 
struct FCreateBuildWithProcessBasedServer
{
	struct FMultiplayerCreateBuildWithProcessBasedServerRequest Request;  // 0x0(0xC8)
	struct FDelegate onSuccess;  // 0xC8(0x10)
	struct FDelegate onFailure;  // 0xD8(0x10)
	struct UObject* customData;  // 0xE8(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0xF0(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateLobby
// Size: 0x88(Inherited: 0x0) 
struct FCreateLobby
{
	struct FMultiplayerCreateLobbyRequest Request;  // 0x0(0x58)
	struct FDelegate onSuccess;  // 0x58(0x10)
	struct FDelegate onFailure;  // 0x68(0x10)
	struct UObject* customData;  // 0x78(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x80(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteBuildAliasRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerDeleteBuildAliasRequest : public FPlayFabRequestCommon
{
	struct FString AliasId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateMatchmakingTicketResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerCreateMatchmakingTicketResult : public FPlayFabResultCommon
{
	struct FString TicketId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListCertificateSummaries
// Size: 0x50(Inherited: 0x0) 
struct FHelperListCertificateSummaries
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateRemoteUser
// Size: 0x90(Inherited: 0x0) 
struct FCreateRemoteUser
{
	struct FMultiplayerCreateRemoteUserRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x88(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateRemoteUser__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessCreateRemoteUser__DelegateSignature
{
	struct FMultiplayerCreateRemoteUserResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ServerSavePushNotificationTemplateRequest
// Size: 0x50(Inherited: 0x8) 
struct FServerSavePushNotificationTemplateRequest : public FPlayFabRequestCommon
{
	struct FString AndroidPayload;  // 0x8(0x10)
	struct FString ID;  // 0x18(0x10)
	struct FString IOSPayload;  // 0x28(0x10)
	struct UPlayFabJsonObject* LocalizedPushNotificationTemplates;  // 0x38(0x8)
	struct FString Name;  // 0x40(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessNotifyMatchmakerPlayerLeft__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessNotifyMatchmakerPlayerLeft__DelegateSignature
{
	struct FServerNotifyMatchmakerPlayerLeftResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateRemoteUserRequest
// Size: 0x60(Inherited: 0x8) 
struct FMultiplayerCreateRemoteUserRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString ExpirationTime;  // 0x20(0x10)
	struct FString Region;  // 0x30(0x10)
	struct FString Username;  // 0x40(0x10)
	struct FString VmId;  // 0x50(0x10)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetGlobalPolicy__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetGlobalPolicy__DelegateSignature
{
	struct FProfilesGetGlobalPolicyResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateServerMatchmakingTicket__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessCreateServerMatchmakingTicket__DelegateSignature
{
	struct FMultiplayerCreateMatchmakingTicketResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateServerBackfillTicket
// Size: 0x70(Inherited: 0x0) 
struct FCreateServerBackfillTicket
{
	struct FMultiplayerCreateServerBackfillTicketRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateServerBackfillTicketResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerCreateServerBackfillTicketResult : public FPlayFabResultCommon
{
	struct FString TicketId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerUnlinkServerCustomIdResult
// Size: 0x8(Inherited: 0x8) 
struct FServerUnlinkServerCustomIdResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.MultiplayerCreateServerBackfillTicketRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerCreateServerBackfillTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t GiveUpAfterSeconds;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x18(0x10)
	struct FString QueueName;  // 0x28(0x10)
	struct UPlayFabJsonObject* ServerDetails;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateServerMatchmakingTicketRequest
// Size: 0x38(Inherited: 0x8) 
struct FMultiplayerCreateServerMatchmakingTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t GiveUpAfterSeconds;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x18(0x10)
	struct FString QueueName;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerSubscribeToLobbyResourceRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerSubscribeToLobbyResourceRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* EntityKey;  // 0x10(0x8)
	struct FString PubSubConnectionHandle;  // 0x18(0x10)
	struct FString ResourceId;  // 0x28(0x10)
	int32_t SubscriptionVersion;  // 0x38(0x4)
	uint8_t  Type;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.CreateTitleMultiplayerServersQuotaChange
// Size: 0x90(Inherited: 0x0) 
struct FCreateTitleMultiplayerServersQuotaChange
{
	struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x88(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerCreateTitleMultiplayerServersQuotaChangeRequest
// Size: 0x60(Inherited: 0x8) 
struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeRequest : public FPlayFabRequestCommon
{
	struct FString ChangeDescription;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Changes;  // 0x18(0x10)
	struct FString ContactEmail;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)
	struct FString Notes;  // 0x40(0x10)
	struct FString StartDate;  // 0x50(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteBuild__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteBuild__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteBuildAlias__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteBuildAlias__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteBuildRegion__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteBuildRegion__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteRemoteUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteRemoteUser__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerEnableMultiplayerServersForTitleResponse
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerEnableMultiplayerServersForTitleResponse : public FPlayFabResultCommon
{
	uint8_t  Status;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeReportPlayerClientResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeReportPlayerClientResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientReportPlayerClientResult ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerFindFriendLobbiesResult
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerFindFriendLobbiesResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Lobbies;  // 0x8(0x10)
	struct UPlayFabJsonObject* Pagination;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessFindLobbies__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessFindLobbies__DelegateSignature
{
	struct FMultiplayerFindLobbiesResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerFindLobbiesResult
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerFindLobbiesResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Lobbies;  // 0x8(0x10)
	struct UPlayFabJsonObject* Pagination;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateStoreItemsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdateStoreItemsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdateStoreItemsResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetAssetDownloadUrlResponse
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerGetAssetDownloadUrlResponse : public FPlayFabResultCommon
{
	struct FString AssetDownloadUrl;  // 0x8(0x10)
	struct FString Filename;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetLobby__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetLobby__DelegateSignature
{
	struct FMultiplayerGetLobbyResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetBuild__DelegateSignature
// Size: 0x110(Inherited: 0x0) 
struct FDelegateOnSuccessGetBuild__DelegateSignature
{
	struct FMultiplayerGetBuildResponse Result;  // 0x0(0x108)
	struct UObject* customData;  // 0x108(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetContainerRegistryCredentials__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetContainerRegistryCredentials__DelegateSignature
{
	struct FMultiplayerGetContainerRegistryCredentialsResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMatch__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FDelegateOnSuccessGetMatch__DelegateSignature
{
	struct FMultiplayerGetMatchResult Result;  // 0x0(0x50)
	struct UObject* customData;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMatchmakingTicket__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FDelegateOnSuccessGetMatchmakingTicket__DelegateSignature
{
	struct FMultiplayerGetMatchmakingTicketResult Result;  // 0x0(0xA0)
	struct UObject* customData;  // 0xA0(0x8)

}; 
// ScriptStruct PlayFab.ProfilesGetTitlePlayersFromMasterPlayerAccountIdsResponse
// Size: 0x20(Inherited: 0x8) 
struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsResponse : public FPlayFabResultCommon
{
	struct FString TitleId;  // 0x8(0x10)
	struct UPlayFabJsonObject* TitlePlayerAccounts;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetMatchmakingTicketResult
// Size: 0xA0(Inherited: 0x8) 
struct FMultiplayerGetMatchmakingTicketResult : public FPlayFabResultCommon
{
	struct FString CancellationReasonString;  // 0x8(0x10)
	int32_t ChangeNumber;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Created;  // 0x20(0x10)
	struct UPlayFabJsonObject* Creator;  // 0x30(0x8)
	int32_t GiveUpAfterSeconds;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString MatchID;  // 0x40(0x10)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x50(0x10)
	struct TArray<struct UPlayFabJsonObject*> MembersToMatchWith;  // 0x60(0x10)
	struct FString QueueName;  // 0x70(0x10)
	struct FString Status;  // 0x80(0x10)
	struct FString TicketId;  // 0x90(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGameServerRegionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGameServerRegionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGameServerRegionsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.MultiplayerGetMultiplayerServerDetailsResponse
// Size: 0xB8(Inherited: 0x8) 
struct FMultiplayerGetMultiplayerServerDetailsResponse : public FPlayFabResultCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> ConnectedPlayers;  // 0x18(0x10)
	struct FString FQDN;  // 0x28(0x10)
	struct FString IPV4Address;  // 0x38(0x10)
	struct FString LastStateTransitionTime;  // 0x48(0x10)
	struct TArray<struct UPlayFabJsonObject*> Ports;  // 0x58(0x10)
	struct FString Region;  // 0x68(0x10)
	struct FString ServerId;  // 0x78(0x10)
	struct FString SessionId;  // 0x88(0x10)
	struct FString State;  // 0x98(0x10)
	struct FString VmId;  // 0xA8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMultiplayerServerLogs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetMultiplayerServerLogs__DelegateSignature
{
	struct FMultiplayerGetMultiplayerServerLogsResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetQueueStatisticsResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerGetQueueStatisticsResult : public FPlayFabResultCommon
{
	int32_t NumberOfPlayersMatching;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* TimeToMatchStatisticsInSeconds;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerUpdateUserDataResult
// Size: 0x10(Inherited: 0x8) 
struct FServerUpdateUserDataResult : public FPlayFabResultCommon
{
	int32_t DataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.MultiplayerGetServerBackfillTicketResult
// Size: 0x88(Inherited: 0x8) 
struct FMultiplayerGetServerBackfillTicketResult : public FPlayFabResultCommon
{
	struct FString CancellationReasonString;  // 0x8(0x10)
	struct FString Created;  // 0x18(0x10)
	int32_t GiveUpAfterSeconds;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString MatchID;  // 0x30(0x10)
	struct TArray<struct UPlayFabJsonObject*> Members;  // 0x40(0x10)
	struct FString QueueName;  // 0x50(0x10)
	struct UPlayFabJsonObject* ServerDetails;  // 0x60(0x8)
	struct FString Status;  // 0x68(0x10)
	struct FString TicketId;  // 0x78(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerGetTitleEnabledForMultiplayerServersStatusResponse
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusResponse : public FPlayFabResultCommon
{
	uint8_t  Status;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct PlayFab.ServerAddUserVirtualCurrencyRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerAddUserVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString VirtualCurrency;  // 0x28(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetTitleMultiplayerServersQuotaChange__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitleMultiplayerServersQuotaChange__DelegateSignature
{
	struct FMultiplayerGetTitleMultiplayerServersQuotaChangeResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetTitleMultiplayerServersQuotas__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitleMultiplayerServersQuotas__DelegateSignature
{
	struct FMultiplayerGetTitleMultiplayerServersQuotasResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessInviteToLobby__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessInviteToLobby__DelegateSignature
{
	struct FMultiplayerLobbyEmptyResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessJoinArrangedLobby__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessJoinArrangedLobby__DelegateSignature
{
	struct FMultiplayerJoinLobbyResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessJoinLobby__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessJoinLobby__DelegateSignature
{
	struct FMultiplayerJoinLobbyResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerJoinMatchmakingTicketResult
// Size: 0x8(Inherited: 0x8) 
struct FMultiplayerJoinMatchmakingTicketResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabServerAPI.GrantItemsToUser
// Size: 0x80(Inherited: 0x0) 
struct FGrantItemsToUser
{
	struct FServerGrantItemsToUserRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListArchivedMultiplayerServers__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListArchivedMultiplayerServers__DelegateSignature
{
	struct FMultiplayerListMultiplayerServersResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListAssetSummaries__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListAssetSummaries__DelegateSignature
{
	struct FMultiplayerListAssetSummariesResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListBuildSummariesV2__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListBuildSummariesV2__DelegateSignature
{
	struct FMultiplayerListBuildSummariesResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListContainerImages__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListContainerImages__DelegateSignature
{
	struct FMultiplayerListContainerImagesResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// ScriptStruct PlayFab.ServerLoginWithServerCustomIdRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerLoginWithServerCustomIdRequest : public FPlayFabRequestCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CreateAccount : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x18(0x8)
	struct FString PlayerSecret;  // 0x20(0x10)
	struct FString ServerCustomId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerListContainerImageTagsResponse
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerListContainerImageTagsResponse : public FPlayFabResultCommon
{
	struct FString Tags;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListMatchmakingTicketsForPlayer__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListMatchmakingTicketsForPlayer__DelegateSignature
{
	struct FMultiplayerListMatchmakingTicketsForPlayerResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetAssetDownloadUrl
// Size: 0x50(Inherited: 0x0) 
struct FGetAssetDownloadUrl
{
	struct FMultiplayerGetAssetDownloadUrlRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListPartyQosServers__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListPartyQosServers__DelegateSignature
{
	struct FMultiplayerListPartyQosServersResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListQosServersForTitle__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListQosServersForTitle__DelegateSignature
{
	struct FMultiplayerListQosServersForTitleResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessEvaluateRandomResultTable__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessEvaluateRandomResultTable__DelegateSignature
{
	struct FServerEvaluateRandomResultTableResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListTitleMultiplayerServersQuotaChanges__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessListTitleMultiplayerServersQuotaChanges__DelegateSignature
{
	struct FMultiplayerListTitleMultiplayerServersQuotaChangesResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListVirtualMachineSummaries__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessListVirtualMachineSummaries__DelegateSignature
{
	struct FMultiplayerListVirtualMachineSummariesResponse Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessShutdownMultiplayerServer__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessShutdownMultiplayerServer__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerRemoveSharedGroupMembersRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerRemoveSharedGroupMembersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabIds;  // 0x8(0x10)
	struct FString SharedGroupId;  // 0x18(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessSubscribeToLobbyResource__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessSubscribeToLobbyResource__DelegateSignature
{
	struct FMultiplayerSubscribeToLobbyResourceResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerSubscribeToLobbyResourceResult
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerSubscribeToLobbyResourceResult : public FPlayFabResultCommon
{
	struct FString Topic;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUntagContainerImage__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUntagContainerImage__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildAlias__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateBuildAlias__DelegateSignature
{
	struct FMultiplayerBuildAliasDetailsResponse Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildRegion__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateBuildRegion__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildRegions__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateBuildRegions__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUploadCertificate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUploadCertificate__DelegateSignature
{
	struct FMultiplayerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteAssetRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerDeleteAssetRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Filename;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteBuild
// Size: 0x50(Inherited: 0x0) 
struct FDeleteBuild
{
	struct FMultiplayerDeleteBuildRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteBuildAlias
// Size: 0x50(Inherited: 0x0) 
struct FDeleteBuildAlias
{
	struct FMultiplayerDeleteBuildAliasRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteBuildRegionRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerDeleteBuildRegionRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Region;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteCertificate
// Size: 0x50(Inherited: 0x0) 
struct FDeleteCertificate
{
	struct FMultiplayerDeleteCertificateRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteCertificateRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerDeleteCertificateRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Name;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetCloudScriptRevisionResultResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeGetCloudScriptRevisionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetCloudScriptRevisionResult ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteContainerImageRepository
// Size: 0x50(Inherited: 0x0) 
struct FDeleteContainerImageRepository
{
	struct FMultiplayerDeleteContainerImageRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteContainerImageRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerDeleteContainerImageRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ImageName;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerDeleteLobbyRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerDeleteLobbyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.DeleteRemoteUser
// Size: 0x80(Inherited: 0x0) 
struct FDeleteRemoteUser
{
	struct FMultiplayerDeleteRemoteUserRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.EnableMultiplayerServersForTitle
// Size: 0x40(Inherited: 0x0) 
struct FEnableMultiplayerServersForTitle
{
	struct FMultiplayerEnableMultiplayerServersForTitleRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerEnableMultiplayerServersForTitleRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerEnableMultiplayerServersForTitleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.FindFriendLobbies
// Size: 0x80(Inherited: 0x0) 
struct FFindFriendLobbies
{
	struct FMultiplayerFindFriendLobbiesRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.FindLobbies
// Size: 0x68(Inherited: 0x0) 
struct FFindLobbies
{
	struct FMultiplayerFindLobbiesRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetAssetDownloadUrlRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetAssetDownloadUrlRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Filename;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetBuild
// Size: 0x50(Inherited: 0x0) 
struct FGetBuild
{
	struct FMultiplayerGetBuildRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetContainerRegistryCredentialsRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerGetContainerRegistryCredentialsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetMatchRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerGetMatchRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool EscapeObject : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString MatchID;  // 0x18(0x10)
	struct FString QueueName;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnMemberAttributes : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerGetQueueStatisticsRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerGetQueueStatisticsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString QueueName;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetRemoteLoginEndpoint
// Size: 0x70(Inherited: 0x0) 
struct FGetRemoteLoginEndpoint
{
	struct FMultiplayerGetRemoteLoginEndpointRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerGetRemoteLoginEndpointRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerGetRemoteLoginEndpointRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString Region;  // 0x20(0x10)
	struct FString VmId;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.GetTitleMultiplayerServersQuotaChange
// Size: 0x50(Inherited: 0x0) 
struct FGetTitleMultiplayerServersQuotaChange
{
	struct FMultiplayerGetTitleMultiplayerServersQuotaChangeRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCancelAllServerBackfillTicketsForPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperCancelAllServerBackfillTicketsForPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildWithCustomContainer
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateBuildWithCustomContainer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildWithManagedContainer
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateBuildWithManagedContainer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerGetCatalogItemsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetCatalogItemsRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildWithProcessBasedServer
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateBuildWithProcessBasedServer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperCreateMatchmakingTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperCreateMatchmakingTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerGetCharacterInventoryResult
// Size: 0x48(Inherited: 0x8) 
struct FServerGetCharacterInventoryResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct TArray<struct UPlayFabJsonObject*> Inventory;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x38(0x8)
	struct UPlayFabJsonObject* VirtualCurrencyRechargeTimes;  // 0x40(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeleteLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetAssetDownloadUrl
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetAssetDownloadUrl
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetMatch
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetMatch
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerRemoveGenericIDRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerRemoveGenericIDRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* GenericId;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperGetTitleMultiplayerServersQuotaChange
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetTitleMultiplayerServersQuotaChange
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSavePushNotificationTemplate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessSavePushNotificationTemplate__DelegateSignature
{
	struct FServerSavePushNotificationTemplateResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperJoinArrangedLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperJoinArrangedLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperJoinLobby
// Size: 0x50(Inherited: 0x0) 
struct FHelperJoinLobby
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperJoinMatchmakingTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperJoinMatchmakingTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerSendEmailFromTemplateResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSendEmailFromTemplateResult : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListArchivedMultiplayerServers
// Size: 0x50(Inherited: 0x0) 
struct FHelperListArchivedMultiplayerServers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListAssetSummaries
// Size: 0x50(Inherited: 0x0) 
struct FHelperListAssetSummaries
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListBuildSummariesV2
// Size: 0x50(Inherited: 0x0) 
struct FHelperListBuildSummariesV2
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListMatchmakingTicketsForPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperListMatchmakingTicketsForPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListPartyQosServers
// Size: 0x50(Inherited: 0x0) 
struct FHelperListPartyQosServers
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.MultiplayerUpdateBuildRegionRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerUpdateBuildRegionRequest : public FPlayFabRequestCommon
{
	struct FString BuildId;  // 0x8(0x10)
	struct UPlayFabJsonObject* BuildRegion;  // 0x18(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListPartyQosServersRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerListPartyQosServersRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperListServerBackfillTicketsForPlayer
// Size: 0x50(Inherited: 0x0) 
struct FHelperListServerBackfillTicketsForPlayer
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildName
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateBuildName
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildRegion
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateBuildRegion
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildRegions
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateBuildRegions
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.InviteToLobby
// Size: 0x60(Inherited: 0x0) 
struct FInviteToLobby
{
	struct FMultiplayerInviteToLobbyRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.JoinMatchmakingTicket
// Size: 0x68(Inherited: 0x0) 
struct FJoinMatchmakingTicket
{
	struct FMultiplayerJoinMatchmakingTicketRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x60(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListArchivedMultiplayerServers
// Size: 0x78(Inherited: 0x0) 
struct FListArchivedMultiplayerServers
{
	struct FMultiplayerListMultiplayerServersRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x70(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetGameServerInstanceData__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetGameServerInstanceData__DelegateSignature
{
	struct FServerSetGameServerInstanceDataResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListAssetSummaries
// Size: 0x58(Inherited: 0x0) 
struct FListAssetSummaries
{
	struct FMultiplayerListAssetSummariesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateBuildWithManagedContainerResponseResponse
// Size: 0x100(Inherited: 0x0) 
struct FdecodeCreateBuildWithManagedContainerResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateBuildWithManagedContainerResponse ReturnValue;  // 0x8(0xF8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListBuildAliases
// Size: 0x58(Inherited: 0x0) 
struct FListBuildAliases
{
	struct FMultiplayerListBuildAliasesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListBuildSummariesV2
// Size: 0x58(Inherited: 0x0) 
struct FListBuildSummariesV2
{
	struct FMultiplayerListBuildSummariesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListCertificateSummaries
// Size: 0x58(Inherited: 0x0) 
struct FListCertificateSummaries
{
	struct FMultiplayerListCertificateSummariesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListCertificateSummariesRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListCertificateSummariesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t PageSize;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString SkipToken;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListContainerImages
// Size: 0x58(Inherited: 0x0) 
struct FListContainerImages
{
	struct FMultiplayerListContainerImagesRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListContainerImagesRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListContainerImagesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t PageSize;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString SkipToken;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetStoreItemsResultResponse
// Size: 0x50(Inherited: 0x0) 
struct FdecodeGetStoreItemsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetStoreItemsResult ReturnValue;  // 0x8(0x48)

}; 
// ScriptStruct PlayFab.ServerEmptyResponse
// Size: 0x8(Inherited: 0x8) 
struct FServerEmptyResponse : public FPlayFabResultCommon
{

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListContainerImageTags
// Size: 0x50(Inherited: 0x0) 
struct FListContainerImageTags
{
	struct FMultiplayerListContainerImageTagsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListContainerImageTagsRequest
// Size: 0x20(Inherited: 0x8) 
struct FMultiplayerListContainerImageTagsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ImageName;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerRevokeAllBansForUserResult
// Size: 0x18(Inherited: 0x8) 
struct FServerRevokeAllBansForUserResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListMatchmakingTicketsForPlayer
// Size: 0x58(Inherited: 0x0) 
struct FListMatchmakingTicketsForPlayer
{
	struct FMultiplayerListMatchmakingTicketsForPlayerRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelAllMatchmakingTicketsForPlayerResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeCancelAllMatchmakingTicketsForPlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCancelAllMatchmakingTicketsForPlayerResult ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListMatchmakingTicketsForPlayerRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListMatchmakingTicketsForPlayerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString QueueName;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListMultiplayerServers
// Size: 0x78(Inherited: 0x0) 
struct FListMultiplayerServers
{
	struct FMultiplayerListMultiplayerServersRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListPartyQosServers
// Size: 0x40(Inherited: 0x0) 
struct FListPartyQosServers
{
	struct FMultiplayerListPartyQosServersRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListQosServersForTitleRequest
// Size: 0x18(Inherited: 0x8) 
struct FMultiplayerListQosServersForTitleRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IncludeAllRegions : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListServerBackfillTicketsForPlayer
// Size: 0x58(Inherited: 0x0) 
struct FListServerBackfillTicketsForPlayer
{
	struct FMultiplayerListServerBackfillTicketsForPlayerRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerListServerBackfillTicketsForPlayerRequest
// Size: 0x28(Inherited: 0x8) 
struct FMultiplayerListServerBackfillTicketsForPlayerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	struct FString QueueName;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.ListVirtualMachineSummaries
// Size: 0x78(Inherited: 0x0) 
struct FListVirtualMachineSummaries
{
	struct FMultiplayerListVirtualMachineSummariesRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ServerGetCharacterDataResult
// Size: 0x38(Inherited: 0x8) 
struct FServerGetCharacterDataResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* Data;  // 0x18(0x8)
	int32_t DataVersion;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.MultiplayerRequestMultiplayerServerRequest
// Size: 0x68(Inherited: 0x8) 
struct FMultiplayerRequestMultiplayerServerRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* BuildAliasParams;  // 0x8(0x8)
	struct FString BuildId;  // 0x10(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString InitialPlayers;  // 0x28(0x10)
	struct FString PreferredRegions;  // 0x38(0x10)
	struct FString SessionCookie;  // 0x48(0x10)
	struct FString SessionId;  // 0x58(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.RolloverContainerRegistryCredentials
// Size: 0x40(Inherited: 0x0) 
struct FRolloverContainerRegistryCredentials
{
	struct FMultiplayerRolloverContainerRegistryCredentialsRequest Request;  // 0x0(0x10)
	struct FDelegate onSuccess;  // 0x10(0x10)
	struct FDelegate onFailure;  // 0x20(0x10)
	struct UObject* customData;  // 0x30(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerRolloverContainerRegistryCredentialsRequest
// Size: 0x10(Inherited: 0x8) 
struct FMultiplayerRolloverContainerRegistryCredentialsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabJsonValue.GetTypeString
// Size: 0x10(Inherited: 0x0) 
struct FGetTypeString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UnsubscribeFromLobbyResource
// Size: 0x70(Inherited: 0x0) 
struct FUnsubscribeFromLobbyResource
{
	struct FMultiplayerUnsubscribeFromLobbyResourceRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerUnsubscribeFromLobbyResourceRequest
// Size: 0x40(Inherited: 0x8) 
struct FMultiplayerUnsubscribeFromLobbyResourceRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* EntityKey;  // 0x10(0x8)
	struct FString PubSubConnectionHandle;  // 0x18(0x10)
	struct FString ResourceId;  // 0x28(0x10)
	int32_t SubscriptionVersion;  // 0x38(0x4)
	uint8_t  Type;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UntagContainerImage
// Size: 0x60(Inherited: 0x0) 
struct FUntagContainerImage
{
	struct FMultiplayerUntagContainerImageRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerUntagContainerImageRequest
// Size: 0x30(Inherited: 0x8) 
struct FMultiplayerUntagContainerImageRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ImageName;  // 0x10(0x10)
	struct FString Tag;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildAlias
// Size: 0x70(Inherited: 0x0) 
struct FUpdateBuildAlias
{
	struct FMultiplayerUpdateBuildAliasRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabProfilesAPI.GetTitlePlayersFromMasterPlayerAccountIds
// Size: 0x50(Inherited: 0x0) 
struct FGetTitlePlayersFromMasterPlayerAccountIds
{
	struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x48(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildName
// Size: 0x60(Inherited: 0x0) 
struct FUpdateBuildName
{
	struct FMultiplayerUpdateBuildNameRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMatchResultResponse
// Size: 0x58(Inherited: 0x0) 
struct FdecodeGetMatchResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetMatchResult ReturnValue;  // 0x8(0x50)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildRegion
// Size: 0x58(Inherited: 0x0) 
struct FUpdateBuildRegion
{
	struct FMultiplayerUpdateBuildRegionRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x50(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildRegions
// Size: 0x60(Inherited: 0x0) 
struct FUpdateBuildRegions
{
	struct FMultiplayerUpdateBuildRegionsRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x58(0x8)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeInitiateFileUploadsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeInitiateFileUploadsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataInitiateFileUploadsResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UpdateLobby
// Size: 0xC0(Inherited: 0x0) 
struct FUpdateLobby
{
	struct FMultiplayerUpdateLobbyRequest Request;  // 0x0(0x90)
	struct FDelegate onSuccess;  // 0x90(0x10)
	struct FDelegate onFailure;  // 0xA0(0x10)
	struct UObject* customData;  // 0xB0(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0xB8(0x8)

}; 
// ScriptStruct PlayFab.MultiplayerUpdateLobbyRequest
// Size: 0x90(Inherited: 0x8) 
struct FMultiplayerUpdateLobbyRequest : public FPlayFabRequestCommon
{
	uint8_t  AccessPolicy;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct UPlayFabJsonObject* LobbyData;  // 0x18(0x8)
	struct FString LobbyDataToDelete;  // 0x20(0x10)
	struct FString LobbyId;  // 0x30(0x10)
	int32_t MaxPlayers;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UPlayFabJsonObject* MemberData;  // 0x48(0x8)
	struct FString MemberDataToDelete;  // 0x50(0x10)
	struct UPlayFabJsonObject* MemberEntity;  // 0x60(0x8)
	uint8_t  MembershipLock;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UPlayFabJsonObject* Owner;  // 0x70(0x8)
	struct UPlayFabJsonObject* SearchData;  // 0x78(0x8)
	struct FString SearchDataToDelete;  // 0x80(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerAPI.UploadCertificate
// Size: 0x48(Inherited: 0x0) 
struct FUploadCertificate
{
	struct FMultiplayerUploadCertificateRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabMultiplayerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetProfile__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessGetProfile__DelegateSignature
{
	struct FProfilesGetEntityProfileResponse Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ProfilesGetEntityProfilesResponse
// Size: 0x18(Inherited: 0x8) 
struct FProfilesGetEntityProfilesResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Profiles;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemReviewsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetItemReviewsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetItemReviewsResponse ReturnValue;  // 0x8(0x28)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetTitlePlayersFromMasterPlayerAccountIds__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessGetTitlePlayersFromMasterPlayerAccountIds__DelegateSignature
{
	struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsResponse Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessSetGlobalPolicy__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetGlobalPolicy__DelegateSignature
{
	struct FProfilesSetGlobalPolicyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerGetTitleDataRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetTitleDataRequest : public FPlayFabRequestCommon
{
	struct FString Keys;  // 0x8(0x10)
	struct FString OverrideLabel;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ProfilesSetGlobalPolicyResponse
// Size: 0x8(Inherited: 0x8) 
struct FProfilesSetGlobalPolicyResponse : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ProfilesSetProfileLanguageResponse
// Size: 0x10(Inherited: 0x8) 
struct FProfilesSetProfileLanguageResponse : public FPlayFabResultCommon
{
	uint8_t  OperationResult;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t VersionNumber;  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.ProfilesSetEntityProfilePolicyResponse
// Size: 0x18(Inherited: 0x8) 
struct FProfilesSetEntityProfilePolicyResponse : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Permissions;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabProfilesAPI.GetGlobalPolicy
// Size: 0x48(Inherited: 0x0) 
struct FGetGlobalPolicy
{
	struct FProfilesGetGlobalPolicyRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ProfilesGetGlobalPolicyRequest
// Size: 0x18(Inherited: 0x8) 
struct FProfilesGetGlobalPolicyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ProfilesGetEntityProfileRequest
// Size: 0x20(Inherited: 0x8) 
struct FProfilesGetEntityProfileRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool DataAsObject : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UPlayFabJsonObject* Entity;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetItemsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetItemsResponse ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerGetPlayerStatisticVersionsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayerStatisticVersionsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> StatisticVersions;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ProfilesGetEntityProfilesRequest
// Size: 0x28(Inherited: 0x8) 
struct FProfilesGetEntityProfilesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool DataAsObject : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct UPlayFabJsonObject*> Entities;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ProfilesGetTitlePlayersFromMasterPlayerAccountIdsRequest
// Size: 0x20(Inherited: 0x8) 
struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString MasterPlayerAccountIds;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeCreateExperimentResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateExperimentResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationCreateExperimentResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperGetGlobalPolicy
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetGlobalPolicy
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperGetProfile
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetProfile
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkXboxAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkXboxAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUnlinkXboxAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabProfilesAPI.HelperSetGlobalPolicy
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetGlobalPolicy
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabProfilesAPI.SetGlobalPolicy
// Size: 0x50(Inherited: 0x0) 
struct FSetGlobalPolicy
{
	struct FProfilesSetGlobalPolicyRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ProfilesSetGlobalPolicyRequest
// Size: 0x20(Inherited: 0x8) 
struct FProfilesSetGlobalPolicyRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct TArray<struct UPlayFabJsonObject*> Permissions;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabProfilesAPI.SetProfileLanguage
// Size: 0x60(Inherited: 0x0) 
struct FSetProfileLanguage
{
	struct FProfilesSetProfileLanguageRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ProfilesSetProfileLanguageRequest
// Size: 0x30(Inherited: 0x8) 
struct FProfilesSetProfileLanguageRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* Entity;  // 0x10(0x8)
	int32_t ExpectedVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Language;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabProfilesAPI.SetProfilePolicy
// Size: 0x58(Inherited: 0x0) 
struct FSetProfilePolicy
{
	struct FProfilesSetEntityProfilePolicyRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabProfilesAPI* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddCharacterVirtualCurrency__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessAddCharacterVirtualCurrency__DelegateSignature
{
	struct FServerModifyCharacterVirtualCurrencyResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ServerAddFriendRequest
// Size: 0x58(Inherited: 0x8) 
struct FServerAddFriendRequest : public FPlayFabRequestCommon
{
	struct FString FriendEmail;  // 0x8(0x10)
	struct FString FriendPlayFabId;  // 0x18(0x10)
	struct FString FriendTitleDisplayName;  // 0x28(0x10)
	struct FString FriendUsername;  // 0x38(0x10)
	struct FString PlayFabId;  // 0x48(0x10)

}; 
// ScriptStruct PlayFab.ServerEmptyResult
// Size: 0x8(Inherited: 0x8) 
struct FServerEmptyResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerAddPlayerTagRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerAddPlayerTagRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct FString TagName;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerGetUserBansRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetUserBansRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.AuthenticateSessionTicket
// Size: 0x48(Inherited: 0x0) 
struct FAuthenticateSessionTicket
{
	struct FServerAuthenticateSessionTicketRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAuthenticateSessionTicket__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessAuthenticateSessionTicket__DelegateSignature
{
	struct FServerAuthenticateSessionTicketResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerAuthenticateSessionTicketResult
// Size: 0x18(Inherited: 0x8) 
struct FServerAuthenticateSessionTicketResult : public FPlayFabResultCommon
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsSessionTicketExpired : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPlayFabJsonObject* UserInfo;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerMoveItemToCharacterFromCharacterResult
// Size: 0x8(Inherited: 0x8) 
struct FServerMoveItemToCharacterFromCharacterResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerAuthenticateSessionTicketRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerAuthenticateSessionTicketRequest : public FPlayFabRequestCommon
{
	struct FString SessionTicket;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.AwardSteamAchievement
// Size: 0x48(Inherited: 0x0) 
struct FAwardSteamAchievement
{
	struct FServerAwardSteamAchievementRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ServerAwardSteamAchievementResult
// Size: 0x18(Inherited: 0x8) 
struct FServerAwardSteamAchievementResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> AchievementResults;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromPSNAccountIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromPSNAccountIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromPSNAccountIDsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerConsumeItemResult
// Size: 0x20(Inherited: 0x8) 
struct FServerConsumeItemResult : public FPlayFabResultCommon
{
	struct FString ItemInstanceId;  // 0x8(0x10)
	int32_t RemainingUses;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct PlayFab.ServerConsumeItemRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerConsumeItemRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	int32_t ConsumeCount;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString ItemInstanceId;  // 0x28(0x10)
	struct FString PlayFabId;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.ServerCreateSharedGroupResult
// Size: 0x18(Inherited: 0x8) 
struct FServerCreateSharedGroupResult : public FPlayFabResultCommon
{
	struct FString SharedGroupId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerSetGameServerInstanceDataResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSetGameServerInstanceDataResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerDeletePlayerResult
// Size: 0x8(Inherited: 0x8) 
struct FServerDeletePlayerResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantItemsToCharacter__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGrantItemsToCharacter__DelegateSignature
{
	struct FServerGrantItemsToCharacterResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeletePushNotificationTemplate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeletePushNotificationTemplate__DelegateSignature
{
	struct FServerDeletePushNotificationTemplateResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerDeletePushNotificationTemplateResult
// Size: 0x8(Inherited: 0x8) 
struct FServerDeletePushNotificationTemplateResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeleteSharedGroup__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeleteSharedGroup__DelegateSignature
{
	struct FServerEmptyResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeregisterGame__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessDeregisterGame__DelegateSignature
{
	struct FServerDeregisterGameResponse Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerEvaluateRandomResultTableResult
// Size: 0x18(Inherited: 0x8) 
struct FServerEvaluateRandomResultTableResult : public FPlayFabResultCommon
{
	struct FString ResultItemId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerExecuteCloudScriptResult
// Size: 0x60(Inherited: 0x8) 
struct FServerExecuteCloudScriptResult : public FPlayFabResultCommon
{
	int32_t APIRequestsIssued;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* Error;  // 0x10(0x8)
	int32_t ExecutionTimeSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString FunctionName;  // 0x20(0x10)
	struct UPlayFabJsonObject* FunctionResult;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool FunctionResultTooLarge : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t HttpRequestsIssued;  // 0x3C(0x4)
	struct TArray<struct UPlayFabJsonObject*> Logs;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool LogsTooLarge : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t MemoryConsumedBytes;  // 0x54(0x4)
	int32_t ProcessorTimeSeconds;  // 0x58(0x4)
	int32_t Revision;  // 0x5C(0x4)

}; 
// ScriptStruct PlayFab.ServerGetAllSegmentsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetAllSegmentsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Segments;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerListUsersCharactersResult
// Size: 0x18(Inherited: 0x8) 
struct FServerListUsersCharactersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Characters;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetCatalogItemsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetCatalogItemsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Catalog;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterInternalData__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDelegateOnSuccessGetCharacterInternalData__DelegateSignature
{
	struct FServerGetCharacterDataResult Result;  // 0x0(0x38)
	struct UObject* customData;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ServerGetCharacterStatisticsResult
// Size: 0x30(Inherited: 0x8) 
struct FServerGetCharacterStatisticsResult : public FPlayFabResultCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CharacterStatistics;  // 0x18(0x8)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerGetContentDownloadUrlResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetContentDownloadUrlResult : public FPlayFabResultCommon
{
	struct FString URL;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardResult
// Size: 0x30(Inherited: 0x8) 
struct FServerGetLeaderboardResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)
	struct FString NextReset;  // 0x18(0x10)
	int32_t Version;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardAroundCharacterResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetLeaderboardAroundCharacterResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboardAroundUser__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FDelegateOnSuccessGetLeaderboardAroundUser__DelegateSignature
{
	struct FServerGetLeaderboardAroundUserResult Result;  // 0x0(0x30)
	struct UObject* customData;  // 0x30(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromGenericIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromGenericIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromGenericIDsResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardForUsersCharactersResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetLeaderboardForUsersCharactersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Leaderboard;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayerCombinedInfoResult
// Size: 0x20(Inherited: 0x8) 
struct FServerGetPlayerCombinedInfoResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* InfoResultPayload;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayerSegmentsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayerSegmentsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Segments;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetBuildResponseResponse
// Size: 0x110(Inherited: 0x0) 
struct FdecodeGetBuildResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetBuildResponse ReturnValue;  // 0x8(0x108)

}; 
// ScriptStruct PlayFab.ServerGetPlayerTagsResult
// Size: 0x28(Inherited: 0x8) 
struct FServerGetPlayerTagsResult : public FPlayFabResultCommon
{
	struct FString PlayFabId;  // 0x8(0x10)
	struct FString Tags;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.LinkServerCustomId
// Size: 0x68(Inherited: 0x0) 
struct FLinkServerCustomId
{
	struct FServerLinkServerCustomIdRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromFacebookInstantGamesIdsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromGenericIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromGenericIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromNintendoServiceAccountIdsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromPSNAccountIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromPSNAccountIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromTwitchIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromTwitchIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromXboxLiveIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromXboxLiveIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeCreateSharedGroupResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateSharedGroupResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerCreateSharedGroupResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerGetPublisherDataResult
// Size: 0x10(Inherited: 0x8) 
struct FServerGetPublisherDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerGetRandomResultTablesResult
// Size: 0x10(Inherited: 0x8) 
struct FServerGetRandomResultTablesResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Tables;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetServerCustomIDsFromPlayFabIDs__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGetServerCustomIDsFromPlayFabIDs__DelegateSignature
{
	struct FServerGetServerCustomIDsFromPlayFabIDsResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerGetServerCustomIDsFromPlayFabIDsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetServerCustomIDsFromPlayFabIDsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Data;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetTitleNewsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGetTitleNewsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> News;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetUserAccountInfoResult
// Size: 0x10(Inherited: 0x8) 
struct FServerGetUserAccountInfoResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* UserInfo;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerGetUserDataResult
// Size: 0x28(Inherited: 0x8) 
struct FServerGetUserDataResult : public FPlayFabResultCommon
{
	struct UPlayFabJsonObject* Data;  // 0x8(0x8)
	int32_t DataVersion;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerGetUserInventoryResult
// Size: 0x38(Inherited: 0x8) 
struct FServerGetUserInventoryResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Inventory;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x28(0x8)
	struct UPlayFabJsonObject* VirtualCurrencyRechargeTimes;  // 0x30(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantItemsToUser__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessGrantItemsToUser__DelegateSignature
{
	struct FServerGrantItemsToUserResult Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerGrantItemsToUserResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGrantItemsToUserResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> ItemGrantResults;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGrantItemsToUsersResult
// Size: 0x18(Inherited: 0x8) 
struct FServerGrantItemsToUsersResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> ItemGrantResults;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerLinkPSNAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FServerLinkPSNAccountResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerLinkXboxAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FServerLinkXboxAccountResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithServerCustomId__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithServerCustomId__DelegateSignature
{
	struct FServerServerLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.HelperEvaluateRandomResultTable
// Size: 0x50(Inherited: 0x0) 
struct FHelperEvaluateRandomResultTable
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerUpdateBansResult
// Size: 0x18(Inherited: 0x8) 
struct FServerUpdateBansResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> BanData;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerServerLoginResult
// Size: 0x68(Inherited: 0x10) 
struct FServerServerLoginResult : public FPlayFabLoginResultCommon
{
	struct UPlayFabJsonObject* EntityToken;  // 0x10(0x8)
	struct UPlayFabJsonObject* InfoResultPayload;  // 0x18(0x8)
	struct FString LastLoginTime;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool NewlyCreated : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString PlayFabId;  // 0x38(0x10)
	struct FString SessionTicket;  // 0x48(0x10)
	struct UPlayFabJsonObject* SettingsForUser;  // 0x58(0x8)
	struct UPlayFabJsonObject* TreatmentAssignment;  // 0x60(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithSteamId__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FDelegateOnSuccessLoginWithSteamId__DelegateSignature
{
	struct FServerServerLoginResult Result;  // 0x0(0x68)
	struct UObject* customData;  // 0x68(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessModifyItemUses__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FDelegateOnSuccessModifyItemUses__DelegateSignature
{
	struct FServerModifyItemUsesResult Result;  // 0x0(0x20)
	struct UObject* customData;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateBuildWithProcessBasedServerResponseResponse
// Size: 0x100(Inherited: 0x0) 
struct FdecodeCreateBuildWithProcessBasedServerResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateBuildWithProcessBasedServerResponse ReturnValue;  // 0x8(0xF8)

}; 
// ScriptStruct PlayFab.ServerModifyItemUsesResult
// Size: 0x20(Inherited: 0x8) 
struct FServerModifyItemUsesResult : public FPlayFabResultCommon
{
	struct FString ItemInstanceId;  // 0x8(0x10)
	int32_t RemainingUses;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessMoveItemToCharacterFromCharacter__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessMoveItemToCharacterFromCharacter__DelegateSignature
{
	struct FServerMoveItemToCharacterFromCharacterResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerMoveItemToUserFromCharacterResult
// Size: 0x8(Inherited: 0x8) 
struct FServerMoveItemToUserFromCharacterResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerSetPublisherDataRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerSetPublisherDataRequest : public FPlayFabRequestCommon
{
	struct FString Key;  // 0x8(0x10)
	struct FString Value;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerNotifyMatchmakerPlayerLeftResult
// Size: 0x10(Inherited: 0x8) 
struct FServerNotifyMatchmakerPlayerLeftResult : public FPlayFabResultCommon
{
	uint8_t  PlayerState;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct PlayFab.ServerRedeemCouponResult
// Size: 0x18(Inherited: 0x8) 
struct FServerRedeemCouponResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> GrantedItems;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRedeemMatchmakerTicket__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FDelegateOnSuccessRedeemMatchmakerTicket__DelegateSignature
{
	struct FServerRedeemMatchmakerTicketResult Result;  // 0x0(0x28)
	struct UObject* customData;  // 0x28(0x8)

}; 
// ScriptStruct PlayFab.ServerRedeemMatchmakerTicketResult
// Size: 0x28(Inherited: 0x8) 
struct FServerRedeemMatchmakerTicketResult : public FPlayFabResultCommon
{
	struct FString Error;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool TicketIsValid : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UPlayFabJsonObject* UserInfo;  // 0x20(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListPartyQosServersResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListPartyQosServersResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListPartyQosServersResponse ReturnValue;  // 0x8(0x30)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRefreshGameServerInstanceHeartbeat__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessRefreshGameServerInstanceHeartbeat__DelegateSignature
{
	struct FServerRefreshGameServerInstanceHeartbeatResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerRefreshGameServerInstanceHeartbeatResult
// Size: 0x8(Inherited: 0x8) 
struct FServerRefreshGameServerInstanceHeartbeatResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRegisterGame__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDelegateOnSuccessRegisterGame__DelegateSignature
{
	struct FServerRegisterGameResponse Result;  // 0x0(0x18)
	struct UObject* customData;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerRemoveSharedGroupMembersResult
// Size: 0x8(Inherited: 0x8) 
struct FServerRemoveSharedGroupMembersResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerReportPlayerServerResult
// Size: 0x10(Inherited: 0x8) 
struct FServerReportPlayerServerResult : public FPlayFabResultCommon
{
	int32_t SubmissionsRemaining;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct PlayFab.ServerRevokeInventoryItemsResult
// Size: 0x18(Inherited: 0x8) 
struct FServerRevokeInventoryItemsResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> Errors;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerSavePushNotificationTemplateResult
// Size: 0x18(Inherited: 0x8) 
struct FServerSavePushNotificationTemplateResult : public FPlayFabResultCommon
{
	struct FString PushNotificationTemplateId;  // 0x8(0x10)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendCustomAccountRecoveryEmail__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSendCustomAccountRecoveryEmail__DelegateSignature
{
	struct FServerSendCustomAccountRecoveryEmailResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendEmailFromTemplate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSendEmailFromTemplate__DelegateSignature
{
	struct FServerSendEmailFromTemplateResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeGetFilesResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetFilesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataGetFilesResponse ReturnValue;  // 0x8(0x20)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendPushNotification__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSendPushNotification__DelegateSignature
{
	struct FServerSendPushNotificationResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerSetGameServerInstanceStateResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSetGameServerInstanceStateResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetGameServerInstanceTags__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessSetGameServerInstanceTags__DelegateSignature
{
	struct FServerSetGameServerInstanceTagsResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerSetGameServerInstanceTagsResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSetGameServerInstanceTagsResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerSetPlayerSecretResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSetPlayerSecretResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerSetPublisherDataResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSetPublisherDataResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerSetTitleDataResult
// Size: 0x8(Inherited: 0x8) 
struct FServerSetTitleDataResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerUnlinkPSNAccountResult
// Size: 0x8(Inherited: 0x8) 
struct FServerUnlinkPSNAccountResult : public FPlayFabResultCommon
{

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkServerCustomId__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDelegateOnSuccessUnlinkServerCustomId__DelegateSignature
{
	struct FServerUnlinkServerCustomIdResult Result;  // 0x0(0x8)
	struct UObject* customData;  // 0x8(0x8)

}; 
// ScriptStruct PlayFab.ServerUnlockContainerItemResult
// Size: 0x40(Inherited: 0x8) 
struct FServerUnlockContainerItemResult : public FPlayFabResultCommon
{
	struct TArray<struct UPlayFabJsonObject*> GrantedItems;  // 0x8(0x10)
	struct FString UnlockedItemInstanceId;  // 0x18(0x10)
	struct FString UnlockedWithItemInstanceId;  // 0x28(0x10)
	struct UPlayFabJsonObject* VirtualCurrency;  // 0x38(0x8)

}; 
// ScriptStruct PlayFab.ServerUpdateCharacterDataResult
// Size: 0x10(Inherited: 0x8) 
struct FServerUpdateCharacterDataResult : public FPlayFabResultCommon
{
	int32_t DataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterReadOnlyData__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateOnSuccessUpdateCharacterReadOnlyData__DelegateSignature
{
	struct FServerUpdateCharacterDataResult Result;  // 0x0(0x10)
	struct UObject* customData;  // 0x10(0x8)

}; 
// ScriptStruct PlayFab.ServerUpdateCharacterStatisticsResult
// Size: 0x8(Inherited: 0x8) 
struct FServerUpdateCharacterStatisticsResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerUpdateSharedGroupDataResult
// Size: 0x8(Inherited: 0x8) 
struct FServerUpdateSharedGroupDataResult : public FPlayFabResultCommon
{

}; 
// ScriptStruct PlayFab.ServerWriteEventResponse
// Size: 0x18(Inherited: 0x8) 
struct FServerWriteEventResponse : public FPlayFabResultCommon
{
	struct FString EventId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.DeleteCharacterFromUser
// Size: 0x68(Inherited: 0x0) 
struct FDeleteCharacterFromUser
{
	struct FServerDeleteCharacterFromUserRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ServerDeleteCharacterFromUserRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerDeleteCharacterFromUserRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString PlayFabId;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool SaveCharacterInventory : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct PlayFab.ServerSetGameServerInstanceDataRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerSetGameServerInstanceDataRequest : public FPlayFabRequestCommon
{
	struct FString GameServerData;  // 0x8(0x10)
	struct FString LobbyId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerDeletePlayerRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerDeletePlayerRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerDeletePushNotificationTemplateRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerDeletePushNotificationTemplateRequest : public FPlayFabRequestCommon
{
	struct FString PushNotificationTemplateId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.DeleteSharedGroup
// Size: 0x48(Inherited: 0x0) 
struct FDeleteSharedGroup
{
	struct FServerDeleteSharedGroupRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ServerDeregisterGameRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerDeregisterGameRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateServerBackfillTicketResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateServerBackfillTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateServerBackfillTicketResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.EvaluateRandomResultTable
// Size: 0x58(Inherited: 0x0) 
struct FEvaluateRandomResultTable
{
	struct FServerEvaluateRandomResultTableRequest Request;  // 0x0(0x28)
	struct FDelegate onSuccess;  // 0x28(0x10)
	struct FDelegate onFailure;  // 0x38(0x10)
	struct UObject* customData;  // 0x48(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct PlayFab.ServerEvaluateRandomResultTableRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerEvaluateRandomResultTableRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString TableId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerListUsersCharactersRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerListUsersCharactersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetCharacterDataRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGetCharacterDataRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	int32_t IfChangedFromDataVersion;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Keys;  // 0x20(0x10)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayersInSegmentRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerGetPlayersInSegmentRequest : public FPlayFabRequestCommon
{
	struct FString ContinuationToken;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	int32_t MaxBatchSize;  // 0x20(0x4)
	int32_t SecondsToLive;  // 0x24(0x4)
	struct FString SegmentId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetCharacterInternalData
// Size: 0x70(Inherited: 0x0) 
struct FGetCharacterInternalData
{
	struct FServerGetCharacterDataRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ServerGetCharacterInventoryRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGetCharacterInventoryRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerGetCharacterStatisticsRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetCharacterStatisticsRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerGetContentDownloadUrlRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerGetContentDownloadUrlRequest : public FPlayFabRequestCommon
{
	struct FString HttpMethod;  // 0x8(0x10)
	struct FString Key;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ThruCDN : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct PlayFab.ServerGetFriendsListRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGetFriendsListRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IncludeFacebookFriends : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IncludeSteamFriends : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x28(0x8)
	struct FString XboxToken;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardAroundCharacterRequest
// Size: 0x50(Inherited: 0x8) 
struct FServerGetLeaderboardAroundCharacterRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString CharacterType;  // 0x18(0x10)
	int32_t MaxResultsCount;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString PlayFabId;  // 0x30(0x10)
	struct FString StatisticName;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ServerGetUserInventoryRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerGetUserInventoryRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GetLeaderboardAroundUser
// Size: 0x78(Inherited: 0x0) 
struct FGetLeaderboardAroundUser
{
	struct FServerGetLeaderboardAroundUserRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.MoveItemToCharacterFromCharacter
// Size: 0x78(Inherited: 0x0) 
struct FMoveItemToCharacterFromCharacter
{
	struct FServerMoveItemToCharacterFromCharacterRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardAroundUserRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerGetLeaderboardAroundUserRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	int32_t MaxResultsCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString PlayFabId;  // 0x18(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x28(0x8)
	struct FString StatisticName;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool UseSpecificVersion : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Version;  // 0x44(0x4)

}; 
// ScriptStruct PlayFab.ServerGetLeaderboardForUsersCharactersRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetLeaderboardForUsersCharactersRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)
	struct FString StatisticName;  // 0x18(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUnlockContainerItemResultResponse
// Size: 0x48(Inherited: 0x0) 
struct FdecodeUnlockContainerItemResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUnlockContainerItemResult ReturnValue;  // 0x8(0x40)

}; 
// ScriptStruct PlayFab.ServerGetPlayerCombinedInfoRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetPlayerCombinedInfoRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct UPlayFabJsonObject* InfoRequestParameters;  // 0x10(0x8)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayerProfileRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetPlayerProfileRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)
	struct UPlayFabJsonObject* ProfileConstraints;  // 0x20(0x8)

}; 
// ScriptStruct PlayFab.ServerGetPlayersSegmentsRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerGetPlayersSegmentsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayerStatisticVersionsRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerGetPlayerStatisticVersionsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString StatisticName;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayerTagsRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerGetPlayerTagsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Namespace;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromFacebookIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromFacebookIDsRequest : public FPlayFabRequestCommon
{
	struct FString FacebookIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromFacebookInstantGamesIdsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsRequest : public FPlayFabRequestCommon
{
	struct FString FacebookInstantGamesIds;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromNintendoServiceAccountIdsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsRequest : public FPlayFabRequestCommon
{
	struct FString NintendoAccountIds;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest : public FPlayFabRequestCommon
{
	struct FString NintendoSwitchDeviceIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPhotonAuthenticationTokenResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPhotonAuthenticationTokenResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPhotonAuthenticationTokenResult ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromPSNAccountIDsRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromPSNAccountIDsRequest : public FPlayFabRequestCommon
{
	int32_t IssuerId;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString PSNAccountIDs;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromSteamIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromSteamIDsRequest : public FPlayFabRequestCommon
{
	struct FString SteamStringIDs;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromTwitchIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromTwitchIDsRequest : public FPlayFabRequestCommon
{
	struct FString TwitchIds;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPlayFabIDsFromXboxLiveIDsRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetPlayFabIDsFromXboxLiveIDsRequest : public FPlayFabRequestCommon
{
	struct FString Sandbox;  // 0x8(0x10)
	struct FString XboxLiveAccountIDs;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerGetPublisherDataRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetPublisherDataRequest : public FPlayFabRequestCommon
{
	struct FString Keys;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetRandomResultTablesRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerGetRandomResultTablesRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString TableIDs;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerGetServerCustomIDsFromPlayFabIDsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetServerCustomIDsFromPlayFabIDsRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabIds;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetStoreItemsServerRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGetStoreItemsServerRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString PlayFabId;  // 0x20(0x10)
	struct FString StoreId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerGetTitleNewsRequest
// Size: 0x10(Inherited: 0x8) 
struct FServerGetTitleNewsRequest : public FPlayFabRequestCommon
{
	int32_t Count;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemModerationStateResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetItemModerationStateResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetItemModerationStateResponse ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetUserAccountInfoRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerGetUserAccountInfoRequest : public FPlayFabRequestCommon
{
	struct FString PlayFabId;  // 0x8(0x10)

}; 
// ScriptStruct PlayFab.ServerGetUserDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerGetUserDataRequest : public FPlayFabRequestCommon
{
	int32_t IfChangedFromDataVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Keys;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerGrantCharacterToUserRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerGrantCharacterToUserRequest : public FPlayFabRequestCommon
{
	struct FString CharacterName;  // 0x8(0x10)
	struct FString CharacterType;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString PlayFabId;  // 0x30(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.GrantItemsToCharacter
// Size: 0x90(Inherited: 0x0) 
struct FGrantItemsToCharacter
{
	struct FServerGrantItemsToCharacterRequest Request;  // 0x0(0x60)
	struct FDelegate onSuccess;  // 0x60(0x10)
	struct FDelegate onFailure;  // 0x70(0x10)
	struct UObject* customData;  // 0x80(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x88(0x8)

}; 
// ScriptStruct PlayFab.ServerGrantItemsToCharacterRequest
// Size: 0x60(Inherited: 0x8) 
struct FServerGrantItemsToCharacterRequest : public FPlayFabRequestCommon
{
	struct FString Annotation;  // 0x8(0x10)
	struct FString CatalogVersion;  // 0x18(0x10)
	struct FString CharacterId;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)
	struct FString ItemIds;  // 0x40(0x10)
	struct FString PlayFabId;  // 0x50(0x10)

}; 
// ScriptStruct PlayFab.ServerGrantItemsToUserRequest
// Size: 0x50(Inherited: 0x8) 
struct FServerGrantItemsToUserRequest : public FPlayFabRequestCommon
{
	struct FString Annotation;  // 0x8(0x10)
	struct FString CatalogVersion;  // 0x18(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x28(0x8)
	struct FString ItemIds;  // 0x30(0x10)
	struct FString PlayFabId;  // 0x40(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.HelperAuthenticateSessionTicket
// Size: 0x50(Inherited: 0x0) 
struct FHelperAuthenticateSessionTicket
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperDeletePushNotificationTemplate
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeletePushNotificationTemplate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperDeregisterGame
// Size: 0x50(Inherited: 0x0) 
struct FHelperDeregisterGame
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetCharacterInternalData
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetCharacterInternalData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetLeaderboardAroundUser
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetLeaderboardAroundUser
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperGetServerCustomIDsFromPlayFabIDs
// Size: 0x50(Inherited: 0x0) 
struct FHelperGetServerCustomIDsFromPlayFabIDs
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperLoginWithXboxId
// Size: 0x50(Inherited: 0x0) 
struct FHelperLoginWithXboxId
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRegisterGameResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRegisterGameResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRegisterGameResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerAPI.HelperMoveItemToUserFromCharacter
// Size: 0x50(Inherited: 0x0) 
struct FHelperMoveItemToUserFromCharacter
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperNotifyMatchmakerPlayerLeft
// Size: 0x50(Inherited: 0x0) 
struct FHelperNotifyMatchmakerPlayerLeft
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperRegisterGame
// Size: 0x50(Inherited: 0x0) 
struct FHelperRegisterGame
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSendEmailFromTemplate
// Size: 0x50(Inherited: 0x0) 
struct FHelperSendEmailFromTemplate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSendPushNotification
// Size: 0x50(Inherited: 0x0) 
struct FHelperSendPushNotification
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSendPushNotificationFromTemplate
// Size: 0x50(Inherited: 0x0) 
struct FHelperSendPushNotificationFromTemplate
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetGameServerInstanceState
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetGameServerInstanceState
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSetGameServerInstanceTags
// Size: 0x50(Inherited: 0x0) 
struct FHelperSetGameServerInstanceTags
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperSubtractCharacterVirtualCurrency
// Size: 0x50(Inherited: 0x0) 
struct FHelperSubtractCharacterVirtualCurrency
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterReadOnlyData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateCharacterReadOnlyData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function PlayFab.PlayFabServerAPI.HelperUpdateUserInventoryItemCustomData
// Size: 0x50(Inherited: 0x0) 
struct FHelperUpdateUserInventoryItemCustomData
{
	struct FPlayFabBaseModel Response;  // 0x0(0x40)
	struct UObject* customData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Successful : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct PlayFab.ServerLinkPSNAccountRequest
// Size: 0x48(Inherited: 0x8) 
struct FServerLinkPSNAccountRequest : public FPlayFabRequestCommon
{
	struct FString AuthCode;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ForceLink : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t IssuerId;  // 0x24(0x4)
	struct FString PlayFabId;  // 0x28(0x10)
	struct FString RedirectUri;  // 0x38(0x10)

}; 
// ScriptStruct PlayFab.ServerLinkServerCustomIdRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerLinkServerCustomIdRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString ServerCustomId;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListVirtualMachineSummariesResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListVirtualMachineSummariesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListVirtualMachineSummariesResponse ReturnValue;  // 0x8(0x30)

}; 
// ScriptStruct PlayFab.ServerLinkXboxAccountRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerLinkXboxAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceLink : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString XboxToken;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListBuildSummariesResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListBuildSummariesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListBuildSummariesResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabServerAPI.LoginWithServerCustomId
// Size: 0x70(Inherited: 0x0) 
struct FLoginWithServerCustomId
{
	struct FServerLoginWithServerCustomIdRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.LoginWithXboxId
// Size: 0x70(Inherited: 0x0) 
struct FLoginWithXboxId
{
	struct FServerLoginWithXboxIdRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.ModifyItemUses
// Size: 0x68(Inherited: 0x0) 
struct FModifyItemUses
{
	struct FServerModifyItemUsesRequest Request;  // 0x0(0x38)
	struct FDelegate onSuccess;  // 0x38(0x10)
	struct FDelegate onFailure;  // 0x48(0x10)
	struct UObject* customData;  // 0x58(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct PlayFab.ServerModifyItemUsesRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerModifyItemUsesRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString ItemInstanceId;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)
	int32_t UsesToAdd;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct PlayFab.ServerMoveItemToCharacterFromUserRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerMoveItemToCharacterFromUserRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString ItemInstanceId;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ServerNotifyMatchmakerPlayerLeftRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerNotifyMatchmakerPlayerLeftRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerRedeemCouponRequest
// Size: 0x50(Inherited: 0x8) 
struct FServerRedeemCouponRequest : public FPlayFabRequestCommon
{
	struct FString CatalogVersion;  // 0x8(0x10)
	struct FString CharacterId;  // 0x18(0x10)
	struct FString CouponCode;  // 0x28(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x38(0x8)
	struct FString PlayFabId;  // 0x40(0x10)

}; 
// ScriptStruct PlayFab.ServerRedeemMatchmakerTicketRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerRedeemMatchmakerTicketRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString LobbyId;  // 0x10(0x10)
	struct FString Ticket;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.RefreshGameServerInstanceHeartbeat
// Size: 0x48(Inherited: 0x0) 
struct FRefreshGameServerInstanceHeartbeat
{
	struct FServerRefreshGameServerInstanceHeartbeatRequest Request;  // 0x0(0x18)
	struct FDelegate onSuccess;  // 0x18(0x10)
	struct FDelegate onFailure;  // 0x28(0x10)
	struct UObject* customData;  // 0x38(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct PlayFab.ServerRefreshGameServerInstanceHeartbeatRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerRefreshGameServerInstanceHeartbeatRequest : public FPlayFabRequestCommon
{
	struct FString LobbyId;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeFindFriendLobbiesResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeFindFriendLobbiesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerFindFriendLobbiesResult ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabServerAPI.RegisterGame
// Size: 0xC0(Inherited: 0x0) 
struct FRegisterGame
{
	struct FServerRegisterGameRequest Request;  // 0x0(0x90)
	struct FDelegate onSuccess;  // 0x90(0x10)
	struct FDelegate onFailure;  // 0xA0(0x10)
	struct UObject* customData;  // 0xB0(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0xB8(0x8)

}; 
// ScriptStruct PlayFab.ServerRemoveFriendRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerRemoveFriendRequest : public FPlayFabRequestCommon
{
	struct FString FriendPlayFabId;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerReportPlayerServerRequest
// Size: 0x40(Inherited: 0x8) 
struct FServerReportPlayerServerRequest : public FPlayFabRequestCommon
{
	struct FString Comment;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct FString ReporteeId;  // 0x20(0x10)
	struct FString ReporterId;  // 0x30(0x10)

}; 
// ScriptStruct PlayFab.ServerRevokeBansRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerRevokeBansRequest : public FPlayFabRequestCommon
{
	struct FString BanIds;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.GetBoolArrayField
// Size: 0x20(Inherited: 0x0) 
struct FGetBoolArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<bool> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerRevokeInventoryItemRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerRevokeInventoryItemRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct FString ItemInstanceId;  // 0x18(0x10)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ServerRevokeInventoryItemsRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerRevokeInventoryItemsRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Items;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.SavePushNotificationTemplate
// Size: 0x80(Inherited: 0x0) 
struct FSavePushNotificationTemplate
{
	struct FServerSavePushNotificationTemplateRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// Function PlayFab.PlayFabServerAPI.SendCustomAccountRecoveryEmail
// Size: 0x70(Inherited: 0x0) 
struct FSendCustomAccountRecoveryEmail
{
	struct FServerSendCustomAccountRecoveryEmailRequest Request;  // 0x0(0x40)
	struct FDelegate onSuccess;  // 0x40(0x10)
	struct FDelegate onFailure;  // 0x50(0x10)
	struct UObject* customData;  // 0x60(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x68(0x8)

}; 
// ScriptStruct PlayFab.ServerSendEmailFromTemplateRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerSendEmailFromTemplateRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString EmailTemplateId;  // 0x10(0x10)
	struct FString PlayFabId;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.SendPushNotificationFromTemplate
// Size: 0x60(Inherited: 0x0) 
struct FSendPushNotificationFromTemplate
{
	struct FServerSendPushNotificationFromTemplateRequest Request;  // 0x0(0x30)
	struct FDelegate onSuccess;  // 0x30(0x10)
	struct FDelegate onFailure;  // 0x40(0x10)
	struct UObject* customData;  // 0x50(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct PlayFab.ServerSendPushNotificationFromTemplateRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerSendPushNotificationFromTemplateRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PushNotificationTemplateId;  // 0x10(0x10)
	struct FString Recipient;  // 0x20(0x10)

}; 
// ScriptStruct PlayFab.ServerSetFriendTagsRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerSetFriendTagsRequest : public FPlayFabRequestCommon
{
	struct FString FriendPlayFabId;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString Tags;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteMasterPlayerAccountResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeDeleteMasterPlayerAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeleteMasterPlayerAccountResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabServerAPI.SetGameServerInstanceTags
// Size: 0x50(Inherited: 0x0) 
struct FSetGameServerInstanceTags
{
	struct FServerSetGameServerInstanceTagsRequest Request;  // 0x0(0x20)
	struct FDelegate onSuccess;  // 0x20(0x10)
	struct FDelegate onFailure;  // 0x30(0x10)
	struct UObject* customData;  // 0x40(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct PlayFab.ServerSetGameServerInstanceTagsRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerSetGameServerInstanceTagsRequest : public FPlayFabRequestCommon
{
	struct FString LobbyId;  // 0x8(0x10)
	struct UPlayFabJsonObject* Tags;  // 0x18(0x8)

}; 
// ScriptStruct PlayFab.ServerSetPlayerSecretRequest
// Size: 0x28(Inherited: 0x8) 
struct FServerSetPlayerSecretRequest : public FPlayFabRequestCommon
{
	struct FString PlayerSecret;  // 0x8(0x10)
	struct FString PlayFabId;  // 0x18(0x10)

}; 
// ScriptStruct PlayFab.ServerSetTitleDataRequest
// Size: 0x30(Inherited: 0x8) 
struct FServerSetTitleDataRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.SubtractCharacterVirtualCurrency
// Size: 0x78(Inherited: 0x0) 
struct FSubtractCharacterVirtualCurrency
{
	struct FServerSubtractCharacterVirtualCurrencyRequest Request;  // 0x0(0x48)
	struct FDelegate onSuccess;  // 0x48(0x10)
	struct FDelegate onFailure;  // 0x58(0x10)
	struct UObject* customData;  // 0x68(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct PlayFab.ServerSubtractUserVirtualCurrencyRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerSubtractUserVirtualCurrencyRequest : public FPlayFabRequestCommon
{
	int32_t Amount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString PlayFabId;  // 0x18(0x10)
	struct FString VirtualCurrency;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ServerUnlinkPSNAccountRequest
// Size: 0x20(Inherited: 0x8) 
struct FServerUnlinkPSNAccountRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	struct FString PlayFabId;  // 0x10(0x10)

}; 
// ScriptStruct PlayFab.ServerUpdateBansRequest
// Size: 0x18(Inherited: 0x8) 
struct FServerUpdateBansRequest : public FPlayFabRequestCommon
{
	struct TArray<struct UPlayFabJsonObject*> Bans;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerAPI.UpdateCharacterInternalData
// Size: 0x80(Inherited: 0x0) 
struct FUpdateCharacterInternalData
{
	struct FServerUpdateCharacterDataRequest Request;  // 0x0(0x50)
	struct FDelegate onSuccess;  // 0x50(0x10)
	struct FDelegate onFailure;  // 0x60(0x10)
	struct UObject* customData;  // 0x70(0x8)
	struct UPlayFabServerAPI* ReturnValue;  // 0x78(0x8)

}; 
// ScriptStruct PlayFab.ServerUpdateCharacterStatisticsRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerUpdateCharacterStatisticsRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CharacterStatistics;  // 0x18(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x20(0x8)
	struct FString PlayFabId;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ServerUpdatePlayerStatisticsRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerUpdatePlayerStatisticsRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* CustomTags;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceUpdate : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString PlayFabId;  // 0x18(0x10)
	struct TArray<struct UPlayFabJsonObject*> Statistics;  // 0x28(0x10)

}; 
// ScriptStruct PlayFab.ServerUpdateUserInventoryItemDataRequest
// Size: 0x58(Inherited: 0x8) 
struct FServerUpdateUserInventoryItemDataRequest : public FPlayFabRequestCommon
{
	struct FString CharacterId;  // 0x8(0x10)
	struct UPlayFabJsonObject* CustomTags;  // 0x18(0x8)
	struct UPlayFabJsonObject* Data;  // 0x20(0x8)
	struct FString ItemInstanceId;  // 0x28(0x10)
	struct FString KeysToRemove;  // 0x38(0x10)
	struct FString PlayFabId;  // 0x48(0x10)

}; 
// ScriptStruct PlayFab.ServerWriteTitleEventRequest
// Size: 0x38(Inherited: 0x8) 
struct FServerWriteTitleEventRequest : public FPlayFabRequestCommon
{
	struct UPlayFabJsonObject* Body;  // 0x8(0x8)
	struct UPlayFabJsonObject* CustomTags;  // 0x10(0x8)
	struct FString EventName;  // 0x18(0x10)
	struct FString Timestamp;  // 0x28(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeAddNewsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeAddNewsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminAddNewsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeAddPlayerTagResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAddPlayerTagResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerAddPlayerTagResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeCheckLimitedEditionItemAvailabilityResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeCheckLimitedEditionItemAvailabilityResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminCheckLimitedEditionItemAvailabilityResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeCreatePlayerSharedSecretResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreatePlayerSharedSecretResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminCreatePlayerSharedSecretResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeCreateSegmentResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeCreateSegmentResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminCreateSegmentResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeCreateTaskResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateTaskResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminCreateTaskResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeDeletePlayerResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeletePlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerDeletePlayerResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeletePlayerSharedSecretResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeletePlayerSharedSecretResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeletePlayerSharedSecretResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteStoreResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteStoreResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeleteStoreResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteTitleDataOverrideResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteTitleDataOverrideResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeleteTitleDataOverrideResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkFacebookAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkFacebookAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkFacebookAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteTitleResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteTitleResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminDeleteTitleResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeEmptyResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeEmptyResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerEmptyResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeExportPlayersInSegmentResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeExportPlayersInSegmentResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminExportPlayersInSegmentResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetActionsOnPlayersInSegmentTaskInstanceResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetActionsOnPlayersInSegmentTaskInstanceResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetActionsOnPlayersInSegmentTaskInstanceResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetAllSegmentsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetAllSegmentsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetAllSegmentsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetCatalogItemsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetCatalogItemsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetCatalogItemsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetContentListResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetContentListResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetContentListResult ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabJsonObject.GetNumberArrayField
// Size: 0x20(Inherited: 0x0) 
struct FGetNumberArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<float> ReturnValue;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetDataReportResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetDataReportResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetDataReportResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetMatchmakerGameInfoResultResponse
// Size: 0xC0(Inherited: 0x0) 
struct FdecodeGetMatchmakerGameInfoResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetMatchmakerGameInfoResult ReturnValue;  // 0x8(0xB8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetMatchmakerGameModesResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetMatchmakerGameModesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetMatchmakerGameModesResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayedTitleListResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayedTitleListResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetPlayedTitleListResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerIdFromAuthTokenResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayerIdFromAuthTokenResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetPlayerIdFromAuthTokenResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerSegmentsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayerSegmentsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayerSegmentsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayersInSegmentExportResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetPlayersInSegmentExportResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetPlayersInSegmentExportResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerStatisticDefinitionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayerStatisticDefinitionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetPlayerStatisticDefinitionsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPublisherDataResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetPublisherDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPublisherDataResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetRandomResultTablesResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetRandomResultTablesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetRandomResultTablesResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeGetTasksResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetTasksResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminGetTasksResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetTitleDataResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetTitleDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetTitleDataResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetUserBansResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetUserBansResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetUserBansResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetUserDataResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetUserDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetUserDataResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetUserInventoryResultResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeGetUserInventoryResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetUserInventoryResult ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGrantItemsToUsersResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGrantItemsToUsersResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGrantItemsToUsersResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeIncrementLimitedEditionItemAvailabilityResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeIncrementLimitedEditionItemAvailabilityResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminIncrementLimitedEditionItemAvailabilityResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeIncrementPlayerStatisticVersionResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeIncrementPlayerStatisticVersionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminIncrementPlayerStatisticVersionResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeListVirtualCurrencyTypesResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListVirtualCurrencyTypesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminListVirtualCurrencyTypesResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeLookupUserAccountInfoResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeLookupUserAccountInfoResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminLookupUserAccountInfoResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeModifyServerBuildResultResponse
// Size: 0x90(Inherited: 0x0) 
struct FdecodeModifyServerBuildResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminModifyServerBuildResult ReturnValue;  // 0x8(0x88)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkGooglePlayGamesServicesAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkGooglePlayGamesServicesAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkGooglePlayGamesServicesAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeRefundPurchaseResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRefundPurchaseResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminRefundPurchaseResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeGetGroupResponseResponse
// Size: 0x68(Inherited: 0x0) 
struct FdecodeGetGroupResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsGetGroupResponse ReturnValue;  // 0x8(0x60)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeResetCharacterStatisticsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeResetCharacterStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminResetCharacterStatisticsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeResetPasswordResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeResetPasswordResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminResetPasswordResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRevokeInventoryItemsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRevokeInventoryItemsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRevokeInventoryItemsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeRunTaskResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRunTaskResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminRunTaskResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabJsonValue.AsArray
// Size: 0x10(Inherited: 0x0) 
struct FAsArray
{
	struct TArray<struct UPlayFabJsonValue*> ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSetPlayerSecretResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetPlayerSecretResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSetPlayerSecretResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeSetPublishedRevisionResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetPublishedRevisionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminSetPublishedRevisionResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSetPublisherDataResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetPublisherDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSetPublisherDataResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSetTitleDataResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetTitleDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSetTitleDataResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeSetupPushNotificationResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeSetupPushNotificationResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminSetupPushNotificationResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateCloudScriptResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeUpdateCloudScriptResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdateCloudScriptResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeAuthenticateSessionTicketResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeAuthenticateSessionTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerAuthenticateSessionTicketResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdatePlayerSharedSecretResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdatePlayerSharedSecretResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdatePlayerSharedSecretResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdatePlayerStatisticDefinitionResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeUpdatePlayerStatisticDefinitionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdatePlayerStatisticDefinitionResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdatePolicyResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeUpdatePolicyResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdatePolicyResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateRandomResultTablesResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdateRandomResultTablesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdateRandomResultTablesResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateSegmentResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeUpdateSegmentResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAdminUpdateSegmentResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUpdateUserTitleDisplayNameResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeUpdateUserTitleDisplayNameResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUpdateUserTitleDisplayNameResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabAuthenticationModelDecoder.decodeGetEntityTokenResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetEntityTokenResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAuthenticationGetEntityTokenResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabAuthenticationModelDecoder.decodeValidateEntityTokenResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeValidateEntityTokenResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FAuthenticationValidateEntityTokenResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAcceptTradeResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeAcceptTradeResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAcceptTradeResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAddFriendResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeAddFriendResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAddFriendResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAddOrUpdateContactEmailResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAddOrUpdateContactEmailResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAddOrUpdateContactEmailResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeAddSharedGroupMembersResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAddSharedGroupMembersResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerAddSharedGroupMembersResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeAttributeInstallResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeAttributeInstallResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientAttributeInstallResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeCancelTradeResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeCancelTradeResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientCancelTradeResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeConfirmPurchaseResultResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeConfirmPurchaseResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientConfirmPurchaseResult ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeConsumeItemResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeConsumeItemResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerConsumeItemResult ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeConsumeMicrosoftStoreEntitlementsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeConsumeMicrosoftStoreEntitlementsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientConsumeMicrosoftStoreEntitlementsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeConsumePS5EntitlementsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeConsumePS5EntitlementsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientConsumePS5EntitlementsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeConsumePSNEntitlementsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeConsumePSNEntitlementsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientConsumePSNEntitlementsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeExecuteCloudScriptResultResponse
// Size: 0x68(Inherited: 0x0) 
struct FdecodeExecuteCloudScriptResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerExecuteCloudScriptResult ReturnValue;  // 0x8(0x60)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetAccountInfoResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetAccountInfoResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetAccountInfoResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetAdPlacementsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetAdPlacementsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetAdPlacementsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterInventoryResultResponse
// Size: 0x50(Inherited: 0x0) 
struct FdecodeGetCharacterInventoryResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetCharacterInventoryResult ReturnValue;  // 0x8(0x48)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetLeaderboardAroundPlayerResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetLeaderboardAroundPlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetLeaderboardAroundPlayerResult ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardForUsersCharactersResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetLeaderboardForUsersCharactersResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetLeaderboardForUsersCharactersResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetLeaderboardResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetLeaderboardResult ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPaymentTokenResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetPaymentTokenResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPaymentTokenResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerCombinedInfoResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetPlayerCombinedInfoResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayerCombinedInfoResult ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerStatisticsResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetPlayerStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayerStatisticsResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerTradesResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetPlayerTradesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPlayerTradesResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGooglePlayGamesPlayerIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromGooglePlayGamesPlayerIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromNintendoServiceAccountIdsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromNintendoServiceAccountIdsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromNintendoSwitchDeviceIdsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromNintendoSwitchDeviceIdsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromSteamIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromSteamIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromSteamIDsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromXboxLiveIDsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetPlayFabIDsFromXboxLiveIDsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetPlayFabIDsFromXboxLiveIDsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetTimeResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetTimeResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetTimeResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkKongregateAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkKongregateAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkKongregateAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetTitleNewsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetTitleNewsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetTitleNewsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeGetTradeStatusResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetTradeStatusResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientGetTradeStatusResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkFacebookInstantGamesIdResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkFacebookInstantGamesIdResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkFacebookInstantGamesIdResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkGameCenterAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkGameCenterAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkGameCenterAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkKongregateAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkKongregateAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkKongregateAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkNintendoSwitchDeviceIdResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkNintendoSwitchDeviceIdResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkNintendoSwitchDeviceIdResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkSteamAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkSteamAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkSteamAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeLinkTwitchAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkTwitchAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientLinkTwitchAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodePayForPurchaseResultResponse
// Size: 0x80(Inherited: 0x0) 
struct FdecodePayForPurchaseResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientPayForPurchaseResult ReturnValue;  // 0x8(0x78)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRemoveContactEmailResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRemoveContactEmailResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRemoveContactEmailResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRemoveFriendResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRemoveFriendResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRemoveFriendResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRemoveGenericIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRemoveGenericIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRemoveGenericIDResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRemoveSharedGroupMembersResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeRemoveSharedGroupMembersResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRemoveSharedGroupMembersResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeReportAdActivityResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeReportAdActivityResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientReportAdActivityResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRestoreIOSPurchasesResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeRestoreIOSPurchasesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRestoreIOSPurchasesResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeRewardAdActivityResultResponse
// Size: 0x60(Inherited: 0x0) 
struct FdecodeRewardAdActivityResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientRewardAdActivityResult ReturnValue;  // 0x8(0x58)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeSetFriendTagsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetFriendTagsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientSetFriendTagsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkAndroidDeviceIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkAndroidDeviceIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkAndroidDeviceIDResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkGameCenterAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkGameCenterAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkGameCenterAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkGoogleAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkGoogleAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkGoogleAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkIOSDeviceIDResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkIOSDeviceIDResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkIOSDeviceIDResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkPSNAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkPSNAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUnlinkPSNAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkTwitchAccountResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUnlinkTwitchAccountResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientUnlinkTwitchAccountResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUpdateCharacterDataResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeUpdateCharacterDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUpdateCharacterDataResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUpdateCharacterStatisticsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdateCharacterStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUpdateCharacterStatisticsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.SetNumberField
// Size: 0x18(Inherited: 0x0) 
struct FSetNumberField
{
	struct FString FieldName;  // 0x0(0x10)
	float Number;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeUpdatePlayerStatisticsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeUpdatePlayerStatisticsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerUpdatePlayerStatisticsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabClientModelDecoder.decodeValidateGooglePlayPurchaseResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeValidateGooglePlayPurchaseResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FClientValidateGooglePlayPurchaseResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabJsonValue.IsNull
// Size: 0x1(Inherited: 0x0) 
struct FIsNull
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function PlayFab.PlayFabCloudScriptModelDecoder.decodeExecuteFunctionResultResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeExecuteFunctionResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FCloudScriptExecuteFunctionResult ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabCloudScriptModelDecoder.decodeListQueuedFunctionsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListQueuedFunctionsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FCloudScriptListQueuedFunctionsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeAbortFileUploadsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeAbortFileUploadsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataAbortFileUploadsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeFinalizeFileUploadsResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeFinalizeFileUploadsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataFinalizeFileUploadsResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabDataModelDecoder.decodeSetObjectsResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeSetObjectsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FDataSetObjectsResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeCreateUploadUrlsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateUploadUrlsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyCreateUploadUrlsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeDeleteEntityItemReviewsResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteEntityItemReviewsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyDeleteEntityItemReviewsResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetCatalogConfigResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetCatalogConfigResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetCatalogConfigResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetEntityDraftItemsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetEntityDraftItemsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetEntityDraftItemsResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetDraftItemResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetDraftItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetDraftItemResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetDraftItemsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetDraftItemsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetDraftItemsResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetEntityItemReviewResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetEntityItemReviewResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetEntityItemReviewResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemPublishStatusResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeGetItemPublishStatusResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetItemPublishStatusResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyGetItemResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodePublishDraftItemResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodePublishDraftItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyPublishDraftItemResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeReportItemResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeReportItemResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomyReportItemResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.SetField
// Size: 0x18(Inherited: 0x0) 
struct FSetField
{
	struct FString FieldName;  // 0x0(0x10)
	struct UPlayFabJsonValue* JsonValue;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeSearchItemsResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeSearchItemsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomySearchItemsResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabEconomyModelDecoder.decodeSubmitItemReviewVoteResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSubmitItemReviewVoteResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FEconomySubmitItemReviewVoteResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetExclusionGroupsResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetExclusionGroupsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationGetExclusionGroupsResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetExclusionGroupTrafficResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetExclusionGroupTrafficResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationGetExclusionGroupTrafficResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetLatestScorecardResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetLatestScorecardResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FExperimentationGetLatestScorecardResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeApplyToGroupResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeApplyToGroupResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsApplyToGroupResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeCreateGroupRoleResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeCreateGroupRoleResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsCreateGroupRoleResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeInviteToGroupResponseResponse
// Size: 0x48(Inherited: 0x0) 
struct FdecodeInviteToGroupResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsInviteToGroupResponse ReturnValue;  // 0x8(0x40)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeIsMemberResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeIsMemberResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsIsMemberResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupMembersResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListGroupMembersResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsListGroupMembersResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeListMembershipOpportunitiesResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeListMembershipOpportunitiesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsListMembershipOpportunitiesResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeUpdateGroupResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeUpdateGroupResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsUpdateGroupResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabGroupsModelDecoder.decodeUpdateGroupRoleResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeUpdateGroupRoleResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FGroupsUpdateGroupRoleResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetDetailsResponseResponse
// Size: 0x48(Inherited: 0x0) 
struct FdecodeInsightsGetDetailsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FInsightsInsightsGetDetailsResponse ReturnValue;  // 0x8(0x40)

}; 
// Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetPendingOperationsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeInsightsGetPendingOperationsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FInsightsInsightsGetPendingOperationsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsOperationResponseResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeInsightsOperationResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FInsightsInsightsOperationResponse ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabJsonObject.ConstructJsonObject
// Size: 0x10(Inherited: 0x0) 
struct FConstructJsonObject
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UPlayFabJsonObject* ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.DecodeJson
// Size: 0x18(Inherited: 0x0) 
struct FDecodeJson
{
	struct FString JsonString;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function PlayFab.PlayFabJsonObject.EncodeJson
// Size: 0x10(Inherited: 0x0) 
struct FEncodeJson
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.GetArrayField
// Size: 0x20(Inherited: 0x0) 
struct FGetArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<struct UPlayFabJsonValue*> ReturnValue;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.GetBoolField
// Size: 0x18(Inherited: 0x0) 
struct FGetBoolField
{
	struct FString FieldName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function PlayFab.PlayFabJsonObject.GetFieldNames
// Size: 0x10(Inherited: 0x0) 
struct FGetFieldNames
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.GetNumberField
// Size: 0x18(Inherited: 0x0) 
struct FGetNumberField
{
	struct FString FieldName;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function PlayFab.PlayFabJsonObject.GetObjectArrayField
// Size: 0x20(Inherited: 0x0) 
struct FGetObjectArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<struct UPlayFabJsonObject*> ReturnValue;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.GetObjectField
// Size: 0x18(Inherited: 0x0) 
struct FGetObjectField
{
	struct FString FieldName;  // 0x0(0x10)
	struct UPlayFabJsonObject* ReturnValue;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.GetStringArrayField
// Size: 0x20(Inherited: 0x0) 
struct FGetStringArrayField
{
	struct FString FieldName;  // 0x0(0x10)
	struct TArray<struct FString> ReturnValue;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.GetStringField
// Size: 0x20(Inherited: 0x0) 
struct FGetStringField
{
	struct FString FieldName;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.HasField
// Size: 0x18(Inherited: 0x0) 
struct FHasField
{
	struct FString FieldName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function PlayFab.PlayFabJsonObject.SetFieldNull
// Size: 0x10(Inherited: 0x0) 
struct FSetFieldNull
{
	struct FString FieldName;  // 0x0(0x10)

}; 
// Function PlayFab.PlayFabJsonObject.SetObjectField
// Size: 0x18(Inherited: 0x0) 
struct FSetObjectField
{
	struct FString FieldName;  // 0x0(0x10)
	struct UPlayFabJsonObject* JsonObject;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabJsonObject.SetStringField
// Size: 0x20(Inherited: 0x0) 
struct FSetStringField
{
	struct FString FieldName;  // 0x0(0x10)
	struct FString StringValue;  // 0x10(0x10)

}; 
// Function PlayFab.PlayFabJsonValue.AsBool
// Size: 0x1(Inherited: 0x0) 
struct FAsBool
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function PlayFab.PlayFabJsonValue.AsNumber
// Size: 0x4(Inherited: 0x0) 
struct FAsNumber
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function PlayFab.PlayFabJsonValue.AsString
// Size: 0x10(Inherited: 0x0) 
struct FAsString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFab.PlayFabJsonValue.ConstructJsonValueArray
// Size: 0x20(Inherited: 0x0) 
struct FConstructJsonValueArray
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<struct UPlayFabJsonValue*> inArray;  // 0x8(0x10)
	struct UPlayFabJsonValue* ReturnValue;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabJsonValue.ConstructJsonValueObject
// Size: 0x18(Inherited: 0x0) 
struct FConstructJsonValueObject
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UPlayFabJsonObject* JsonObject;  // 0x8(0x8)
	struct UPlayFabJsonValue* ReturnValue;  // 0x10(0x8)

}; 
// Function PlayFab.PlayFabJsonValue.ConstructJsonValueString
// Size: 0x20(Inherited: 0x0) 
struct FConstructJsonValueString
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString StringValue;  // 0x8(0x10)
	struct UPlayFabJsonValue* ReturnValue;  // 0x18(0x8)

}; 
// Function PlayFab.PlayFabJsonValue.GetType
// Size: 0x1(Inherited: 0x0) 
struct FGetType
{
	char EPFJson ReturnValue;  // 0x0(0x1)

}; 
// Function PlayFab.PlayFabMatchmakerModelDecoder.decodeAuthUserResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeAuthUserResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMatchmakerAuthUserResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabMatchmakerModelDecoder.decodePlayerJoinedResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodePlayerJoinedResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMatchmakerPlayerJoinedResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMatchmakerModelDecoder.decodeUserInfoResponseResponse
// Size: 0x78(Inherited: 0x0) 
struct FdecodeUserInfoResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMatchmakerUserInfoResponse ReturnValue;  // 0x8(0x70)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeBuildAliasDetailsResponseResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeBuildAliasDetailsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerBuildAliasDetailsResponse ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelAllServerBackfillTicketsForPlayerResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeCancelAllServerBackfillTicketsForPlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCancelAllServerBackfillTicketsForPlayerResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelServerBackfillTicketResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeCancelServerBackfillTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCancelServerBackfillTicketResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateBuildWithCustomContainerResponseResponse
// Size: 0xF8(Inherited: 0x0) 
struct FdecodeCreateBuildWithCustomContainerResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateBuildWithCustomContainerResponse ReturnValue;  // 0x8(0xF0)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateLobbyResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeCreateLobbyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateLobbyResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateMatchmakingTicketResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeCreateMatchmakingTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateMatchmakingTicketResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateRemoteUserResponseResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeCreateRemoteUserResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateRemoteUserResponse ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateTitleMultiplayerServersQuotaChangeResponseResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeCreateTitleMultiplayerServersQuotaChangeResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeResponse ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeEnableMultiplayerServersForTitleResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeEnableMultiplayerServersForTitleResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerEnableMultiplayerServersForTitleResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeFindLobbiesResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeFindLobbiesResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerFindLobbiesResult ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetAssetUploadUrlResponseResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeGetAssetUploadUrlResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetAssetUploadUrlResponse ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetContainerRegistryCredentialsResponseResponse
// Size: 0x40(Inherited: 0x0) 
struct FdecodeGetContainerRegistryCredentialsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetContainerRegistryCredentialsResponse ReturnValue;  // 0x8(0x38)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetLobbyResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetLobbyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetLobbyResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMatchmakingTicketResultResponse
// Size: 0xA8(Inherited: 0x0) 
struct FdecodeGetMatchmakingTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetMatchmakingTicketResult ReturnValue;  // 0x8(0xA0)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMultiplayerServerLogsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetMultiplayerServerLogsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetMultiplayerServerLogsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetServerBackfillTicketResultResponse
// Size: 0x90(Inherited: 0x0) 
struct FdecodeGetServerBackfillTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetServerBackfillTicketResult ReturnValue;  // 0x8(0x88)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetTitleEnabledForMultiplayerServersStatusResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetTitleEnabledForMultiplayerServersStatusResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetTitleMultiplayerServersQuotaChangeResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetTitleMultiplayerServersQuotaChangeResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetTitleMultiplayerServersQuotaChangeResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetTitleMultiplayerServersQuotasResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetTitleMultiplayerServersQuotasResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerGetTitleMultiplayerServersQuotasResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeJoinMatchmakingTicketResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeJoinMatchmakingTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerJoinMatchmakingTicketResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListAssetSummariesResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListAssetSummariesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListAssetSummariesResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListContainerImagesResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListContainerImagesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListContainerImagesResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListContainerImageTagsResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListContainerImageTagsResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListContainerImageTagsResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListMatchmakingTicketsForPlayerResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeListMatchmakingTicketsForPlayerResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListMatchmakingTicketsForPlayerResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListQosServersForTitleResponseResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeListQosServersForTitleResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerListQosServersForTitleResponse ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeLobbyEmptyResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLobbyEmptyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerLobbyEmptyResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabMultiplayerModelDecoder.decodeSubscribeToLobbyResourceResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeSubscribeToLobbyResourceResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FMultiplayerSubscribeToLobbyResourceResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeGetEntityProfilesResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetEntityProfilesResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesGetEntityProfilesResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeGetGlobalPolicyResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeGetGlobalPolicyResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesGetGlobalPolicyResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeSetEntityProfilePolicyResponseResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeSetEntityProfilePolicyResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesSetEntityProfilePolicyResponse ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabProfilesModelDecoder.decodeSetProfileLanguageResponseResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeSetProfileLanguageResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FProfilesSetProfileLanguageResponse ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeAwardSteamAchievementResultResponse
// Size: 0x20(Inherited: 0x0) 
struct FdecodeAwardSteamAchievementResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerAwardSteamAchievementResult ReturnValue;  // 0x8(0x18)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeDeleteCharacterFromUserResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeleteCharacterFromUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerDeleteCharacterFromUserResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeDeregisterGameResponseResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeDeregisterGameResponseResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerDeregisterGameResponse ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardAroundUserResultResponse
// Size: 0x38(Inherited: 0x0) 
struct FdecodeGetLeaderboardAroundUserResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetLeaderboardAroundUserResult ReturnValue;  // 0x8(0x30)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeGetUserAccountInfoResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeGetUserAccountInfoResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerGetUserAccountInfoResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeLinkServerCustomIdResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeLinkServerCustomIdResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerLinkServerCustomIdResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeModifyCharacterVirtualCurrencyResultResponse
// Size: 0x28(Inherited: 0x0) 
struct FdecodeModifyCharacterVirtualCurrencyResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerModifyCharacterVirtualCurrencyResult ReturnValue;  // 0x8(0x20)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeMoveItemToCharacterFromCharacterResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeMoveItemToCharacterFromCharacterResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerMoveItemToCharacterFromCharacterResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeNotifyMatchmakerPlayerLeftResultResponse
// Size: 0x18(Inherited: 0x0) 
struct FdecodeNotifyMatchmakerPlayerLeftResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerNotifyMatchmakerPlayerLeftResult ReturnValue;  // 0x8(0x10)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeRedeemMatchmakerTicketResultResponse
// Size: 0x30(Inherited: 0x0) 
struct FdecodeRedeemMatchmakerTicketResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerRedeemMatchmakerTicketResult ReturnValue;  // 0x8(0x28)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSendPushNotificationResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSendPushNotificationResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSendPushNotificationResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSetGameServerInstanceDataResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetGameServerInstanceDataResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSetGameServerInstanceDataResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSetGameServerInstanceStateResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetGameServerInstanceStateResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSetGameServerInstanceStateResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabServerModelDecoder.decodeSetGameServerInstanceTagsResultResponse
// Size: 0x10(Inherited: 0x0) 
struct FdecodeSetGameServerInstanceTagsResultResponse
{
	struct UPlayFabJsonObject* Response;  // 0x0(0x8)
	struct FServerSetGameServerInstanceTagsResult ReturnValue;  // 0x8(0x8)

}; 
// Function PlayFab.PlayFabUtilities.getErrorText
// Size: 0x18(Inherited: 0x0) 
struct FgetErrorText
{
	int32_t code;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
