#pragma once 
#include "SDK.h" 
 
 
// Function LVL_Menu.LVL_Menu_C.ExecuteUbergraph_LVL_Menu
// Size: 0x11(Inherited: 0x0) 
struct FExecuteUbergraph_LVL_Menu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
