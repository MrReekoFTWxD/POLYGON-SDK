#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct FullBodyIK.FBIKBoneLimit
// Size: 0x20(Inherited: 0x0) 
struct FFBIKBoneLimit
{
	uint8_t  LimitType_X;  // 0x0(0x1)
	uint8_t  LimitType_Y;  // 0x1(0x1)
	uint8_t  LimitType_Z;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FVector Limit;  // 0x8(0x18)

}; 
// ScriptStruct FullBodyIK.FBIKConstraintOption
// Size: 0xA0(Inherited: 0x0) 
struct FFBIKConstraintOption
{
	struct FRigElementKey Item;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bEnabled : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bUseStiffness : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct FVector LinearStiffness;  // 0x10(0x18)
	struct FVector AngularStiffness;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bUseAngularLimit : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FFBIKBoneLimit AngularLimit;  // 0x48(0x20)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bUsePoleVector : 1;  // 0x68(0x1)
	uint8_t  PoleVectorOption;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)
	struct FVector PoleVector;  // 0x70(0x18)
	struct FRotator OffsetRotation;  // 0x88(0x18)

}; 
// ScriptStruct FullBodyIK.MotionProcessInput
// Size: 0x2(Inherited: 0x0) 
struct FMotionProcessInput
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bForceEffectorRotationTarget : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bOnlyApplyWhenReachedToTarget : 1;  // 0x1(0x1)

}; 
// ScriptStruct FullBodyIK.FBIKDebugOption
// Size: 0x80(Inherited: 0x0) 
struct FFBIKDebugOption
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDrawDebugHierarchy : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bColorAngularMotionStrength : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bColorLinearMotionStrength : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bDrawDebugAxes : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bDrawDebugEffector : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool bDrawDebugConstraints : 1;  // 0x5(0x1)
	char pad_6[10];  // 0x6(0xA)
	struct FTransform DrawWorldOffset;  // 0x10(0x60)
	float DrawSize;  // 0x70(0x4)
	char pad_116[12];  // 0x74(0xC)

}; 
// ScriptStruct FullBodyIK.FBIKEndEffector
// Size: 0x60(Inherited: 0x0) 
struct FFBIKEndEffector
{
	struct FRigElementKey Item;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FVector position;  // 0x10(0x18)
	float PositionAlpha;  // 0x28(0x4)
	int32_t PositionDepth;  // 0x2C(0x4)
	struct FQuat Rotation;  // 0x30(0x20)
	float RotationAlpha;  // 0x50(0x4)
	int32_t RotationDepth;  // 0x54(0x4)
	float Pull;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

}; 
// ScriptStruct FullBodyIK.SolverInput
// Size: 0x24(Inherited: 0x0) 
struct FSolverInput
{
	float LinearMotionStrength;  // 0x0(0x4)
	float MinLinearMotionStrength;  // 0x4(0x4)
	float AngularMotionStrength;  // 0x8(0x4)
	float MinAngularMotionStrength;  // 0xC(0x4)
	float DefaultTargetClamp;  // 0x10(0x4)
	float Precision;  // 0x14(0x4)
	float Damping;  // 0x18(0x4)
	int32_t MaxIterations;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bUseJacobianTranspose : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)

}; 
// ScriptStruct FullBodyIK.RigUnit_FullbodyIK_WorkData
// Size: 0x198(Inherited: 0x0) 
struct FRigUnit_FullbodyIK_WorkData
{
	char pad_0[408];  // 0x0(0x198)

}; 
// ScriptStruct FullBodyIK.RigUnit_FullbodyIK
// Size: 0x350(Inherited: 0xD0) 
struct FRigUnit_FullbodyIK : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Root;  // 0xD0(0xC)
	char pad_220[4];  // 0xDC(0x4)
	struct TArray<struct FFBIKEndEffector> Effectors;  // 0xE0(0x10)
	struct TArray<struct FFBIKConstraintOption> Constraints;  // 0xF0(0x10)
	struct FSolverInput SolverProperty;  // 0x100(0x24)
	struct FMotionProcessInput MotionProperty;  // 0x124(0x2)
	char pad_294_1 : 7;  // 0x126(0x1)
	bool bPropagateToChildren : 1;  // 0x126(0x1)
	char pad_295[9];  // 0x127(0x9)
	struct FFBIKDebugOption DebugOption;  // 0x130(0x80)
	struct FRigUnit_FullbodyIK_WorkData WorkData;  // 0x1B0(0x198)
	char pad_840[8];  // 0x348(0x8)

}; 
