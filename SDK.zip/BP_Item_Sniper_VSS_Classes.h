#pragma once 
#include <BP_Item_Sniper_VSS_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Sniper_VSS.BP_Item_Sniper_VSS_C
// Size: 0x598(Inherited: 0x590) 
struct ABP_Item_Sniper_VSS_C : public AItem_Weapon_Sniper
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x590(0x8)

	void SetSight(); // Function BP_Item_Sniper_VSS.BP_Item_Sniper_VSS_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Sniper_VSS.BP_Item_Sniper_VSS_C.ReceiveBeginPlay
	void OnSetWeaponModules_Event(); // Function BP_Item_Sniper_VSS.BP_Item_Sniper_VSS_C.OnSetWeaponModules_Event
	void ExecuteUbergraph_BP_Item_Sniper_VSS(int32_t EntryPoint); // Function BP_Item_Sniper_VSS.BP_Item_Sniper_VSS_C.ExecuteUbergraph_BP_Item_Sniper_VSS
}; 



