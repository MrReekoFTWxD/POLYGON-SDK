#pragma once 
#include <Rejoin_Structs.h>
 
 
 
// Class Rejoin.RejoinCheck
// Size: 0x170(Inherited: 0x28) 
struct URejoinCheck : public UObject
{
	uint8_t  LastKnownStatus;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bRejoinAfterCheck : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bAttemptingRejoin : 1;  // 0x2A(0x1)
	char pad_43[325];  // 0x2B(0x145)

}; 



