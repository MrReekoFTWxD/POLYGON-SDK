#pragma once 
#include <ChaosSolverEngine_Structs.h>
 
 
 
// Class ChaosSolverEngine.ChaosDebugDrawComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UChaosDebugDrawComponent : public UActorComponent
{
	char pad_176[8];  // 0xB0(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x378(Inherited: 0x278) 
struct AChaosSolverActor : public AActor
{
	struct FChaosSolverConfiguration Properties;  // 0x278(0x6C)
	float TimeStepMultiplier;  // 0x2E4(0x4)
	int32_t CollisionIterations;  // 0x2E8(0x4)
	int32_t PushOutIterations;  // 0x2EC(0x4)
	int32_t PushOutPairIterations;  // 0x2F0(0x4)
	float ClusterConnectionFactor;  // 0x2F4(0x4)
	uint8_t  ClusterUnionConnectionType;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool DoGenerateCollisionData : 1;  // 0x2F9(0x1)
	char pad_762[2];  // 0x2FA(0x2)
	struct FSolverCollisionFilterSettings CollisionFilterSettings;  // 0x2FC(0x10)
	char pad_780_1 : 7;  // 0x30C(0x1)
	bool DoGenerateBreakingData : 1;  // 0x30C(0x1)
	char pad_781[3];  // 0x30D(0x3)
	struct FSolverBreakingFilterSettings BreakingFilterSettings;  // 0x310(0x10)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool DoGenerateTrailingData : 1;  // 0x320(0x1)
	char pad_801[3];  // 0x321(0x3)
	struct FSolverTrailingFilterSettings TrailingFilterSettings;  // 0x324(0x10)
	float MassScale;  // 0x334(0x4)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool bGenerateContactGraph : 1;  // 0x338(0x1)
	char pad_825_1 : 7;  // 0x339(0x1)
	bool bHasFloor : 1;  // 0x339(0x1)
	char pad_826[2];  // 0x33A(0x2)
	float FloorHeight;  // 0x33C(0x4)
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl;  // 0x340(0x3)
	char pad_835[5];  // 0x343(0x5)
	struct UBillboardComponent* SpriteComponent;  // 0x348(0x8)
	char pad_848[24];  // 0x350(0x18)
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent;  // 0x368(0x8)
	char pad_880[8];  // 0x370(0x8)

	void SetSolverActive(bool bActive); // Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
	void SetAsCurrentWorldSolver(); // Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
}; 



// Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UChaosEventListenerComponent : public UActorComponent
{
	char pad_176[8];  // 0xB0(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolver
// Size: 0x28(Inherited: 0x28) 
struct UChaosSolver : public UObject
{

}; 



// Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x2C8(Inherited: 0xB8) 
struct UChaosGameplayEventDispatcher : public UChaosEventListenerComponent
{
	char pad_184[272];  // 0xB8(0x110)
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations;  // 0x1C8(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations;  // 0x218(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FRemovalEventCallbackWrapper> RemovalEventRegistrations;  // 0x268(0x50)
	char pad_696[16];  // 0x2B8(0x10)

}; 



// Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0x58(Inherited: 0x38) 
struct UChaosSolverSettings : public UDeveloperSettings
{
	char pad_56[8];  // 0x38(0x8)
	struct FSoftClassPath DefaultChaosSolverActorClass;  // 0x40(0x18)

}; 



// Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0x28(Inherited: 0x28) 
struct UChaosNotifyHandlerInterface : public UInterface
{

}; 



// Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UChaosSolverEngineBlueprintLibrary : public UBlueprintFunctionLibrary
{

	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision); // Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
}; 



