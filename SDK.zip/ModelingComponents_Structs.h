#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ModelingComponents.CreateTextureObjectResult
// Size: 0x10(Inherited: 0x0) 
struct FCreateTextureObjectResult
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* NewAsset;  // 0x8(0x8)

}; 
// ScriptStruct ModelingComponents.CreateMeshObjectResult
// Size: 0x20(Inherited: 0x0) 
struct FCreateMeshObjectResult
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* NewActor;  // 0x8(0x8)
	struct UPrimitiveComponent* NewComponent;  // 0x10(0x8)
	struct UObject* NewAsset;  // 0x18(0x8)

}; 
// ScriptStruct ModelingComponents.ModelingToolsAxisFilter
// Size: 0x3(Inherited: 0x0) 
struct FModelingToolsAxisFilter
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAxisX : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bAxisY : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bAxisZ : 1;  // 0x2(0x1)

}; 
// Function ModelingComponents.PreviewGeometry.SetPointSetVisibility
// Size: 0x18(Inherited: 0x0) 
struct FSetPointSetVisibility
{
	struct FString PointSetIdentifier;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bVisible : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// ScriptStruct ModelingComponents.CreateTextureObjectParams
// Size: 0x30(Inherited: 0x0) 
struct FCreateTextureObjectParams
{
	int32_t TypeHintExtended;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWorld* TargetWorld;  // 0x8(0x8)
	struct UObject* StoreRelativeToObject;  // 0x10(0x8)
	struct FString BaseName;  // 0x18(0x10)
	struct UTexture2D* GeneratedTransientTexture;  // 0x28(0x8)

}; 
// ScriptStruct ModelingComponents.CreateMeshObjectParams
// Size: 0x5C0(Inherited: 0x0) 
struct FCreateMeshObjectParams
{
	struct UPrimitiveComponent* SourceComponent;  // 0x0(0x8)
	uint8_t  TypeHint;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	 TypeHintClass;  // 0x10(0x8)
	int32_t TypeHintExtended;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UWorld* TargetWorld;  // 0x20(0x8)
	char pad_40[8];  // 0x28(0x8)
	struct FTransform Transform;  // 0x30(0x60)
	struct FString BaseName;  // 0x90(0x10)
	struct TArray<struct UMaterialInterface*> Materials;  // 0xA0(0x10)
	struct TArray<struct UMaterialInterface*> AssetMaterials;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bEnableCollision : 1;  // 0xC0(0x1)
	char ECollisionTraceFlag CollisionMode;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool bEnableRaytracingSupport : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool bEnableRecomputeNormals : 1;  // 0xC3(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bEnableRecomputeTangents : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool bEnableNanite : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)
	float NaniteProxyTrianglePercent;  // 0xC8(0x4)
	char pad_204[1268];  // 0xCC(0x4F4)

}; 
// Function ModelingComponents.PreviewGeometry.RemoveAllLineSets
// Size: 0x1(Inherited: 0x0) 
struct FRemoveAllLineSets
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDestroy : 1;  // 0x0(0x1)

}; 
// ScriptStruct ModelingComponents.RenderableTriangleVertex
// Size: 0x48(Inherited: 0x0) 
struct FRenderableTriangleVertex
{
	struct FVector position;  // 0x0(0x18)
	struct FVector2D UV;  // 0x18(0x10)
	struct FVector Normal;  // 0x28(0x18)
	struct FColor Color;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// Function ModelingComponents.OctreeDynamicMeshComponent.SetDynamicMesh
// Size: 0x8(Inherited: 0x0) 
struct FSetDynamicMesh
{
	struct UDynamicMesh* NewMesh;  // 0x0(0x8)

}; 
// ScriptStruct ModelingComponents.RenderableTriangle
// Size: 0xE0(Inherited: 0x0) 
struct FRenderableTriangle
{
	struct UMaterialInterface* Material;  // 0x0(0x8)
	struct FRenderableTriangleVertex Vertex0;  // 0x8(0x48)
	struct FRenderableTriangleVertex Vertex1;  // 0x50(0x48)
	struct FRenderableTriangleVertex Vertex2;  // 0x98(0x48)

}; 
// Function ModelingComponents.WeightMapSetProperties.GetWeightMapsFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetWeightMapsFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function ModelingComponents.CreateMeshObjectTypeProperties.GetCurrentCreateMeshType
// Size: 0x1(Inherited: 0x0) 
struct FGetCurrentCreateMeshType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function ModelingComponents.CreateMeshObjectTypeProperties.GetOutputTypeNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetOutputTypeNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function ModelingComponents.PreviewGeometry.AddLineSet
// Size: 0x18(Inherited: 0x0) 
struct FAddLineSet
{
	struct FString LineSetIdentifier;  // 0x0(0x10)
	struct ULineSetComponent* ReturnValue;  // 0x10(0x8)

}; 
// Function ModelingComponents.CreateMeshObjectTypeProperties.ShouldShowPropertySet
// Size: 0x1(Inherited: 0x0) 
struct FShouldShowPropertySet
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ModelingComponents.PreviewGeometry.AddPointSet
// Size: 0x18(Inherited: 0x0) 
struct FAddPointSet
{
	struct FString PointSetIdentifier;  // 0x0(0x10)
	struct UPointSetComponent* ReturnValue;  // 0x10(0x8)

}; 
// Function ModelingComponents.PreviewGeometry.CreateInWorld
// Size: 0x70(Inherited: 0x0) 
struct FCreateInWorld
{
	struct UWorld* World;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform WithTransform;  // 0x10(0x60)

}; 
// Function ModelingComponents.PreviewGeometry.FindLineSet
// Size: 0x18(Inherited: 0x0) 
struct FFindLineSet
{
	struct FString LineSetIdentifier;  // 0x0(0x10)
	struct ULineSetComponent* ReturnValue;  // 0x10(0x8)

}; 
// Function ModelingComponents.PreviewGeometry.FindPointSet
// Size: 0x18(Inherited: 0x0) 
struct FFindPointSet
{
	struct FString PointSetIdentifier;  // 0x0(0x10)
	struct UPointSetComponent* ReturnValue;  // 0x10(0x8)

}; 
// Function ModelingComponents.PreviewGeometry.GetActor
// Size: 0x8(Inherited: 0x0) 
struct FGetActor
{
	struct APreviewGeometryActor* ReturnValue;  // 0x0(0x8)

}; 
// Function ModelingComponents.PreviewGeometry.RemoveAllPointSets
// Size: 0x1(Inherited: 0x0) 
struct FRemoveAllPointSets
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDestroy : 1;  // 0x0(0x1)

}; 
// Function ModelingComponents.PreviewGeometry.RemoveLineSet
// Size: 0x18(Inherited: 0x0) 
struct FRemoveLineSet
{
	struct FString LineSetIdentifier;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDestroy : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function ModelingComponents.PreviewGeometry.RemovePointSet
// Size: 0x18(Inherited: 0x0) 
struct FRemovePointSet
{
	struct FString PointSetIdentifier;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDestroy : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function ModelingComponents.PreviewGeometry.SetAllLineSetsMaterial
// Size: 0x8(Inherited: 0x0) 
struct FSetAllLineSetsMaterial
{
	struct UMaterialInterface* Material;  // 0x0(0x8)

}; 
// Function ModelingComponents.PreviewGeometry.SetAllPointSetsMaterial
// Size: 0x8(Inherited: 0x0) 
struct FSetAllPointSetsMaterial
{
	struct UMaterialInterface* Material;  // 0x0(0x8)

}; 
// Function ModelingComponents.PreviewGeometry.SetLineSetMaterial
// Size: 0x20(Inherited: 0x0) 
struct FSetLineSetMaterial
{
	struct FString LineSetIdentifier;  // 0x0(0x10)
	struct UMaterialInterface* NewMaterial;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ModelingComponents.PreviewGeometry.SetLineSetVisibility
// Size: 0x18(Inherited: 0x0) 
struct FSetLineSetVisibility
{
	struct FString LineSetIdentifier;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bVisible : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function ModelingComponents.PreviewGeometry.SetPointSetMaterial
// Size: 0x20(Inherited: 0x0) 
struct FSetPointSetMaterial
{
	struct FString PointSetIdentifier;  // 0x0(0x10)
	struct UMaterialInterface* NewMaterial;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ModelingComponents.ModelingObjectsCreationAPI.CreateMeshObject
// Size: 0x5E0(Inherited: 0x0) 
struct FCreateMeshObject
{
	struct FCreateMeshObjectParams CreateMeshParams;  // 0x0(0x5C0)
	struct FCreateMeshObjectResult ReturnValue;  // 0x5C0(0x20)

}; 
// Function ModelingComponents.ModelingObjectsCreationAPI.CreateTextureObject
// Size: 0x40(Inherited: 0x0) 
struct FCreateTextureObject
{
	struct FCreateTextureObjectParams CreateTexParams;  // 0x0(0x30)
	struct FCreateTextureObjectResult ReturnValue;  // 0x30(0x10)

}; 
// Function ModelingComponents.PolygroupLayersProperties.GetGroupLayersFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetGroupLayersFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
