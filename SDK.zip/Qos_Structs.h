#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Qos.RegionQosInstance
// Size: 0x50(Inherited: 0x0) 
struct FRegionQosInstance
{
	struct FQosRegionInfo Definition;  // 0x0(0x40)
	struct TArray<struct FDatacenterQosInstance> DatacenterOptions;  // 0x40(0x10)

}; 
// ScriptStruct Qos.QosPingServerInfo
// Size: 0x18(Inherited: 0x0) 
struct FQosPingServerInfo
{
	struct FString Address;  // 0x0(0x10)
	int32_t Port;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct Qos.QosSubspaceComparisonParams
// Size: 0x10(Inherited: 0x0) 
struct FQosSubspaceComparisonParams
{
	int32_t MaxNonSubspacePingMs;  // 0x0(0x4)
	int32_t MinSubspacePingMs;  // 0x4(0x4)
	int32_t ConstantMaxToleranceMs;  // 0x8(0x4)
	float ScaledMaxTolerancePct;  // 0xC(0x4)

}; 
// ScriptStruct Qos.QosDatacenterInfo
// Size: 0x38(Inherited: 0x0) 
struct FQosDatacenterInfo
{
	struct FString ID;  // 0x0(0x10)
	struct FString RegionId;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bEnabled : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FQosPingServerInfo> Servers;  // 0x28(0x10)

}; 
// ScriptStruct Qos.QosRegionInfo
// Size: 0x40(Inherited: 0x0) 
struct FQosRegionInfo
{
	struct FText DisplayName;  // 0x0(0x18)
	struct FString RegionId;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnabled : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bVisible : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bAutoAssignable : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bAllowSubspaceBias : 1;  // 0x2B(0x1)
	struct FQosSubspaceComparisonParams SubspaceBiasParams;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct Qos.DatacenterQosInstance
// Size: 0x68(Inherited: 0x0) 
struct FDatacenterQosInstance
{
	struct FQosDatacenterInfo Definition;  // 0x0(0x38)
	uint8_t  Result;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t AvgPingMs;  // 0x3C(0x4)
	struct TArray<int32_t> PingResults;  // 0x40(0x10)
	char pad_80[8];  // 0x50(0x8)
	struct FDateTime LastCheckTimestamp;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bUsable : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function Qos.QosBeaconClient.ServerQosRequest
// Size: 0x10(Inherited: 0x0) 
struct FServerQosRequest
{
	struct FString InSessionId;  // 0x0(0x10)

}; 
// Function Qos.QosBeaconClient.ClientQosResponse
// Size: 0x1(Inherited: 0x0) 
struct FClientQosResponse
{
	uint8_t  Response;  // 0x0(0x1)

}; 
