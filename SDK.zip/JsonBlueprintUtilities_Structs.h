#pragma once 
#include "SDK.h" 
 
 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.GetFieldNames
// Size: 0x38(Inherited: 0x0) 
struct FGetFieldNames
{
	struct FJsonObjectWrapper JsonObject;  // 0x0(0x20)
	struct TArray<struct FString> FieldNames;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.FromFile
// Size: 0x40(Inherited: 0x0) 
struct FFromFile
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FFilePath File;  // 0x8(0x10)
	struct FJsonObjectWrapper OutJsonObject;  // 0x18(0x20)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.FromString
// Size: 0x40(Inherited: 0x0) 
struct FFromString
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString JsonString;  // 0x8(0x10)
	struct FJsonObjectWrapper OutJsonObject;  // 0x18(0x20)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.GetField
// Size: 0x38(Inherited: 0x0) 
struct FGetField
{
	struct FJsonObjectWrapper JsonObject;  // 0x0(0x20)
	struct FString FieldName;  // 0x20(0x10)
	int32_t OutValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.ToString
// Size: 0x38(Inherited: 0x0) 
struct FToString
{
	struct FJsonObjectWrapper JsonObject;  // 0x0(0x20)
	struct FString OutJsonString;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.SetField
// Size: 0x38(Inherited: 0x0) 
struct FSetField
{
	struct FJsonObjectWrapper JsonObject;  // 0x0(0x20)
	struct FString FieldName;  // 0x20(0x10)
	int32_t Value;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.HasField
// Size: 0x38(Inherited: 0x0) 
struct FHasField
{
	struct FJsonObjectWrapper JsonObject;  // 0x0(0x20)
	struct FString FieldName;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.ToFile
// Size: 0x38(Inherited: 0x0) 
struct FToFile
{
	struct FJsonObjectWrapper JsonObject;  // 0x0(0x20)
	struct FFilePath File;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
