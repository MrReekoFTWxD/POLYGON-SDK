#pragma once 
#include <PlayFabCommon_Structs.h>
 
 
 
// Class PlayFabCommon.PlayFabAuthenticationContext
// Size: 0x68(Inherited: 0x28) 
struct UPlayFabAuthenticationContext : public UObject
{
	struct FString ClientSessionTicket;  // 0x28(0x10)
	struct FString EntityToken;  // 0x38(0x10)
	struct FString DeveloperSecretKey;  // 0x48(0x10)
	struct FString PlayFabId;  // 0x58(0x10)

	void SetPlayFabId(struct FString InKey); // Function PlayFabCommon.PlayFabAuthenticationContext.SetPlayFabId
	void SetEntityToken(struct FString InToken); // Function PlayFabCommon.PlayFabAuthenticationContext.SetEntityToken
	void SetDeveloperSecretKey(struct FString InKey); // Function PlayFabCommon.PlayFabAuthenticationContext.SetDeveloperSecretKey
	void SetClientSessionTicket(struct FString InTicket); // Function PlayFabCommon.PlayFabAuthenticationContext.SetClientSessionTicket
	struct FString GetPlayFabId(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetPlayFabId
	struct FString GetEntityToken(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetEntityToken
	struct FString GetDeveloperSecretKey(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetDeveloperSecretKey
	struct FString GetClientSessionTicket(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetClientSessionTicket
	void ForgetAllCredentials(); // Function PlayFabCommon.PlayFabAuthenticationContext.ForgetAllCredentials
	void ClientAdminSecurityCheck(); // Function PlayFabCommon.PlayFabAuthenticationContext.ClientAdminSecurityCheck
}; 



// Class PlayFabCommon.PlayFabRuntimeSettings
// Size: 0x58(Inherited: 0x28) 
struct UPlayFabRuntimeSettings : public UObject
{
	struct FString ProductionEnvironmentURL;  // 0x28(0x10)
	struct FString TitleId;  // 0x38(0x10)
	struct FString DeveloperSecretKey;  // 0x48(0x10)

}; 



