#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Optic_8x.BP_Item_Optic_8x_C.ExecuteUbergraph_BP_Item_Optic_8x
// Size: 0x5D(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Optic_8x
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_isAiming : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsLocalPlayerController_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APG_PlayerController_Game* K2Node_DynamicCast_AsPG_Player_Controller_Game;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UBP_FOVManagerComponent_Game_C* K2Node_DynamicCast_AsBP_FOVManager_Component_Game;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_DoubleDouble_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APG_Character* K2Node_DynamicCast_AsPG_Character;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_IsAiming_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_IsAiming_ReturnValue_2 : 1;  // 0x5C(0x1)

}; 
// Function BP_Item_Optic_8x.BP_Item_Optic_8x_C.ToggleAiming
// Size: 0x1(Inherited: 0x1) 
struct FToggleAiming : public FToggleAiming
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsAiming : 1;  // 0x0(0x1)

}; 
