#pragma once 
#include <SignificanceManager_Structs.h>
 
 
 
// Class SignificanceManager.SignificanceManager
// Size: 0x120(Inherited: 0x28) 
struct USignificanceManager : public UObject
{
	char pad_40[224];  // 0x28(0xE0)
	struct FSoftClassPath SignificanceManagerClassName;  // 0x108(0x18)

}; 



