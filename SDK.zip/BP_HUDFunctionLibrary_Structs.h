#pragma once 
#include "SDK.h" 
 
 
// Function BP_HUDFunctionLibrary.BP_HUDFunctionLibrary_C.GetColorByID
// Size: 0x31(Inherited: 0x0) 
struct FGetColorByID
{
	struct FName RowName;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	struct FST_HUDColor CallFunc_GetDataTableRowFromName_OutRow;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x30(0x1)

}; 
