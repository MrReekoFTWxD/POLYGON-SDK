#pragma once 
#include <PlayFabGSDK_Structs.h>
 
 
 
// Class PlayFabGSDK.GSDKUtils
// Size: 0x28(Inherited: 0x28) 
struct UGSDKUtils : public UBlueprintFunctionLibrary
{

	void UpdateConnectedPlayers(struct TArray<struct FConnectedPlayer>& CurrentlyConnectedPlayers); // Function PlayFabGSDK.GSDKUtils.UpdateConnectedPlayers
	bool SetDefaultServerHostPort(); // Function PlayFabGSDK.GSDKUtils.SetDefaultServerHostPort
	void RegisterGSDKShutdownDelegate(struct FDelegate& OnGSDKShutdownDelegate); // Function PlayFabGSDK.GSDKUtils.RegisterGSDKShutdownDelegate
	void RegisterGSDKServerActiveDelegate(struct FDelegate& OnGSDKServerActiveDelegate); // Function PlayFabGSDK.GSDKUtils.RegisterGSDKServerActiveDelegate
	void RegisterGSDKReadyForPlayers(struct FDelegate& OnGSDKReadyForPlayersDelegate); // Function PlayFabGSDK.GSDKUtils.RegisterGSDKReadyForPlayers
	void RegisterGSDKMaintenanceDelegate(struct FDelegate& OnGSDKMaintenanceDelegate); // Function PlayFabGSDK.GSDKUtils.RegisterGSDKMaintenanceDelegate
	void RegisterGSDKHealthCheckDelegate(struct FDelegate& OnGSDKHealthCheckDelegate); // Function PlayFabGSDK.GSDKUtils.RegisterGSDKHealthCheckDelegate
	struct FString GetVMId(); // Function PlayFabGSDK.GSDKUtils.GetVMId
	struct FString GetTitleId(); // Function PlayFabGSDK.GSDKUtils.GetTitleId
	struct FString GetSharedContentDirectory(); // Function PlayFabGSDK.GSDKUtils.GetSharedContentDirectory
	struct FString GetServerId(); // Function PlayFabGSDK.GSDKUtils.GetServerId
	struct FString GetRegionName(); // Function PlayFabGSDK.GSDKUtils.GetRegionName
	struct FString GetMetaDataValue(struct FString MetaDataName); // Function PlayFabGSDK.GSDKUtils.GetMetaDataValue
	struct FString GetMatchSessionCookie(); // Function PlayFabGSDK.GSDKUtils.GetMatchSessionCookie
	struct FString GetMatchId(); // Function PlayFabGSDK.GSDKUtils.GetMatchId
	struct FString GetLogsDirectory(); // Function PlayFabGSDK.GSDKUtils.GetLogsDirectory
	struct TArray<struct FString> GetInitialPlayers(); // Function PlayFabGSDK.GSDKUtils.GetInitialPlayers
	struct FGameServerConnectionInfo GetGameServerConnectionInfo(); // Function PlayFabGSDK.GSDKUtils.GetGameServerConnectionInfo
	struct FString GetBuildId(); // Function PlayFabGSDK.GSDKUtils.GetBuildId
}; 



