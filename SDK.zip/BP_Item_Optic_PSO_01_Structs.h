#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Optic_PSO_01.BP_Item_Optic_PSO_01_C.ExecuteUbergraph_BP_Item_Optic_PSO_01
// Size: 0x57(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Optic_PSO_01
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_isAiming : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsLocalPlayerController_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x18(0x8)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x20(0x8)
	struct APG_PlayerController_Game* K2Node_DynamicCast_AsPG_Player_Controller_Game;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APG_Character* K2Node_DynamicCast_AsPG_Character;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UBP_FOVManagerComponent_Game_C* K2Node_DynamicCast_AsBP_FOVManager_Component_Game;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsAiming_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_Less_DoubleDouble_ReturnValue : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_IsAiming_ReturnValue_2 : 1;  // 0x55(0x1)
	char pad_86_1 : 7;  // 0x56(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x56(0x1)

}; 
// Function BP_Item_Optic_PSO_01.BP_Item_Optic_PSO_01_C.ToggleAiming
// Size: 0x1(Inherited: 0x1) 
struct FToggleAiming : public FToggleAiming
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsAiming : 1;  // 0x0(0x1)

}; 
