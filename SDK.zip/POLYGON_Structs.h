#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction POLYGON.EOSCreatePartyComplete__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FEOSCreatePartyComplete__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool wasSuccessful : 1;  // 0x0(0x1)

}; 
// Function POLYGON.WeaponComponent.SetWantsToAiming_server
// Size: 0x1(Inherited: 0x0) 
struct FSetWantsToAiming_server
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewState : 1;  // 0x0(0x1)

}; 
// DelegateFunction POLYGON.OnIsCaptureDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnIsCaptureDelegate__DelegateSignature
{
	struct AControlPoint* ControlPoint;  // 0x0(0x8)

}; 
// DelegateFunction POLYGON.OnAddedGameScoreDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAddedGameScoreDelegate__DelegateSignature
{
	struct TArray<struct FScoreInfoBlueprint> ScoreInfos;  // 0x0(0x10)

}; 
// DelegateFunction POLYGON.OnConnectedStateChangeDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnConnectedStateChangeDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// Function POLYGON.ControlPoint.GetControlPointNameAsString
// Size: 0x10(Inherited: 0x0) 
struct FGetControlPointNameAsString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct POLYGON.GameChatMessage
// Size: 0x20(Inherited: 0x0) 
struct FGameChatMessage
{
	struct APG_PlayerState_Game* Sender;  // 0x0(0x8)
	uint8_t  MessageType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Message;  // 0x10(0x10)

}; 
// Function POLYGON.ClientBackendComponent.SerPlayerExperiments
// Size: 0x8(Inherited: 0x0) 
struct FSerPlayerExperiments
{
	struct UPlayFabJsonObject* Experiments;  // 0x0(0x8)

}; 
// ScriptStruct POLYGON.ScoreInfoBlueprint
// Size: 0x10(Inherited: 0x0) 
struct FScoreInfoBlueprint
{
	int32_t Score;  // 0x0(0x4)
	uint8_t  ScoreType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UObject* Giver;  // 0x8(0x8)

}; 
// Function POLYGON.HealthStatsComponent.GetHealth
// Size: 0x4(Inherited: 0x0) 
struct FGetHealth
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction POLYGON.OnCustomLoginCompleteDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnCustomLoginCompleteDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool isSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// DelegateFunction POLYGON.OnAimingDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnAimingDelegate__DelegateSignature
{
	struct AItem_Module_Optic* OpticItem;  // 0x0(0x8)

}; 
// ScriptStruct POLYGON.PlayerAssist
// Size: 0x18(Inherited: 0x0) 
struct FPlayerAssist
{
	struct APG_PlayerState_Game* PlayerAssist;  // 0x0(0x8)
	int32_t Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FTimerHandle TimerResetAssist;  // 0x10(0x8)

}; 
// DelegateFunction POLYGON.OnApplyWeaponDamageDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnApplyWeaponDamageDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHeadshot : 1;  // 0x0(0x1)

}; 
// DelegateFunction POLYGON.OnCapturedTeamDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnCapturedTeamDelegate__DelegateSignature
{
	struct AControlPoint* ControlPoint;  // 0x0(0x8)

}; 
// DelegateFunction POLYGON.OnPutInQueueDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnPutInQueueDelegate__DelegateSignature
{
	char Number;  // 0x0(0x1)

}; 
// DelegateFunction POLYGON.OnResponseReserveSlotDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnResponseReserveSlotDelegate__DelegateSignature
{
	char Payload;  // 0x0(0x1)

}; 
// DelegateFunction POLYGON.OnSetCurrentWeaponDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSetCurrentWeaponDelegate__DelegateSignature
{
	struct AItem_Weapon_General* OldCurrentWeapon;  // 0x0(0x8)

}; 
// Function POLYGON.WeaponComponent.SelectWeaponSlot_server
// Size: 0x1(Inherited: 0x0) 
struct FSelectWeaponSlot_server
{
	char Slot;  // 0x0(0x1)

}; 
// ScriptStruct POLYGON.ItemReference
// Size: 0x10(Inherited: 0x8) 
struct FItemReference : public FTableRowBase
{
	AItem_General* Item;  // 0x8(0x8)

}; 
// Function POLYGON.DataManagerLibrary.GetDataTable_BattlePass_Season_3
// Size: 0x8(Inherited: 0x0) 
struct FGetDataTable_BattlePass_Season_3
{
	struct UDataTable* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.TraceProjectile.OnTrace
// Size: 0x30(Inherited: 0x0) 
struct FOnTrace
{
	struct FVector StartLocation;  // 0x0(0x18)
	struct FVector EndLocation;  // 0x18(0x18)

}; 
// DelegateFunction POLYGON.OnUpdatePlayerCombinedInfoDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnUpdatePlayerCombinedInfoDelegate__DelegateSignature
{
	struct TArray<uint8_t > ModifiedData;  // 0x0(0x10)
	struct FString CustomString;  // 0x10(0x10)

}; 
// ScriptStruct POLYGON.BallisticMaterialResponseMapEntry
// Size: 0x34(Inherited: 0x0) 
struct FBallisticMaterialResponseMapEntry
{
	uint8_t  PenTraceType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool NeverPenetrate : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float PenetrationDepthMultiplier;  // 0x4(0x4)
	float PenetrationNormalization;  // 0x8(0x4)
	float PenetrationNormalizationGrazing;  // 0xC(0x4)
	float PenetrationEntryAngleSpread;  // 0x10(0x4)
	float PenetrationExitAngleSpread;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool NeverRicochet : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float RicochetProbabilityMultiplier;  // 0x1C(0x4)
	float RicochetRestitution;  // 0x20(0x4)
	float RicochetRestitutionInfluence;  // 0x24(0x4)
	float RicochetFriction;  // 0x28(0x4)
	float RicochetFrictionInfluence;  // 0x2C(0x4)
	float RicochetSpread;  // 0x30(0x4)

}; 
// Function POLYGON.ServerGameInstance.OnGSDKHealthCheck
// Size: 0x1(Inherited: 0x0) 
struct FOnGSDKHealthCheck
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.ClientBackendComponent.IsClientLoggedIn
// Size: 0x1(Inherited: 0x0) 
struct FIsClientLoggedIn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.TraceProjectile.UpdateVelocity
// Size: 0x50(Inherited: 0x0) 
struct FUpdateVelocity
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector previousVelocity;  // 0x18(0x18)
	float DeltaTime;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FVector ReturnValue;  // 0x38(0x18)

}; 
// ScriptStruct POLYGON.BattlePassReward
// Size: 0x80(Inherited: 0x8) 
struct FBattlePassReward : public FTableRowBase
{
	int32_t Level;  // 0x8(0x4)
	int32_t RequiredExperience;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsFree : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString ItemId;  // 0x18(0x10)
	struct FString ItemCatalog;  // 0x28(0x10)
	struct UTexture2D* Image;  // 0x38(0x8)
	struct UTexture2D* Icon;  // 0x40(0x8)
	struct FLinearColor Color;  // 0x48(0x10)
	uint8_t  Quality;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FText Name;  // 0x60(0x18)
	int32_t Number;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)

}; 
// ScriptStruct POLYGON.BeaconSlotRequest
// Size: 0x20(Inherited: 0x0) 
struct FBeaconSlotRequest
{
	struct APG_BeaconClient* BeaconClient;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> UserIds;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)

}; 
// ScriptStruct POLYGON.WeaponShot
// Size: 0x20(Inherited: 0x0) 
struct FWeaponShot
{
	struct FVector_NetQuantizeNormal ShotDirection;  // 0x0(0x18)
	char RandomSeed;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function POLYGON.PG_Character.CameraNeutralizationEffectEvent
// Size: 0x4(Inherited: 0x0) 
struct FCameraNeutralizationEffectEvent
{
	float Damage;  // 0x0(0x4)

}; 
// Function POLYGON.HealthStatsComponent.GetHealthProtection
// Size: 0x1(Inherited: 0x0) 
struct FGetHealthProtection
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct POLYGON.WeaponHitOnCharacter
// Size: 0x28(Inherited: 0x0) 
struct FWeaponHitOnCharacter
{
	struct FVector_NetQuantize Location;  // 0x0(0x18)
	struct TWeakObjectPtr<AActor> Actor;  // 0x18(0x8)
	char BoneIndex;  // 0x20(0x1)
	char EPhysicalSurface PhysSurfaceType;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// ScriptStruct POLYGON.LevelInfo
// Size: 0x20(Inherited: 0x8) 
struct FLevelInfo : public FTableRowBase
{
	struct FName LevelID;  // 0x8(0x8)
	int32_t Level;  // 0x10(0x4)
	int32_t ProgressRequired;  // 0x14(0x4)
	struct UTexture2D* LevelIcon;  // 0x18(0x8)

}; 
// Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Roll
// Size: 0x4(Inherited: 0x0) 
struct FSetWeaponRecoilAlpha_Roll
{
	float newRollRecoil;  // 0x0(0x4)

}; 
// Function POLYGON.TraceProjectile.OnTrajectoryUpdateReceived
// Size: 0x48(Inherited: 0x0) 
struct FOnTrajectoryUpdateReceived
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector OldVelocity;  // 0x18(0x18)
	struct FVector NewVelocity;  // 0x30(0x18)

}; 
// ScriptStruct POLYGON.MapInfo
// Size: 0x88(Inherited: 0x8) 
struct FMapInfo : public FTableRowBase
{
	struct FName MapRowName;  // 0x8(0x8)
	struct FString MapName;  // 0x10(0x10)
	struct FText MapDisplayName;  // 0x20(0x18)
	struct TArray<uint8_t > GameModes;  // 0x38(0x10)
	int32_t MaxPlayers;  // 0x48(0x4)
	int32_t MaxScoreForWin;  // 0x4C(0x4)
	struct UTexture2D* MapPreview;  // 0x50(0x8)
	struct UTexture2D* MinimapImage;  // 0x58(0x8)
	float Dimension;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FVector CameraPosition;  // 0x68(0x18)
	float CameraRotate;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool IsDevelopment : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)

}; 
// Function POLYGON.PG_PlayerController_Game.StartInteraction_Client
// Size: 0x4(Inherited: 0x0) 
struct FStartInteraction_Client
{
	float interactionTime;  // 0x0(0x4)

}; 
// Function POLYGON.ClientGameInstance.GetPlayerCombinedInfo
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerCombinedInfo
{
	struct UPlayFabJsonObject* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct POLYGON.PlayerId
// Size: 0x20(Inherited: 0x0) 
struct FPlayerId
{
	struct FString PlayerMasterId;  // 0x0(0x10)
	struct FString PlayerTitleId;  // 0x10(0x10)

}; 
// Function POLYGON.DataManagerLibrary.GetDataTable_MapsInfo
// Size: 0x8(Inherited: 0x0) 
struct FGetDataTable_MapsInfo
{
	struct UDataTable* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct POLYGON.ScoreInfo
// Size: 0x10(Inherited: 0x0) 
struct FScoreInfo
{
	uint16_t Score;  // 0x0(0x2)
	uint8_t  ScoreType;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct UObject* Giver;  // 0x8(0x8)

}; 
// Function POLYGON.ClientGameInstance.SetPlayerCombinedInfo
// Size: 0x8(Inherited: 0x0) 
struct FSetPlayerCombinedInfo
{
	struct UPlayFabJsonObject* newPlayerCombinedInfo;  // 0x0(0x8)

}; 
// Function POLYGON.TraceProjectile.CollisionFilter
// Size: 0xF0(Inherited: 0x0) 
struct FCollisionFilter
{
	struct FHitResult HitResult;  // 0x0(0xE8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)

}; 
// Function POLYGON.HealthStatsComponent.OnRep_Health
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_Health
{
	char previousHealth;  // 0x0(0x1)

}; 
// Function POLYGON.FOVManagerComponent.SetDefaultCameraFOV
// Size: 0x4(Inherited: 0x0) 
struct FSetDefaultCameraFOV
{
	float newDefaultCameraFOV;  // 0x0(0x4)

}; 
// Function POLYGON.PG_PlayerController_Game.RequestSpawnOnSquadMember_server
// Size: 0x8(Inherited: 0x0) 
struct FRequestSpawnOnSquadMember_server
{
	struct APG_PlayerState_Game* squadMember;  // 0x0(0x8)

}; 
// Function POLYGON.TraceProjectile.OnImpact
// Size: 0x128(Inherited: 0x0) 
struct FOnImpact
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ricochet : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool passedThrough : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FVector exitVelocity;  // 0x8(0x18)
	struct FVector Impulse;  // 0x20(0x18)
	float PenetrationDepth;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FHitResult HitResult;  // 0x40(0xE8)

}; 
// Function POLYGON.TraceProjectile.Spawn
// Size: 0x48(Inherited: 0x0) 
struct FSpawn
{
	ATraceProjectile* bulletClass;  // 0x0(0x8)
	struct AItem_Weapon_General* weapon;  // 0x8(0x8)
	struct FVector SpawnLocation;  // 0x10(0x18)
	struct FVector startVelocity;  // 0x28(0x18)
	char RandomSeed;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function POLYGON.HealthStatsComponent.GetStamina
// Size: 0x4(Inherited: 0x0) 
struct FGetStamina
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.TraceProjectile.SpawnWithExactVelocity
// Size: 0x48(Inherited: 0x0) 
struct FSpawnWithExactVelocity
{
	ATraceProjectile* bulletClass;  // 0x0(0x8)
	struct AItem_Weapon_General* weapon;  // 0x8(0x8)
	struct FVector SpawnLocation;  // 0x10(0x18)
	struct FVector startVelocity;  // 0x28(0x18)
	char RandomSeed;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function POLYGON.PlayerCoreComponent.GetNextLevelInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetNextLevelInfo
{
	struct FLevelInfo ReturnValue;  // 0x0(0x20)

}; 
// Function POLYGON.ChatSystemComponent.SendMessage_Server
// Size: 0x20(Inherited: 0x0) 
struct FSendMessage_Server
{
	struct FGameChatMessage Message;  // 0x0(0x20)

}; 
// Function POLYGON.ControlPoint.GetControlPointNameAsOneLetter
// Size: 0x10(Inherited: 0x0) 
struct FGetControlPointNameAsOneLetter
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function POLYGON.ChatSystemComponent.SentMessage_Multicast
// Size: 0x20(Inherited: 0x0) 
struct FSentMessage_Multicast
{
	struct FGameChatMessage Message;  // 0x0(0x20)

}; 
// Function POLYGON.ClientBackendComponent.GiveVipLocal
// Size: 0x10(Inherited: 0x0) 
struct FGiveVipLocal
{
	struct FString ID;  // 0x0(0x10)

}; 
// Function POLYGON.ClientBackendComponent.GetPlayerExperiments
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerExperiments
{
	struct UPlayFabJsonObject* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.ControlPoint.ContainsCharacter
// Size: 0x10(Inherited: 0x0) 
struct FContainsCharacter
{
	struct ACharacter* Character;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function POLYGON.PG_PlayerController_Game.LoginPlayer_server
// Size: 0x10(Inherited: 0x0) 
struct FLoginPlayer_server
{
	struct FString PlayerMasterId;  // 0x0(0x10)

}; 
// Function POLYGON.ClientGameInstance.SetPlayerId
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerId
{
	struct FString newPlayerMasterId;  // 0x0(0x10)

}; 
// Function POLYGON.ClientGameInstance.SetServerTime
// Size: 0x8(Inherited: 0x0) 
struct FSetServerTime
{
	struct FDateTime serverTime;  // 0x0(0x8)

}; 
// Function POLYGON.ClientGameInstance.GetPlayerMasterId
// Size: 0x10(Inherited: 0x0) 
struct FGetPlayerMasterId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function POLYGON.PG_PlayerController_Game.SetVisibleLoadingScreen
// Size: 0x1(Inherited: 0x0) 
struct FSetVisibleLoadingScreen
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsVisible : 1;  // 0x0(0x1)

}; 
// Function POLYGON.EOSPartyMemberId.ToString
// Size: 0x10(Inherited: 0x0) 
struct FToString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function POLYGON.ClientGameInstance.GetServerTime
// Size: 0x8(Inherited: 0x0) 
struct FGetServerTime
{
	struct FDateTime ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.ClientGameInstance.HandleNetworkFailure
// Size: 0x28(Inherited: 0x0) 
struct FHandleNetworkFailure
{
	struct UWorld* World;  // 0x0(0x8)
	struct UNetDriver* NetDriver;  // 0x8(0x8)
	char ENetworkFailure FailureType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString ErrorString;  // 0x18(0x10)

}; 
// Function POLYGON.FOVManagerComponent.SetCameraFOV
// Size: 0x4(Inherited: 0x0) 
struct FSetCameraFOV
{
	float newCameraFOV;  // 0x0(0x4)

}; 
// Function POLYGON.DataManagerLibrary.GetDataTable_ItemReferences
// Size: 0x8(Inherited: 0x0) 
struct FGetDataTable_ItemReferences
{
	struct UDataTable* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.DataManagerLibrary.GetDataTable_LevelInfo
// Size: 0x8(Inherited: 0x0) 
struct FGetDataTable_LevelInfo
{
	struct UDataTable* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.EOSSubsystemAvanced.GetJoinedParties
// Size: 0x18(Inherited: 0x0) 
struct FGetJoinedParties
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<struct UEOSPartyId*> ReturnValue;  // 0x8(0x10)

}; 
// Function POLYGON.Item_Weapon_General.SetWeaponModules
// Size: 0x8(Inherited: 0x0) 
struct FSetWeaponModules
{
	struct UPlayFabJsonObject* modules;  // 0x0(0x8)

}; 
// Function POLYGON.EOSSubsystemAvanced.StartLogin
// Size: 0x10(Inherited: 0x0) 
struct FStartLogin
{
	struct FDelegate OnLoginComplete;  // 0x0(0x10)

}; 
// Function POLYGON.EOSSubsystemAvanced.GetPartyMembers
// Size: 0x20(Inherited: 0x0) 
struct FGetPartyMembers
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UEOSPartyId* PartyId;  // 0x8(0x8)
	struct TArray<struct UEOSPartyMemberId*> ReturnValue;  // 0x10(0x10)

}; 
// Function POLYGON.PG_PlayerState_Base.SetPlayerName
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerName
{
	struct FString PlayerName;  // 0x0(0x10)

}; 
// Function POLYGON.EOSSubsystemAvanced.StartCreateParty
// Size: 0x20(Inherited: 0x0) 
struct FStartCreateParty
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t PartyTypeId;  // 0x8(0x4)
	struct FDelegate onDone;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function POLYGON.FOVManagerComponent.SetMeshFOV
// Size: 0x4(Inherited: 0x0) 
struct FSetMeshFOV
{
	float newMeshFOV;  // 0x0(0x4)

}; 
// Function POLYGON.InteractInterface.SetPlayerLooks
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerLooks
{
	struct APG_Character* Character;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsLooks : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function POLYGON.InteractInterface.StartInteract
// Size: 0x8(Inherited: 0x0) 
struct FStartInteract
{
	struct APG_Character* Character;  // 0x0(0x8)

}; 
// Function POLYGON.InteractInterface.StopInteract
// Size: 0x8(Inherited: 0x0) 
struct FStopInteract
{
	struct APG_Character* Character;  // 0x0(0x8)

}; 
// Function POLYGON.PlayerCoreComponent.UpdatePlayerCombinedInfo
// Size: 0x20(Inherited: 0x0) 
struct FUpdatePlayerCombinedInfo
{
	struct TArray<uint8_t > ModifiedData;  // 0x0(0x10)
	struct FString customDelegateString;  // 0x10(0x10)

}; 
// Function POLYGON.InventoryComponent_Game.AddGrenate_server
// Size: 0x1(Inherited: 0x0) 
struct FAddGrenate_server
{
	char Number;  // 0x0(0x1)

}; 
// Function POLYGON.InventoryComponent_Game.EquipItems
// Size: 0x20(Inherited: 0x0) 
struct FEquipItems
{
	struct TArray<struct FString> itemsInstanceId;  // 0x0(0x10)
	struct TArray<struct FString> ReturnValue;  // 0x10(0x10)

}; 
// Function POLYGON.InventoryComponent_Game.OnRep_CurrentWeapon
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_CurrentWeapon
{
	struct AItem_Weapon_General* previousWeapon;  // 0x0(0x8)

}; 
// Function POLYGON.InventoryComponent_Game.RequestEquipItems_server
// Size: 0x10(Inherited: 0x0) 
struct FRequestEquipItems_server
{
	struct TArray<struct FString> itemsInstanceId;  // 0x0(0x10)

}; 
// Function POLYGON.InventoryComponent_Game.RequestSetWeaponModules_server
// Size: 0x20(Inherited: 0x0) 
struct FRequestSetWeaponModules_server
{
	struct FString weaponInstanceId;  // 0x0(0x10)
	struct TArray<struct FString> itemsInstanceId;  // 0x10(0x10)

}; 
// Function POLYGON.Item_Module_Flashlight.OnChangeEnableState
// Size: 0x1(Inherited: 0x0) 
struct FOnChangeEnableState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPlaySound : 1;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Module_Flashlight.OnRep_IsEnable
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_IsEnable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool oldState : 1;  // 0x0(0x1)

}; 
// Function POLYGON.WeaponComponent.OnSetCurrentWeapon
// Size: 0x8(Inherited: 0x0) 
struct FOnSetCurrentWeapon
{
	struct AItem_Weapon_General* OldCurrentWeapon;  // 0x0(0x8)

}; 
// Function POLYGON.Item_Module_Flashlight.SetFlashlightEnable
// Size: 0x2(Inherited: 0x0) 
struct FSetFlashlightEnable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool isEnable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bCallOnServer : 1;  // 0x1(0x1)

}; 
// Function POLYGON.Item_Module_Flashlight.SetFlashlightEnable_server
// Size: 0x1(Inherited: 0x0) 
struct FSetFlashlightEnable_server
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool isEnable : 1;  // 0x0(0x1)

}; 
// Function POLYGON.PG_GameState_Game.GetGameTimer
// Size: 0x4(Inherited: 0x0) 
struct FGetGameTimer
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.Item_Module_Optic.ToggleAiming
// Size: 0x1(Inherited: 0x0) 
struct FToggleAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsAiming : 1;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Weapon_General.AddStockAmmo_server
// Size: 0x1(Inherited: 0x0) 
struct FAddStockAmmo_server
{
	int8_t addAmmo;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Weapon_General.GetCurrentStockAmmo
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentStockAmmo
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.Item_Weapon_General.GetForwardShot
// Size: 0x18(Inherited: 0x0) 
struct FGetForwardShot
{
	struct FVector ReturnValue;  // 0x0(0x18)

}; 
// Function POLYGON.Item_Weapon_General.NotifyServerHit
// Size: 0x28(Inherited: 0x0) 
struct FNotifyServerHit
{
	struct FWeaponHitOnCharacter hitOnCharacter;  // 0x0(0x28)

}; 
// Function POLYGON.Item_Weapon_General.NotifyServerHitWithEnergy
// Size: 0x30(Inherited: 0x0) 
struct FNotifyServerHitWithEnergy
{
	struct FWeaponHitOnCharacter hitOnCharacter;  // 0x0(0x28)
	char energy;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function POLYGON.WeaponComponent.GetIsShooting
// Size: 0x1(Inherited: 0x0) 
struct FGetIsShooting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Weapon_General.NotifyServerOfShot
// Size: 0x20(Inherited: 0x0) 
struct FNotifyServerOfShot
{
	struct FWeaponShot WeaponShot;  // 0x0(0x20)

}; 
// Function POLYGON.Item_Weapon_General.NotifyServerTraceHit
// Size: 0x28(Inherited: 0x0) 
struct FNotifyServerTraceHit
{
	struct FWeaponHitOnCharacter hitOnCharacter;  // 0x0(0x28)

}; 
// Function POLYGON.Item_Weapon_General.OnRep_CallHardReset
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_CallHardReset
{
	char PreviousValue;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Weapon_General.OnRep_ReloadCaller
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_ReloadCaller
{
	char PreviousValue;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Weapon_General.OnRep_WeaponHitOfShortShot
// Size: 0x18(Inherited: 0x0) 
struct FOnRep_WeaponHitOfShortShot
{
	struct FVector_NetQuantize PreviousValue;  // 0x0(0x18)

}; 
// Function POLYGON.Item_Weapon_General.OnRep_WeaponShot
// Size: 0x20(Inherited: 0x0) 
struct FOnRep_WeaponShot
{
	struct FWeaponShot previousShot;  // 0x0(0x20)

}; 
// Function POLYGON.Item_Weapon_General.RequestReload_server
// Size: 0x1(Inherited: 0x0) 
struct FRequestReload_server
{
	char currentNumberAmmo;  // 0x0(0x1)

}; 
// Function POLYGON.Item_Weapon_Grenade.OnMeshHit
// Size: 0x118(Inherited: 0x0) 
struct FOnMeshHit
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0x18)
	struct FHitResult Hit;  // 0x30(0xE8)

}; 
// Function POLYGON.PG_PlayerController_Game.DisplayMessageToChatEvent
// Size: 0x20(Inherited: 0x0) 
struct FDisplayMessageToChatEvent
{
	struct FGameChatMessage Message;  // 0x0(0x20)

}; 
// Function POLYGON.PG_Character.ActionWhenTakeDamage_client
// Size: 0x8(Inherited: 0x0) 
struct FActionWhenTakeDamage_client
{
	struct AActor* DamageCauser;  // 0x0(0x8)

}; 
// Function POLYGON.PG_Character.SetNeutralizationVignetteImpact
// Size: 0x4(Inherited: 0x0) 
struct FSetNeutralizationVignetteImpact
{
	float newNeutralizationVignetteImpact;  // 0x0(0x4)

}; 
// Function POLYGON.PG_Character.ActionWhenWeaponHit_client
// Size: 0x10(Inherited: 0x0) 
struct FActionWhenWeaponHit_client
{
	struct APG_Character* characterInstigator;  // 0x0(0x8)
	char hitBoneIndex;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function POLYGON.PG_PlayerController_Game.StartInteractionEvent
// Size: 0x4(Inherited: 0x0) 
struct FStartInteractionEvent
{
	float interactionTime;  // 0x0(0x4)

}; 
// Function POLYGON.PG_Character.DeathEvent
// Size: 0x10(Inherited: 0x0) 
struct FDeathEvent
{
	struct APG_PlayerState_Game* killer;  // 0x0(0x8)
	uint8_t  deathType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function POLYGON.PG_Character.EventTakeDamage
// Size: 0x18(Inherited: 0x0) 
struct FEventTakeDamage
{
	struct FVector Origin;  // 0x0(0x18)

}; 
// Function POLYGON.PG_Character.GetActiveCamera
// Size: 0x8(Inherited: 0x0) 
struct FGetActiveCamera
{
	struct UCameraComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.PG_Character.GetIsSprinting
// Size: 0x1(Inherited: 0x0) 
struct FGetIsSprinting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.GetNeutralizationVignetteImpact
// Size: 0x4(Inherited: 0x0) 
struct FGetNeutralizationVignetteImpact
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.WeaponComponent.GetCurrentWeapon
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentWeapon
{
	struct AItem_Weapon_General* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.PG_Character.GetPlayerAction
// Size: 0x1(Inherited: 0x0) 
struct FGetPlayerAction
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.GetTeam
// Size: 0x1(Inherited: 0x0) 
struct FGetTeam
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.LeanBody_server
// Size: 0x1(Inherited: 0x0) 
struct FLeanBody_server
{
	int8_t LeanBodyAlpha;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.NotifyDeath_multicast
// Size: 0x10(Inherited: 0x0) 
struct FNotifyDeath_multicast
{
	struct APG_PlayerState_Game* killer;  // 0x0(0x8)
	uint8_t  deathType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function POLYGON.PG_Character.NotifyDeathWithImpulse_multicast
// Size: 0x30(Inherited: 0x0) 
struct FNotifyDeathWithImpulse_multicast
{
	struct APG_PlayerState_Game* killer;  // 0x0(0x8)
	uint8_t  deathType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FVector_NetQuantize Impulse;  // 0x10(0x18)
	char BoneIndex;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function POLYGON.PG_Character.OnRep_PlayerAction
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_PlayerAction
{
	uint8_t  previousAction;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.OnRep_RespawnCounter
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_RespawnCounter
{
	char PreviousValue;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.Respawn_client
// Size: 0x30(Inherited: 0x0) 
struct FRespawn_client
{
	struct FVector_NetQuantize NewLocation;  // 0x0(0x18)
	struct FVector_NetQuantizeNormal newRotator;  // 0x18(0x18)

}; 
// Function POLYGON.PG_Character.SetIsSprinting_server
// Size: 0x1(Inherited: 0x0) 
struct FSetIsSprinting_server
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewState : 1;  // 0x0(0x1)

}; 
// Function POLYGON.PG_Character.StartInteractWithObject_server
// Size: 0x8(Inherited: 0x0) 
struct FStartInteractWithObject_server
{
	struct AActor* interactActor;  // 0x0(0x8)

}; 
// Function POLYGON.PG_FunctionLibraryKit.GetBuildNumber
// Size: 0x4(Inherited: 0x0) 
struct FGetBuildNumber
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.PG_FunctionLibraryKit.GetProjectVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetProjectVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function POLYGON.PG_FunctionLibraryKit.GetRegionEnum
// Size: 0x18(Inherited: 0x0) 
struct FGetRegionEnum
{
	struct FString regionName;  // 0x0(0x10)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function POLYGON.PG_FunctionLibraryKit.ParseOption
// Size: 0x40(Inherited: 0x0) 
struct FParseOption
{
	struct FString Options;  // 0x0(0x10)
	struct FString Key;  // 0x10(0x10)
	struct FString Separator;  // 0x20(0x10)
	struct FString ReturnValue;  // 0x30(0x10)

}; 
// Function POLYGON.PG_GameInstance.GetClientGameInstance
// Size: 0x8(Inherited: 0x0) 
struct FGetClientGameInstance
{
	struct UClientGameInstance* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.PG_GameInstance.GetServerGameInstance
// Size: 0x8(Inherited: 0x0) 
struct FGetServerGameInstance
{
	struct UServerGameInstance* ReturnValue;  // 0x0(0x8)

}; 
// Function POLYGON.PG_GameMode_Game.LoginPlayer
// Size: 0x18(Inherited: 0x0) 
struct FLoginPlayer
{
	struct APG_PlayerController_Game* PlayerController;  // 0x0(0x8)
	struct FString PlayerMasterId;  // 0x8(0x10)

}; 
// Function POLYGON.PG_GameState_Game.GetMaxScoreForWin
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxScoreForWin
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.PG_GameState_Game.GetScoreAlphaTeam
// Size: 0x4(Inherited: 0x0) 
struct FGetScoreAlphaTeam
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.PG_GameState_Game.GetScoreBravoTeam
// Size: 0x4(Inherited: 0x0) 
struct FGetScoreBravoTeam
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.PG_GameState_Game.NotifyPlayerWasKicked
// Size: 0x18(Inherited: 0x0) 
struct FNotifyPlayerWasKicked
{
	struct FString badGuyName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNameWasOptimized : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function POLYGON.PG_GameState_Game.SetCanMovePlayers
// Size: 0x1(Inherited: 0x0) 
struct FSetCanMovePlayers
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool newMoveState : 1;  // 0x0(0x1)

}; 
// Function POLYGON.PG_BeaconClient.ConnectToServer
// Size: 0x28(Inherited: 0x0) 
struct FConnectToServer
{
	struct FString IP;  // 0x0(0x10)
	int32_t BeaconPort;  // 0x10(0x4)
	struct FDelegate onConnectedStateChange;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function POLYGON.PG_BeaconClient.RequestReserveSlot
// Size: 0x38(Inherited: 0x0) 
struct FRequestReserveSlot
{
	struct TArray<struct FUniqueNetIdRepl> unequeIds;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool isUsedMatchmaker : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate onResponseReserveSlot;  // 0x14(0x10)
	struct FDelegate onPutInQueue;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function POLYGON.PG_BeaconClient.RequestReserveSlot_server
// Size: 0x18(Inherited: 0x0) 
struct FRequestReserveSlot_server
{
	struct TArray<struct FUniqueNetIdRepl> unequeIds;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool isUsedMatchmaker : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function POLYGON.PG_BeaconClient.ResponseReserveSlot_client
// Size: 0x1(Inherited: 0x0) 
struct FResponseReserveSlot_client
{
	char Payload;  // 0x0(0x1)

}; 
// Function POLYGON.PG_BeaconClient.SendNumberInQueue_client
// Size: 0x1(Inherited: 0x0) 
struct FSendNumberInQueue_client
{
	char Number;  // 0x0(0x1)

}; 
// Function POLYGON.WeaponComponent.IsAiming
// Size: 0x1(Inherited: 0x0) 
struct FIsAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.PG_PlayerController_Base.ShowError
// Size: 0x30(Inherited: 0x0) 
struct FShowError
{
	struct FText ErrorMessage;  // 0x0(0x18)
	struct FText ErrorDetails;  // 0x18(0x18)

}; 
// Function POLYGON.PG_PlayerController_Game.RequestSpawnOnControlPoint_server
// Size: 0x1(Inherited: 0x0) 
struct FRequestSpawnOnControlPoint_server
{
	uint8_t  spawnToControlPoint;  // 0x0(0x1)

}; 
// Function POLYGON.PG_PlayerController_Game.VoteKick
// Size: 0x8(Inherited: 0x0) 
struct FVoteKick
{
	struct APG_PlayerState_Game* badGuy;  // 0x0(0x8)

}; 
// Function POLYGON.PG_PlayerState_Base.GetUniqueNetId
// Size: 0x30(Inherited: 0x0) 
struct FGetUniqueNetId
{
	struct FUniqueNetIdRepl ReturnValue;  // 0x0(0x30)

}; 
// Function POLYGON.PG_PlayerState_Game.CustomIsInactive
// Size: 0x1(Inherited: 0x0) 
struct FCustomIsInactive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.PG_PlayerState_Game.SetTeam
// Size: 0x1(Inherited: 0x0) 
struct FSetTeam
{
	uint8_t  newTeam;  // 0x0(0x1)

}; 
// Function POLYGON.PlayerCoreComponent.AddCurrency
// Size: 0x4(Inherited: 0x0) 
struct FAddCurrency
{
	int32_t AddCurrency;  // 0x0(0x4)

}; 
// Function POLYGON.PlayerCoreComponent.GetCurrentLevelInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetCurrentLevelInfo
{
	struct FLevelInfo ReturnValue;  // 0x0(0x20)

}; 
// Function POLYGON.PlayerCoreComponent.GetLevelByProgress
// Size: 0x28(Inherited: 0x0) 
struct FGetLevelByProgress
{
	int32_t Progress;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FLevelInfo ReturnValue;  // 0x8(0x20)

}; 
// Function POLYGON.PlayerCoreComponent.GetNextLevelByLevelID
// Size: 0x28(Inherited: 0x0) 
struct FGetNextLevelByLevelID
{
	struct FName LevelID;  // 0x0(0x8)
	struct FLevelInfo ReturnValue;  // 0x8(0x20)

}; 
// Function POLYGON.PlayerCoreComponent.NotifyAddedGameScore_client
// Size: 0x10(Inherited: 0x0) 
struct FNotifyAddedGameScore_client
{
	struct TArray<struct FScoreInfo> ScoreInfos;  // 0x0(0x10)

}; 
// Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Backward
// Size: 0x4(Inherited: 0x0) 
struct FGetWeaponRecoilAlpha_Backward
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Pitch
// Size: 0x4(Inherited: 0x0) 
struct FGetWeaponRecoilAlpha_Pitch
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Roll
// Size: 0x4(Inherited: 0x0) 
struct FGetWeaponRecoilAlpha_Roll
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Yaw
// Size: 0x4(Inherited: 0x0) 
struct FGetWeaponRecoilAlpha_Yaw
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function POLYGON.WeaponComponent.IsWantsToAiming
// Size: 0x1(Inherited: 0x0) 
struct FIsWantsToAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function POLYGON.WeaponComponent.SetStrivingWeaponRecoilAlpha_Pitch
// Size: 0x4(Inherited: 0x0) 
struct FSetStrivingWeaponRecoilAlpha_Pitch
{
	float newStrivingPitchRecoil;  // 0x0(0x4)

}; 
// Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Yaw
// Size: 0x4(Inherited: 0x0) 
struct FSetWeaponRecoilAlpha_Yaw
{
	float newYawRecoil;  // 0x0(0x4)

}; 
