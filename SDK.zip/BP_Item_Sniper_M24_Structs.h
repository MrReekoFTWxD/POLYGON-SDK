#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.UserConstructionScript
// Size: 0x1(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x0(0x1)

}; 
