#pragma once 
#include <MediaIOCore_Structs.h>
 
 
 
// Class MediaIOCore.MediaOutput
// Size: 0x30(Inherited: 0x28) 
struct UMediaOutput : public UObject
{
	int32_t NumberOfTextureBuffers;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

	bool Validate(struct FString& OutFailureReason); // Function MediaIOCore.MediaOutput.Validate
	struct UMediaCapture* CreateMediaCapture(); // Function MediaIOCore.MediaOutput.CreateMediaCapture
}; 



// Class MediaIOCore.MediaCapture
// Size: 0x108(Inherited: 0x28) 
struct UMediaCapture : public UObject
{
	struct FMulticastInlineDelegate OnStateChanged;  // 0x28(0x10)
	char pad_56[24];  // 0x38(0x18)
	struct UMediaOutput* MediaOutput;  // 0x50(0x8)
	char pad_88[32];  // 0x58(0x20)
	struct UTextureRenderTarget2D* CapturingRenderTarget;  // 0x78(0x8)
	char pad_128[136];  // 0x80(0x88)

	bool UpdateTextureRenderTarget2D(struct UTextureRenderTarget2D* RenderTarget); // Function MediaIOCore.MediaCapture.UpdateTextureRenderTarget2D
	void StopCapture(bool bAllowPendingFrameToBeProcess); // Function MediaIOCore.MediaCapture.StopCapture
	void SetMediaOutput(struct UMediaOutput* InMediaOutput); // Function MediaIOCore.MediaCapture.SetMediaOutput
	uint8_t  GetState(); // Function MediaIOCore.MediaCapture.GetState
	struct FIntPoint GetDesiredSize(); // Function MediaIOCore.MediaCapture.GetDesiredSize
	char EPixelFormat GetDesiredPixelFormat(); // Function MediaIOCore.MediaCapture.GetDesiredPixelFormat
	bool CaptureTextureRenderTarget2D(struct UTextureRenderTarget2D* RenderTarget, struct FMediaCaptureOptions CaptureOptions); // Function MediaIOCore.MediaCapture.CaptureTextureRenderTarget2D
	bool CaptureActiveSceneViewport(struct FMediaCaptureOptions CaptureOptions); // Function MediaIOCore.MediaCapture.CaptureActiveSceneViewport
}; 



// Class MediaIOCore.FileMediaCapture
// Size: 0x170(Inherited: 0x108) 
struct UFileMediaCapture : public UMediaCapture
{
	char pad_264[104];  // 0x108(0x68)

}; 



// Class MediaIOCore.FileMediaOutput
// Size: 0xD0(Inherited: 0x30) 
struct UFileMediaOutput : public UMediaOutput
{
	struct FImageWriteOptions WriteOptions;  // 0x30(0x60)
	struct FDirectoryPath FilePath;  // 0x90(0x10)
	struct FString BaseFileName;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bOverrideDesiredSize : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FIntPoint DesiredSize;  // 0xB4(0x8)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bOverridePixelFormat : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	uint8_t  DesiredPixelFormat;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bInvertAlpha : 1;  // 0xC4(0x1)
	char pad_197[11];  // 0xC5(0xB)

}; 



// Class MediaIOCore.MediaIOCoreSubsystem
// Size: 0x38(Inherited: 0x30) 
struct UMediaIOCoreSubsystem : public UEngineSubsystem
{
	char pad_48[8];  // 0x30(0x8)

}; 



