#pragma once 
#include <BP_Item_Optic_8x_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Optic_8x.BP_Item_Optic_8x_C
// Size: 0x328(Inherited: 0x310) 
struct ABP_Item_Optic_8x_C : public AItem_Module_Optic
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct TArray<struct UMaterialInterface*> SavedMaterials;  // 0x318(0x10)

	void ToggleAiming(bool IsAiming); // Function BP_Item_Optic_8x.BP_Item_Optic_8x_C.ToggleAiming
	void ExecuteUbergraph_BP_Item_Optic_8x(int32_t EntryPoint); // Function BP_Item_Optic_8x.BP_Item_Optic_8x_C.ExecuteUbergraph_BP_Item_Optic_8x
}; 



