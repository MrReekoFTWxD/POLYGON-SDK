#pragma once 
#include <DefaultAxisMapping_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultAxisMapping.DefaultAxisMapping_C
// Size: 0x2E0(Inherited: 0x2E0) 
struct UDefaultAxisMapping_C : public UAxisMapping
{

}; 



