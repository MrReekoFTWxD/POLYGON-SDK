#pragma once 
#include <CableComponent_Structs.h>
 
 
 
// Class CableComponent.CableActor
// Size: 0x280(Inherited: 0x278) 
struct ACableActor : public AActor
{
	struct UCableComponent* CableComponent;  // 0x278(0x8)

}; 



// Class CableComponent.CableComponent
// Size: 0x620(Inherited: 0x570) 
struct UCableComponent : public UMeshComponent
{
	char pad_1392_1 : 7;  // 0x570(0x1)
	bool bAttachStart : 1;  // 0x568(0x1)
	char pad_1393_1 : 7;  // 0x571(0x1)
	bool bAttachEnd : 1;  // 0x569(0x1)
	struct FComponentReference AttachEndTo;  // 0x570(0x28)
	struct FName AttachEndToSocketName;  // 0x598(0x8)
	struct FVector EndLocation;  // 0x5A0(0x18)
	float CableLength;  // 0x5B8(0x4)
	int32_t NumSegments;  // 0x5BC(0x4)
	float SubstepTime;  // 0x5C0(0x4)
	int32_t SolverIterations;  // 0x5C4(0x4)
	char pad_1482_1 : 7;  // 0x5CA(0x1)
	bool bEnableStiffness : 1;  // 0x5C8(0x1)
	char pad_1483_1 : 7;  // 0x5CB(0x1)
	bool bUseSubstepping : 1;  // 0x5C9(0x1)
	char pad_1484_1 : 7;  // 0x5CC(0x1)
	bool bSkipCableUpdateWhenNotVisible : 1;  // 0x5CA(0x1)
	char pad_1485_1 : 7;  // 0x5CD(0x1)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered : 1;  // 0x5CB(0x1)
	char pad_1486_1 : 7;  // 0x5CE(0x1)
	bool bEnableCollision : 1;  // 0x5CC(0x1)
	char pad_1487[1];  // 0x5CF(0x1)
	float CollisionFriction;  // 0x5D0(0x4)
	char pad_1492[4];  // 0x5D4(0x4)
	struct FVector CableForce;  // 0x5D8(0x18)
	float CableGravityScale;  // 0x5F0(0x4)
	float CableWidth;  // 0x5F4(0x4)
	int32_t NumSides;  // 0x5F8(0x4)
	float TileMaterial;  // 0x5FC(0x4)
	char pad_1536[32];  // 0x600(0x20)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor
}; 



