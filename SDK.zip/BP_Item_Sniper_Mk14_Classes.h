#pragma once 
#include <BP_Item_Sniper_Mk14_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C
// Size: 0x598(Inherited: 0x590) 
struct ABP_Item_Sniper_Mk14_C : public AItem_Weapon_Sniper
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x590(0x8)

	void SetSight(); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.ReceiveBeginPlay
	void OnSetWeaponModules_Event(); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.OnSetWeaponModules_Event
	void ExecuteUbergraph_BP_Item_Sniper_Mk14(int32_t EntryPoint); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.ExecuteUbergraph_BP_Item_Sniper_Mk14
}; 



