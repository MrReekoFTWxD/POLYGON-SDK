#pragma once 
#include <ControlRig_Structs.h>
 
 
 
// Class ControlRig.ControlRig
// Size: 0x490(Inherited: 0x28) 
struct UControlRig : public UObject
{
	char pad_40[30];  // 0x28(0x1E)
	uint8_t  ExecutionType;  // 0x46(0x1)
	char pad_71[9];  // 0x47(0x9)
	struct FRigVMRuntimeSettings VMRuntimeSettings;  // 0x50(0x50)
	struct TMap<struct FRigElementKey, struct FRigControlElementCustomization> ControlCustomizations;  // 0xA0(0x50)
	struct URigVM* VM;  // 0xF0(0x8)
	struct URigHierarchy* DynamicHierarchy;  // 0xF8(0x8)
	struct TSoftObjectPtr<UControlRigShapeLibrary> GizmoLibrary;  // 0x100(0x28)
	struct TArray<struct TSoftObjectPtr<UControlRigShapeLibrary>> ShapeLibraries;  // 0x128(0x10)
	char pad_312[16];  // 0x138(0x10)
	struct TMap<struct FName, struct FCachedPropertyPath> InputProperties;  // 0x148(0x50)
	struct TMap<struct FName, struct FCachedPropertyPath> OutputProperties;  // 0x198(0x50)
	char pad_488[160];  // 0x1E8(0xA0)
	struct FControlRigDrawContainer DrawContainer;  // 0x288(0x18)
	char pad_672[24];  // 0x2A0(0x18)
	struct UAnimationDataSourceRegistry* DataSourceRegistry;  // 0x2B8(0x8)
	struct TArray<struct FName> EventQueue;  // 0x2C0(0x10)
	char pad_720[168];  // 0x2D0(0xA8)
	struct FRigInfluenceMapPerEvent Influences;  // 0x378(0x60)
	struct UControlRig* InteractionRig;  // 0x3D8(0x8)
	UControlRig* InteractionRigClass;  // 0x3E0(0x8)
	struct TArray<struct UAssetUserData*> AssetUserData;  // 0x3E8(0x10)
	char pad_1016[152];  // 0x3F8(0x98)

	bool SupportsEvent(struct FName& InEventName); // Function ControlRig.ControlRig.SupportsEvent
	bool SetVariableFromString(struct FName& InVariableName, struct FString InValue); // Function ControlRig.ControlRig.SetVariableFromString
	void SetInteractionRigClass(UControlRig* InInteractionRigClass); // Function ControlRig.ControlRig.SetInteractionRigClass
	void SetInteractionRig(struct UControlRig* InInteractionRig); // Function ControlRig.ControlRig.SetInteractionRig
	void SetFramesPerSecond(float InFramesPerSecond); // Function ControlRig.ControlRig.SetFramesPerSecond
	void SetDeltaTime(float InDeltaTime); // Function ControlRig.ControlRig.SetDeltaTime
	void SetAbsoluteTime(float InAbsoluteTime, bool InSetDeltaTimeZero); // Function ControlRig.ControlRig.SetAbsoluteTime
	void SetAbsoluteAndDeltaTime(float InAbsoluteTime, float InDeltaTime); // Function ControlRig.ControlRig.SetAbsoluteAndDeltaTime
	void SelectControl(struct FName& InControlName, bool bSelect); // Function ControlRig.ControlRig.SelectControl
	void RequestSetup(); // Function ControlRig.ControlRig.RequestSetup
	void RequestInit(); // Function ControlRig.ControlRig.RequestInit
	bool IsControlSelected(struct FName& InControlName); // Function ControlRig.ControlRig.IsControlSelected
	struct URigVM* GetVM(); // Function ControlRig.ControlRig.GetVM
	struct FName GetVariableType(struct FName& InVariableName); // Function ControlRig.ControlRig.GetVariableType
	struct FString GetVariableAsString(struct FName& InVariableName); // Function ControlRig.ControlRig.GetVariableAsString
	struct TArray<struct FName> GetSupportedEvents(); // Function ControlRig.ControlRig.GetSupportedEvents
	struct TArray<struct FName> GetScriptAccessibleVariables(); // Function ControlRig.ControlRig.GetScriptAccessibleVariables
	UControlRig* GetInteractionRigClass(); // Function ControlRig.ControlRig.GetInteractionRigClass
	struct UControlRig* GetInteractionRig(); // Function ControlRig.ControlRig.GetInteractionRig
	struct URigHierarchy* GetHierarchy(); // Function ControlRig.ControlRig.GetHierarchy
	float GetCurrentFramesPerSecond(); // Function ControlRig.ControlRig.GetCurrentFramesPerSecond
	float GetAbsoluteTime(); // Function ControlRig.ControlRig.GetAbsoluteTime
	struct TArray<struct UControlRig*> FindControlRigs(struct UObject* Outer, UControlRig* OptionalClass); // Function ControlRig.ControlRig.FindControlRigs
	void Execute(uint8_t  State, struct FName& InEventName); // Function ControlRig.ControlRig.Execute
	struct TArray<struct FName> CurrentControlSelection(); // Function ControlRig.ControlRig.CurrentControlSelection
	bool ClearControlSelection(); // Function ControlRig.ControlRig.ClearControlSelection
	bool CanExecute(); // Function ControlRig.ControlRig.CanExecute
}; 



// Class ControlRig.ControlRigEditorSettings
// Size: 0x38(Inherited: 0x38) 
struct UControlRigEditorSettings : public UDeveloperSettings
{

}; 



// Class ControlRig.AdditiveControlRig
// Size: 0x4A0(Inherited: 0x490) 
struct UAdditiveControlRig : public UControlRig
{
	char pad_1168[16];  // 0x490(0x10)

}; 



// Class ControlRig.ControlRigAnimInstance
// Size: 0x350(Inherited: 0x350) 
struct UControlRigAnimInstance : public UAnimInstance
{

}; 



// Class ControlRig.ControlRigBlueprintGeneratedClass
// Size: 0x328(Inherited: 0x328) 
struct UControlRigBlueprintGeneratedClass : public UBlueprintGeneratedClass
{

}; 



// Class ControlRig.ControlRigShapeLibrary
// Size: 0x120(Inherited: 0x28) 
struct UControlRigShapeLibrary : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct FControlRigShapeDefinition DefaultShape;  // 0x30(0xA0)
	struct TSoftObjectPtr<UMaterial> DefaultMaterial;  // 0xD0(0x28)
	struct FName MaterialColorParameter;  // 0xF8(0x8)
	struct TArray<struct FControlRigShapeDefinition> Shapes;  // 0x100(0x10)
	char pad_272[16];  // 0x110(0x10)

}; 



// Class ControlRig.ControlRigValidator
// Size: 0x68(Inherited: 0x28) 
struct UControlRigValidator : public UObject
{
	struct TArray<struct UControlRigValidationPass*> Passes;  // 0x28(0x10)
	char pad_56[48];  // 0x38(0x30)

}; 



// Class ControlRig.ControlRigComponent
// Size: 0x680(Inherited: 0x540) 
struct UControlRigComponent : public UPrimitiveComponent
{
	UControlRig* ControlRigClass;  // 0x540(0x8)
	struct FMulticastInlineDelegate OnPreInitializeDelegate;  // 0x548(0x10)
	struct FMulticastInlineDelegate OnPostInitializeDelegate;  // 0x558(0x10)
	struct FMulticastInlineDelegate OnPreSetupDelegate;  // 0x568(0x10)
	struct FMulticastInlineDelegate OnPostSetupDelegate;  // 0x578(0x10)
	struct FMulticastInlineDelegate OnPreForwardsSolveDelegate;  // 0x588(0x10)
	struct FMulticastInlineDelegate OnPostForwardsSolveDelegate;  // 0x598(0x10)
	struct TArray<struct FControlRigComponentMappedElement> MappedElements;  // 0x5A8(0x10)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	bool bEnableLazyEvaluation : 1;  // 0x5B8(0x1)
	char pad_1465[3];  // 0x5B9(0x3)
	float LazyEvaluationPositionThreshold;  // 0x5BC(0x4)
	float LazyEvaluationRotationThreshold;  // 0x5C0(0x4)
	float LazyEvaluationScaleThreshold;  // 0x5C4(0x4)
	char pad_1480_1 : 7;  // 0x5C8(0x1)
	bool bResetTransformBeforeTick : 1;  // 0x5C8(0x1)
	char pad_1481_1 : 7;  // 0x5C9(0x1)
	bool bResetInitialsBeforeSetup : 1;  // 0x5C9(0x1)
	char pad_1482_1 : 7;  // 0x5CA(0x1)
	bool bUpdateRigOnTick : 1;  // 0x5CA(0x1)
	char pad_1483_1 : 7;  // 0x5CB(0x1)
	bool bUpdateInEditor : 1;  // 0x5CB(0x1)
	char pad_1484_1 : 7;  // 0x5CC(0x1)
	bool bDrawBones : 1;  // 0x5CC(0x1)
	char pad_1485_1 : 7;  // 0x5CD(0x1)
	bool bShowDebugDrawing : 1;  // 0x5CD(0x1)
	char pad_1486[2];  // 0x5CE(0x2)
	struct UControlRig* ControlRig;  // 0x5D0(0x8)
	char pad_1496[168];  // 0x5D8(0xA8)

	void Update(float DeltaTime); // Function ControlRig.ControlRigComponent.Update
	void SetMappedElements(struct TArray<struct FControlRigComponentMappedElement> NewMappedElements); // Function ControlRig.ControlRigComponent.SetMappedElements
	void SetInitialSpaceTransform(struct FName SpaceName, struct FTransform InitialTransform, uint8_t  Space); // Function ControlRig.ControlRigComponent.SetInitialSpaceTransform
	void SetInitialBoneTransform(struct FName BoneName, struct FTransform InitialTransform, uint8_t  Space, bool bPropagateToChildren); // Function ControlRig.ControlRigComponent.SetInitialBoneTransform
	void SetControlVector2D(struct FName ControlName, struct FVector2D Value); // Function ControlRig.ControlRigComponent.SetControlVector2D
	void SetControlTransform(struct FName ControlName, struct FTransform Value, uint8_t  Space); // Function ControlRig.ControlRigComponent.SetControlTransform
	void SetControlScale(struct FName ControlName, struct FVector Value, uint8_t  Space); // Function ControlRig.ControlRigComponent.SetControlScale
	void SetControlRotator(struct FName ControlName, struct FRotator Value, uint8_t  Space); // Function ControlRig.ControlRigComponent.SetControlRotator
	void SetControlPosition(struct FName ControlName, struct FVector Value, uint8_t  Space); // Function ControlRig.ControlRigComponent.SetControlPosition
	void SetControlOffset(struct FName ControlName, struct FTransform OffsetTransform, uint8_t  Space); // Function ControlRig.ControlRigComponent.SetControlOffset
	void SetControlInt(struct FName ControlName, int32_t Value); // Function ControlRig.ControlRigComponent.SetControlInt
	void SetControlFloat(struct FName ControlName, float Value); // Function ControlRig.ControlRigComponent.SetControlFloat
	void SetControlBool(struct FName ControlName, bool Value); // Function ControlRig.ControlRigComponent.SetControlBool
	void SetBoneTransform(struct FName BoneName, struct FTransform Transform, uint8_t  Space, float Weight, bool bPropagateToChildren); // Function ControlRig.ControlRigComponent.SetBoneTransform
	void SetBoneInitialTransformsFromSkeletalMesh(struct USkeletalMesh* InSkeletalMesh); // Function ControlRig.ControlRigComponent.SetBoneInitialTransformsFromSkeletalMesh
	void OnPreSetup(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPreSetup
	void OnPreInitialize(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPreInitialize
	void OnPreForwardsSolve(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPreForwardsSolve
	void OnPostSetup(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPostSetup
	void OnPostInitialize(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPostInitialize
	void OnPostForwardsSolve(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPostForwardsSolve
	void Initialize(); // Function ControlRig.ControlRigComponent.Initialize
	struct FTransform GetSpaceTransform(struct FName SpaceName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetSpaceTransform
	struct FTransform GetInitialSpaceTransform(struct FName SpaceName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetInitialSpaceTransform
	struct FTransform GetInitialBoneTransform(struct FName BoneName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetInitialBoneTransform
	struct TArray<struct FName> GetElementNames(uint8_t  ElementType); // Function ControlRig.ControlRigComponent.GetElementNames
	struct FVector2D GetControlVector2D(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlVector2D
	struct FTransform GetControlTransform(struct FName ControlName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetControlTransform
	struct FVector GetControlScale(struct FName ControlName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetControlScale
	struct FRotator GetControlRotator(struct FName ControlName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetControlRotator
	struct UControlRig* GetControlRig(); // Function ControlRig.ControlRigComponent.GetControlRig
	struct FVector GetControlPosition(struct FName ControlName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetControlPosition
	struct FTransform GetControlOffset(struct FName ControlName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetControlOffset
	int32_t GetControlInt(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlInt
	float GetControlFloat(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlFloat
	bool GetControlBool(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlBool
	struct FTransform GetBoneTransform(struct FName BoneName, uint8_t  Space); // Function ControlRig.ControlRigComponent.GetBoneTransform
	float GetAbsoluteTime(); // Function ControlRig.ControlRigComponent.GetAbsoluteTime
	bool DoesElementExist(struct FName Name, uint8_t  ElementType); // Function ControlRig.ControlRigComponent.DoesElementExist
	void ClearMappedElements(); // Function ControlRig.ControlRigComponent.ClearMappedElements
	bool CanExecute(); // Function ControlRig.ControlRigComponent.CanExecute
	void AddMappedSkeletalMesh(struct USkeletalMeshComponent* SkeletalMeshComponent, struct TArray<struct FControlRigComponentMappedBone> Bones, struct TArray<struct FControlRigComponentMappedCurve> Curves); // Function ControlRig.ControlRigComponent.AddMappedSkeletalMesh
	void AddMappedElements(struct TArray<struct FControlRigComponentMappedElement> NewMappedElements); // Function ControlRig.ControlRigComponent.AddMappedElements
	void AddMappedComponents(struct TArray<struct FControlRigComponentMappedComponent> Components); // Function ControlRig.ControlRigComponent.AddMappedComponents
	void AddMappedCompleteSkeletalMesh(struct USkeletalMeshComponent* SkeletalMeshComponent); // Function ControlRig.ControlRigComponent.AddMappedCompleteSkeletalMesh
}; 



// Class ControlRig.ControlRigShapeActor
// Size: 0x2A0(Inherited: 0x278) 
struct AControlRigShapeActor : public AActor
{
	struct USceneComponent* ActorRootComponent;  // 0x278(0x8)
	struct UStaticMeshComponent* StaticMeshComponent;  // 0x280(0x8)
	uint32_t ControlRigIndex;  // 0x288(0x4)
	struct FName ControlName;  // 0x28C(0x8)
	struct FName ColorParameterName;  // 0x294(0x8)
	char bEnabled : 1;  // 0x29C(0x1)
	char bSelected : 1;  // 0x29C(0x1)
	char bSelectable : 1;  // 0x29C(0x1)
	char bHovered : 1;  // 0x29C(0x1)
	char pad_668_1 : 4;  // 0x29C(0x1)
	char pad_669[4];  // 0x29D(0x4)

	void SetSelected(bool bInSelected); // Function ControlRig.ControlRigShapeActor.SetSelected
	void SetSelectable(bool bInSelectable); // Function ControlRig.ControlRigShapeActor.SetSelectable
	void SetHovered(bool bInHovered); // Function ControlRig.ControlRigShapeActor.SetHovered
	void SetGlobalTransform(struct FTransform& InTransform); // Function ControlRig.ControlRigShapeActor.SetGlobalTransform
	void SetEnabled(bool bInEnabled); // Function ControlRig.ControlRigShapeActor.SetEnabled
	void OnTransformChanged(struct FTransform& NewTransform); // Function ControlRig.ControlRigShapeActor.OnTransformChanged
	void OnSelectionChanged(bool bIsSelected); // Function ControlRig.ControlRigShapeActor.OnSelectionChanged
	void OnManipulatingChanged(bool bIsManipulating); // Function ControlRig.ControlRigShapeActor.OnManipulatingChanged
	void OnHoveredChanged(bool bIsSelected); // Function ControlRig.ControlRigShapeActor.OnHoveredChanged
	void OnEnabledChanged(bool BIsEnabled); // Function ControlRig.ControlRigShapeActor.OnEnabledChanged
	bool IsSelectedInEditor(); // Function ControlRig.ControlRigShapeActor.IsSelectedInEditor
	bool IsHovered(); // Function ControlRig.ControlRigShapeActor.IsHovered
	bool IsEnabled(); // Function ControlRig.ControlRigShapeActor.IsEnabled
	struct FTransform GetGlobalTransform(); // Function ControlRig.ControlRigShapeActor.GetGlobalTransform
}; 



// Class ControlRig.ControlRigControlActor
// Size: 0x310(Inherited: 0x278) 
struct AControlRigControlActor : public AActor
{
	struct AActor* ActorToTrack;  // 0x278(0x8)
	UControlRig* ControlRigClass;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool bRefreshOnTick : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool bIsSelectable : 1;  // 0x289(0x1)
	char pad_650[6];  // 0x28A(0x6)
	struct UMaterialInterface* MaterialOverride;  // 0x290(0x8)
	struct FString ColorParameter;  // 0x298(0x10)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool bCastShadows : 1;  // 0x2A8(0x1)
	char pad_681[7];  // 0x2A9(0x7)
	struct USceneComponent* ActorRootComponent;  // 0x2B0(0x8)
	struct UControlRig* ControlRig;  // 0x2B8(0x8)
	struct TArray<struct FName> ControlNames;  // 0x2C0(0x10)
	struct TArray<struct FTransform> ShapeTransforms;  // 0x2D0(0x10)
	struct TArray<struct UStaticMeshComponent*> Components;  // 0x2E0(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> Materials;  // 0x2F0(0x10)
	struct FName ColorParameterName;  // 0x300(0x8)
	char pad_776[8];  // 0x308(0x8)

	void Refresh(); // Function ControlRig.ControlRigControlActor.Refresh
	void Clear(); // Function ControlRig.ControlRigControlActor.Clear
}; 



// Class ControlRig.ControlRigPoseMirrorSettings
// Size: 0x50(Inherited: 0x28) 
struct UControlRigPoseMirrorSettings : public UObject
{
	struct FString RightSide;  // 0x28(0x10)
	struct FString LeftSide;  // 0x38(0x10)
	char EAxis MirrorAxis;  // 0x48(0x1)
	char EAxis AxisToFlip;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)

}; 



// Class ControlRig.ControlRigLayerInstance
// Size: 0x350(Inherited: 0x350) 
struct UControlRigLayerInstance : public UAnimInstance
{

}; 



// Class ControlRig.ControlRigValidationPass
// Size: 0x28(Inherited: 0x28) 
struct UControlRigValidationPass : public UObject
{

}; 



// Class ControlRig.ControlRigNumericalValidationPass
// Size: 0xC0(Inherited: 0x28) 
struct UControlRigNumericalValidationPass : public UControlRigValidationPass
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bCheckControls : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bCheckBones : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bCheckCurves : 1;  // 0x2A(0x1)
	char pad_43[1];  // 0x2B(0x1)
	float TranslationPrecision;  // 0x2C(0x4)
	float RotationPrecision;  // 0x30(0x4)
	float ScalePrecision;  // 0x34(0x4)
	float CurvePrecision;  // 0x38(0x4)
	struct FName EventNameA;  // 0x3C(0x8)
	struct FName EventNameB;  // 0x44(0x8)
	char pad_76[4];  // 0x4C(0x4)
	struct FRigPose Pose;  // 0x50(0x70)

}; 



// Class ControlRig.ControlRigObjectHolder
// Size: 0x38(Inherited: 0x28) 
struct UControlRigObjectHolder : public UObject
{
	struct TArray<struct UObject*> Objects;  // 0x28(0x10)

}; 



// Class ControlRig.ControlRigPoseAsset
// Size: 0x88(Inherited: 0x28) 
struct UControlRigPoseAsset : public UObject
{
	struct FControlRigControlPose Pose;  // 0x28(0x60)

	void SelectControls(struct UControlRig* InControlRig, bool bDoMirror); // Function ControlRig.ControlRigPoseAsset.SelectControls
	void SavePose(struct UControlRig* InControlRig, bool bUseAll); // Function ControlRig.ControlRigPoseAsset.SavePose
	void ReplaceControlName(struct FName& CurrentName, struct FName& NewName); // Function ControlRig.ControlRigPoseAsset.ReplaceControlName
	void PastePose(struct UControlRig* InControlRig, bool bDoKey, bool bDoMirror); // Function ControlRig.ControlRigPoseAsset.PastePose
	void GetCurrentPose(struct UControlRig* InControlRig, struct FControlRigControlPose& OutPose); // Function ControlRig.ControlRigPoseAsset.GetCurrentPose
	struct TArray<struct FName> GetControlNames(); // Function ControlRig.ControlRigPoseAsset.GetControlNames
	bool DoesMirrorMatch(struct UControlRig* ControlRig, struct FName& ControlName); // Function ControlRig.ControlRigPoseAsset.DoesMirrorMatch
}; 



// Class ControlRig.ControlRigPoseProjectSettings
// Size: 0x38(Inherited: 0x28) 
struct UControlRigPoseProjectSettings : public UObject
{
	struct TArray<struct FDirectoryPath> RootSaveDirs;  // 0x28(0x10)

}; 



// Class ControlRig.ControlRigSettings
// Size: 0x38(Inherited: 0x38) 
struct UControlRigSettings : public UDeveloperSettings
{

}; 



// Class ControlRig.ControlRigSequence
// Size: 0x220(Inherited: 0x1C8) 
struct UControlRigSequence : public ULevelSequence
{
	struct TSoftObjectPtr<UAnimSequence> LastExportedToAnimationSequence;  // 0x1C8(0x28)
	struct TSoftObjectPtr<USkeletalMesh> LastExportedUsingSkeletalMesh;  // 0x1F0(0x28)
	float LastExportedFrameRate;  // 0x218(0x4)
	char pad_540[4];  // 0x21C(0x4)

}; 



// Class ControlRig.ControlRigSnapSettings
// Size: 0x30(Inherited: 0x28) 
struct UControlRigSnapSettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bKeepOffset : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bSnapPosition : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bSnapRotation : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bSnapScale : 1;  // 0x2B(0x1)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class ControlRig.FKControlRig
// Size: 0x4A0(Inherited: 0x490) 
struct UFKControlRig : public UControlRig
{
	struct TArray<bool> IsControlActive;  // 0x488(0x10)
	uint8_t  ApplyMode;  // 0x498(0x1)

}; 



// Class ControlRig.MovieSceneControlRigParameterSection
// Size: 0x348(Inherited: 0x148) 
struct UMovieSceneControlRigParameterSection : public UMovieSceneParameterSection
{
	char pad_328[24];  // 0x148(0x18)
	struct UControlRig* ControlRig;  // 0x160(0x8)
	UControlRig* ControlRigClass;  // 0x168(0x8)
	struct TArray<bool> ControlsMask;  // 0x170(0x10)
	struct FMovieSceneTransformMask TransformMask;  // 0x180(0x4)
	char pad_388[4];  // 0x184(0x4)
	struct FMovieSceneFloatChannel Weight;  // 0x188(0xE8)
	struct TMap<struct FName, struct FChannelMapInfo> ControlChannelMap;  // 0x270(0x50)
	struct TArray<struct FEnumParameterNameAndCurve> EnumParameterNamesAndCurves;  // 0x2C0(0x10)
	struct TArray<struct FIntegerParameterNameAndCurve> IntegerParameterNamesAndCurves;  // 0x2D0(0x10)
	struct TArray<struct FSpaceControlNameAndChannel> SpaceChannels;  // 0x2E0(0x10)
	char pad_752[88];  // 0x2F0(0x58)

}; 



// Class ControlRig.MovieSceneControlRigParameterTrack
// Size: 0xE0(Inherited: 0x90) 
struct UMovieSceneControlRigParameterTrack : public UMovieSceneNameableTrack
{
	char pad_144[40];  // 0x90(0x28)
	struct UControlRig* ControlRig;  // 0xB8(0x8)
	struct UMovieSceneSection* SectionToKey;  // 0xC0(0x8)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0xC8(0x10)
	struct FName TrackName;  // 0xD8(0x8)

}; 



// Class ControlRig.RigHierarchy
// Size: 0x200(Inherited: 0x28) 
struct URigHierarchy : public UObject
{
	char pad_40[48];  // 0x28(0x30)
	uint16_t TopologyVersion;  // 0x58(0x2)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool bEnableDirtyPropagation : 1;  // 0x5A(0x1)
	char pad_91[117];  // 0x5B(0x75)
	int32_t TransformStackIndex;  // 0xD0(0x4)
	char pad_212[92];  // 0xD4(0x5C)
	struct URigHierarchyController* HierarchyController;  // 0x130(0x8)
	char pad_312[80];  // 0x138(0x50)
	struct TMap<struct FRigElementKey, struct FRigElementKey> PreviousNameMap;  // 0x188(0x50)
	char pad_472[32];  // 0x1D8(0x20)
	struct URigHierarchy* HierarchyForCacheValidation;  // 0x1F8(0x8)

	bool SwitchToWorldSpace(struct FRigElementKey InChild, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SwitchToWorldSpace
	bool SwitchToParent(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SwitchToParent
	bool SwitchToDefaultParent(struct FRigElementKey InChild, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SwitchToDefaultParent
	struct TArray<struct FRigElementKey> SortKeys(struct TArray<struct FRigElementKey>& InKeys); // Function ControlRig.RigHierarchy.SortKeys
	void SetPose_ForBlueprint(struct FRigPose InPose); // Function ControlRig.RigHierarchy.SetPose_ForBlueprint
	bool SetParentWeightArray(struct FRigElementKey InChild, struct TArray<struct FRigElementWeight> InWeights, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SetParentWeightArray
	bool SetParentWeight(struct FRigElementKey InChild, struct FRigElementKey InParent, struct FRigElementWeight InWeight, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SetParentWeight
	void SetLocalTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetLocalTransformByIndex
	void SetLocalTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetLocalTransform
	void SetGlobalTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetGlobalTransformByIndex
	void SetGlobalTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetGlobalTransform
	void SetCurveValueByIndex(int32_t InElementIndex, float InValue, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetCurveValueByIndex
	void SetCurveValue(struct FRigElementKey InKey, float InValue, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetCurveValue
	void SetControlVisibilityByIndex(int32_t InElementIndex, bool bVisibility); // Function ControlRig.RigHierarchy.SetControlVisibilityByIndex
	void SetControlVisibility(struct FRigElementKey InKey, bool bVisibility); // Function ControlRig.RigHierarchy.SetControlVisibility
	void SetControlValueByIndex(int32_t InElementIndex, struct FRigControlValue InValue, uint8_t  InValueType, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlValueByIndex
	void SetControlValue(struct FRigElementKey InKey, struct FRigControlValue InValue, uint8_t  InValueType, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlValue
	void SetControlShapeTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetControlShapeTransformByIndex
	void SetControlShapeTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetControlShapeTransform
	void SetControlSettingsByIndex(int32_t InElementIndex, struct FRigControlSettings InSettings, bool bSetupUndo, bool bForce, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlSettingsByIndex
	void SetControlSettings(struct FRigElementKey InKey, struct FRigControlSettings InSettings, bool bSetupUndo, bool bForce, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlSettings
	void SetControlOffsetTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlOffsetTransformByIndex
	void SetControlOffsetTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlOffsetTransform
	void SendAutoKeyEvent(struct FRigElementKey InElement, float InOffsetInSeconds, bool bAsynchronous); // Function ControlRig.RigHierarchy.SendAutoKeyEvent
	void ResetPoseToInitial(uint8_t  InTypeFilter); // Function ControlRig.RigHierarchy.ResetPoseToInitial
	void ResetCurveValues(); // Function ControlRig.RigHierarchy.ResetCurveValues
	void Reset(); // Function ControlRig.RigHierarchy.Reset
	int32_t Num(); // Function ControlRig.RigHierarchy.Num
	struct FRigControlValue MakeControlValueFromVector2D(struct FVector2D InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromVector2D
	struct FRigControlValue MakeControlValueFromVector(struct FVector InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromVector
	struct FRigControlValue MakeControlValueFromTransformNoScale(struct FTransformNoScale InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromTransformNoScale
	struct FRigControlValue MakeControlValueFromTransform(struct FTransform InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromTransform
	struct FRigControlValue MakeControlValueFromRotator(struct FRotator InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromRotator
	struct FRigControlValue MakeControlValueFromInt(int32_t InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromInt
	struct FRigControlValue MakeControlValueFromFloat(float InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromFloat
	struct FRigControlValue MakeControlValueFromEulerTransform(struct FEulerTransform InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromEulerTransform
	struct FRigControlValue MakeControlValueFromBool(bool InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromBool
	bool IsValidIndex(int32_t InElementIndex); // Function ControlRig.RigHierarchy.IsValidIndex
	bool IsSelectedByIndex(int32_t InIndex); // Function ControlRig.RigHierarchy.IsSelectedByIndex
	bool IsSelected(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.IsSelected
	bool IsParentedTo(struct FRigElementKey InChild, struct FRigElementKey InParent); // Function ControlRig.RigHierarchy.IsParentedTo
	struct FVector GetVectorFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetVectorFromControlValue
	struct FVector2D GetVector2DFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetVector2DFromControlValue
	struct FTransformNoScale GetTransformNoScaleFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetTransformNoScaleFromControlValue
	struct FTransform GetTransformFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetTransformFromControlValue
	struct TArray<struct FRigElementKey> GetSelectedKeys(uint8_t  InTypeFilter); // Function ControlRig.RigHierarchy.GetSelectedKeys
	struct FRotator GetRotatorFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetRotatorFromControlValue
	struct TArray<struct FRigElementKey> GetRigidBodyKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetRigidBodyKeys
	struct TArray<struct FRigElementKey> GetReferenceKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetReferenceKeys
	struct FRigElementKey GetPreviousParent(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.GetPreviousParent
	struct FName GetPreviousName(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.GetPreviousName
	struct FRigPose GetPose(bool bInitial); // Function ControlRig.RigHierarchy.GetPose
	struct TArray<struct FRigElementWeight> GetParentWeightArray(struct FRigElementKey InChild, bool bInitial); // Function ControlRig.RigHierarchy.GetParentWeightArray
	struct FRigElementWeight GetParentWeight(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bInitial); // Function ControlRig.RigHierarchy.GetParentWeight
	struct FTransform GetParentTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetParentTransformByIndex
	struct FTransform GetParentTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetParentTransform
	struct TArray<struct FRigElementKey> GetParents(struct FRigElementKey InKey, bool bRecursive); // Function ControlRig.RigHierarchy.GetParents
	int32_t GetNumberOfParents(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetNumberOfParents
	struct TArray<struct FRigElementKey> GetNullKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetNullKeys
	struct FTransform GetLocalTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetLocalTransformByIndex
	struct FTransform GetLocalTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetLocalTransform
	struct FRigElementKey GetKey(int32_t InElementIndex); // Function ControlRig.RigHierarchy.GetKey
	int32_t GetIntFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetIntFromControlValue
	int32_t GetIndex_ForBlueprint(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetIndex_ForBlueprint
	struct FTransform GetGlobalTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalTransformByIndex
	struct FTransform GetGlobalTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalTransform
	struct FTransform GetGlobalControlShapeTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlShapeTransformByIndex
	struct FTransform GetGlobalControlShapeTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlShapeTransform
	struct FTransform GetGlobalControlOffsetTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransformByIndex
	struct FTransform GetGlobalControlOffsetTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransform
	float GetFloatFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetFloatFromControlValue
	struct FRigElementKey GetFirstParent(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetFirstParent
	struct FEulerTransform GetEulerTransformFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetEulerTransformFromControlValue
	float GetCurveValueByIndex(int32_t InElementIndex); // Function ControlRig.RigHierarchy.GetCurveValueByIndex
	float GetCurveValue(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetCurveValue
	struct TArray<struct FRigElementKey> GetCurveKeys(); // Function ControlRig.RigHierarchy.GetCurveKeys
	struct FRigControlValue GetControlValueByIndex(int32_t InElementIndex, uint8_t  InValueType); // Function ControlRig.RigHierarchy.GetControlValueByIndex
	struct FRigControlValue GetControlValue(struct FRigElementKey InKey, uint8_t  InValueType); // Function ControlRig.RigHierarchy.GetControlValue
	struct URigHierarchyController* GetController(bool bCreateIfNeeded); // Function ControlRig.RigHierarchy.GetController
	struct TArray<struct FRigElementKey> GetControlKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetControlKeys
	struct TArray<struct FRigElementKey> GetChildren(struct FRigElementKey InKey, bool bRecursive); // Function ControlRig.RigHierarchy.GetChildren
	struct TArray<struct FRigElementKey> GetBoneKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetBoneKeys
	struct TArray<struct FRigElementKey> GetAllKeys_ForBlueprint(bool bTraverse); // Function ControlRig.RigHierarchy.GetAllKeys_ForBlueprint
	struct FRigNullElement FindNull_ForBlueprintOnly(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.FindNull_ForBlueprintOnly
	struct FRigControlElement FindControl_ForBlueprintOnly(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.FindControl_ForBlueprintOnly
	struct FRigBoneElement FindBone_ForBlueprintOnly(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.FindBone_ForBlueprintOnly
	void CopyPose(struct URigHierarchy* InHierarchy, bool bCurrent, bool bInitial); // Function ControlRig.RigHierarchy.CopyPose
	void CopyHierarchy(struct URigHierarchy* InHierarchy); // Function ControlRig.RigHierarchy.CopyHierarchy
	bool Contains_ForBlueprint(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.Contains_ForBlueprint
}; 



// Class ControlRig.RigHierarchyController
// Size: 0xA0(Inherited: 0x28) 
struct URigHierarchyController : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bReportWarningsAndErrors : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct TWeakObjectPtr<URigHierarchy> Hierarchy;  // 0x2C(0x8)
	char pad_52[108];  // 0x34(0x6C)

	bool SetSelection(struct TArray<struct FRigElementKey>& InKeys, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.SetSelection
	bool SetParent(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bMaintainGlobalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.SetParent
	void SetHierarchy(struct URigHierarchy* InHierarchy); // Function ControlRig.RigHierarchyController.SetHierarchy
	bool SetControlSettings(struct FRigElementKey InKey, struct FRigControlSettings InSettings, bool bSetupUndo); // Function ControlRig.RigHierarchyController.SetControlSettings
	bool SelectElement(struct FRigElementKey InKey, bool bSelect, bool bClearSelection); // Function ControlRig.RigHierarchyController.SelectElement
	struct FRigElementKey RenameElement(struct FRigElementKey InElement, struct FName InName, bool bSetupUndo, bool bPrintPythonCommand, bool bClearSelection); // Function ControlRig.RigHierarchyController.RenameElement
	bool RemoveParent(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bMaintainGlobalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.RemoveParent
	bool RemoveElement(struct FRigElementKey InElement, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.RemoveElement
	bool RemoveAllParents(struct FRigElementKey InChild, bool bMaintainGlobalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.RemoveAllParents
	struct TArray<struct FRigElementKey> MirrorElements(struct TArray<struct FRigElementKey> InKeys, struct FRigMirrorSettings InSettings, bool bSelectNewElements, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchyController.MirrorElements
	struct TArray<struct FRigElementKey> ImportFromText(struct FString InContent, bool bReplaceExistingElements, bool bSelectNewElements, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchyController.ImportFromText
	struct TArray<struct FRigElementKey> ImportCurves(struct USkeleton* InSkeleton, struct FName InNameSpace, bool bSelectCurves, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.ImportCurves
	struct TArray<struct FRigElementKey> ImportBones(struct USkeleton* InSkeleton, struct FName InNameSpace, bool bReplaceExistingBones, bool bRemoveObsoleteBones, bool bSelectBones, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.ImportBones
	struct URigHierarchy* GetHierarchy(); // Function ControlRig.RigHierarchyController.GetHierarchy
	struct FRigControlSettings GetControlSettings(struct FRigElementKey InKey); // Function ControlRig.RigHierarchyController.GetControlSettings
	struct FString ExportToText(struct TArray<struct FRigElementKey> InKeys); // Function ControlRig.RigHierarchyController.ExportToText
	struct FString ExportSelectionToText(); // Function ControlRig.RigHierarchyController.ExportSelectionToText
	struct TArray<struct FRigElementKey> DuplicateElements(struct TArray<struct FRigElementKey> InKeys, bool bSelectNewElements, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchyController.DuplicateElements
	bool DeselectElement(struct FRigElementKey InKey); // Function ControlRig.RigHierarchyController.DeselectElement
	bool ClearSelection(); // Function ControlRig.RigHierarchyController.ClearSelection
	struct FRigElementKey AddRigidBody(struct FName InName, struct FRigElementKey InParent, struct FRigRigidBodySettings InSettings, struct FTransform InLocalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddRigidBody
	bool AddParent(struct FRigElementKey InChild, struct FRigElementKey InParent, float InWeight, bool bMaintainGlobalTransform, bool bSetupUndo); // Function ControlRig.RigHierarchyController.AddParent
	struct FRigElementKey AddNull(struct FName InName, struct FRigElementKey InParent, struct FTransform InTransform, bool bTransformInGlobal, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddNull
	struct FRigElementKey AddCurve(struct FName InName, float InValue, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddCurve
	struct FRigElementKey AddControl_ForBlueprint(struct FName InName, struct FRigElementKey InParent, struct FRigControlSettings InSettings, struct FRigControlValue InValue, bool bSetupUndo); // Function ControlRig.RigHierarchyController.AddControl_ForBlueprint
	struct FRigElementKey AddBone(struct FName InName, struct FRigElementKey InParent, struct FTransform InTransform, bool bTransformInGlobal, uint8_t  InBoneType, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddBone
}; 



