#pragma once 
#include <FunctionLibrary_Structs.h>
 
 
 
// BlueprintGeneratedClass FunctionLibrary.FunctionLibrary_C
// Size: 0x28(Inherited: 0x28) 
struct UFunctionLibrary_C : public UBlueprintFunctionLibrary
{

	void GetGameInstance(struct UObject* __WorldContext, struct UBP_PG_GameInstance_C*& MyGameIntance); // Function FunctionLibrary.FunctionLibrary_C.GetGameInstance
	void GetGameModeBP_Game(struct UObject* __WorldContext, struct ABP_PG_GameMode_Game_C*& MyGameMode); // Function FunctionLibrary.FunctionLibrary_C.GetGameModeBP_Game
	void GetGameStateBP(struct UObject* __WorldContext, struct ABP_PG_GameState_Game_C*& MyGameState); // Function FunctionLibrary.FunctionLibrary_C.GetGameStateBP
}; 



