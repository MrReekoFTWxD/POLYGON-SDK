#pragma once 
#include <OnlineSubsystemSteam_Structs.h>
 
 
 
// Class OnlineSubsystemSteam.SteamAuthComponentModuleInterface
// Size: 0x28(Inherited: 0x28) 
struct USteamAuthComponentModuleInterface : public UHandlerComponentFactory
{

}; 



// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x32F0(Inherited: 0x32E0) 
struct USteamNetConnection : public UIpConnection
{
	char pad_13024_1 : 7;  // 0x32E0(0x1)
	bool bIsPassthrough : 1;  // 0x32E0(0x1)
	char pad_13025[15];  // 0x32E1(0xF)

}; 



// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x7E0(Inherited: 0x7D8) 
struct USteamNetDriver : public UIpNetDriver
{
	char pad_2008[8];  // 0x7D8(0x8)

}; 



