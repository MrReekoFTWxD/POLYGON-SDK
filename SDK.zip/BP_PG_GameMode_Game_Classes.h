#pragma once 
#include <BP_PG_GameMode_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_GameMode_Game.BP_PG_GameMode_Game_C
// Size: 0x3C8(Inherited: 0x3C0) 
struct ABP_PG_GameMode_Game_C : public APG_GameMode_Game
{
	struct USceneComponent* DefaultSceneRoot;  // 0x3C0(0x8)

}; 



