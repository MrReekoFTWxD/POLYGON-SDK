#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimationCore.NodeHierarchyData
// Size: 0x70(Inherited: 0x0) 
struct FNodeHierarchyData
{
	struct TArray<struct FNodeObject> Nodes;  // 0x0(0x10)
	struct TArray<struct FTransform> Transforms;  // 0x10(0x10)
	struct TMap<struct FName, int32_t> NodeNameToIndexMapping;  // 0x20(0x50)

}; 
// ScriptStruct AnimationCore.FilterOptionPerAxis
// Size: 0x3(Inherited: 0x0) 
struct FFilterOptionPerAxis
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bX : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bY : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bZ : 1;  // 0x2(0x1)

}; 
// ScriptStruct AnimationCore.TransformConstraint
// Size: 0x28(Inherited: 0x0) 
struct FTransformConstraint
{
	struct FConstraintDescription Operator;  // 0x0(0xD)
	char pad_13[3];  // 0xD(0x3)
	struct FName SourceNode;  // 0x10(0x8)
	struct FName TargetNode;  // 0x18(0x8)
	float Weight;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bMaintainOffset : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct AnimationCore.ConstraintDescription
// Size: 0xD(Inherited: 0x0) 
struct FConstraintDescription
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTranslation : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bRotation : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bScale : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bParent : 1;  // 0x3(0x1)
	struct FFilterOptionPerAxis TranslationAxes;  // 0x4(0x3)
	struct FFilterOptionPerAxis RotationAxes;  // 0x7(0x3)
	struct FFilterOptionPerAxis ScaleAxes;  // 0xA(0x3)

}; 
// ScriptStruct AnimationCore.ConstraintOffset
// Size: 0xC0(Inherited: 0x0) 
struct FConstraintOffset
{
	struct FVector Translation;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FQuat Rotation;  // 0x20(0x20)
	struct FVector Scale;  // 0x40(0x18)
	char pad_88[8];  // 0x58(0x8)
	struct FTransform Parent;  // 0x60(0x60)

}; 
// ScriptStruct AnimationCore.NodeHierarchyWithUserData
// Size: 0x78(Inherited: 0x0) 
struct FNodeHierarchyWithUserData
{
	char pad_0[8];  // 0x0(0x8)
	struct FNodeHierarchyData Hierarchy;  // 0x8(0x70)

}; 
// ScriptStruct AnimationCore.ConstraintData
// Size: 0xE0(Inherited: 0x0) 
struct FConstraintData
{
	struct FConstraintDescriptor Constraint;  // 0x0(0x10)
	float Weight;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bMaintainOffset : 1;  // 0x14(0x1)
	char pad_21[11];  // 0x15(0xB)
	struct FTransform Offset;  // 0x20(0x60)
	struct FTransform CurrentTransform;  // 0x80(0x60)

}; 
// ScriptStruct AnimationCore.NodeObject
// Size: 0x10(Inherited: 0x0) 
struct FNodeObject
{
	struct FName Name;  // 0x0(0x8)
	struct FName ParentName;  // 0x8(0x8)

}; 
// ScriptStruct AnimationCore.ConstraintDescriptor
// Size: 0x10(Inherited: 0x0) 
struct FConstraintDescriptor
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct AnimationCore.TransformFilter
// Size: 0x9(Inherited: 0x0) 
struct FTransformFilter
{
	struct FFilterOptionPerAxis TranslationFilter;  // 0x0(0x3)
	struct FFilterOptionPerAxis RotationFilter;  // 0x3(0x3)
	struct FFilterOptionPerAxis ScaleFilter;  // 0x6(0x3)

}; 
// ScriptStruct AnimationCore.CCDIKChainLink
// Size: 0xE0(Inherited: 0x0) 
struct FCCDIKChainLink
{
	char pad_0[224];  // 0x0(0xE0)

}; 
// ScriptStruct AnimationCore.EulerTransform
// Size: 0x48(Inherited: 0x0) 
struct FEulerTransform
{
	struct FVector Location;  // 0x0(0x18)
	struct FRotator Rotation;  // 0x18(0x18)
	struct FVector Scale;  // 0x30(0x18)

}; 
// ScriptStruct AnimationCore.FABRIKChainLink
// Size: 0x50(Inherited: 0x0) 
struct FFABRIKChainLink
{
	char pad_0[80];  // 0x0(0x50)

}; 
// ScriptStruct AnimationCore.Axis
// Size: 0x20(Inherited: 0x0) 
struct FAxis
{
	struct FVector Axis;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInLocalSpace : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct AnimationCore.ConstraintDescriptionEx
// Size: 0x10(Inherited: 0x0) 
struct FConstraintDescriptionEx
{
	char pad_0[8];  // 0x0(0x8)
	struct FFilterOptionPerAxis AxesFilterOption;  // 0x8(0x3)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct AnimationCore.TransformConstraintDescription
// Size: 0x18(Inherited: 0x10) 
struct FTransformConstraintDescription : public FConstraintDescriptionEx
{
	uint8_t  TransformType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AnimationCore.AimConstraintDescription
// Size: 0x70(Inherited: 0x10) 
struct FAimConstraintDescription : public FConstraintDescriptionEx
{
	struct FAxis LookAt_Axis;  // 0x10(0x20)
	struct FAxis LookUp_Axis;  // 0x30(0x20)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bUseLookUp : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FVector LookUpTarget;  // 0x58(0x18)

}; 
// ScriptStruct AnimationCore.NodeChain
// Size: 0x10(Inherited: 0x0) 
struct FNodeChain
{
	struct TArray<struct FName> Nodes;  // 0x0(0x10)

}; 
// ScriptStruct AnimationCore.TransformNoScale
// Size: 0x40(Inherited: 0x0) 
struct FTransformNoScale
{
	struct FVector Location;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FQuat Rotation;  // 0x20(0x20)

}; 
