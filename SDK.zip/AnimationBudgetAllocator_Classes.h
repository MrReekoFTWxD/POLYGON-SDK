#pragma once 
#include <AnimationBudgetAllocator_Structs.h>
 
 
 
// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
}; 



// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xF30(Inherited: 0xF00) 
struct USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
	char pad_3840[32];  // 0xF00(0x20)
	char bAutoRegisterWithBudgetAllocator : 1;  // 0xF20(0x1)
	char bAutoCalculateSignificance : 1;  // 0xF20(0x1)
	char bShouldUseActorRenderedFlag : 1;  // 0xF20(0x1)
	char pad_3872_1 : 5;  // 0xF20(0x1)
	char pad_3873[16];  // 0xF21(0x10)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
}; 



