#pragma once 
#include <CommonUI_Structs.h>
 
 
 
// Class CommonUI.AnalogSlider
// Size: 0x700(Inherited: 0x6E0) 
struct UAnalogSlider : public USlider
{
	struct FMulticastInlineDelegate OnAnalogCapture;  // 0x6E0(0x10)
	char pad_1776[16];  // 0x6F0(0x10)

}; 



// Class CommonUI.CommonBorderStyle
// Size: 0x100(Inherited: 0x28) 
struct UCommonBorderStyle : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct FSlateBrush Background;  // 0x30(0xD0)

	void GetBackgroundBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonBorderStyle.GetBackgroundBrush
}; 



// Class CommonUI.CommonActionHandlerInterface
// Size: 0x28(Inherited: 0x28) 
struct UCommonActionHandlerInterface : public UInterface
{

}; 



// Class CommonUI.CommonActivatableWidget
// Size: 0x378(Inherited: 0x2B8) 
struct UCommonActivatableWidget : public UCommonUserWidget
{
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool bIsBackHandler : 1;  // 0x2B8(0x1)
	char pad_697_1 : 7;  // 0x2B9(0x1)
	bool bIsBackActionDisplayedInActionBar : 1;  // 0x2B9(0x1)
	char pad_698_1 : 7;  // 0x2BA(0x1)
	bool bAutoActivate : 1;  // 0x2BA(0x1)
	char pad_699_1 : 7;  // 0x2BB(0x1)
	bool bSupportsActivationFocus : 1;  // 0x2BB(0x1)
	char pad_700_1 : 7;  // 0x2BC(0x1)
	bool bIsModal : 1;  // 0x2BC(0x1)
	char pad_701_1 : 7;  // 0x2BD(0x1)
	bool bAutoRestoreFocus : 1;  // 0x2BD(0x1)
	char pad_702[2];  // 0x2BE(0x2)
	struct FMulticastInlineDelegate BP_OnWidgetActivated;  // 0x2C0(0x10)
	struct FMulticastInlineDelegate BP_OnWidgetDeactivated;  // 0x2D0(0x10)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool bIsActive : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)
	struct TArray<struct TWeakObjectPtr<UCommonActivatableWidget>> VisibilityBoundWidgets;  // 0x2E8(0x10)
	char pad_760[120];  // 0x2F8(0x78)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool bSetVisibilityOnActivated : 1;  // 0x370(0x1)
	uint8_t  ActivatedVisibility;  // 0x371(0x1)
	char pad_882_1 : 7;  // 0x372(0x1)
	bool bSetVisibilityOnDeactivated : 1;  // 0x372(0x1)
	uint8_t  DeactivatedVisibility;  // 0x373(0x1)
	char pad_884[4];  // 0x374(0x4)

	void SetBindVisibilities(uint8_t  OnActivatedVisibility, uint8_t  OnDeactivatedVisibility, bool bInAllActive); // Function CommonUI.CommonActivatableWidget.SetBindVisibilities
	bool IsActivated(); // Function CommonUI.CommonActivatableWidget.IsActivated
	struct UWidget* GetDesiredFocusTarget(); // Function CommonUI.CommonActivatableWidget.GetDesiredFocusTarget
	void DeactivateWidget(); // Function CommonUI.CommonActivatableWidget.DeactivateWidget
	bool BP_OnHandleBackAction(); // Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
	void BP_OnDeactivated(); // Function CommonUI.CommonActivatableWidget.BP_OnDeactivated
	void BP_OnActivated(); // Function CommonUI.CommonActivatableWidget.BP_OnActivated
	struct UWidget* BP_GetDesiredFocusTarget(); // Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
	void BindVisibilityToActivation(struct UCommonActivatableWidget* ActivatableWidget); // Function CommonUI.CommonActivatableWidget.BindVisibilityToActivation
	void ActivateWidget(); // Function CommonUI.CommonActivatableWidget.ActivateWidget
}; 



// Class CommonUI.CommonUISettings
// Size: 0x1D0(Inherited: 0x28) 
struct UCommonUISettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAutoLoadData : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TSoftObjectPtr<UObject> DefaultImageResourceObject;  // 0x30(0x28)
	struct TSoftObjectPtr<UMaterialInterface> DefaultThrobberMaterial;  // 0x58(0x28)
	struct TSoftClassPtr<UObject> DefaultRichTextDataClass;  // 0x80(0x28)
	struct TArray<struct FGameplayTag> PlatformTraits;  // 0xA8(0x10)
	char pad_184[40];  // 0xB8(0x28)
	struct UObject* DefaultImageResourceObjectInstance;  // 0xE0(0x8)
	struct UMaterialInterface* DefaultThrobberMaterialInstance;  // 0xE8(0x8)
	struct FSlateBrush DefaultThrobberBrush;  // 0xF0(0xD0)
	struct UCommonUIRichTextData* RichTextDataInstance;  // 0x1C0(0x8)
	char pad_456[8];  // 0x1C8(0x8)

}; 



// Class CommonUI.CommonListView
// Size: 0xBE0(Inherited: 0xBE0) 
struct UCommonListView : public UListView
{

	void SetEntrySpacing(float InEntrySpacing); // Function CommonUI.CommonListView.SetEntrySpacing
}; 



// Class CommonUI.CommonGameViewportClient
// Size: 0x3E0(Inherited: 0x3A0) 
struct UCommonGameViewportClient : public UGameViewportClient
{
	char pad_928[64];  // 0x3A0(0x40)

}; 



// Class CommonUI.CommonActionWidget
// Size: 0x430(Inherited: 0x128) 
struct UCommonActionWidget : public UWidget
{
	struct FMulticastInlineDelegate OnInputMethodChanged;  // 0x128(0x10)
	char pad_312[8];  // 0x138(0x8)
	struct FSlateBrush ProgressMaterialBrush;  // 0x140(0xD0)
	struct FName ProgressMaterialParam;  // 0x210(0x8)
	char pad_536[8];  // 0x218(0x8)
	struct FSlateBrush IconRimBrush;  // 0x220(0xD0)
	struct TArray<struct FDataTableRowHandle> InputActions;  // 0x2F0(0x10)
	char pad_768[8];  // 0x300(0x8)
	struct UMaterialInstanceDynamic* ProgressDynamicMaterial;  // 0x308(0x8)
	char pad_784[288];  // 0x310(0x120)

	void SetInputActions(struct TArray<struct FDataTableRowHandle> NewInputActions); // Function CommonUI.CommonActionWidget.SetInputActions
	void SetInputAction(struct FDataTableRowHandle InputActionRow); // Function CommonUI.CommonActionWidget.SetInputAction
	void SetIconRimBrush(struct FSlateBrush InIconRimBrush); // Function CommonUI.CommonActionWidget.SetIconRimBrush
	void OnInputMethodChanged__DelegateSignature(bool bUsingGamepad); // DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
	bool IsHeldAction(); // Function CommonUI.CommonActionWidget.IsHeldAction
	struct FSlateBrush GetIcon(); // Function CommonUI.CommonActionWidget.GetIcon
	struct FText GetDisplayText(); // Function CommonUI.CommonActionWidget.GetDisplayText
}; 



// Class CommonUI.CommonActivatableWidgetQueue
// Size: 0x248(Inherited: 0x248) 
struct UCommonActivatableWidgetQueue : public UCommonActivatableWidgetContainerBase
{

}; 



// Class CommonUI.CommonTreeView
// Size: 0xC40(Inherited: 0xC40) 
struct UCommonTreeView : public UTreeView
{

}; 



// Class CommonUI.CommonTileView
// Size: 0xC00(Inherited: 0xC00) 
struct UCommonTileView : public UTileView
{

}; 



// Class CommonUI.CommonButtonStyle
// Size: 0x7B0(Inherited: 0x28) 
struct UCommonButtonStyle : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bSingleMaterial : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FSlateBrush SingleMaterialBrush;  // 0x30(0xD0)
	struct FSlateBrush NormalBase;  // 0x100(0xD0)
	struct FSlateBrush NormalHovered;  // 0x1D0(0xD0)
	struct FSlateBrush NormalPressed;  // 0x2A0(0xD0)
	struct FSlateBrush SelectedBase;  // 0x370(0xD0)
	struct FSlateBrush SelectedHovered;  // 0x440(0xD0)
	struct FSlateBrush SelectedPressed;  // 0x510(0xD0)
	struct FSlateBrush Disabled;  // 0x5E0(0xD0)
	struct FMargin ButtonPadding;  // 0x6B0(0x10)
	struct FMargin CustomPadding;  // 0x6C0(0x10)
	int32_t MinWidth;  // 0x6D0(0x4)
	int32_t MinHeight;  // 0x6D4(0x4)
	UCommonTextStyle* NormalTextStyle;  // 0x6D8(0x8)
	UCommonTextStyle* NormalHoveredTextStyle;  // 0x6E0(0x8)
	UCommonTextStyle* SelectedTextStyle;  // 0x6E8(0x8)
	UCommonTextStyle* SelectedHoveredTextStyle;  // 0x6F0(0x8)
	UCommonTextStyle* DisabledTextStyle;  // 0x6F8(0x8)
	struct FSlateSound PressedSlateSound;  // 0x700(0x18)
	struct FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound;  // 0x718(0x20)
	struct FCommonButtonStyleOptionalSlateSound DisabledPressedSlateSound;  // 0x738(0x20)
	struct FSlateSound HoveredSlateSound;  // 0x758(0x18)
	struct FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound;  // 0x770(0x20)
	struct FCommonButtonStyleOptionalSlateSound DisabledHoveredSlateSound;  // 0x790(0x20)

	struct UCommonTextStyle* GetSelectedTextStyle(); // Function CommonUI.CommonButtonStyle.GetSelectedTextStyle
	void GetSelectedPressedBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush
	struct UCommonTextStyle* GetSelectedHoveredTextStyle(); // Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
	void GetSelectedHoveredBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
	void GetSelectedBaseBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush
	struct UCommonTextStyle* GetNormalTextStyle(); // Function CommonUI.CommonButtonStyle.GetNormalTextStyle
	void GetNormalPressedBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetNormalPressedBrush
	struct UCommonTextStyle* GetNormalHoveredTextStyle(); // Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
	void GetNormalHoveredBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush
	void GetNormalBaseBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetNormalBaseBrush
	void GetMaterialBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetMaterialBrush
	struct UCommonTextStyle* GetDisabledTextStyle(); // Function CommonUI.CommonButtonStyle.GetDisabledTextStyle
	void GetDisabledBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetDisabledBrush
	void GetCustomPadding(struct FMargin& OutCustomPadding); // Function CommonUI.CommonButtonStyle.GetCustomPadding
	void GetButtonPadding(struct FMargin& OutButtonPadding); // Function CommonUI.CommonButtonStyle.GetButtonPadding
}; 



// Class CommonUI.CommonUserWidget
// Size: 0x2B8(Inherited: 0x290) 
struct UCommonUserWidget : public UUserWidget
{
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bDisplayInActionBar : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool bConsumePointerInput : 1;  // 0x291(0x1)
	char pad_658[38];  // 0x292(0x26)

	void SetConsumePointerInput(bool bInConsumePointerInput); // Function CommonUI.CommonUserWidget.SetConsumePointerInput
}; 



// Class CommonUI.CommonUISubsystemBase
// Size: 0x40(Inherited: 0x30) 
struct UCommonUISubsystemBase : public UGameInstanceSubsystem
{
	char pad_48[16];  // 0x30(0x10)

	struct FSlateBrush GetInputActionButtonIcon(struct FDataTableRowHandle& InputActionRowHandle, uint8_t  InputType, struct FName& GamepadName); // Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon
}; 



// Class CommonUI.CommonActivatableWidgetContainerBase
// Size: 0x248(Inherited: 0x128) 
struct UCommonActivatableWidgetContainerBase : public UWidget
{
	char pad_296[24];  // 0x128(0x18)
	uint8_t  TransitionType;  // 0x140(0x1)
	uint8_t  TransitionCurveType;  // 0x141(0x1)
	char pad_322[2];  // 0x142(0x2)
	float TransitionDuration;  // 0x144(0x4)
	struct TArray<struct UCommonActivatableWidget*> WidgetList;  // 0x148(0x10)
	struct UCommonActivatableWidget* DisplayedWidget;  // 0x158(0x8)
	struct FUserWidgetPool GeneratedWidgetsPool;  // 0x160(0x88)
	char pad_488[96];  // 0x1E8(0x60)

	void SetTransitionDuration(float Duration); // Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration
	void RemoveWidget(struct UCommonActivatableWidget* WidgetToRemove); // Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
	float GetTransitionDuration(); // Function CommonUI.CommonActivatableWidgetContainerBase.GetTransitionDuration
	struct UCommonActivatableWidget* GetActiveWidget(); // Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
	void ClearWidgets(); // Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets
	struct UCommonActivatableWidget* BP_AddWidget(UCommonActivatableWidget* ActivatableWidgetClass); // Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
}; 



// Class CommonUI.CommonActivatableWidgetStack
// Size: 0x258(Inherited: 0x248) 
struct UCommonActivatableWidgetStack : public UCommonActivatableWidgetContainerBase
{
	UCommonActivatableWidget* RootContentWidgetClass;  // 0x248(0x8)
	struct UCommonActivatableWidget* RootContentWidget;  // 0x250(0x8)

}; 



// Class CommonUI.CommonAnimatedSwitcher
// Size: 0x1B0(Inherited: 0x158) 
struct UCommonAnimatedSwitcher : public UWidgetSwitcher
{
	char pad_344[24];  // 0x158(0x18)
	uint8_t  TransitionType;  // 0x170(0x1)
	uint8_t  TransitionCurveType;  // 0x171(0x1)
	char pad_370[2];  // 0x172(0x2)
	float TransitionDuration;  // 0x174(0x4)
	char pad_376[56];  // 0x178(0x38)

	void SetDisableTransitionAnimation(bool bDisableAnimation); // Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
	bool IsCurrentlySwitching(); // Function CommonUI.CommonAnimatedSwitcher.IsCurrentlySwitching
	bool HasWidgets(); // Function CommonUI.CommonAnimatedSwitcher.HasWidgets
	void ActivatePreviousWidget(bool bCanWrap); // Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
	void ActivateNextWidget(bool bCanWrap); // Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
}; 



// Class CommonUI.CommonActivatableWidgetSwitcher
// Size: 0x1B0(Inherited: 0x1B0) 
struct UCommonActivatableWidgetSwitcher : public UCommonAnimatedSwitcher
{

}; 



// Class CommonUI.CommonBorder
// Size: 0x310(Inherited: 0x2F0) 
struct UCommonBorder : public UBorder
{
	UCommonBorderStyle* Style;  // 0x2E8(0x8)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool bReducePaddingBySafezone : 1;  // 0x2F0(0x1)
	struct FMargin MinimumPadding;  // 0x2F4(0x10)
	char pad_777[7];  // 0x309(0x7)

	void SetStyle(UCommonBorderStyle* InStyle); // Function CommonUI.CommonBorder.SetStyle
}; 



// Class CommonUI.CommonBoundActionBar
// Size: 0x218(Inherited: 0x208) 
struct UCommonBoundActionBar : public UDynamicEntryBoxBase
{
	UCommonBoundActionButton* ActionButtonClass;  // 0x208(0x8)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool bDisplayOwningPlayerActionsOnly : 1;  // 0x210(0x1)
	char pad_529_1 : 7;  // 0x211(0x1)
	bool bIgnoreDuplicateActions : 1;  // 0x211(0x1)
	char pad_530[6];  // 0x212(0x6)

	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions); // Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
}; 



// Class CommonUI.UCommonVisibilityWidgetBase
// Size: 0x360(Inherited: 0x310) 
struct UUCommonVisibilityWidgetBase : public UCommonBorder
{
	struct TMap<struct FName, bool> VisibilityControls;  // 0x308(0x50)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool bShowForGamepad : 1;  // 0x358(0x1)
	char pad_865_1 : 7;  // 0x361(0x1)
	bool bShowForMouseAndKeyboard : 1;  // 0x359(0x1)
	char pad_866_1 : 7;  // 0x362(0x1)
	bool bShowForTouch : 1;  // 0x35A(0x1)
	uint8_t  VisibleType;  // 0x35B(0x1)
	uint8_t  HiddenType;  // 0x35C(0x1)

	struct TArray<struct FName> GetRegisteredPlatforms(); // Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms
}; 



// Class CommonUI.CommonHardwareVisibilityBorder
// Size: 0x360(Inherited: 0x310) 
struct UCommonHardwareVisibilityBorder : public UCommonBorder
{
	struct FGameplayTagQuery VisibilityQuery;  // 0x308(0x48)
	uint8_t  VisibleType;  // 0x350(0x1)
	uint8_t  HiddenType;  // 0x351(0x1)
	char pad_858[6];  // 0x35A(0x6)

}; 



// Class CommonUI.CommonButtonBase
// Size: 0x1070(Inherited: 0x2B8) 
struct UCommonButtonBase : public UCommonUserWidget
{
	int32_t MinWidth;  // 0x2B8(0x4)
	int32_t MinHeight;  // 0x2BC(0x4)
	UCommonButtonStyle* Style;  // 0x2C0(0x8)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool bHideInputAction : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct FSlateSound PressedSlateSoundOverride;  // 0x2D0(0x18)
	struct FSlateSound HoveredSlateSoundOverride;  // 0x2E8(0x18)
	char bApplyAlphaOnDisable : 1;  // 0x300(0x1)
	char bSelectable : 1;  // 0x300(0x1)
	char bShouldSelectUponReceivingFocus : 1;  // 0x300(0x1)
	char bInteractableWhenSelected : 1;  // 0x300(0x1)
	char bToggleable : 1;  // 0x300(0x1)
	char bDisplayInputActionWhenNotInteractable : 1;  // 0x300(0x1)
	char bHideInputActionWithKeyboard : 1;  // 0x300(0x1)
	char bShouldUseFallbackDefaultInputAction : 1;  // 0x300(0x1)
	char pad_769[1];  // 0x301(0x1)
	char EButtonClickMethod ClickMethod;  // 0x302(0x1)
	char EButtonTouchMethod TouchMethod;  // 0x303(0x1)
	char EButtonPressMethod PressMethod;  // 0x304(0x1)
	char pad_773[3];  // 0x305(0x3)
	int32_t InputPriority;  // 0x308(0x4)
	char pad_780[4];  // 0x30C(0x4)
	struct FDataTableRowHandle TriggeringInputAction;  // 0x310(0x10)
	char pad_800[16];  // 0x320(0x10)
	struct FMulticastInlineDelegate OnSelectedChangedBase;  // 0x330(0x10)
	struct FMulticastInlineDelegate OnButtonBaseClicked;  // 0x340(0x10)
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked;  // 0x350(0x10)
	struct FMulticastInlineDelegate OnButtonBaseHovered;  // 0x360(0x10)
	struct FMulticastInlineDelegate OnButtonBaseUnhovered;  // 0x370(0x10)
	char pad_896[4];  // 0x380(0x4)
	char pad_900_1 : 7;  // 0x384(0x1)
	bool bIsPersistentBinding : 1;  // 0x384(0x1)
	uint8_t  InputModeOverride;  // 0x385(0x1)
	char pad_902[50];  // 0x386(0x32)
	struct UMaterialInstanceDynamic* SingleMaterialStyleMID;  // 0x3B8(0x8)
	struct FButtonStyle NormalStyle;  // 0x3C0(0x3F0)
	struct FButtonStyle SelectedStyle;  // 0x7B0(0x3F0)
	struct FButtonStyle DisabledStyle;  // 0xBA0(0x3F0)
	char bStopDoubleClickPropagation : 1;  // 0xF90(0x1)
	char pad_3984_1 : 7;  // 0xF90(0x1)
	char pad_3985[208];  // 0xF91(0xD0)
	struct UCommonActionWidget* InputActionWidget;  // 0x1060(0x8)
	char pad_4200[8];  // 0x1068(0x8)

	void StopDoubleClickPropagation(); // Function CommonUI.CommonButtonBase.StopDoubleClickPropagation
	void SetTriggeringInputAction(struct FDataTableRowHandle& InputActionRow); // Function CommonUI.CommonButtonBase.SetTriggeringInputAction
	void SetTriggeredInputAction(struct FDataTableRowHandle& InputActionRow); // Function CommonUI.CommonButtonBase.SetTriggeredInputAction
	void SetTouchMethod(char EButtonTouchMethod InTouchMethod); // Function CommonUI.CommonButtonBase.SetTouchMethod
	void SetStyle(UCommonButtonStyle* InStyle); // Function CommonUI.CommonButtonBase.SetStyle
	void SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction); // Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
	void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus); // Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
	void SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadcast); // Function CommonUI.CommonButtonBase.SetSelectedInternal
	void SetPressMethod(char EButtonPressMethod InPressMethod); // Function CommonUI.CommonButtonBase.SetPressMethod
	void SetPressedSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetPressedSoundOverride
	void SetMinDimensions(int32_t InMinWidth, int32_t InMinHeight); // Function CommonUI.CommonButtonBase.SetMinDimensions
	void SetIsToggleable(bool bInIsToggleable); // Function CommonUI.CommonButtonBase.SetIsToggleable
	void SetIsSelected(bool InSelected, bool bGiveClickFeedback); // Function CommonUI.CommonButtonBase.SetIsSelected
	void SetIsSelectable(bool bInIsSelectable); // Function CommonUI.CommonButtonBase.SetIsSelectable
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled); // Function CommonUI.CommonButtonBase.SetIsInteractionEnabled
	void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected); // Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
	void SetIsFocusable(bool bInIsFocusable); // Function CommonUI.CommonButtonBase.SetIsFocusable
	void SetInputActionProgressMaterial(struct FSlateBrush& InProgressMaterialBrush, struct FName& InProgressMaterialParam); // Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial
	void SetHoveredSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetHoveredSoundOverride
	void SetClickMethod(char EButtonClickMethod InClickMethod); // Function CommonUI.CommonButtonBase.SetClickMethod
	void OnTriggeredInputActionChanged(struct FDataTableRowHandle& NewTriggeredAction); // Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
	void OnInputMethodChanged(uint8_t  CurrentInputType); // Function CommonUI.CommonButtonBase.OnInputMethodChanged
	void OnCurrentTextStyleChanged(); // Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged
	void OnActionProgress(float HeldPercent); // Function CommonUI.CommonButtonBase.OnActionProgress
	void OnActionComplete(); // Function CommonUI.CommonButtonBase.OnActionComplete
	void NativeOnActionProgress(float HeldPercent); // Function CommonUI.CommonButtonBase.NativeOnActionProgress
	void NativeOnActionComplete(); // Function CommonUI.CommonButtonBase.NativeOnActionComplete
	bool IsPressed(); // Function CommonUI.CommonButtonBase.IsPressed
	bool IsInteractionEnabled(); // Function CommonUI.CommonButtonBase.IsInteractionEnabled
	void HandleTriggeringActionCommited(bool& bPassThrough); // Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited
	void HandleFocusReceived(); // Function CommonUI.CommonButtonBase.HandleFocusReceived
	void HandleButtonReleased(); // Function CommonUI.CommonButtonBase.HandleButtonReleased
	void HandleButtonPressed(); // Function CommonUI.CommonButtonBase.HandleButtonPressed
	void HandleButtonClicked(); // Function CommonUI.CommonButtonBase.HandleButtonClicked
	struct UCommonButtonStyle* GetStyle(); // Function CommonUI.CommonButtonBase.GetStyle
	struct UMaterialInstanceDynamic* GetSingleMaterialStyleMID(); // Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
	bool GetShouldSelectUponReceivingFocus(); // Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
	bool GetSelected(); // Function CommonUI.CommonButtonBase.GetSelected
	bool GetIsFocusable(); // Function CommonUI.CommonButtonBase.GetIsFocusable
	bool GetInputAction(struct FDataTableRowHandle& InputActionRow); // Function CommonUI.CommonButtonBase.GetInputAction
	UCommonTextStyle* GetCurrentTextStyleClass(); // Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass
	struct UCommonTextStyle* GetCurrentTextStyle(); // Function CommonUI.CommonButtonBase.GetCurrentTextStyle
	void GetCurrentCustomPadding(struct FMargin& OutCustomPadding); // Function CommonUI.CommonButtonBase.GetCurrentCustomPadding
	void GetCurrentButtonPadding(struct FMargin& OutButtonPadding); // Function CommonUI.CommonButtonBase.GetCurrentButtonPadding
	void DisableButtonWithReason(struct FText& DisabledReason); // Function CommonUI.CommonButtonBase.DisableButtonWithReason
	void ClearSelection(); // Function CommonUI.CommonButtonBase.ClearSelection
	void BP_OnUnhovered(); // Function CommonUI.CommonButtonBase.BP_OnUnhovered
	void BP_OnSelected(); // Function CommonUI.CommonButtonBase.BP_OnSelected
	void BP_OnHovered(); // Function CommonUI.CommonButtonBase.BP_OnHovered
	void BP_OnEnabled(); // Function CommonUI.CommonButtonBase.BP_OnEnabled
	void BP_OnDoubleClicked(); // Function CommonUI.CommonButtonBase.BP_OnDoubleClicked
	void BP_OnDisabled(); // Function CommonUI.CommonButtonBase.BP_OnDisabled
	void BP_OnDeselected(); // Function CommonUI.CommonButtonBase.BP_OnDeselected
	void BP_OnClicked(); // Function CommonUI.CommonButtonBase.BP_OnClicked
}; 



// Class CommonUI.CommonTextScrollStyle
// Size: 0x40(Inherited: 0x28) 
struct UCommonTextScrollStyle : public UObject
{
	float Speed;  // 0x28(0x4)
	float StartDelay;  // 0x2C(0x4)
	float EndDelay;  // 0x30(0x4)
	float FadeInDelay;  // 0x34(0x4)
	float FadeOutDelay;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class CommonUI.CommonBoundActionButton
// Size: 0x1080(Inherited: 0x1070) 
struct UCommonBoundActionButton : public UCommonButtonBase
{
	struct UCommonTextBlock* Text_ActionName;  // 0x1068(0x8)
	char pad_4216[8];  // 0x1078(0x8)

	void OnUpdateInputAction(); // Function CommonUI.CommonBoundActionButton.OnUpdateInputAction
}; 



// Class CommonUI.CommonWidgetCarouselNavBar
// Size: 0x170(Inherited: 0x128) 
struct UCommonWidgetCarouselNavBar : public UWidget
{
	UCommonButtonBase* ButtonWidgetType;  // 0x128(0x8)
	struct FMargin ButtonPadding;  // 0x130(0x10)
	char pad_320[16];  // 0x140(0x10)
	struct UCommonWidgetCarousel* LinkedCarousel;  // 0x150(0x8)
	struct UCommonButtonGroupBase* ButtonGroup;  // 0x158(0x8)
	struct TArray<struct UCommonButtonBase*> Buttons;  // 0x160(0x10)

	void SetLinkedCarousel(struct UCommonWidgetCarousel* CommonCarousel); // Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
	void HandlePageChanged(struct UCommonWidgetCarousel* CommonCarousel, int32_t PageIndex); // Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
	void HandleButtonClicked(struct UCommonButtonBase* AssociatedButton, int32_t ButtonIndex); // Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
}; 



// Class CommonUI.CommonUIVisibilitySubsystem
// Size: 0x88(Inherited: 0x30) 
struct UCommonUIVisibilitySubsystem : public ULocalPlayerSubsystem
{
	char pad_48[88];  // 0x30(0x58)

}; 



// Class CommonUI.CommonNumericTextBlock
// Size: 0x3E0(Inherited: 0x340) 
struct UCommonNumericTextBlock : public UCommonTextBlock
{
	struct FMulticastInlineDelegate OnInterpolationStartedEvent;  // 0x338(0x10)
	struct FMulticastInlineDelegate OnInterpolationUpdatedEvent;  // 0x348(0x10)
	struct FMulticastInlineDelegate OnOutroEvent;  // 0x358(0x10)
	struct FMulticastInlineDelegate OnInterpolationEndedEvent;  // 0x368(0x10)
	float CurrentNumericValue;  // 0x378(0x4)
	uint8_t  NumericType;  // 0x37C(0x1)
	struct FCommonNumberFormattingOptions FormattingSpecification;  // 0x380(0x14)
	float EaseOutInterpolationExponent;  // 0x394(0x4)
	float InterpolationUpdateInterval;  // 0x398(0x4)
	float PostInterpolationShrinkDuration;  // 0x39C(0x4)
	char pad_933_1 : 7;  // 0x3A5(0x1)
	bool PerformSizeInterpolation : 1;  // 0x3A0(0x1)
	char pad_934_1 : 7;  // 0x3A6(0x1)
	bool IsPercentage : 1;  // 0x3A1(0x1)
	char pad_935[57];  // 0x3A7(0x39)

	void SetNumericType(uint8_t  InNumericType); // Function CommonUI.CommonNumericTextBlock.SetNumericType
	void SetCurrentValue(float NewValue); // Function CommonUI.CommonNumericTextBlock.SetCurrentValue
	void OnOutro__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock); // DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
	void OnInterpolationUpdated__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, float LastValue, float NewValue); // DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
	void OnInterpolationStarted__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock); // DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
	void OnInterpolationEnded__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, bool HadCompleted); // DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
	bool IsInterpolatingNumericValue(); // Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
	void InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset); // Function CommonUI.CommonNumericTextBlock.InterpolateToValue
	float GetTargetValue(); // Function CommonUI.CommonNumericTextBlock.GetTargetValue
}; 



// Class CommonUI.CommonDateTimeTextBlock
// Size: 0x390(Inherited: 0x340) 
struct UCommonDateTimeTextBlock : public UCommonTextBlock
{
	char pad_832[80];  // 0x340(0x50)

	void SetTimespanValue(struct FTimespan InTimespan); // Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue
	void SetDateTimeValue(struct FDateTime InDateTime, bool bShowAsCountdown, float InRefreshDelay); // Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue
	void SetCountDownCompletionText(struct FText InCompletionText); // Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText
	struct FDateTime GetDateTime(); // Function CommonUI.CommonDateTimeTextBlock.GetDateTime
}; 



// Class CommonUI.CommonButtonInternalBase
// Size: 0x630(Inherited: 0x5D0) 
struct UCommonButtonInternalBase : public UButton
{
	char pad_1488[8];  // 0x5D0(0x8)
	struct FMulticastInlineDelegate OnDoubleClicked;  // 0x5D8(0x10)
	char pad_1512[16];  // 0x5E8(0x10)
	int32_t MinWidth;  // 0x5F8(0x4)
	int32_t MinHeight;  // 0x5FC(0x4)
	char pad_1536_1 : 7;  // 0x600(0x1)
	bool bButtonEnabled : 1;  // 0x600(0x1)
	char pad_1537_1 : 7;  // 0x601(0x1)
	bool bInteractionEnabled : 1;  // 0x601(0x1)
	char pad_1538[46];  // 0x602(0x2E)

}; 



// Class CommonUI.CommonWidgetGroupBase
// Size: 0x28(Inherited: 0x28) 
struct UCommonWidgetGroupBase : public UObject
{

	void RemoveWidget(struct UWidget* InWidget); // Function CommonUI.CommonWidgetGroupBase.RemoveWidget
	void RemoveAll(); // Function CommonUI.CommonWidgetGroupBase.RemoveAll
	void AddWidget(struct UWidget* InWidget); // Function CommonUI.CommonWidgetGroupBase.AddWidget
}; 



// Class CommonUI.CommonButtonGroupBase
// Size: 0x110(Inherited: 0x28) 
struct UCommonButtonGroupBase : public UCommonWidgetGroupBase
{
	struct FMulticastInlineDelegate OnSelectedButtonBaseChanged;  // 0x28(0x10)
	char pad_56[24];  // 0x38(0x18)
	struct FMulticastInlineDelegate OnHoveredButtonBaseChanged;  // 0x50(0x10)
	char pad_96[24];  // 0x60(0x18)
	struct FMulticastInlineDelegate OnButtonBaseClicked;  // 0x78(0x10)
	char pad_136[24];  // 0x88(0x18)
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked;  // 0xA0(0x10)
	char pad_176[24];  // 0xB0(0x18)
	struct FMulticastInlineDelegate OnSelectionCleared;  // 0xC8(0x10)
	char pad_216[24];  // 0xD8(0x18)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bSelectionRequired : 1;  // 0xF0(0x1)
	char pad_241[31];  // 0xF1(0x1F)

	void SetSelectionRequired(bool bRequireSelection); // Function CommonUI.CommonButtonGroupBase.SetSelectionRequired
	void SelectPreviousButton(bool bAllowWrap); // Function CommonUI.CommonButtonGroupBase.SelectPreviousButton
	void SelectNextButton(bool bAllowWrap); // Function CommonUI.CommonButtonGroupBase.SelectNextButton
	void SelectButtonAtIndex(int32_t ButtonIndex); // Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
	void OnSelectionStateChangedBase(struct UCommonButtonBase* BaseButton, bool bIsSelected); // Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
	void OnHandleButtonBaseDoubleClicked(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
	void OnHandleButtonBaseClicked(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
	void OnButtonBaseUnhovered(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
	void OnButtonBaseHovered(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
	bool HasAnyButtons(); // Function CommonUI.CommonButtonGroupBase.HasAnyButtons
	int32_t GetSelectedButtonIndex(); // Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
	struct UCommonButtonBase* GetSelectedButtonBase(); // Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
	int32_t GetHoveredButtonIndex(); // Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
	int32_t GetButtonCount(); // Function CommonUI.CommonButtonGroupBase.GetButtonCount
	struct UCommonButtonBase* GetButtonBaseAtIndex(int32_t Index); // Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
	int32_t FindButtonIndex(struct UCommonButtonBase* ButtonToFind); // Function CommonUI.CommonButtonGroupBase.FindButtonIndex
	void DeselectAll(); // Function CommonUI.CommonButtonGroupBase.DeselectAll
}; 



// Class CommonUI.CommonCustomNavigation
// Size: 0x300(Inherited: 0x2F0) 
struct UCommonCustomNavigation : public UBorder
{
	struct FDelegate OnNavigationEvent;  // 0x2E8(0x10)

}; 



// Class CommonUI.CommonVideoPlayer
// Size: 0x280(Inherited: 0x128) 
struct UCommonVideoPlayer : public UWidget
{
	struct UMediaSource* Video;  // 0x128(0x8)
	struct UMediaPlayer* MediaPlayer;  // 0x130(0x8)
	struct UMediaTexture* MediaTexture;  // 0x138(0x8)
	struct UMaterial* VideoMaterial;  // 0x140(0x8)
	struct UMediaSoundComponent* SoundComponent;  // 0x148(0x8)
	struct FSlateBrush VideoBrush;  // 0x150(0xD0)
	char pad_544[96];  // 0x220(0x60)

}; 



// Class CommonUI.CommonTextBlock
// Size: 0x340(Inherited: 0x310) 
struct UCommonTextBlock : public UTextBlock
{
	UCommonTextStyle* Style;  // 0x310(0x8)
	UCommonTextScrollStyle* ScrollStyle;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool bDisplayAllCaps : 1;  // 0x320(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool bAutoCollapseWithEmptyText : 1;  // 0x321(0x1)
	char pad_802[2];  // 0x322(0x2)
	float MobileFontSizeMultiplier;  // 0x324(0x4)
	char pad_808[24];  // 0x328(0x18)

	void SetWrapTextWidth(int32_t InWrapTextAt); // Function CommonUI.CommonTextBlock.SetWrapTextWidth
	void SetTextCase(bool bUseAllCaps); // Function CommonUI.CommonTextBlock.SetTextCase
	void SetStyle(UCommonTextStyle* InStyle); // Function CommonUI.CommonTextBlock.SetStyle
	void ResetScrollState(); // Function CommonUI.CommonTextBlock.ResetScrollState
}; 



// Class CommonUI.CommonHierarchicalScrollBox
// Size: 0xC80(Inherited: 0xC80) 
struct UCommonHierarchicalScrollBox : public UScrollBox
{

}; 



// Class CommonUI.CommonGenericInputActionDataTable
// Size: 0xB0(Inherited: 0xB0) 
struct UCommonGenericInputActionDataTable : public UDataTable
{

}; 



// Class CommonUI.CommonInputActionDataProcessor
// Size: 0x28(Inherited: 0x28) 
struct UCommonInputActionDataProcessor : public UObject
{

}; 



// Class CommonUI.CommonLazyImage
// Size: 0x390(Inherited: 0x280) 
struct UCommonLazyImage : public UImage
{
	struct FSlateBrush LoadingBackgroundBrush;  // 0x280(0xD0)
	struct FName MaterialTextureParamName;  // 0x350(0x8)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged;  // 0x358(0x10)
	char pad_872[40];  // 0x368(0x28)

	void SetMaterialTextureParamName(struct FName TextureParamName); // Function CommonUI.CommonLazyImage.SetMaterialTextureParamName
	void SetBrushFromLazyTexture(struct TSoftObjectPtr<UTexture2D>& LazyTexture, bool bMatchSize); // Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture
	void SetBrushFromLazyMaterial(struct TSoftObjectPtr<UMaterialInterface>& LazyMaterial); // Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
	void SetBrushFromLazyDisplayAsset(struct TSoftObjectPtr<UObject>& LazyObject, bool bMatchTextureSize); // Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
	bool IsLoading(); // Function CommonUI.CommonLazyImage.IsLoading
}; 



// Class CommonUI.CommonLazyWidget
// Size: 0x280(Inherited: 0x128) 
struct UCommonLazyWidget : public UWidget
{
	char pad_296[8];  // 0x128(0x8)
	struct FSlateBrush LoadingBackgroundBrush;  // 0x130(0xD0)
	struct UUserWidget* Content;  // 0x200(0x8)
	char pad_520[40];  // 0x208(0x28)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged;  // 0x230(0x10)
	char pad_576[64];  // 0x240(0x40)

	void SetLazyContent(struct TSoftClassPtr<UObject> SoftWidget); // Function CommonUI.CommonLazyWidget.SetLazyContent
	bool IsLoading(); // Function CommonUI.CommonLazyWidget.IsLoading
	struct UUserWidget* GetContent(); // Function CommonUI.CommonLazyWidget.GetContent
}; 



// Class CommonUI.LoadGuardSlot
// Size: 0x60(Inherited: 0x38) 
struct ULoadGuardSlot : public UPanelSlot
{
	struct FMargin Padding;  // 0x38(0x10)
	char EHorizontalAlignment HorizontalAlignment;  // 0x48(0x1)
	char EVerticalAlignment VerticalAlignment;  // 0x49(0x1)
	char pad_74[22];  // 0x4A(0x16)

	void SetVerticalAlignment(char EVerticalAlignment InVerticalAlignment); // Function CommonUI.LoadGuardSlot.SetVerticalAlignment
	void SetPadding(struct FMargin InPadding); // Function CommonUI.LoadGuardSlot.SetPadding
	void SetHorizontalAlignment(char EHorizontalAlignment InHorizontalAlignment); // Function CommonUI.LoadGuardSlot.SetHorizontalAlignment
}; 



// Class CommonUI.CommonLoadGuard
// Size: 0x2A0(Inherited: 0x140) 
struct UCommonLoadGuard : public UContentWidget
{
	struct FSlateBrush LoadingBackgroundBrush;  // 0x140(0xD0)
	char EHorizontalAlignment ThrobberAlignment;  // 0x210(0x1)
	char pad_529[3];  // 0x211(0x3)
	struct FMargin ThrobberPadding;  // 0x214(0x10)
	char pad_548[4];  // 0x224(0x4)
	struct FText LoadingText;  // 0x228(0x18)
	UCommonTextStyle* TextStyle;  // 0x240(0x8)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged;  // 0x248(0x10)
	struct FSoftObjectPath SpinnerMaterialPath;  // 0x258(0x18)
	char pad_624[48];  // 0x270(0x30)

	void SetLoadingText(struct FText& InLoadingText); // Function CommonUI.CommonLoadGuard.SetLoadingText
	void SetIsLoading(bool bInIsLoading); // Function CommonUI.CommonLoadGuard.SetIsLoading
	void OnAssetLoaded__DelegateSignature(struct UObject* Object); // DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
	bool IsLoading(); // Function CommonUI.CommonLoadGuard.IsLoading
	void BP_GuardAndLoadAsset(struct TSoftObjectPtr<UObject>& InLazyAsset, struct FDelegate& OnAssetLoaded); // Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
}; 



// Class CommonUI.CommonUIRichTextData
// Size: 0x30(Inherited: 0x28) 
struct UCommonUIRichTextData : public UObject
{
	struct UDataTable* InlineIconSet;  // 0x28(0x8)

}; 



// Class CommonUI.CommonTabListWidgetBase
// Size: 0x388(Inherited: 0x2B8) 
struct UCommonTabListWidgetBase : public UCommonUserWidget
{
	struct FMulticastInlineDelegate OnTabSelected;  // 0x2B8(0x10)
	struct FMulticastInlineDelegate OnTabButtonCreation;  // 0x2C8(0x10)
	struct FMulticastInlineDelegate OnTabButtonRemoval;  // 0x2D8(0x10)
	struct FDataTableRowHandle NextTabInputActionData;  // 0x2E8(0x10)
	struct FDataTableRowHandle PreviousTabInputActionData;  // 0x2F8(0x10)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool bAutoListenForInput : 1;  // 0x308(0x1)
	char pad_777[3];  // 0x309(0x3)
	struct TWeakObjectPtr<UCommonAnimatedSwitcher> LinkedSwitcher;  // 0x30C(0x8)
	char pad_788[4];  // 0x314(0x4)
	struct UCommonButtonGroupBase* TabButtonGroup;  // 0x318(0x8)
	char pad_800[8];  // 0x320(0x8)
	struct TMap<struct FName, struct FCommonRegisteredTabInfo> RegisteredTabsByID;  // 0x328(0x50)
	char pad_888[16];  // 0x378(0x10)

	void SetTabVisibility(struct FName TabNameID, uint8_t  NewVisibility); // Function CommonUI.CommonTabListWidgetBase.SetTabVisibility
	void SetTabInteractionEnabled(struct FName TabNameID, bool bEnable); // Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
	void SetTabEnabled(struct FName TabNameID, bool bEnable); // Function CommonUI.CommonTabListWidgetBase.SetTabEnabled
	void SetListeningForInput(bool bShouldListen); // Function CommonUI.CommonTabListWidgetBase.SetListeningForInput
	void SetLinkedSwitcher(struct UCommonAnimatedSwitcher* CommonSwitcher); // Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
	bool SelectTabByID(struct FName TabNameID, bool bSuppressClickFeedback); // Function CommonUI.CommonTabListWidgetBase.SelectTabByID
	bool RemoveTab(struct FName TabNameID); // Function CommonUI.CommonTabListWidgetBase.RemoveTab
	void RemoveAllTabs(); // Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs
	bool RegisterTab(struct FName TabNameID, UCommonButtonBase* ButtonWidgetType, struct UWidget* ContentWidget); // Function CommonUI.CommonTabListWidgetBase.RegisterTab
	void OnTabSelected__DelegateSignature(struct FName TabId); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
	void OnTabButtonRemoval__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
	void OnTabButtonCreation__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
	void HandleTabRemoval(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval
	void HandleTabCreation(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Function CommonUI.CommonTabListWidgetBase.HandleTabCreation
	void HandleTabButtonSelected(struct UCommonButtonBase* SelectedTabButton, int32_t ButtonIndex); // Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
	void HandlePreviousTabInputAction(bool& bPassThrough); // Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
	void HandlePreLinkedSwitcherChanged_BP(); // Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP
	void HandlePostLinkedSwitcherChanged_BP(); // Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP
	void HandleNextTabInputAction(bool& bPassThrough); // Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
	struct FName GetTabIdAtIndex(int32_t Index); // Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
	int32_t GetTabCount(); // Function CommonUI.CommonTabListWidgetBase.GetTabCount
	struct UCommonButtonBase* GetTabButtonBaseByID(struct FName TabNameID); // Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
	struct FName GetSelectedTabId(); // Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId
	struct UCommonAnimatedSwitcher* GetLinkedSwitcher(); // Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
	struct FName GetActiveTab(); // Function CommonUI.CommonTabListWidgetBase.GetActiveTab
	void DisableTabWithReason(struct FName TabNameID, struct FText& Reason); // Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason
}; 



// Class CommonUI.CommonPoolableWidgetInterface
// Size: 0x28(Inherited: 0x28) 
struct UCommonPoolableWidgetInterface : public UInterface
{

	void OnReleaseToPool(); // Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool
	void OnAcquireFromPool(); // Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool
}; 



// Class CommonUI.CommonRichTextBlock
// Size: 0x880(Inherited: 0x840) 
struct UCommonRichTextBlock : public URichTextBlock
{
	uint8_t  InlineIconDisplayMode;  // 0x840(0x1)
	char pad_2113_1 : 7;  // 0x841(0x1)
	bool bTintInlineIcon : 1;  // 0x841(0x1)
	char pad_2114[6];  // 0x842(0x6)
	UCommonTextStyle* DefaultTextStyleOverrideClass;  // 0x848(0x8)
	float MobileTextBlockScale;  // 0x850(0x4)
	char pad_2132[4];  // 0x854(0x4)
	UCommonTextScrollStyle* ScrollStyle;  // 0x858(0x8)
	char pad_2144_1 : 7;  // 0x860(0x1)
	bool bDisplayAllCaps : 1;  // 0x860(0x1)
	char pad_2145[31];  // 0x861(0x1F)

}; 



// Class CommonUI.CommonRotator
// Size: 0x10C0(Inherited: 0x1070) 
struct UCommonRotator : public UCommonButtonBase
{
	char pad_4208[8];  // 0x1070(0x8)
	struct FMulticastInlineDelegate OnRotated;  // 0x1078(0x10)
	char pad_4232[24];  // 0x1088(0x18)
	struct UCommonTextBlock* MyText;  // 0x10A0(0x8)
	char pad_4264[24];  // 0x10A8(0x18)

	void ShiftTextRight(); // Function CommonUI.CommonRotator.ShiftTextRight
	void ShiftTextLeft(); // Function CommonUI.CommonRotator.ShiftTextLeft
	void SetSelectedItem(int32_t InValue); // Function CommonUI.CommonRotator.SetSelectedItem
	void PopulateTextLabels(struct TArray<struct FText> Labels); // Function CommonUI.CommonRotator.PopulateTextLabels
	struct FText GetSelectedText(); // Function CommonUI.CommonRotator.GetSelectedText
	int32_t GetSelectedIndex(); // Function CommonUI.CommonRotator.GetSelectedIndex
	void BP_OnOptionsPopulated(int32_t Count); // Function CommonUI.CommonRotator.BP_OnOptionsPopulated
	void BP_OnOptionSelected(int32_t Index); // Function CommonUI.CommonRotator.BP_OnOptionSelected
}; 



// Class CommonUI.CommonUIEditorSettings
// Size: 0xA8(Inherited: 0x28) 
struct UCommonUIEditorSettings : public UObject
{
	struct TSoftClassPtr<UObject> TemplateTextStyle;  // 0x28(0x28)
	struct TSoftClassPtr<UObject> TemplateButtonStyle;  // 0x50(0x28)
	struct TSoftClassPtr<UObject> TemplateBorderStyle;  // 0x78(0x28)
	char pad_160[8];  // 0xA0(0x8)

}; 



// Class CommonUI.CommonTextStyle
// Size: 0x1B0(Inherited: 0x28) 
struct UCommonTextStyle : public UObject
{
	struct FSlateFontInfo Font;  // 0x28(0x58)
	struct FLinearColor Color;  // 0x80(0x10)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bUsesDropShadow : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FVector2D ShadowOffset;  // 0x98(0x10)
	struct FLinearColor ShadowColor;  // 0xA8(0x10)
	struct FMargin Margin;  // 0xB8(0x10)
	char pad_200[8];  // 0xC8(0x8)
	struct FSlateBrush StrikeBrush;  // 0xD0(0xD0)
	float LineHeightPercentage;  // 0x1A0(0x4)
	char pad_420[12];  // 0x1A4(0xC)

	void GetStrikeBrush(struct FSlateBrush& OutStrikeBrush); // Function CommonUI.CommonTextStyle.GetStrikeBrush
	void GetShadowOffset(struct FVector2D& OutShadowOffset); // Function CommonUI.CommonTextStyle.GetShadowOffset
	void GetShadowColor(struct FLinearColor& OutColor); // Function CommonUI.CommonTextStyle.GetShadowColor
	void GetMargin(struct FMargin& OutMargin); // Function CommonUI.CommonTextStyle.GetMargin
	float GetLineHeightPercentage(); // Function CommonUI.CommonTextStyle.GetLineHeightPercentage
	void GetFont(struct FSlateFontInfo& OutFont); // Function CommonUI.CommonTextStyle.GetFont
	void GetColor(struct FLinearColor& OutColor); // Function CommonUI.CommonTextStyle.GetColor
}; 



// Class CommonUI.CommonUIActionRouterBase
// Size: 0x108(Inherited: 0x30) 
struct UCommonUIActionRouterBase : public ULocalPlayerSubsystem
{
	char pad_48[216];  // 0x30(0xD8)

}; 



// Class CommonUI.CommonUIInputSettings
// Size: 0x78(Inherited: 0x28) 
struct UCommonUIInputSettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bLinkCursorToGamepadFocus : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t UIActionProcessingPriority;  // 0x2C(0x4)
	struct TArray<struct FUIInputAction> InputActions;  // 0x30(0x10)
	struct TArray<struct FUIInputAction> ActionOverrides;  // 0x40(0x10)
	struct FCommonAnalogCursorSettings AnalogCursorSettings;  // 0x50(0x24)
	char pad_116[4];  // 0x74(0x4)

}; 



// Class CommonUI.CommonUILibrary
// Size: 0x28(Inherited: 0x28) 
struct UCommonUILibrary : public UBlueprintFunctionLibrary
{

	struct UWidget* FindParentWidgetOfType(struct UWidget* StartingWidget, UWidget* Type); // Function CommonUI.CommonUILibrary.FindParentWidgetOfType
}; 



// Class CommonUI.CommonVisualAttachment
// Size: 0x198(Inherited: 0x178) 
struct UCommonVisualAttachment : public USizeBox
{
	struct FVector2D ContentAnchor;  // 0x178(0x10)
	char pad_392[16];  // 0x188(0x10)

}; 



// Class CommonUI.CommonVisibilitySwitcher
// Size: 0x178(Inherited: 0x150) 
struct UCommonVisibilitySwitcher : public UOverlay
{
	uint8_t  ShownVisibility;  // 0x150(0x1)
	char pad_337[3];  // 0x151(0x3)
	int32_t ActiveWidgetIndex;  // 0x154(0x4)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool bAutoActivateSlot : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool bActivateFirstSlotOnAdding : 1;  // 0x159(0x1)
	char pad_346[30];  // 0x15A(0x1E)

	void SetActiveWidgetIndex(int32_t Index); // Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex
	void SetActiveWidget(struct UWidget* Widget); // Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget
	void IncrementActiveWidgetIndex(bool bAllowWrapping); // Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
	int32_t GetActiveWidgetIndex(); // Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex
	struct UWidget* GetActiveWidget(); // Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget
	void DecrementActiveWidgetIndex(bool bAllowWrapping); // Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
	void DeactivateVisibleSlot(); // Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot
	void ActivateVisibleSlot(); // Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot
}; 



// Class CommonUI.CommonVisibilitySwitcherSlot
// Size: 0x68(Inherited: 0x58) 
struct UCommonVisibilitySwitcherSlot : public UOverlaySlot
{
	char pad_88[16];  // 0x58(0x10)

}; 



// Class CommonUI.CommonWidgetCarousel
// Size: 0x188(Inherited: 0x140) 
struct UCommonWidgetCarousel : public UPanelWidget
{
	int32_t ActiveWidgetIndex;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)
	struct FMulticastInlineDelegate OnCurrentPageIndexChanged;  // 0x148(0x10)
	char pad_344[48];  // 0x158(0x30)

	void SetActiveWidgetIndex(int32_t Index); // Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
	void SetActiveWidget(struct UWidget* Widget); // Function CommonUI.CommonWidgetCarousel.SetActiveWidget
	void PreviousPage(); // Function CommonUI.CommonWidgetCarousel.PreviousPage
	void NextPage(); // Function CommonUI.CommonWidgetCarousel.NextPage
	struct UWidget* GetWidgetAtIndex(int32_t Index); // Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
	int32_t GetActiveWidgetIndex(); // Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
	void EndAutoScrolling(); // Function CommonUI.CommonWidgetCarousel.EndAutoScrolling
	void BeginAutoScrolling(float ScrollInterval); // Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling
}; 



