#pragma once 
#include <HorizonUI_Structs.h>
 
 
 
// Class HorizonUI.HorizonImage
// Size: 0x2B0(Inherited: 0x280) 
struct UHorizonImage : public UImage
{
	struct FBox2D UVRegion;  // 0x280(0x28)
	char pad_680[8];  // 0x2A8(0x8)

}; 



// Class HorizonUI.HorizonButton
// Size: 0x690(Inherited: 0x5D0) 
struct UHorizonButton : public UButton
{
	struct FMulticastInlineDelegate OnClickedDelegate;  // 0x5C8(0x10)
	struct FMulticastInlineDelegate OnPressedDelegate;  // 0x5D8(0x10)
	struct FMulticastInlineDelegate OnReleasedDelegate;  // 0x5E8(0x10)
	struct FMulticastInlineDelegate OnHoveredDelegate;  // 0x5F8(0x10)
	struct FMulticastInlineDelegate OnUnhoveredDelegate;  // 0x608(0x10)
	char pad_1568[112];  // 0x620(0x70)

	void OnUnhoveredButton(); // Function HorizonUI.HorizonButton.OnUnhoveredButton
	void OnReleasedButton(); // Function HorizonUI.HorizonButton.OnReleasedButton
	void OnPressedButton(); // Function HorizonUI.HorizonButton.OnPressedButton
	void OnHoveredButton(); // Function HorizonUI.HorizonButton.OnHoveredButton
	void OnHorizonButtonEvent__DelegateSignature(struct UHorizonButton* Button); // DelegateFunction HorizonUI.HorizonButton.OnHorizonButtonEvent__DelegateSignature
	void OnClickedButton(); // Function HorizonUI.HorizonButton.OnClickedButton
}; 



// Class HorizonUI.HorizonUserWidget
// Size: 0x290(Inherited: 0x290) 
struct UHorizonUserWidget : public UUserWidget
{

}; 



// Class HorizonUI.HorizonDialogueMsgDecorator
// Size: 0x28(Inherited: 0x28) 
struct UHorizonDialogueMsgDecorator : public UObject
{

	bool Run(struct UHorizonDialogueMsgTextBlock* InMsgTextBlock, struct FHorizonDialogueBlockInfo& InDialogueBlockInfo, struct FHorizonDialogueSegmentInfo& InSegInfo); // Function HorizonUI.HorizonDialogueMsgDecorator.Run
	bool PreRun(struct UHorizonDialogueMsgTextBlock* InMsgTextBlock, struct FHorizonDialogueBlockInfo& InDialogueBlockInfo, struct FHorizonDialogueSegmentInfo& InSegInfo); // Function HorizonUI.HorizonDialogueMsgDecorator.PreRun
	bool BuildSegment(struct UHorizonDialogueMsgTextBlock* InMsgTextBlock, int32_t InCurrentSegInfoIndex, struct FHorizonDialogueSegmentInfo& InCurrentSegInfo, struct TArray<struct FHorizonDialogueSegmentInfo>& InSegInfos); // Function HorizonUI.HorizonDialogueMsgDecorator.BuildSegment
}; 



// Class HorizonUI.HorizonDialogueMsgSpaceDecorator
// Size: 0x58(Inherited: 0x28) 
struct UHorizonDialogueMsgSpaceDecorator : public UHorizonDialogueMsgDecorator
{
	struct FText FirstLineSpaceL;  // 0x28(0x18)
	struct FText Space;  // 0x40(0x18)

}; 



// Class HorizonUI.HorizonButtonUserWidget
// Size: 0x4C0(Inherited: 0x290) 
struct UHorizonButtonUserWidget : public UHorizonDesignableUserWidget
{
	struct FMulticastInlineDelegate OnButtonClickedDelegate;  // 0x290(0x10)
	struct FMulticastInlineDelegate OnButtonPressedDelegate;  // 0x2A0(0x10)
	struct FMulticastInlineDelegate OnButtonReleasedDelegate;  // 0x2B0(0x10)
	struct FMulticastInlineDelegate OnButtonHoveredDelegate;  // 0x2C0(0x10)
	struct FMulticastInlineDelegate OnButtonUnhoveredDelegate;  // 0x2D0(0x10)
	struct FMulticastInlineDelegate OnButtonFocusDelegate;  // 0x2E0(0x10)
	struct FMulticastInlineDelegate OnButtonFocusLostDelegate;  // 0x2F0(0x10)
	char pad_768[168];  // 0x300(0xA8)
	struct UButton* Button_Main;  // 0x3A8(0x8)
	struct UTextBlock* TextBlock_Main;  // 0x3B0(0x8)
	struct UImage* Image_Main;  // 0x3B8(0x8)
	struct FText Text_Main;  // 0x3C0(0x18)
	char pad_984[8];  // 0x3D8(0x8)
	struct FSlateBrush SlateBrush_ImageMain;  // 0x3E0(0xD0)
	char pad_1200_1 : 7;  // 0x4B0(0x1)
	bool bFocusOnHovered : 1;  // 0x4B0(0x1)
	char pad_1201_1 : 7;  // 0x4B1(0x1)
	bool bButtonFocused : 1;  // 0x4B1(0x1)
	char pad_1202[14];  // 0x4B2(0xE)

	void ReceiveOnOnButtonFocusLost(struct FFocusEvent& InFocusEvent); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnOnButtonFocusLost
	void ReceiveOnButtonUnhovered(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonUnhovered
	void ReceiveOnButtonReleased(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonReleased
	void ReceiveOnButtonPressed(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonPressed
	void ReceiveOnButtonHovered(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonHovered
	void ReceiveOnButtonFocus(struct FFocusEvent& InFocusEvent); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonFocus
	void ReceiveOnButtonClicked(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonClicked
	void OnHorizonButtonFocusEvent__DelegateSignature(struct UHorizonButtonUserWidget* InButton, struct FFocusEvent& InFocusEvent); // DelegateFunction HorizonUI.HorizonButtonUserWidget.OnHorizonButtonFocusEvent__DelegateSignature
	void OnHorizonButtonEvent__DelegateSignature(struct UHorizonButtonUserWidget* InButton); // DelegateFunction HorizonUI.HorizonButtonUserWidget.OnHorizonButtonEvent__DelegateSignature
	void NativeOnButtonUnhovered(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonUnhovered
	void NativeOnButtonReleased(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonReleased
	void NativeOnButtonPressed(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonPressed
	void NativeOnButtonHovered(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonHovered
	void NativeOnButtonClicked(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonClicked
}; 



// Class HorizonUI.HorizonDesignableUserWidget
// Size: 0x290(Inherited: 0x290) 
struct UHorizonDesignableUserWidget : public UHorizonUserWidget
{

	void SynchronizeProperties(); // Function HorizonUI.HorizonDesignableUserWidget.SynchronizeProperties
	void OnSynchronizeProperties(); // Function HorizonUI.HorizonDesignableUserWidget.OnSynchronizeProperties
}; 



// Class HorizonUI.HorizonDialogueMsgTextBlock
// Size: 0x4D0(Inherited: 0x150) 
struct UHorizonDialogueMsgTextBlock : public UCanvasPanel
{
	char pad_336[8];  // 0x150(0x8)
	struct FMulticastInlineDelegate OnHypertextClickedDelegate;  // 0x158(0x10)
	char pad_360[24];  // 0x168(0x18)
	struct FMulticastInlineDelegate OnHypertextPressedDelegate;  // 0x180(0x10)
	char pad_400[24];  // 0x190(0x18)
	struct FMulticastInlineDelegate OnHypertextReleasedDelegate;  // 0x1A8(0x10)
	char pad_440[24];  // 0x1B8(0x18)
	struct FMulticastInlineDelegate OnHypertextHoveredDelegate;  // 0x1D0(0x10)
	char pad_480[24];  // 0x1E0(0x18)
	struct FMulticastInlineDelegate OnHypertextUnhoveredDelegate;  // 0x1F8(0x10)
	char pad_520[24];  // 0x208(0x18)
	struct FMulticastInlineDelegate OnDialogueMsgLoopFunction;  // 0x220(0x10)
	char pad_560[24];  // 0x230(0x18)
	struct FMulticastInlineDelegate OnDialogueMsgCompleteFunction;  // 0x248(0x10)
	char pad_600[24];  // 0x258(0x18)
	struct FMulticastInlineDelegate OnSetDialoguePageFunction;  // 0x270(0x10)
	char pad_640[24];  // 0x280(0x18)
	struct FMulticastInlineDelegate OnDialoguePageEndFunction;  // 0x298(0x10)
	char pad_680[24];  // 0x2A8(0x18)
	struct FMulticastInlineDelegate OnRebuildDialogueDelegate;  // 0x2C0(0x10)
	char pad_720[24];  // 0x2D0(0x18)
	struct FMulticastInlineDelegate OnCustomEventDelegate;  // 0x2E8(0x10)
	char pad_760[24];  // 0x2F8(0x18)
	struct FMulticastInlineDelegate OnCharAdvancedDelegate;  // 0x310(0x10)
	char pad_800[24];  // 0x320(0x18)
	struct FText Text;  // 0x338(0x18)
	uint8_t  TextOverFlowWrapMethod;  // 0x350(0x1)
	uint8_t  TextOverFlowWarpMethod;  // 0x351(0x1)
	char pad_850[2];  // 0x352(0x2)
	float DialogueMsgSpeed;  // 0x354(0x4)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool bIsStartTickDialogueMsg : 1;  // 0x358(0x1)
	char pad_857_1 : 7;  // 0x359(0x1)
	bool bIsRepeatDialogueMsg : 1;  // 0x359(0x1)
	char pad_858[2];  // 0x35A(0x2)
	float RepeatDialogueMsgInterval;  // 0x35C(0x4)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool bIsDialogueMsgText : 1;  // 0x360(0x1)
	char pad_865_1 : 7;  // 0x361(0x1)
	bool bIsAutoNextDialogueMsgPage : 1;  // 0x361(0x1)
	char pad_866[2];  // 0x362(0x2)
	float AutoNextDialogueMsgPageIntervalRate;  // 0x364(0x4)
	float AutoNextDialogueMsgPageIntervalMin;  // 0x368(0x4)
	float AutoNextDialogueMsgPageIntervalMax;  // 0x36C(0x4)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool bIgnoreTimeDilation : 1;  // 0x370(0x1)
	char pad_881[3];  // 0x371(0x3)
	float CustomTimeDilation;  // 0x374(0x4)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool bForceRebuildDialogueMsgText : 1;  // 0x378(0x1)
	char pad_889[7];  // 0x379(0x7)
	struct TArray<UHorizonDialogueStyleInfo*> StyleInfoClassList;  // 0x380(0x10)
	struct TArray<struct FHorizonDialogueSegmentInfoStyle> SegmentStyleList;  // 0x390(0x10)
	char pad_928_1 : 7;  // 0x3A0(0x1)
	bool bIsRichText : 1;  // 0x3A0(0x1)
	char pad_929[3];  // 0x3A1(0x3)
	struct FSlateColor ColorAndOpacity;  // 0x3A4(0x14)
	struct FSlateFontInfo Font;  // 0x3B8(0x58)
	struct FVector2D ShadowOffset;  // 0x410(0x10)
	struct FLinearColor ShadowColorAndOpacity;  // 0x420(0x10)
	char ETextJustify Justification;  // 0x430(0x1)
	char pad_1073[3];  // 0x431(0x3)
	struct FMargin LineMargin;  // 0x434(0x10)
	char pad_1092[4];  // 0x444(0x4)
	UHorizonButton* DefaultButtonStyleWidgetClass;  // 0x448(0x8)
	struct TArray<UHorizonDialogueMsgDecorator*> DecoratorClasses;  // 0x450(0x10)
	char pad_1120[80];  // 0x460(0x50)
	struct TArray<struct UHorizonDialogueStyleInfo*> StyleInfoList;  // 0x4B0(0x10)
	char pad_1216[16];  // 0x4C0(0x10)

	void StopDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.StopDialogue
	void StartDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.StartDialogue
	void SkipDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.SkipDialogue
	void SkipCurrentDialoguePage(); // Function HorizonUI.HorizonDialogueMsgTextBlock.SkipCurrentDialoguePage
	void SkipCurrentDialogueMsgPageTick(); // Function HorizonUI.HorizonDialogueMsgTextBlock.SkipCurrentDialogueMsgPageTick
	void SetTextOverflowWrapMethod(uint8_t  InOverflowWrapMethod); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetTextOverflowWrapMethod
	void SetTextAndRebuildDialogue(struct FText& InText); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetTextAndRebuildDialogue
	void SetShadowOffset(struct FVector2D InShadowOffset, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetShadowOffset
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetShadowColorAndOpacity
	void SetRepeatDialogueMsgInterval(float interval); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetRepeatDialogueMsgInterval
	void SetOpacity(float InOpacity); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetOpacity
	void SetJustification(char ETextJustify InJustification, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetJustification
	void SetIsStartTickDialogueMsg(bool bShouldStartTick, bool bShouldResetDialogue); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsStartTickDialogueMsg
	void SetIsRepeatDialogueMsg(bool B); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsRepeatDialogueMsg
	void SetIsDialogueMsgText(bool B); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsDialogueMsgText
	void SetIsAutoNextDialogueMsgPage(bool B); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsAutoNextDialogueMsgPage
	void SetFontSize(int32_t FontSize); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetFontSize
	void SetFont(struct FSlateFontInfo InFontInfo, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetFont
	void SetDialogueMsgSpeed(float Speed, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetDialogueMsgSpeed
	void SetDialogueMsgPage(int32_t InPageIndex, bool bShouldStartTick); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetDialogueMsgPage
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetColorAndOpacity
	void SetAutoNextDialogueMsgPageIntervalRate(float InAutoNextDialogueMsgPageIntervalRate); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetAutoNextDialogueMsgPageIntervalRate
	void ResumeDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.ResumeDialogue
	void RequestRebuildDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.RequestRebuildDialogue
	void PrevDialogueMsgPage(bool bShouldStartTick); // Function HorizonUI.HorizonDialogueMsgTextBlock.PrevDialogueMsgPage
	void PauseDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.PauseDialogue
	void OnHorizonHypertextEvent__DelegateSignature(struct FHorizonDialogueHypertextResult& InResult); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonHypertextEvent__DelegateSignature
	void OnHorizonDialoguePageEvent__DelegateSignature(struct FHorizonDialogueDialoguePageResult& InResult); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialoguePageEvent__DelegateSignature
	void OnHorizonDialogueMsgEvent__DelegateSignature(); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueMsgEvent__DelegateSignature
	void OnHorizonDialogueCustomEvent__DelegateSignature(struct FString InEventName, struct FHorizonDialogueSegmentInfo& InSegInfo); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueCustomEvent__DelegateSignature
	void OnHorizonDialogueCharAdvancedEvent__DelegateSignature(struct FHorizonDialogueBlockInfo& InCurrentBlockInfo); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueCharAdvancedEvent__DelegateSignature
	void NextDialogueMsgPage(bool bShouldStartTick); // Function HorizonUI.HorizonDialogueMsgTextBlock.NextDialogueMsgPage
	bool IsDialogueMsgPageEnd(); // Function HorizonUI.HorizonDialogueMsgTextBlock.IsDialogueMsgPageEnd
	bool IsDialogueMsgCompleted(); // Function HorizonUI.HorizonDialogueMsgTextBlock.IsDialogueMsgCompleted
	uint8_t  GetTextOverflowWrapMethod(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetTextOverflowWrapMethod
	int32_t GetTextLength(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetTextLength
	struct FText GetText(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetText
	struct FText GetPageTextByIndex(int32_t PageIndex); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetPageTextByIndex
	int32_t GetNumPage(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetNumPage
	char ETextJustify GetJustification(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetJustification
	int32_t GetCurrentPageTextLength(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetCurrentPageTextLength
	int32_t GetCurrentPageIndex(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetCurrentPageIndex
}; 



// Class HorizonUI.HorizonDialogueStyleInfo
// Size: 0x38(Inherited: 0x28) 
struct UHorizonDialogueStyleInfo : public UObject
{
	struct TArray<struct FHorizonDialogueSegmentInfoStyle> SegmentStyleList;  // 0x28(0x10)

}; 



// Class HorizonUI.HorizonFileSystem
// Size: 0x38(Inherited: 0x28) 
struct UHorizonFileSystem : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct UObject* LoadUAsset(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadUAsset
	struct UTexture2D* LoadTexture2D(struct FString InPackageFilePath, int32_t& OutWidth, int32_t& OutHeight); // Function HorizonUI.HorizonFileSystem.LoadTexture2D
	struct USoundBase* LoadSound(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadSound
	struct UPaperFlipbook* LoadPaperFlipbook(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadPaperFlipbook
	struct UMaterial* LoadMaterial(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadMaterial
	struct UFont* LoadFont(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadFont
	struct UHorizonFileSystem* GetInstance(); // Function HorizonUI.HorizonFileSystem.GetInstance
	void DestroyInstance(); // Function HorizonUI.HorizonFileSystem.DestroyInstance
	void CreateDirectoryRecursively(struct FString InFolderToMake); // Function HorizonUI.HorizonFileSystem.CreateDirectoryRecursively
}; 



// Class HorizonUI.HorizonFlipbookWidget
// Size: 0x300(Inherited: 0x280) 
struct UHorizonFlipbookWidget : public UImage
{
	char pad_640[8];  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool bIsStartTick : 1;  // 0x288(0x1)
	char pad_649[3];  // 0x289(0x3)
	int32_t NumOfLoop;  // 0x28C(0x4)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bAnimationFinished : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct UPaperFlipbook* PaperFlipbook;  // 0x298(0x8)
	struct FMulticastInlineDelegate OnAnimationStart;  // 0x2A0(0x10)
	char pad_688[24];  // 0x2B0(0x18)
	struct FMulticastInlineDelegate OnAnimationFinished;  // 0x2C8(0x10)
	char pad_728[40];  // 0x2D8(0x28)

	void StopAnimation(); // Function HorizonUI.HorizonFlipbookWidget.StopAnimation
	void SetFlipbook(struct UPaperFlipbook* InFlipbook); // Function HorizonUI.HorizonFlipbookWidget.SetFlipbook
	void SetCurrentAnimationDuration(float InDuration); // Function HorizonUI.HorizonFlipbookWidget.SetCurrentAnimationDuration
	void ResumeAnimation(); // Function HorizonUI.HorizonFlipbookWidget.ResumeAnimation
	void ResetAnimation(); // Function HorizonUI.HorizonFlipbookWidget.ResetAnimation
	void PlayAnimation(); // Function HorizonUI.HorizonFlipbookWidget.PlayAnimation
	void PauseAnimation(); // Function HorizonUI.HorizonFlipbookWidget.PauseAnimation
	void OnHorizonFlipbookStartEvent__DelegateSignature(int32_t InCurrentNumOfLoop); // DelegateFunction HorizonUI.HorizonFlipbookWidget.OnHorizonFlipbookStartEvent__DelegateSignature
	void OnHorizonFlipbookEvent__DelegateSignature(); // DelegateFunction HorizonUI.HorizonFlipbookWidget.OnHorizonFlipbookEvent__DelegateSignature
	float GetCurrentAnimationDuration(); // Function HorizonUI.HorizonFlipbookWidget.GetCurrentAnimationDuration
}; 



// Class HorizonUI.HorizonMultiToggleButtonWidget
// Size: 0x318(Inherited: 0x290) 
struct UHorizonMultiToggleButtonWidget : public UHorizonDesignableUserWidget
{
	struct FMulticastInlineDelegate OnStateSyncDelegate;  // 0x290(0x10)
	char pad_672[24];  // 0x2A0(0x18)
	struct FMulticastInlineDelegate OnStateChangedDelegate;  // 0x2B8(0x10)
	char pad_712[24];  // 0x2C8(0x18)
	struct UButton* Button_ToggleState_Prev;  // 0x2E0(0x8)
	struct UButton* Button_ToggleState_Next;  // 0x2E8(0x8)
	struct UTextBlock* TextBlock_CurrentState;  // 0x2F0(0x8)
	struct UImage* Image_CurrentState;  // 0x2F8(0x8)
	struct TArray<struct FHorizonMultiToggleButtonState> StateList;  // 0x300(0x10)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool bLoopToggleState : 1;  // 0x310(0x1)
	char pad_785[3];  // 0x311(0x3)
	int32_t CurrentStateIndex;  // 0x314(0x4)

	void ToggleState_Prev(); // Function HorizonUI.HorizonMultiToggleButtonWidget.ToggleState_Prev
	void ToggleState_Next(); // Function HorizonUI.HorizonMultiToggleButtonWidget.ToggleState_Next
	void SetLoopToggleState(bool InLoopToggleState); // Function HorizonUI.HorizonMultiToggleButtonWidget.SetLoopToggleState
	void SetCurrentStateIndex(int32_t InStateIndex); // Function HorizonUI.HorizonMultiToggleButtonWidget.SetCurrentStateIndex
	void OnHorizonMultiToggleButtonSyncEvent__DelegateSignature(int32_t InCurrentStateIndex); // DelegateFunction HorizonUI.HorizonMultiToggleButtonWidget.OnHorizonMultiToggleButtonSyncEvent__DelegateSignature
	void OnHorizonMultiToggleButtonEvent__DelegateSignature(int32_t InCurrentStateIndex, int32_t InToStateIndex); // DelegateFunction HorizonUI.HorizonMultiToggleButtonWidget.OnHorizonMultiToggleButtonEvent__DelegateSignature
	int32_t GetToggleState_PrevIndex(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetToggleState_PrevIndex
	int32_t GetToggleState_NextIndex(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetToggleState_NextIndex
	bool GetLoopToggleState(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetLoopToggleState
	int32_t GetCurrentStateIndex(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetCurrentStateIndex
}; 



// Class HorizonUI.HorizonRadioButtonUserWidget
// Size: 0x320(Inherited: 0x290) 
struct UHorizonRadioButtonUserWidget : public UHorizonDesignableUserWidget
{
	struct FMulticastInlineDelegate OnCheckedDelegate;  // 0x290(0x10)
	struct FMulticastInlineDelegate OnUnCheckedDelegate;  // 0x2A0(0x10)
	char pad_688[48];  // 0x2B0(0x30)
	struct UCheckBox* CheckBox_Main;  // 0x2E0(0x8)
	struct UTextBlock* TextBlock_Main;  // 0x2E8(0x8)
	struct FText Text_Main;  // 0x2F0(0x18)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool bCheckedByDefault : 1;  // 0x308(0x1)
	char pad_777[23];  // 0x309(0x17)

	void SetChecked(); // Function HorizonUI.HorizonRadioButtonUserWidget.SetChecked
	void OnHorizonRadioButtonEvent__DelegateSignature(); // DelegateFunction HorizonUI.HorizonRadioButtonUserWidget.OnHorizonRadioButtonEvent__DelegateSignature
	void NativeOnCheckStateChanged(bool bIsChecked); // Function HorizonUI.HorizonRadioButtonUserWidget.NativeOnCheckStateChanged
	void BP_OnCheckStateChanged(bool bIsChecked); // Function HorizonUI.HorizonRadioButtonUserWidget.BP_OnCheckStateChanged
}; 



// Class HorizonUI.HorizonTextBlock
// Size: 0x310(Inherited: 0x310) 
struct UHorizonTextBlock : public UTextBlock
{

	char ETextJustify GetJustification(); // Function HorizonUI.HorizonTextBlock.GetJustification
}; 



// Class HorizonUI.HorizonTileView
// Size: 0xC00(Inherited: 0xC00) 
struct UHorizonTileView : public UTileView
{

}; 



// Class HorizonUI.HorizonWidgetFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UHorizonWidgetFunctionLibrary : public UBlueprintFunctionLibrary
{

	struct UWidget* SetWidgetVisibility(struct UUserWidget* UserWidget, struct FName WidgetName, uint8_t  eVisiblity); // Function HorizonUI.HorizonWidgetFunctionLibrary.SetWidgetVisibility
	void SetInputMode(struct APlayerController* InPC, uint8_t  InInputMode, struct UWidget* InWidgetToFocus, uint8_t  InMouseLockMode, bool bInHideCursorDuringCapture); // Function HorizonUI.HorizonWidgetFunctionLibrary.SetInputMode
	struct UWidget* GetWidgetFromNameRecursively(struct UUserWidget* pUserWidget, struct FName& InWidgetName); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetWidgetFromNameRecursively
	struct UWidgetAnimation* GetUserWidgetAnimation(struct UUserWidget* pUserWidget, struct FName& animeName); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetUserWidgetAnimation
	int32_t GetUserIndex(struct UWidget* InWidget); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetUserIndex
	struct UCanvasPanelSlot* GetParentCanvasPanelSlot(struct UWidget* pWidget); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetParentCanvasPanelSlot
	uint8_t  GetInputMode(struct APlayerController* InPC); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetInputMode
}; 



