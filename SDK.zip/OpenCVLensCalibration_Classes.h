#pragma once 
#include <OpenCVLensCalibration_Structs.h>
 
 
 
// Class OpenCVLensCalibration.OpenCVLensCalibrator
// Size: 0x90(Inherited: 0x28) 
struct UOpenCVLensCalibrator : public UObject
{
	struct FVector2D MinimumCornerCoordinates;  // 0x28(0x10)
	struct FVector2D MaximumCornerCoordinates;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	bool FeedRenderTarget(struct UTextureRenderTarget2D* TextureRenderTarget); // Function OpenCVLensCalibration.OpenCVLensCalibrator.FeedRenderTarget
	bool FeedImage(struct FString FilePath); // Function OpenCVLensCalibration.OpenCVLensCalibrator.FeedImage
	struct UOpenCVLensCalibrator* CreateCalibrator(int32_t BoardWidth, int32_t BoardHeight, float SquareSize, bool bUseFisheyeModel); // Function OpenCVLensCalibration.OpenCVLensCalibrator.CreateCalibrator
	bool CalculateLensParameters(struct FOpenCVLensDistortionParameters& LensDistortionParameters, float& MarginOfError, struct FOpenCVCameraViewInfo& CameraViewInfo); // Function OpenCVLensCalibration.OpenCVLensCalibrator.CalculateLensParameters
}; 



