#pragma once 
#include <JsonBlueprintUtilities_Structs.h>
 
 
 
// Class JsonBlueprintUtilities.JsonBlueprintFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UJsonBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{

	bool ToString(struct FJsonObjectWrapper& JsonObject, struct FString& OutJsonString); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.ToString
	bool ToFile(struct FJsonObjectWrapper& JsonObject, struct FFilePath& File); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.ToFile
	bool SetField(struct FJsonObjectWrapper& JsonObject, struct FString FieldName, int32_t& Value); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.SetField
	bool HasField(struct FJsonObjectWrapper& JsonObject, struct FString FieldName); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.HasField
	bool GetFieldNames(struct FJsonObjectWrapper& JsonObject, struct TArray<struct FString>& FieldNames); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.GetFieldNames
	bool GetField(struct FJsonObjectWrapper& JsonObject, struct FString FieldName, int32_t& OutValue); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.GetField
	bool FromString(struct UObject* WorldContextObject, struct FString JsonString, struct FJsonObjectWrapper& OutJsonObject); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.FromString
	bool FromFile(struct UObject* WorldContextObject, struct FFilePath& File, struct FJsonObjectWrapper& OutJsonObject); // Function JsonBlueprintUtilities.JsonBlueprintFunctionLibrary.FromFile
}; 



