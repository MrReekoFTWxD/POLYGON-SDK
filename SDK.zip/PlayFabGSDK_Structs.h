#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction PlayFabGSDK.OnGSDKHealthCheck_Dyn__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnGSDKHealthCheck_Dyn__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction PlayFabGSDK.OnGSDKMaintenance_Dyn__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnGSDKMaintenance_Dyn__DelegateSignature
{
	struct FDateTime MaintenanceTime;  // 0x0(0x8)

}; 
// ScriptStruct PlayFabGSDK.ConnectedPlayer
// Size: 0x10(Inherited: 0x0) 
struct FConnectedPlayer
{
	struct FString PlayerId;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetBuildId
// Size: 0x10(Inherited: 0x0) 
struct FGetBuildId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct PlayFabGSDK.GameServerConnectionInfo
// Size: 0x20(Inherited: 0x0) 
struct FGameServerConnectionInfo
{
	struct FString PublicIpV4Address;  // 0x0(0x10)
	struct TArray<struct FGamePort> GamePortsConfiguration;  // 0x10(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.RegisterGSDKHealthCheckDelegate
// Size: 0x10(Inherited: 0x0) 
struct FRegisterGSDKHealthCheckDelegate
{
	struct FDelegate OnGSDKHealthCheckDelegate;  // 0x0(0x10)

}; 
// ScriptStruct PlayFabGSDK.GamePort
// Size: 0x18(Inherited: 0x0) 
struct FGamePort
{
	struct FString Name;  // 0x0(0x10)
	int32_t ServerListeningPort;  // 0x10(0x4)
	int32_t ClientConnectionPort;  // 0x14(0x4)

}; 
// Function PlayFabGSDK.GSDKUtils.GetGameServerConnectionInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetGameServerConnectionInfo
{
	struct FGameServerConnectionInfo ReturnValue;  // 0x0(0x20)

}; 
// Function PlayFabGSDK.GSDKUtils.GetServerId
// Size: 0x10(Inherited: 0x0) 
struct FGetServerId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetInitialPlayers
// Size: 0x10(Inherited: 0x0) 
struct FGetInitialPlayers
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetLogsDirectory
// Size: 0x10(Inherited: 0x0) 
struct FGetLogsDirectory
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.RegisterGSDKServerActiveDelegate
// Size: 0x10(Inherited: 0x0) 
struct FRegisterGSDKServerActiveDelegate
{
	struct FDelegate OnGSDKServerActiveDelegate;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetMatchId
// Size: 0x10(Inherited: 0x0) 
struct FGetMatchId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.SetDefaultServerHostPort
// Size: 0x1(Inherited: 0x0) 
struct FSetDefaultServerHostPort
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function PlayFabGSDK.GSDKUtils.GetMatchSessionCookie
// Size: 0x10(Inherited: 0x0) 
struct FGetMatchSessionCookie
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.UpdateConnectedPlayers
// Size: 0x10(Inherited: 0x0) 
struct FUpdateConnectedPlayers
{
	struct TArray<struct FConnectedPlayer> CurrentlyConnectedPlayers;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetMetaDataValue
// Size: 0x20(Inherited: 0x0) 
struct FGetMetaDataValue
{
	struct FString MetaDataName;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetRegionName
// Size: 0x10(Inherited: 0x0) 
struct FGetRegionName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.RegisterGSDKShutdownDelegate
// Size: 0x10(Inherited: 0x0) 
struct FRegisterGSDKShutdownDelegate
{
	struct FDelegate OnGSDKShutdownDelegate;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetSharedContentDirectory
// Size: 0x10(Inherited: 0x0) 
struct FGetSharedContentDirectory
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetTitleId
// Size: 0x10(Inherited: 0x0) 
struct FGetTitleId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.GetVMId
// Size: 0x10(Inherited: 0x0) 
struct FGetVMId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.RegisterGSDKMaintenanceDelegate
// Size: 0x10(Inherited: 0x0) 
struct FRegisterGSDKMaintenanceDelegate
{
	struct FDelegate OnGSDKMaintenanceDelegate;  // 0x0(0x10)

}; 
// Function PlayFabGSDK.GSDKUtils.RegisterGSDKReadyForPlayers
// Size: 0x10(Inherited: 0x0) 
struct FRegisterGSDKReadyForPlayers
{
	struct FDelegate OnGSDKReadyForPlayersDelegate;  // 0x0(0x10)

}; 
