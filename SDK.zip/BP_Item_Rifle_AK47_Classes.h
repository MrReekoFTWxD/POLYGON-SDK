#pragma once 
#include <BP_Item_Rifle_AK47_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C
// Size: 0x598(Inherited: 0x590) 
struct ABP_Item_Rifle_AK47_C : public AItem_Weapon_Rifle
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x590(0x8)

	void SetSight(); // Function BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C.ReceiveBeginPlay
	void OnSetWeaponModules_Event(); // Function BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C.OnSetWeaponModules_Event
	void ExecuteUbergraph_BP_Item_Rifle_AK47(int32_t EntryPoint); // Function BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C.ExecuteUbergraph_BP_Item_Rifle_AK47
}; 



