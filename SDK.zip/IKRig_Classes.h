#pragma once 
#include <IKRig_Structs.h>
 
 
 
// Class IKRig.IKRetargetProcessor
// Size: 0x1E0(Inherited: 0x28) 
struct UIKRetargetProcessor : public UObject
{
	char pad_40[208];  // 0x28(0xD0)
	struct UIKRigProcessor* IKRigProcessor;  // 0xF8(0x8)
	char pad_256[224];  // 0x100(0xE0)

}; 



// Class IKRig.IKRigComponent
// Size: 0xC8(Inherited: 0xB0) 
struct UIKRigComponent : public UActorComponent
{
	char pad_176[24];  // 0xB0(0x18)

	void SetIKRigGoalTransform(struct FName GoalName, struct FTransform Transform, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalTransform
	void SetIKRigGoalPositionAndRotation(struct FName GoalName, struct FVector position, struct FQuat Rotation, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalPositionAndRotation
	void SetIKRigGoal(struct FIKRigGoal& Goal); // Function IKRig.IKRigComponent.SetIKRigGoal
	void ClearAllGoals(); // Function IKRig.IKRigComponent.ClearAllGoals
}; 



// Class IKRig.IKGoalCreatorInterface
// Size: 0x28(Inherited: 0x28) 
struct UIKGoalCreatorInterface : public UInterface
{

	void AddIKGoals(struct TMap<struct FName, struct FIKRigGoal>& OutGoals); // Function IKRig.IKGoalCreatorInterface.AddIKGoals
}; 



// Class IKRig.RetargetChainSettings
// Size: 0x90(Inherited: 0x28) 
struct URetargetChainSettings : public UObject
{
	struct FName SourceChain;  // 0x28(0x8)
	struct FName TargetChain;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CopyPoseUsingFK : 1;  // 0x38(0x1)
	uint8_t  RotationMode;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float RotationAlpha;  // 0x3C(0x4)
	uint8_t  TranslationMode;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float TranslationAlpha;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool DriveIKGoal : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float BlendToSource;  // 0x4C(0x4)
	struct FVector BlendToSourceWeights;  // 0x50(0x18)
	struct FVector StaticOffset;  // 0x68(0x18)
	float Extension;  // 0x80(0x4)
	float MatchSourceVelocity;  // 0x84(0x4)
	float VelocityThreshold;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)

}; 



// Class IKRig.IKRetargeter
// Size: 0xB8(Inherited: 0x28) 
struct UIKRetargeter : public UObject
{
	struct UIKRigDefinition* SourceIKRigAsset;  // 0x28(0x8)
	struct UIKRigDefinition* TargetIKRigAsset;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bRetargetRoot : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bRetargetFK : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool bRetargetIK : 1;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)
	struct TMap<struct FName, struct FIKRetargetPose> RetargetPoses;  // 0x40(0x50)
	struct TArray<struct FRetargetChainMap> ChainMapping;  // 0x90(0x10)
	struct TArray<struct URetargetChainSettings*> ChainSettings;  // 0xA0(0x10)
	struct FName CurrentRetargetPose;  // 0xB0(0x8)

}; 



// Class IKRig.IKRigEffectorGoal
// Size: 0x100(Inherited: 0x28) 
struct UIKRigEffectorGoal : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float PositionAlpha;  // 0x38(0x4)
	float RotationAlpha;  // 0x3C(0x4)
	struct FTransform CurrentTransform;  // 0x40(0x60)
	struct FTransform InitialTransform;  // 0xA0(0x60)

}; 



// Class IKRig.IKRigDefinition
// Size: 0xE0(Inherited: 0x28) 
struct UIKRigDefinition : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct USkeletalMesh* PreviewSkeletalMesh;  // 0x30(0x8)
	struct FIKRigSkeleton Skeleton;  // 0x38(0x70)
	struct TArray<struct UIKRigEffectorGoal*> Goals;  // 0xA8(0x10)
	struct TArray<struct UIKRigSolver*> Solvers;  // 0xB8(0x10)
	struct FRetargetDefinition RetargetDefinition;  // 0xC8(0x18)

}; 



// Class IKRig.IKRig_PoleSolverEffector
// Size: 0x40(Inherited: 0x28) 
struct UIKRig_PoleSolverEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float Alpha;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class IKRig.IKRigProcessor
// Size: 0x110(Inherited: 0x28) 
struct UIKRigProcessor : public UObject
{
	struct TArray<struct UIKRigSolver*> Solvers;  // 0x28(0x10)
	char pad_56[216];  // 0x38(0xD8)

}; 



// Class IKRig.IKRigSolver
// Size: 0x28(Inherited: 0x28) 
struct UIKRigSolver : public UObject
{

}; 



// Class IKRig.IKRig_BodyMoverEffector
// Size: 0x40(Inherited: 0x28) 
struct UIKRig_BodyMoverEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float InfluenceMultiplier;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class IKRig.IKRig_BodyMover
// Size: 0x78(Inherited: 0x28) 
struct UIKRig_BodyMover : public UIKRigSolver
{
	struct FName RootBone;  // 0x28(0x8)
	float PositionAlpha;  // 0x30(0x4)
	float PositionPositiveX;  // 0x34(0x4)
	float PositionNegativeX;  // 0x38(0x4)
	float PositionPositiveY;  // 0x3C(0x4)
	float PositionNegativeY;  // 0x40(0x4)
	float PositionPositiveZ;  // 0x44(0x4)
	float PositionNegativeZ;  // 0x48(0x4)
	float RotationAlpha;  // 0x4C(0x4)
	float RotateXAlpha;  // 0x50(0x4)
	float RotateYAlpha;  // 0x54(0x4)
	float RotateZAlpha;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct TArray<struct UIKRig_BodyMoverEffector*> Effectors;  // 0x60(0x10)
	char pad_112[8];  // 0x70(0x8)

}; 



// Class IKRig.IKRig_LimbEffector
// Size: 0x38(Inherited: 0x28) 
struct UIKRig_LimbEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)

}; 



// Class IKRig.IKRig_PBIKBoneSettings
// Size: 0x78(Inherited: 0x28) 
struct UIKRig_PBIKBoneSettings : public UObject
{
	struct FName bone;  // 0x28(0x8)
	float RotationStiffness;  // 0x30(0x4)
	float PositionStiffness;  // 0x34(0x4)
	uint8_t  X;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float MinX;  // 0x3C(0x4)
	float MaxX;  // 0x40(0x4)
	uint8_t  Y;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float MinY;  // 0x48(0x4)
	float MaxY;  // 0x4C(0x4)
	uint8_t  Z;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float MinZ;  // 0x54(0x4)
	float MaxZ;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bUsePreferredAngles : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FVector PreferredAngles;  // 0x60(0x18)

}; 



// Class IKRig.IKRig_LimbSolver
// Size: 0x88(Inherited: 0x28) 
struct UIKRig_LimbSolver : public UIKRigSolver
{
	struct FName RootName;  // 0x28(0x8)
	float ReachPrecision;  // 0x30(0x4)
	char EAxis HingeRotationAxis;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t MaxIterations;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bEnableLimit : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	float MinRotationAngle;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bAveragePull : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float PullDistribution;  // 0x48(0x4)
	float ReachStepAlpha;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bEnableTwistCorrection : 1;  // 0x50(0x1)
	char EAxis EndBoneForwardAxis;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct UIKRig_LimbEffector* Effector;  // 0x58(0x8)
	char pad_96[40];  // 0x60(0x28)

}; 



// Class IKRig.IKRig_FBIKEffector
// Size: 0x48(Inherited: 0x28) 
struct UIKRig_FBIKEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float StrengthAlpha;  // 0x38(0x4)
	float PullChainAlpha;  // 0x3C(0x4)
	float PinRotation;  // 0x40(0x4)
	int32_t IndexInSolver;  // 0x44(0x4)

}; 



// Class IKRig.IKRigPBIKSolver
// Size: 0xC8(Inherited: 0x28) 
struct UIKRigPBIKSolver : public UIKRigSolver
{
	struct FName RootBone;  // 0x28(0x8)
	int32_t Iterations;  // 0x30(0x4)
	float MassMultiplier;  // 0x34(0x4)
	float MinMassMultiplier;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bAllowStretch : 1;  // 0x3C(0x1)
	uint8_t  RootBehavior;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool bStartSolveFromInputPose : 1;  // 0x3E(0x1)
	char pad_63[1];  // 0x3F(0x1)
	struct TArray<struct UIKRig_FBIKEffector*> Effectors;  // 0x40(0x10)
	struct TArray<struct UIKRig_PBIKBoneSettings*> BoneSettings;  // 0x50(0x10)
	char pad_96[104];  // 0x60(0x68)

}; 



// Class IKRig.IKRig_PoleSolver
// Size: 0x60(Inherited: 0x28) 
struct UIKRig_PoleSolver : public UIKRigSolver
{
	struct FName RootName;  // 0x28(0x8)
	struct FName EndName;  // 0x30(0x8)
	struct UIKRig_PoleSolverEffector* Effector;  // 0x38(0x8)
	char pad_64[32];  // 0x40(0x20)

}; 



// Class IKRig.IKRig_SetTransformEffector
// Size: 0x30(Inherited: 0x28) 
struct UIKRig_SetTransformEffector : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnablePosition : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bEnableRotation : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	float Alpha;  // 0x2C(0x4)

}; 



// Class IKRig.IKRig_SetTransform
// Size: 0x48(Inherited: 0x28) 
struct UIKRig_SetTransform : public UIKRigSolver
{
	struct FName Goal;  // 0x28(0x8)
	struct FName RootBone;  // 0x30(0x8)
	struct UIKRig_SetTransformEffector* Effector;  // 0x38(0x8)
	char pad_64[8];  // 0x40(0x8)

}; 



