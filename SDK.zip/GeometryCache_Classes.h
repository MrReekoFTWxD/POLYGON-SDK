#pragma once 
#include <GeometryCache_Structs.h>
 
 
 
// Class GeometryCache.GeometryCacheComponent
// Size: 0x5F0(Inherited: 0x570) 
struct UGeometryCacheComponent : public UMeshComponent
{
	struct UGeometryCache* GeometryCache;  // 0x568(0x8)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool bRunning : 1;  // 0x570(0x1)
	char pad_1401_1 : 7;  // 0x579(0x1)
	bool bLooping : 1;  // 0x571(0x1)
	char pad_1402_1 : 7;  // 0x57A(0x1)
	bool bExtrapolateFrames : 1;  // 0x572(0x1)
	float StartTimeOffset;  // 0x574(0x4)
	float PlaybackSpeed;  // 0x578(0x4)
	float MotionVectorScale;  // 0x57C(0x4)
	int32_t NumTracks;  // 0x580(0x4)
	float ElapsedTime;  // 0x584(0x4)
	char pad_1423[69];  // 0x58F(0x45)
	float Duration;  // 0x5D4(0x4)
	char pad_1496_1 : 7;  // 0x5D8(0x1)
	bool bManualTick : 1;  // 0x5D8(0x1)
	char pad_1497_1 : 7;  // 0x5D9(0x1)
	bool bOverrideWireframeColor : 1;  // 0x5D9(0x1)
	char pad_1498[2];  // 0x5DA(0x2)
	struct FLinearColor WireframeOverrideColor;  // 0x5DC(0x10)
	char pad_1516[4];  // 0x5EC(0x4)

	void TickAtThisTime(float time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping); // Function GeometryCache.GeometryCacheComponent.TickAtThisTime
	void Stop(); // Function GeometryCache.GeometryCacheComponent.Stop
	void SetWireframeOverrideColor(struct FLinearColor Color); // Function GeometryCache.GeometryCacheComponent.SetWireframeOverrideColor
	void SetStartTimeOffset(float NewStartTimeOffset); // Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed
	void SetOverrideWireframeColor(bool bOverride); // Function GeometryCache.GeometryCacheComponent.SetOverrideWireframeColor
	void SetMotionVectorScale(float NewMotionVectorScale); // Function GeometryCache.GeometryCacheComponent.SetMotionVectorScale
	void SetLooping(bool bNewLooping); // Function GeometryCache.GeometryCacheComponent.SetLooping
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Function GeometryCache.GeometryCacheComponent.SetGeometryCache
	void SetExtrapolateFrames(bool bNewExtrapolating); // Function GeometryCache.GeometryCacheComponent.SetExtrapolateFrames
	void PlayReversedFromEnd(); // Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd
	void PlayReversed(); // Function GeometryCache.GeometryCacheComponent.PlayReversed
	void PlayFromStart(); // Function GeometryCache.GeometryCacheComponent.PlayFromStart
	void Play(); // Function GeometryCache.GeometryCacheComponent.Play
	void Pause(); // Function GeometryCache.GeometryCacheComponent.Pause
	bool IsPlayingReversed(); // Function GeometryCache.GeometryCacheComponent.IsPlayingReversed
	bool IsPlaying(); // Function GeometryCache.GeometryCacheComponent.IsPlaying
	bool IsLooping(); // Function GeometryCache.GeometryCacheComponent.IsLooping
	bool IsExtrapolatingFrames(); // Function GeometryCache.GeometryCacheComponent.IsExtrapolatingFrames
	struct FLinearColor GetWireframeOverrideColor(); // Function GeometryCache.GeometryCacheComponent.GetWireframeOverrideColor
	float GetStartTimeOffset(); // Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset
	float GetPlaybackSpeed(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed
	float GetPlaybackDirection(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection
	bool GetOverrideWireframeColor(); // Function GeometryCache.GeometryCacheComponent.GetOverrideWireframeColor
	int32_t GetNumberOfFrames(); // Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames
	float GetMotionVectorScale(); // Function GeometryCache.GeometryCacheComponent.GetMotionVectorScale
	float GetDuration(); // Function GeometryCache.GeometryCacheComponent.GetDuration
	float GetAnimationTime(); // Function GeometryCache.GeometryCacheComponent.GetAnimationTime
}; 



// Class GeometryCache.GeometryCache
// Size: 0x70(Inherited: 0x28) 
struct UGeometryCache : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x30(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks;  // 0x40(0x10)
	char pad_80[16];  // 0x50(0x10)
	int32_t StartFrame;  // 0x60(0x4)
	int32_t EndFrame;  // 0x64(0x4)
	uint64_t Hash;  // 0x68(0x8)

}; 



// Class GeometryCache.GeometryCacheActor
// Size: 0x280(Inherited: 0x278) 
struct AGeometryCacheActor : public AActor
{
	struct UGeometryCacheComponent* GeometryCacheComponent;  // 0x278(0x8)

	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
}; 



// Class GeometryCache.NiagaraGeometryCacheRendererProperties
// Size: 0x358(Inherited: 0xD0) 
struct UNiagaraGeometryCacheRendererProperties : public UNiagaraRendererProperties
{
	struct TArray<struct FNiagaraGeometryCacheReference> GeometryCaches;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bIsLooping : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	uint32_t ComponentCountLimit;  // 0xE4(0x4)
	struct FNiagaraVariableAttributeBinding PositionBinding;  // 0xE8(0x58)
	struct FNiagaraVariableAttributeBinding RotationBinding;  // 0x140(0x58)
	struct FNiagaraVariableAttributeBinding ScaleBinding;  // 0x198(0x58)
	struct FNiagaraVariableAttributeBinding ElapsedTimeBinding;  // 0x1F0(0x58)
	struct FNiagaraVariableAttributeBinding EnabledBinding;  // 0x248(0x58)
	struct FNiagaraVariableAttributeBinding ArrayIndexBinding;  // 0x2A0(0x58)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding;  // 0x2F8(0x58)
	int32_t RendererVisibility;  // 0x350(0x4)
	char pad_852_1 : 7;  // 0x354(0x1)
	bool bAssignComponentsOnParticleID : 1;  // 0x354(0x1)
	char pad_853[3];  // 0x355(0x3)

}; 



// Class GeometryCache.GeometryCacheCodecBase
// Size: 0x38(Inherited: 0x28) 
struct UGeometryCacheCodecBase : public UObject
{
	struct TArray<int32_t> TopologyRanges;  // 0x28(0x10)

}; 



// Class GeometryCache.GeometryCacheTrack
// Size: 0x58(Inherited: 0x28) 
struct UGeometryCacheTrack : public UObject
{
	float Duration;  // 0x28(0x4)
	char pad_44[44];  // 0x2C(0x2C)

}; 



// Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x80(Inherited: 0x58) 
struct UGeometryCacheTrack_FlipbookAnimation : public UGeometryCacheTrack
{
	uint32_t NumMeshSamples;  // 0x58(0x4)
	char pad_92[36];  // 0x5C(0x24)

	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample
}; 



// Class GeometryCache.GeometryCacheCodecRaw
// Size: 0x40(Inherited: 0x38) 
struct UGeometryCacheCodecRaw : public UGeometryCacheCodecBase
{
	int32_t DummyProperty;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class GeometryCache.GeometryCacheCodecV1
// Size: 0x40(Inherited: 0x38) 
struct UGeometryCacheCodecV1 : public UGeometryCacheCodecBase
{
	char pad_56[8];  // 0x38(0x8)

}; 



// Class GeometryCache.GeometryCacheTrackStreamable
// Size: 0xD8(Inherited: 0x58) 
struct UGeometryCacheTrackStreamable : public UGeometryCacheTrack
{
	struct UGeometryCacheCodecBase* Codec;  // 0x58(0x8)
	char pad_96[104];  // 0x60(0x68)
	float StartSampleTime;  // 0xC8(0x4)
	char pad_204[12];  // 0xCC(0xC)

}; 



// Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0x120(Inherited: 0x58) 
struct UGeometryCacheTrack_TransformAnimation : public UGeometryCacheTrack
{
	char pad_88[200];  // 0x58(0xC8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh
}; 



// Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0x120(Inherited: 0x58) 
struct UGeometryCacheTrack_TransformGroupAnimation : public UGeometryCacheTrack
{
	char pad_88[200];  // 0x58(0xC8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh
}; 



