#pragma once 
#include <BP_HUDFunctionLibrary_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HUDFunctionLibrary.BP_HUDFunctionLibrary_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_HUDFunctionLibrary_C : public UBlueprintFunctionLibrary
{

	void GetColorByID(struct FName RowName, struct UObject* __WorldContext, struct FLinearColor& Color); // Function BP_HUDFunctionLibrary.BP_HUDFunctionLibrary_C.GetColorByID
}; 



