#pragma once 
#include <BP_PG_AnimBluerpint_Menu_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C
// Size: 0x910(Inherited: 0x350) 
struct UBP_PG_AnimBluerpint_Menu_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x388(0x40)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x3C8(0x48)
	struct FAnimNode_HandIKRetargeting AnimGraphNode_HandIKRetargeting;  // 0x410(0x120)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x530(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x550(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x570(0x128)
	char pad_1688[8];  // 0x698(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0x6A0(0x270)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.AnimGraph
	void ExecuteUbergraph_BP_PG_AnimBluerpint_Menu(int32_t EntryPoint); // Function BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.ExecuteUbergraph_BP_PG_AnimBluerpint_Menu
}; 



