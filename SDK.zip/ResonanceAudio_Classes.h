#pragma once 
#include <ResonanceAudio_Structs.h>
 
 
 
// Class ResonanceAudio.ResonanceAudioSoundfieldSettings
// Size: 0x30(Inherited: 0x28) 
struct UResonanceAudioSoundfieldSettings : public USoundfieldEncodingSettingsBase
{
	uint8_t  RenderMode;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 



// Class ResonanceAudio.ResonanceAudioSettings
// Size: 0x78(Inherited: 0x28) 
struct UResonanceAudioSettings : public UObject
{
	struct FSoftObjectPath OutputSubmix;  // 0x28(0x18)
	uint8_t  QualityMode;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FSoftObjectPath GlobalReverbPreset;  // 0x48(0x18)
	struct FSoftObjectPath GlobalSourcePreset;  // 0x60(0x18)

}; 



// Class ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UResonanceAudioBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{

	void SetGlobalReverbPreset(struct UResonanceAudioReverbPluginPreset* InPreset); // Function ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary.SetGlobalReverbPreset
	struct UResonanceAudioReverbPluginPreset* GetGlobalReverbPreset(); // Function ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary.GetGlobalReverbPreset
}; 



// Class ResonanceAudio.ResonanceAudioDirectivityVisualizer
// Size: 0x2F8(Inherited: 0x278) 
struct AResonanceAudioDirectivityVisualizer : public AActor
{
	char pad_632[112];  // 0x278(0x70)
	struct UMaterial* Material;  // 0x2E8(0x8)
	struct UResonanceAudioSpatializationSourceSettings* Settings;  // 0x2F0(0x8)

}; 



// Class ResonanceAudio.ResonanceAudioReverbPluginPreset
// Size: 0x170(Inherited: 0x68) 
struct UResonanceAudioReverbPluginPreset : public USoundEffectSubmixPreset
{
	char pad_104[152];  // 0x68(0x98)
	struct FResonanceAudioReverbPluginSettings Settings;  // 0x100(0x70)

	void SetRoomRotation(struct FQuat& InRotation); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomRotation
	void SetRoomPosition(struct FVector& InPosition); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomPosition
	void SetRoomMaterials(struct TArray<uint8_t >& InMaterials); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomMaterials
	void SetRoomDimensions(struct FVector& InDimensions); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomDimensions
	void SetReverbTimeModifier(float InReverbTimeModifier); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbTimeModifier
	void SetReverbGain(float InReverbGain); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbGain
	void SetReverbBrightness(float InReverbBrightness); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbBrightness
	void SetReflectionScalar(float InReflectionScalar); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReflectionScalar
	void SetEnableRoomEffects(bool bInEnableRoomEffects); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetEnableRoomEffects
}; 



// Class ResonanceAudio.ResonanceAudioSpatializationSourceSettings
// Size: 0x50(Inherited: 0x28) 
struct UResonanceAudioSpatializationSourceSettings : public USpatializationPluginSourceSettingsBase
{
	uint8_t  SpatializationMethod;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float Pattern;  // 0x2C(0x4)
	float Sharpness;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bToggleVisualization : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float Scale;  // 0x38(0x4)
	float Spread;  // 0x3C(0x4)
	uint8_t  Rolloff;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float MinDistance;  // 0x44(0x4)
	float MaxDistance;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

	void SetSoundSourceSpread(float InSpread); // Function ResonanceAudio.ResonanceAudioSpatializationSourceSettings.SetSoundSourceSpread
	void SetSoundSourceDirectivity(float InPattern, float InSharpness); // Function ResonanceAudio.ResonanceAudioSpatializationSourceSettings.SetSoundSourceDirectivity
}; 



