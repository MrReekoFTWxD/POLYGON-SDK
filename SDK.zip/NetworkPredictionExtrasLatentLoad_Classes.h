#pragma once 
#include <NetworkPredictionExtrasLatentLoad_Structs.h>
 
 
 
// Class NetworkPredictionExtrasLatentLoad.NetworkPredictionExtrasLatentLoadStubObject
// Size: 0x28(Inherited: 0x28) 
struct UNetworkPredictionExtrasLatentLoadStubObject : public UObject
{

}; 



