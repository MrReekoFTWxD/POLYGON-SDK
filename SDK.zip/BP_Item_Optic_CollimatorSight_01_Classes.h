#pragma once 
#include <BP_Item_Optic_CollimatorSight_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Optic_CollimatorSight_01.BP_Item_Optic_CollimatorSight_01_C
// Size: 0x310(Inherited: 0x310) 
struct ABP_Item_Optic_CollimatorSight_01_C : public AItem_Module_Optic
{

}; 



