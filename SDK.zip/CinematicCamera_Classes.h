#pragma once 
#include <CinematicCamera_Structs.h>
 
 
 
// Class CinematicCamera.CameraRig_Crane
// Size: 0x2A8(Inherited: 0x278) 
struct ACameraRig_Crane : public AActor
{
	float CranePitch;  // 0x278(0x4)
	float CraneYaw;  // 0x27C(0x4)
	float CraneArmLength;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool bLockMountPitch : 1;  // 0x284(0x1)
	char pad_645_1 : 7;  // 0x285(0x1)
	bool bLockMountYaw : 1;  // 0x285(0x1)
	char pad_646[2];  // 0x286(0x2)
	struct USceneComponent* TransformComponent;  // 0x288(0x8)
	struct USceneComponent* CraneYawControl;  // 0x290(0x8)
	struct USceneComponent* CranePitchControl;  // 0x298(0x8)
	struct USceneComponent* CraneCameraMount;  // 0x2A0(0x8)

}; 



// Class CinematicCamera.CameraRig_Rail
// Size: 0x298(Inherited: 0x278) 
struct ACameraRig_Rail : public AActor
{
	float CurrentPositionOnRail;  // 0x278(0x4)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool bLockOrientationToRail : 1;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct USceneComponent* TransformComponent;  // 0x280(0x8)
	struct USplineComponent* RailSplineComponent;  // 0x288(0x8)
	struct USceneComponent* RailCameraMount;  // 0x290(0x8)

	struct USplineComponent* GetRailSplineComponent(); // Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent
}; 



// Class CinematicCamera.CineCameraActor
// Size: 0x9F0(Inherited: 0x970) 
struct ACineCameraActor : public ACameraActor
{
	struct FCameraLookatTrackingSettings LookatTrackingSettings;  // 0x970(0x68)
	char pad_2520[24];  // 0x9D8(0x18)

	struct UCineCameraComponent* GetCineCameraComponent(); // Function CinematicCamera.CineCameraActor.GetCineCameraComponent
}; 



// Class CinematicCamera.CineCameraComponent
// Size: 0xB30(Inherited: 0xA20) 
struct UCineCameraComponent : public UCameraComponent
{
	struct FCameraFilmbackSettings FilmbackSettings;  // 0xA20(0xC)
	struct FCameraFilmbackSettings Filmback;  // 0xA2C(0xC)
	struct FCameraLensSettings LensSettings;  // 0xA38(0x18)
	struct FCameraFocusSettings FocusSettings;  // 0xA50(0x68)
	float CurrentFocalLength;  // 0xAB8(0x4)
	float CurrentAperture;  // 0xABC(0x4)
	float CurrentFocusDistance;  // 0xAC0(0x4)
	char pad_2756[12];  // 0xAC4(0xC)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets;  // 0xAD0(0x10)
	struct TArray<struct FNamedLensPreset> LensPresets;  // 0xAE0(0x10)
	struct FString DefaultFilmbackPresetName;  // 0xAF0(0x10)
	struct FString DefaultFilmbackPreset;  // 0xB00(0x10)
	struct FString DefaultLensPresetName;  // 0xB10(0x10)
	float DefaultLensFocalLength;  // 0xB20(0x4)
	float DefaultLensFStop;  // 0xB24(0x4)
	char pad_2856[8];  // 0xB28(0x8)

	void SetLensPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetLensPresetByName
	void SetFilmbackPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName
	void SetCurrentFocalLength(float InFocalLength); // Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength
	float GetVerticalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView
	struct TArray<struct FNamedLensPreset> GetLensPresetsCopy(); // Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy
	struct FString GetLensPresetName(); // Function CinematicCamera.CineCameraComponent.GetLensPresetName
	float GetHorizontalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView
	struct TArray<struct FNamedFilmbackPreset> GetFilmbackPresetsCopy(); // Function CinematicCamera.CineCameraComponent.GetFilmbackPresetsCopy
	struct FString GetFilmbackPresetName(); // Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName
	struct FString GetDefaultFilmbackPresetName(); // Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName
}; 



