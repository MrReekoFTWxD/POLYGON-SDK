#pragma once 
#include <BP_MenuCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MenuCharacter.BP_MenuCharacter_C
// Size: 0x330(Inherited: 0x2C0) 
struct ABP_MenuCharacter_C : public AMenuCharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct UStaticMeshComponent* Rank;  // 0x2C8(0x8)
	struct UStaticMeshComponent* Beard;  // 0x2D0(0x8)
	struct UStaticMeshComponent* Pistol;  // 0x2D8(0x8)
	struct UStaticMeshComponent* Grenade_02;  // 0x2E0(0x8)
	struct UStaticMeshComponent* Grenade_01;  // 0x2E8(0x8)
	struct UStaticMeshComponent* Pouch_03;  // 0x2F0(0x8)
	struct UStaticMeshComponent* Pouch_02;  // 0x2F8(0x8)
	struct UStaticMeshComponent* Pouch_01;  // 0x300(0x8)
	struct UStaticMeshComponent* Glowstick;  // 0x308(0x8)
	struct UStaticMeshComponent* Tool;  // 0x310(0x8)
	struct UStaticMeshComponent* Radio;  // 0x318(0x8)
	struct AActor* NewVar_1;  // 0x320(0x8)
	double NewVar_2;  // 0x328(0x8)

	void OnNotifyEnd_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnNotifyEnd_A7E365CD41E88B50E1CF3A8FFEC592C3
	void OnNotifyBegin_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnNotifyBegin_A7E365CD41E88B50E1CF3A8FFEC592C3
	void OnInterrupted_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnInterrupted_A7E365CD41E88B50E1CF3A8FFEC592C3
	void OnBlendOut_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnBlendOut_A7E365CD41E88B50E1CF3A8FFEC592C3
	void OnCompleted_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnCompleted_A7E365CD41E88B50E1CF3A8FFEC592C3
	void ReceiveBeginPlay(); // Function BP_MenuCharacter.BP_MenuCharacter_C.ReceiveBeginPlay
	void PlayAnimation(); // Function BP_MenuCharacter.BP_MenuCharacter_C.PlayAnimation
	void ExecuteUbergraph_BP_MenuCharacter(int32_t EntryPoint); // Function BP_MenuCharacter.BP_MenuCharacter_C.ExecuteUbergraph_BP_MenuCharacter
}; 



