#pragma once 
#include <CameraShake_SniperShot_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_SniperShot.CameraShake_SniperShot_C
// Size: 0x230(Inherited: 0x230) 
struct UCameraShake_SniperShot_C : public UMatineeCameraShake
{

}; 



