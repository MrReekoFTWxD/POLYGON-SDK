#pragma once 
#include "SDK.h" 
 
 
// Function BP_PG_GameInstance.BP_PG_GameInstance_C.ExecuteUbergraph_BP_PG_GameInstance
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PG_GameInstance
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
