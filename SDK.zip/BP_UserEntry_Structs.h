#pragma once 
#include "SDK.h" 
 
 
// Function BP_UserEntry.BP_UserEntry_C.OnPresenceReceived_Event
// Size: 0xD8(Inherited: 0x0) 
struct FOnPresenceReceived_Event
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FOnlineUserPresenceData Presence;  // 0x30(0xA8)

}; 
// Function BP_UserEntry.BP_UserEntry_C.ExecuteUbergraph_BP_UserEntry
// Size: 0x209(Inherited: 0x0) 
struct FExecuteUbergraph_BP_UserEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_2 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UTexture* K2Node_CustomEvent_ResultTexture_2;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_CustomEvent_bWasSuccessful : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UTexture* K2Node_CustomEvent_ResultTexture;  // 0x28(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x30(0x10)
	struct UTexture* Temp_object_Variable;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Temp_bool_Variable : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FUniqueNetIdRepl K2Node_CustomEvent_UserId_2;  // 0x50(0x30)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x80(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x88(0x10)
	struct FUniqueNetIdRepl CallFunc_GetControllerUniqueNetId_ReturnValue;  // 0x98(0x30)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0xC8(0x8)
	struct UOnlinePresenceSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0xD0(0x8)
	struct FUniqueNetIdRepl CallFunc_GetControllerUniqueNetId_ReturnValue_2;  // 0xD8(0x30)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_EqualEqual_FUniqueNetIdReplFUniqueNetIdRepl_ReturnValue : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct FUniqueNetIdRepl K2Node_CustomEvent_UserId;  // 0x110(0x30)
	struct FOnlineUserPresenceData K2Node_CustomEvent_Presence;  // 0x140(0xA8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool CallFunc_EqualEqual_FUniqueNetIdReplFUniqueNetIdRepl_ReturnValue_2 : 1;  // 0x1E9(0x1)
	char pad_490[6];  // 0x1EA(0x6)
	struct UOnlineAvatarSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_FUniqueNetIdIsValid_ReturnValue : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct UOnlineAvatarSubsystemGetAvatar* CallFunc_GetAvatar_ReturnValue;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x208(0x1)

}; 
// Function BP_UserEntry.BP_UserEntry_C.ParseUserInfo
// Size: 0x30(Inherited: 0x0) 
struct FParseUserInfo
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)

}; 
// Function BP_UserEntry.BP_UserEntry_C.OnCallFailed_824A0C6B4C2DBA1D157208B3CDEF0AE0
// Size: 0x10(Inherited: 0x0) 
struct FOnCallFailed_824A0C6B4C2DBA1D157208B3CDEF0AE0
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTexture* ResultTexture;  // 0x8(0x8)

}; 
// Function BP_UserEntry.BP_UserEntry_C.OnGetAvatarComplete_824A0C6B4C2DBA1D157208B3CDEF0AE0
// Size: 0x10(Inherited: 0x0) 
struct FOnGetAvatarComplete_824A0C6B4C2DBA1D157208B3CDEF0AE0
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTexture* ResultTexture;  // 0x8(0x8)

}; 
