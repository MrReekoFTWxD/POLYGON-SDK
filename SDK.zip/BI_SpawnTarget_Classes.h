#pragma once 
#include <BI_SpawnTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass BI_SpawnTarget.BI_SpawnTarget_C
// Size: 0x28(Inherited: 0x28) 
struct UBI_SpawnTarget_C : public UInterface
{

	void SetAsSpawnTarget(bool IsSpawnTarget); // Function BI_SpawnTarget.BI_SpawnTarget_C.SetAsSpawnTarget
	void GetTargetReference(struct AActor*& Reference); // Function BI_SpawnTarget.BI_SpawnTarget_C.GetTargetReference
}; 



