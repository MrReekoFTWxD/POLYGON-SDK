#pragma once 
#include "SDK.h" 
 
 
// Function NiagaraUIRenderer.NiagaraSystemWidget.UpdateNiagaraSystemReference
// Size: 0x8(Inherited: 0x0) 
struct FUpdateNiagaraSystemReference
{
	struct UNiagaraSystem* NewNiagaraSystem;  // 0x0(0x8)

}; 
// Function NiagaraUIRenderer.NiagaraSystemWidget.ActivateSystem
// Size: 0x1(Inherited: 0x0) 
struct FActivateSystem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Reset : 1;  // 0x0(0x1)

}; 
// Function NiagaraUIRenderer.NiagaraSystemWidget.UpdateTickWhenPaused
// Size: 0x1(Inherited: 0x0) 
struct FUpdateTickWhenPaused
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewTickWhenPaused : 1;  // 0x0(0x1)

}; 
// Function NiagaraUIRenderer.NiagaraSystemWidget.GetNiagaraComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetNiagaraComponent
{
	struct UNiagaraUIComponent* ReturnValue;  // 0x0(0x8)

}; 
