#pragma once 
#include <InputCore_Structs.h>
 
 
 
// Class InputCore.InputCoreTypes
// Size: 0x28(Inherited: 0x28) 
struct UInputCoreTypes : public UObject
{

}; 



