#pragma once 
#include <BP_PG_GameInstance_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_GameInstance.BP_PG_GameInstance_C
// Size: 0x1C0(Inherited: 0x1B8) 
struct UBP_PG_GameInstance_C : public UPG_GameInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1B8(0x8)

	void ReceiveInit(); // Function BP_PG_GameInstance.BP_PG_GameInstance_C.ReceiveInit
	void ExecuteUbergraph_BP_PG_GameInstance(int32_t EntryPoint); // Function BP_PG_GameInstance.BP_PG_GameInstance_C.ExecuteUbergraph_BP_PG_GameInstance
}; 



