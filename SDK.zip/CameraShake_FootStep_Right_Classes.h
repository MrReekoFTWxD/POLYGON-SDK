#pragma once 
#include <CameraShake_FootStep_Right_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_FootStep_Right.CameraShake_FootStep_Right_C
// Size: 0x230(Inherited: 0x230) 
struct UCameraShake_FootStep_Right_C : public UMatineeCameraShake
{

}; 



