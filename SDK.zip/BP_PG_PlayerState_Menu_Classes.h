#pragma once 
#include <BP_PG_PlayerState_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_PlayerState_Menu.BP_PG_PlayerState_Menu_C
// Size: 0x3B8(Inherited: 0x3B0) 
struct ABP_PG_PlayerState_Menu_C : public APG_PlayerState_Menu
{
	struct USceneComponent* DefaultSceneRoot;  // 0x3B0(0x8)

}; 



