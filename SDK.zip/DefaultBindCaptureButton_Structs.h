#pragma once 
#include "SDK.h" 
 
 
// Function DefaultBindCaptureButton.DefaultBindCaptureButton_C.ExecuteUbergraph_DefaultBindCaptureButton
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_DefaultBindCaptureButton
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBindCapturePrompt* CallFunc_StartCapture_ReturnValue;  // 0x8(0x8)

}; 
