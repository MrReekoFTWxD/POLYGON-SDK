#pragma once 
#include "SDK.h" 
 
 
// Function BP_MenuCharacter.BP_MenuCharacter_C.ExecuteUbergraph_BP_MenuCharacter
// Size: 0xC1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MenuCharacter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x28(0x8)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x30(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x38(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x48(0x10)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x58(0x8)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x60(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x68(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x78(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x88(0x8)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x90(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x98(0x10)
	struct FName Temp_name_Variable;  // 0xA8(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0xB0(0x8)
	struct ABP_PG_PlayerController_Menu_C* K2Node_DynamicCast_AsBP_PG_Player_Controller_Menu;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xC0(0x1)

}; 
// Function BP_MenuCharacter.BP_MenuCharacter_C.OnBlendOut_A7E365CD41E88B50E1CF3A8FFEC592C3
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_A7E365CD41E88B50E1CF3A8FFEC592C3
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MenuCharacter.BP_MenuCharacter_C.OnCompleted_A7E365CD41E88B50E1CF3A8FFEC592C3
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_A7E365CD41E88B50E1CF3A8FFEC592C3
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MenuCharacter.BP_MenuCharacter_C.OnNotifyBegin_A7E365CD41E88B50E1CF3A8FFEC592C3
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_A7E365CD41E88B50E1CF3A8FFEC592C3
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MenuCharacter.BP_MenuCharacter_C.OnInterrupted_A7E365CD41E88B50E1CF3A8FFEC592C3
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_A7E365CD41E88B50E1CF3A8FFEC592C3
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MenuCharacter.BP_MenuCharacter_C.OnNotifyEnd_A7E365CD41E88B50E1CF3A8FFEC592C3
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_A7E365CD41E88B50E1CF3A8FFEC592C3
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
