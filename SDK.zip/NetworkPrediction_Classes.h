#pragma once 
#include <NetworkPrediction_Structs.h>
 
 
 
// Class NetworkPrediction.NetworkPredictionPhysicsComponent
// Size: 0x1D0(Inherited: 0xB0) 
struct UNetworkPredictionPhysicsComponent : public UActorComponent
{
	struct FNetworkPredictionProxy NetworkPredictionProxy;  // 0xB0(0xB0)
	struct UPrimitiveComponent* UpdatedPrimitive;  // 0x160(0x8)
	char pad_360[8];  // 0x168(0x8)
	struct FReplicationProxy ReplicationProxy;  // 0x170(0x50)
	char pad_448[16];  // 0x1C0(0x10)

}; 



// Class NetworkPrediction.NetworkPhysicsManager
// Size: 0x6110(Inherited: 0x30) 
struct UNetworkPhysicsManager : public UWorldSubsystem
{
	char pad_48[24800];  // 0x30(0x60E0)

}; 



// Class NetworkPrediction.NetworkPhysicsComponent
// Size: 0xC0(Inherited: 0xB0) 
struct UNetworkPhysicsComponent : public UActorComponent
{
	struct TArray<struct FNetworkPhysicsState> NetworkPhysicsStateArray;  // 0xB0(0x10)

	int32_t GetNetworkPredictionLOD(); // Function NetworkPrediction.NetworkPhysicsComponent.GetNetworkPredictionLOD
}; 



// Class NetworkPrediction.NetworkPredictionComponent
// Size: 0x2A0(Inherited: 0xB0) 
struct UNetworkPredictionComponent : public UActorComponent
{
	struct FNetworkPredictionProxy NetworkPredictionProxy;  // 0xB0(0xB0)
	struct FReplicationProxy ReplicationProxy_ServerRPC;  // 0x160(0x50)
	struct FReplicationProxy ReplicationProxy_Autonomous;  // 0x1B0(0x50)
	struct FReplicationProxy ReplicationProxy_Simulated;  // 0x200(0x50)
	struct FReplicationProxy ReplicationProxy_Replay;  // 0x250(0x50)

	void ServerReceiveClientInput(struct FServerReplicationRPCParameter ProxyParameter); // Function NetworkPrediction.NetworkPredictionComponent.ServerReceiveClientInput
}; 



// Class NetworkPrediction.NetworkPredictionSettingsObject
// Size: 0x60(Inherited: 0x28) 
struct UNetworkPredictionSettingsObject : public UObject
{
	struct FNetworkPredictionSettings Settings;  // 0x28(0x28)
	struct TArray<struct FNetworkPredictionDevHUD> DevHUDs;  // 0x50(0x10)

}; 



// Class NetworkPrediction.NetworkPredictionReplicatedManager
// Size: 0x288(Inherited: 0x278) 
struct ANetworkPredictionReplicatedManager : public AActor
{
	struct FSharedPackageMap SharedPackageMap;  // 0x278(0x10)

}; 



// Class NetworkPrediction.NetworkPredictionWorldManager
// Size: 0x668(Inherited: 0x30) 
struct UNetworkPredictionWorldManager : public UWorldSubsystem
{
	struct ANetworkPredictionReplicatedManager* ReplicatedManager;  // 0x30(0x8)
	char pad_56[1584];  // 0x38(0x630)

}; 



