#pragma once 
#include <MeshModelingToolsExp_Structs.h>
 
 
 
// Class MeshModelingToolsExp.BakeMeshAttributeMapsToolProperties
// Size: 0x130(Inherited: 0xA8) 
struct UBakeMeshAttributeMapsToolProperties : public UInteractiveToolPropertySet
{
	int32_t MapTypes;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FString MapPreview;  // 0xB0(0x10)
	uint8_t  Resolution;  // 0xC0(0x4)
	uint8_t  BitDepth;  // 0xC4(0x4)
	uint8_t  SamplesPerPixel;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct TArray<struct FString> MapPreviewNamesList;  // 0xD0(0x10)
	char pad_224[80];  // 0xE0(0x50)

	struct TArray<struct FString> GetMapPreviewNamesFunc(); // Function MeshModelingToolsExp.BakeMeshAttributeMapsToolProperties.GetMapPreviewNamesFunc
}; 



// Class MeshModelingToolsExp.BakeMeshAttributeMapsTool
// Size: 0x660(Inherited: 0x5F0) 
struct UBakeMeshAttributeMapsTool : public UBakeMeshAttributeMapsToolBase
{
	struct UBakeInputMeshProperties* InputMeshSettings;  // 0x5F0(0x8)
	struct UBakeMeshAttributeMapsToolProperties* Settings;  // 0x5F8(0x8)
	struct UBakeMeshAttributeMapsResultToolProperties* ResultSettings;  // 0x600(0x8)
	char pad_1544[88];  // 0x608(0x58)

}; 



// Class MeshModelingToolsExp.BakeMeshAttributeMapsToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBakeMeshAttributeMapsToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.ImplicitSmoothProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UImplicitSmoothProperties : public UInteractiveToolPropertySet
{
	float SmoothSpeed;  // 0xA8(0x4)
	float Smoothness;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreserveUVs : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float VolumeCorrection;  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.InflateBrushOpProps
// Size: 0xB0(Inherited: 0xA8) 
struct UInflateBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.AlignObjectsToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UAlignObjectsToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.SpaceDeformerOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct USpaceDeformerOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UMeshSpaceDeformerTool* SpaceDeformerTool;  // 0x30(0x8)

}; 



// Class MeshModelingToolsExp.AlignObjectsToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UAlignObjectsToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  AlignType;  // 0xA8(0x4)
	uint8_t  AlignTo;  // 0xAC(0x4)
	uint8_t  BoxPosition;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bAlignX : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bAlignY : 1;  // 0xB5(0x1)
	char pad_182_1 : 7;  // 0xB6(0x1)
	bool bAlignZ : 1;  // 0xB6(0x1)
	char pad_183[1];  // 0xB7(0x1)

}; 



// Class MeshModelingToolsExp.AcceptOutputProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UAcceptOutputProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bExportSeparatedPiecesAsNewMeshAssets : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MeshModelingToolsExp.AddPatchToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UAddPatchToolBuilder : public UInteractiveToolBuilder
{

}; 



// Class MeshModelingToolsExp.CubeGridDuringActivityActions
// Size: 0xB0(Inherited: 0xA8) 
struct UCubeGridDuringActivityActions : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void Done(); // Function MeshModelingToolsExp.CubeGridDuringActivityActions.Done
	void Cancel(); // Function MeshModelingToolsExp.CubeGridDuringActivityActions.Cancel
}; 



// Class MeshModelingToolsExp.OffsetMeshTool
// Size: 0x420(Inherited: 0x400) 
struct UOffsetMeshTool : public UBaseMeshProcessingTool
{
	struct UOffsetMeshToolProperties* OffsetProperties;  // 0x400(0x8)
	struct UIterativeOffsetProperties* IterativeProperties;  // 0x408(0x8)
	struct UImplicitOffsetProperties* ImplicitProperties;  // 0x410(0x8)
	struct UOffsetWeightMapSetProperties* WeightMapProperties;  // 0x418(0x8)

}; 



// Class MeshModelingToolsExp.MeshAttributePaintEditActions
// Size: 0xB0(Inherited: 0xA8) 
struct UMeshAttributePaintEditActions : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

}; 



// Class MeshModelingToolsExp.AddPatchToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UAddPatchToolProperties : public UInteractiveToolPropertySet
{
	float Width;  // 0xA8(0x4)
	float Rotation;  // 0xAC(0x4)
	int32_t Subdivisions;  // 0xB0(0x4)
	float Shift;  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.AlignObjectsTool
// Size: 0x158(Inherited: 0xB8) 
struct UAlignObjectsTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UAlignObjectsToolProperties* AlignProps;  // 0xC0(0x8)
	char pad_200[144];  // 0xC8(0x90)

}; 



// Class MeshModelingToolsExp.AddPatchTool
// Size: 0x128(Inherited: 0xA0) 
struct UAddPatchTool : public USingleClickTool
{
	char pad_160[8];  // 0xA0(0x8)
	struct UAddPatchToolProperties* ShapeSettings;  // 0xA8(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0xB0(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0xB8(0x8)
	char pad_192[104];  // 0xC0(0x68)

}; 



// Class MeshModelingToolsExp.DrawPolyPathToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UDrawPolyPathToolBuilder : public UMeshSurfacePointToolBuilder
{

}; 



// Class MeshModelingToolsExp.MeshSelectionEditActions
// Size: 0xB0(Inherited: 0xB0) 
struct UMeshSelectionEditActions : public UMeshSelectionToolActionPropertySet
{

	void Shrink(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Shrink
	void SelectAll(); // Function MeshModelingToolsExp.MeshSelectionEditActions.SelectAll
	void OptimizeBorder(); // Function MeshModelingToolsExp.MeshSelectionEditActions.OptimizeBorder
	void LargestTriCountPart(); // Function MeshModelingToolsExp.MeshSelectionEditActions.LargestTriCountPart
	void LargestAreaPart(); // Function MeshModelingToolsExp.MeshSelectionEditActions.LargestAreaPart
	void Invert(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Invert
	void Grow(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Grow
	void FloodFill(); // Function MeshModelingToolsExp.MeshSelectionEditActions.FloodFill
	void Clear(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Clear
}; 



// Class MeshModelingToolsExp.BakeMeshAttributeTool
// Size: 0x490(Inherited: 0xB8) 
struct UBakeMeshAttributeTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UBakeOcclusionMapToolProperties* OcclusionSettings;  // 0xC0(0x8)
	struct UBakeCurvatureMapToolProperties* CurvatureSettings;  // 0xC8(0x8)
	struct UBakeTexture2DProperties* TextureSettings;  // 0xD0(0x8)
	struct UBakeMultiTexture2DProperties* MultiTextureSettings;  // 0xD8(0x8)
	struct UMaterialInstanceDynamic* WorkingPreviewMaterial;  // 0xE0(0x8)
	struct UMaterialInstanceDynamic* ErrorPreviewMaterial;  // 0xE8(0x8)
	char pad_240[928];  // 0xF0(0x3A0)

}; 



// Class MeshModelingToolsExp.DeformMeshPolygonsToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UDeformMeshPolygonsToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.BakeMeshAttributeMapsToolBase
// Size: 0x5F0(Inherited: 0x490) 
struct UBakeMeshAttributeMapsToolBase : public UBakeMeshAttributeTool
{
	struct UBakeVisualizationProperties* VisualizationProps;  // 0x490(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0x498(0x8)
	struct UMaterialInstanceDynamic* PreviewMaterial;  // 0x4A0(0x8)
	struct UMaterialInstanceDynamic* BentNormalPreviewMaterial;  // 0x4A8(0x8)
	char pad_1200[64];  // 0x4B0(0x40)
	struct TMap<uint8_t , struct UTexture2D*> CachedMaps;  // 0x4F0(0x50)
	char pad_1344[152];  // 0x540(0x98)
	struct UTexture2D* EmptyNormalMap;  // 0x5D8(0x8)
	struct UTexture2D* EmptyColorMapBlack;  // 0x5E0(0x8)
	struct UTexture2D* EmptyColorMapWhite;  // 0x5E8(0x8)

}; 



// Class MeshModelingToolsExp.BakeMeshAttributeVertexTool
// Size: 0x590(Inherited: 0x490) 
struct UBakeMeshAttributeVertexTool : public UBakeMeshAttributeTool
{
	struct UBakeInputMeshProperties* InputMeshSettings;  // 0x490(0x8)
	struct UBakeMeshAttributeVertexToolProperties* Settings;  // 0x498(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0x4A0(0x8)
	struct UMaterialInstanceDynamic* PreviewMaterial;  // 0x4A8(0x8)
	struct UMaterialInstanceDynamic* PreviewAlphaMaterial;  // 0x4B0(0x8)
	char pad_1208[216];  // 0x4B8(0xD8)

}; 



// Class MeshModelingToolsExp.BakeMeshAttributeVertexToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UBakeMeshAttributeVertexToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  OutputMode;  // 0xA8(0x4)
	int32_t OutputType;  // 0xAC(0x4)
	int32_t OutputTypeR;  // 0xB0(0x4)
	int32_t OutputTypeG;  // 0xB4(0x4)
	int32_t OutputTypeB;  // 0xB8(0x4)
	int32_t OutputTypeA;  // 0xBC(0x4)
	uint8_t  PreviewMode;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bSplitAtNormalSeams : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool bSplitAtUVSeams : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)

}; 



// Class MeshModelingToolsExp.BakeMeshAttributeMapsResultToolProperties
// Size: 0xF8(Inherited: 0xA8) 
struct UBakeMeshAttributeMapsResultToolProperties : public UInteractiveToolPropertySet
{
	struct TMap<uint8_t , struct UTexture2D*> Result;  // 0xA8(0x50)

}; 



// Class MeshModelingToolsExp.BakeInputMeshProperties
// Size: 0x140(Inherited: 0xA8) 
struct UBakeInputMeshProperties : public UInteractiveToolPropertySet
{
	struct UStaticMesh* TargetStaticMesh;  // 0xA8(0x8)
	struct USkeletalMesh* TargetSkeletalMesh;  // 0xB0(0x8)
	struct AActor* TargetDynamicMesh;  // 0xB8(0x8)
	struct FString TargetUVLayer;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bHasTargetUVLayer : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UStaticMesh* SourceStaticMesh;  // 0xD8(0x8)
	struct USkeletalMesh* SourceSkeletalMesh;  // 0xE0(0x8)
	struct AActor* SourceDynamicMesh;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bHideSourceMesh : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct UTexture2D* SourceNormalMap;  // 0xF8(0x8)
	struct FString SourceNormalMapUVLayer;  // 0x100(0x10)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool bHasSourceNormalMap : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float ProjectionDistance;  // 0x114(0x4)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool bProjectionInWorldSpace : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct TArray<struct FString> TargetUVLayerNamesList;  // 0x120(0x10)
	struct TArray<struct FString> SourceUVLayerNamesList;  // 0x130(0x10)

	struct TArray<struct FString> GetTargetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeInputMeshProperties.GetTargetUVLayerNamesFunc
	struct TArray<struct FString> GetSourceUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeInputMeshProperties.GetSourceUVLayerNamesFunc
}; 



// Class MeshModelingToolsExp.RemeshProperties
// Size: 0xB8(Inherited: 0xB0) 
struct URemeshProperties : public UMeshConstraintProperties
{
	float SmoothingStrength;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bFlips : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bSplits : 1;  // 0xB5(0x1)
	char pad_182_1 : 7;  // 0xB6(0x1)
	bool bCollapses : 1;  // 0xB6(0x1)
	char pad_183[1];  // 0xB7(0x1)

}; 



// Class MeshModelingToolsExp.SmoothFillBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct USmoothFillBrushOpProps : public UBaseSmoothBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreserveUVFlow : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 



// Class MeshModelingToolsExp.BakeNormalMapToolProperties
// Size: 0xA8(Inherited: 0xA8) 
struct UBakeNormalMapToolProperties : public UInteractiveToolPropertySet
{

}; 



// Class MeshModelingToolsExp.DisplaceMeshPerlinNoiseProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UDisplaceMeshPerlinNoiseProperties : public UInteractiveToolPropertySet
{
	struct TArray<struct FPerlinLayerProperties> PerlinLayerProperties;  // 0xA8(0x10)

}; 



// Class MeshModelingToolsExp.ConvertMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UConvertMeshesToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.PhysicsInspectorToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UPhysicsInspectorToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.BakeOcclusionMapToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UBakeOcclusionMapToolProperties : public UInteractiveToolPropertySet
{
	int32_t OcclusionRays;  // 0xA8(0x4)
	float MaxDistance;  // 0xAC(0x4)
	float SpreadAngle;  // 0xB0(0x4)
	float BiasAngle;  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.BakeMultiMeshAttributeMapsToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBakeMultiMeshAttributeMapsToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.BakeCurvatureMapToolProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UBakeCurvatureMapToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  CurvatureType;  // 0xA8(0x4)
	uint8_t  ColorMapping;  // 0xAC(0x4)
	float ColorRangeMultiplier;  // 0xB0(0x4)
	float MinRangeMultiplier;  // 0xB4(0x4)
	uint8_t  Clamping;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.BakeTexture2DProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UBakeTexture2DProperties : public UInteractiveToolPropertySet
{
	struct UTexture2D* SourceTexture;  // 0xA8(0x8)
	struct FString UVLayer;  // 0xB0(0x10)
	struct TArray<struct FString> UVLayerNamesList;  // 0xC0(0x10)

	struct TArray<struct FString> GetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeTexture2DProperties.GetUVLayerNamesFunc
}; 



// Class MeshModelingToolsExp.PhysicsObjectToolPropertySet
// Size: 0x100(Inherited: 0xA8) 
struct UPhysicsObjectToolPropertySet : public UInteractiveToolPropertySet
{
	struct FString ObjectName;  // 0xA8(0x10)
	uint8_t  CollisionType;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct TArray<struct FPhysicsSphereData> Spheres;  // 0xC0(0x10)
	struct TArray<struct FPhysicsBoxData> Boxes;  // 0xD0(0x10)
	struct TArray<struct FPhysicsCapsuleData> Capsules;  // 0xE0(0x10)
	struct TArray<struct FPhysicsConvexData> Convexes;  // 0xF0(0x10)

}; 



// Class MeshModelingToolsExp.DynamicMeshBrushSculptProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UDynamicMeshBrushSculptProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bIsRemeshingEnabled : 1;  // 0xA8(0x1)
	uint8_t  PrimaryBrushType;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float PrimaryBrushSpeed;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreserveUVFlow : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bFreezeTarget : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	float SmoothBrushSpeed;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bDetailPreservingSmooth : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 



// Class MeshModelingToolsExp.BakeMultiTexture2DProperties
// Size: 0xE8(Inherited: 0xA8) 
struct UBakeMultiTexture2DProperties : public UInteractiveToolPropertySet
{
	struct TArray<struct UTexture2D*> MaterialIDSourceTextures;  // 0xA8(0x10)
	struct FString UVLayer;  // 0xB8(0x10)
	struct TArray<struct FString> UVLayerNamesList;  // 0xC8(0x10)
	struct TArray<struct UTexture2D*> AllSourceTextures;  // 0xD8(0x10)

	struct TArray<struct FString> GetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeMultiTexture2DProperties.GetUVLayerNamesFunc
}; 



// Class MeshModelingToolsExp.BakeVisualizationProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UBakeVisualizationProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bPreviewAsMaterial : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float Brightness;  // 0xAC(0x4)
	float AOMultiplier;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.BakeMeshAttributeVertexToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBakeMeshAttributeVertexToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.VoxelBlendMeshesToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UVoxelBlendMeshesToolProperties : public UInteractiveToolPropertySet
{
	double BlendPower;  // 0xA8(0x8)
	double BlendFalloff;  // 0xB0(0x8)
	uint8_t  Operation;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool bVoxWrap : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool bRemoveInternalsAfterVoxWrap : 1;  // 0xBA(0x1)
	char pad_187[5];  // 0xBB(0x5)
	double ThickenShells;  // 0xC0(0x8)

}; 



// Class MeshModelingToolsExp.EraseBrushOpProps
// Size: 0xB0(Inherited: 0xA8) 
struct UEraseBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.DynamicMeshSculptToolBuilder
// Size: 0x38(Inherited: 0x30) 
struct UDynamicMeshSculptToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{
	char pad_48[8];  // 0x30(0x8)

}; 



// Class MeshModelingToolsExp.ExtractCollisionGeometryToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UExtractCollisionGeometryToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.BakeMultiMeshAttributeMapsToolProperties
// Size: 0x130(Inherited: 0xA8) 
struct UBakeMultiMeshAttributeMapsToolProperties : public UInteractiveToolPropertySet
{
	int32_t MapTypes;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FString MapPreview;  // 0xB0(0x10)
	uint8_t  Resolution;  // 0xC0(0x4)
	uint8_t  BitDepth;  // 0xC4(0x4)
	uint8_t  SamplesPerPixel;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct TArray<struct FString> MapPreviewNamesList;  // 0xD0(0x10)
	char pad_224[80];  // 0xE0(0x50)

	struct TArray<struct FString> GetMapPreviewNamesFunc(); // Function MeshModelingToolsExp.BakeMultiMeshAttributeMapsToolProperties.GetMapPreviewNamesFunc
}; 



// Class MeshModelingToolsExp.RemoveOccludedTrianglesOperatorFactory
// Size: 0x40(Inherited: 0x28) 
struct URemoveOccludedTrianglesOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct URemoveOccludedTrianglesTool* Tool;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)

}; 



// Class MeshModelingToolsExp.CubeGridToolBuilder
// Size: 0x30(Inherited: 0x28) 
struct UCubeGridToolBuilder : public UInteractiveToolWithToolTargetsBuilder
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class MeshModelingToolsExp.BakeMultiMeshInputToolProperties
// Size: 0xE8(Inherited: 0xA8) 
struct UBakeMultiMeshInputToolProperties : public UInteractiveToolPropertySet
{
	struct UStaticMesh* TargetStaticMesh;  // 0xA8(0x8)
	struct FString TargetUVLayer;  // 0xB0(0x10)
	struct TArray<struct FBakeMultiMeshDetailProperties> SourceMeshes;  // 0xC0(0x10)
	float ProjectionDistance;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct TArray<struct FString> TargetUVLayerNamesList;  // 0xD8(0x10)

	struct TArray<struct FString> GetTargetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeMultiMeshInputToolProperties.GetTargetUVLayerNamesFunc
}; 



// Class MeshModelingToolsExp.EditPivotTool
// Size: 0x230(Inherited: 0xB8) 
struct UEditPivotTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UEditPivotToolProperties* TransformProps;  // 0xC0(0x8)
	struct UEditPivotToolActionPropertySet* EditPivotActions;  // 0xC8(0x8)
	char pad_208[208];  // 0xD0(0xD0)
	struct TArray<struct FEditPivotTarget> ActiveGizmos;  // 0x1A0(0x10)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0x1B0(0x8)
	char pad_440[120];  // 0x1B8(0x78)

}; 



// Class MeshModelingToolsExp.BakeMultiMeshAttributeMapsTool
// Size: 0x6A0(Inherited: 0x5F0) 
struct UBakeMultiMeshAttributeMapsTool : public UBakeMeshAttributeMapsToolBase
{
	struct UBakeMultiMeshAttributeMapsToolProperties* Settings;  // 0x5F0(0x8)
	struct UBakeMultiMeshInputToolProperties* InputMeshSettings;  // 0x5F8(0x8)
	struct UBakeMeshAttributeMapsResultToolProperties* ResultSettings;  // 0x600(0x8)
	char pad_1544[152];  // 0x608(0x98)

}; 



// Class MeshModelingToolsExp.DisplaceMeshSineWaveProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UDisplaceMeshSineWaveProperties : public UInteractiveToolPropertySet
{
	float SineWaveFrequency;  // 0xA8(0x4)
	float SineWavePhaseShift;  // 0xAC(0x4)
	struct FVector SineWaveDirection;  // 0xB0(0x18)

}; 



// Class MeshModelingToolsExp.RevolveBoundaryToolProperties
// Size: 0x148(Inherited: 0x118) 
struct URevolveBoundaryToolProperties : public URevolveProperties
{
	uint8_t  CapFillMode;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool bDisplayInputMesh : 1;  // 0x119(0x1)
	char pad_282[6];  // 0x11A(0x6)
	struct FVector AxisOrigin;  // 0x120(0x18)
	struct FVector2D AxisOrientation;  // 0x138(0x10)

}; 



// Class MeshModelingToolsExp.ConvertToPolygonsToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UConvertToPolygonsToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.BakeTransformToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBakeTransformToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.BakeTransformToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UBakeTransformToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bBakeRotation : 1;  // 0xA8(0x1)
	uint8_t  BakeScale;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bRecenterPivot : 1;  // 0xAA(0x1)
	char pad_171[5];  // 0xAB(0x5)

}; 



// Class MeshModelingToolsExp.BakeTransformTool
// Size: 0xD0(Inherited: 0xB8) 
struct UBakeTransformTool : public UMultiSelectionMeshEditingTool
{
	struct UBakeTransformToolProperties* BasicProperties;  // 0xB8(0x8)
	char pad_192[16];  // 0xC0(0x10)

}; 



// Class MeshModelingToolsExp.SetCollisionGeometryToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USetCollisionGeometryToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.CollisionGeometryVisualizationProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UCollisionGeometryVisualizationProperties : public UInteractiveToolPropertySet
{
	float LineThickness;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bShowHidden : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	struct FColor Color;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.ConvertMeshesToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UConvertMeshesToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bTransferMaterials : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MeshModelingToolsExp.ConvertMeshesTool
// Size: 0xD0(Inherited: 0xB8) 
struct UConvertMeshesTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UConvertMeshesToolProperties* BasicProperties;  // 0xC0(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xC8(0x8)

}; 



// Class MeshModelingToolsExp.ConvertToPolygonsToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UConvertToPolygonsToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  ConversionMode;  // 0xA8(0x4)
	float AngleTolerance;  // 0xAC(0x4)
	int32_t NumPoints;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bSplitExisting : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bNormalWeighted : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)
	float NormalWeighting;  // 0xB8(0x4)
	int32_t MinGroupSize;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bCalculateNormals : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool bShowGroupColors : 1;  // 0xC1(0x1)
	char pad_194[6];  // 0xC2(0x6)

}; 



// Class MeshModelingToolsExp.ConvertToPolygonsOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct UConvertToPolygonsOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UConvertToPolygonsTool* ConvertToPolygonsTool;  // 0x30(0x8)

}; 



// Class MeshModelingToolsExp.ConvertToPolygonsTool
// Size: 0xF0(Inherited: 0xB8) 
struct UConvertToPolygonsTool : public USingleSelectionMeshEditingTool
{
	struct UConvertToPolygonsToolProperties* Settings;  // 0xB8(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* PreviewCompute;  // 0xC0(0x8)
	struct UPreviewGeometry* PreviewGeometry;  // 0xC8(0x8)
	char pad_208[32];  // 0xD0(0x20)

}; 



// Class MeshModelingToolsExp.CubeGridToolProperties
// Size: 0x190(Inherited: 0xA8) 
struct UCubeGridToolProperties : public UInteractiveToolPropertySet
{
	struct FVector GridFrameOrigin;  // 0xA8(0x18)
	struct FRotator GridFrameOrientation;  // 0xC0(0x18)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bShowGizmo : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	int32_t BlocksPerStep;  // 0xDC(0x4)
	char PowerOfTwo;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	double BlockBaseSize;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bCrosswiseDiagonal : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	double PlaneTolerance;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool bHitUnrelatedGeometry : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool bHitGridGroundPlaneIfCloser : 1;  // 0x101(0x1)
	char pad_258[2];  // 0x102(0x2)
	uint8_t  FaceSelectionMode;  // 0x104(0x4)
	struct FString ToggleCornerMode;  // 0x108(0x10)
	struct FString PushPull;  // 0x118(0x10)
	struct FString ResizeGrid;  // 0x128(0x10)
	struct FString SlideSelection;  // 0x138(0x10)
	struct FString FlipSelection;  // 0x148(0x10)
	struct FString GridGizmo;  // 0x158(0x10)
	struct FString QuickShiftGizmo;  // 0x168(0x10)
	struct FString AlignGizmo;  // 0x178(0x10)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool bInCornerMode : 1;  // 0x188(0x1)
	char pad_393_1 : 7;  // 0x189(0x1)
	bool bAllowedToEditGrid : 1;  // 0x189(0x1)
	char pad_394[6];  // 0x18A(0x6)

}; 



// Class MeshModelingToolsExp.CubeGridToolActions
// Size: 0xB0(Inherited: 0xA8) 
struct UCubeGridToolActions : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void SlideForward(); // Function MeshModelingToolsExp.CubeGridToolActions.SlideForward
	void SlideBack(); // Function MeshModelingToolsExp.CubeGridToolActions.SlideBack
	void Push(); // Function MeshModelingToolsExp.CubeGridToolActions.Push
	void Pull(); // Function MeshModelingToolsExp.CubeGridToolActions.Pull
	void Flip(); // Function MeshModelingToolsExp.CubeGridToolActions.Flip
	void CornerMode(); // Function MeshModelingToolsExp.CubeGridToolActions.CornerMode
}; 



// Class MeshModelingToolsExp.CubeGridTool
// Size: 0x5C0(Inherited: 0x98) 
struct UCubeGridTool : public UInteractiveTool
{
	char pad_152[32];  // 0x98(0x20)
	struct UCombinedTransformGizmo* GridGizmo;  // 0xB8(0x8)
	struct UDragAlignmentMechanic* GridGizmoAlignmentMechanic;  // 0xC0(0x8)
	struct UTransformProxy* GridGizmoTransformProxy;  // 0xC8(0x8)
	struct UPreviewGeometry* LineSets;  // 0xD0(0x8)
	struct UClickDragInputBehavior* ClickDragBehavior;  // 0xD8(0x8)
	struct UMouseHoverBehavior* HoverBehavior;  // 0xE0(0x8)
	struct ULocalSingleClickInputBehavior* CtrlMiddleClickBehavior;  // 0xE8(0x8)
	struct ULocalClickDragInputBehavior* MiddleClickDragBehavior;  // 0xF0(0x8)
	struct UCubeGridToolProperties* Settings;  // 0xF8(0x8)
	struct UCubeGridToolActions* ToolActions;  // 0x100(0x8)
	struct UCubeGridDuringActivityActions* DuringActivityActions;  // 0x108(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0x110(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0x118(0x8)
	struct UToolTarget* Target;  // 0x120(0x8)
	char pad_296[384];  // 0x128(0x180)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0x2A8(0x8)
	char pad_688[784];  // 0x2B0(0x310)

}; 



// Class MeshModelingToolsExp.DisplaceMeshTextureMapProperties
// Size: 0xF0(Inherited: 0xA8) 
struct UDisplaceMeshTextureMapProperties : public UInteractiveToolPropertySet
{
	struct UTexture2D* DisplacementMap;  // 0xA8(0x8)
	uint8_t  Channel;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float DisplacementMapBaseValue;  // 0xB4(0x4)
	struct FVector2D UVScale;  // 0xB8(0x10)
	struct FVector2D UVOffset;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bApplyAdjustmentCurve : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UCurveFloat* AdjustmentCurve;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bRecalcNormals : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)

}; 



// Class MeshModelingToolsExp.SculptMaxBrushOpProps
// Size: 0xC0(Inherited: 0xA8) 
struct USculptMaxBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float MaxHeight;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bUseFixedHeight : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	float FixedHeight;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.DeformMeshPolygonsTransformProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UDeformMeshPolygonsTransformProperties : public UInteractiveToolPropertySet
{
	uint8_t  DeformationStrategy;  // 0xA8(0x1)
	uint8_t  TransformMode;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bSelectFaces : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bSelectEdges : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bSelectVertices : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bShowWireframe : 1;  // 0xAD(0x1)
	char pad_174[2];  // 0xAE(0x2)
	uint8_t  SelectedWeightScheme;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	double HandleWeight;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bPostFixHandles : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)

}; 



// Class MeshModelingToolsExp.TransformMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UTransformMeshesToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.MeshSelectionTool
// Size: 0x680(Inherited: 0x2B0) 
struct UMeshSelectionTool : public UDynamicMeshBrushTool
{
	char pad_688[8];  // 0x2B0(0x8)
	struct UMeshSelectionToolProperties* SelectionProps;  // 0x2B8(0x8)
	struct UMeshSelectionEditActions* SelectionActions;  // 0x2C0(0x8)
	struct UMeshSelectionToolActionPropertySet* EditActions;  // 0x2C8(0x8)
	struct UMeshStatisticsProperties* MeshStatisticsProperties;  // 0x2D0(0x8)
	struct UMeshElementsVisualizer* MeshElementsDisplay;  // 0x2D8(0x8)
	struct UMeshUVChannelProperties* UVChannelProperties;  // 0x2E0(0x8)
	struct UPolygroupLayersProperties* PolygroupLayerProperties;  // 0x2E8(0x8)
	struct UMeshSelectionSet* Selection;  // 0x2F0(0x8)
	struct TArray<struct AActor*> SpawnedActors;  // 0x2F8(0x10)
	char pad_776[888];  // 0x308(0x378)

}; 



// Class MeshModelingToolsExp.DrawPolyPathTool
// Size: 0x280(Inherited: 0x98) 
struct UDrawPolyPathTool : public UInteractiveTool
{
	char pad_152[24];  // 0x98(0x18)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xB0(0x8)
	struct UDrawPolyPathProperties* TransformProps;  // 0xB8(0x8)
	struct UDrawPolyPathExtrudeProperties* ExtrudeProperties;  // 0xC0(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0xC8(0x8)
	char pad_208[192];  // 0xD0(0xC0)
	struct UConstructionPlaneMechanic* PlaneMechanic;  // 0x190(0x8)
	char pad_408[192];  // 0x198(0xC0)
	struct UPolyEditPreviewMesh* EditPreview;  // 0x258(0x8)
	struct UPlaneDistanceFromHitMechanic* ExtrudeHeightMechanic;  // 0x260(0x8)
	struct USpatialCurveDistanceMechanic* CurveDistMechanic;  // 0x268(0x8)
	struct UCollectSurfacePathMechanic* SurfacePathMechanic;  // 0x270(0x8)
	char pad_632[8];  // 0x278(0x8)

}; 



// Class MeshModelingToolsExp.MeshSelectionToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UMeshSelectionToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  SelectionMode;  // 0xA8(0x4)
	float AngleTolerance;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bHitBackFaces : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bShowPoints : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	uint8_t  FaceColorMode;  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.DeformMeshPolygonsTool
// Size: 0x1760(Inherited: 0xF8) 
struct UDeformMeshPolygonsTool : public UMeshSurfacePointTool
{
	char pad_248[8];  // 0xF8(0x8)
	struct UWorld* TargetWorld;  // 0x100(0x8)
	struct AInternalToolFrameworkActor* PreviewMeshActor;  // 0x108(0x8)
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0x110(0x8)
	struct UDeformMeshPolygonsTransformProperties* TransformProps;  // 0x118(0x8)
	char pad_288[5696];  // 0x120(0x1640)

}; 



// Class MeshModelingToolsExp.DisplaceMeshCommonProperties
// Size: 0xE0(Inherited: 0xA8) 
struct UDisplaceMeshCommonProperties : public UInteractiveToolPropertySet
{
	uint8_t  DisplacementType;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float DisplaceIntensity;  // 0xAC(0x4)
	int32_t RandomSeed;  // 0xB0(0x4)
	uint8_t  SubdivisionType;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	int32_t Subdivisions;  // 0xB8(0x4)
	struct FName WeightMap;  // 0xBC(0x8)
	char pad_196[4];  // 0xC4(0x4)
	struct TArray<struct FString> WeightMapsList;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bInvertWeightMap : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool bShowWireframe : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool bDisableSizeWarning : 1;  // 0xDA(0x1)
	char pad_219[5];  // 0xDB(0x5)

	struct TArray<struct FString> GetWeightMapsFunc(); // Function MeshModelingToolsExp.DisplaceMeshCommonProperties.GetWeightMapsFunc
}; 



// Class MeshModelingToolsExp.DisplaceMeshDirectionalFilterProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UDisplaceMeshDirectionalFilterProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnableFilter : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FVector FilterDirection;  // 0xB0(0x18)
	float FilterWidth;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class MeshModelingToolsExp.RevolveBoundaryTool
// Size: 0x220(Inherited: 0x1B0) 
struct URevolveBoundaryTool : public UMeshBoundaryToolBase
{
	char pad_432[24];  // 0x1B0(0x18)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0x1C8(0x8)
	struct URevolveBoundaryToolProperties* Settings;  // 0x1D0(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0x1D8(0x8)
	struct UConstructionPlaneMechanic* PlaneMechanic;  // 0x1E0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0x1E8(0x8)
	char pad_496[48];  // 0x1F0(0x30)

}; 



// Class MeshModelingToolsExp.GroupEraseBrushOpProps
// Size: 0xF0(Inherited: 0xA8) 
struct UGroupEraseBrushOpProps : public UMeshSculptBrushOpProps
{
	int32_t Group;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bOnlyEraseCurrent : 1;  // 0xAC(0x1)
	char pad_173[67];  // 0xAD(0x43)

}; 



// Class MeshModelingToolsExp.DisplaceMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UDisplaceMeshToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.DisplaceMeshTool
// Size: 0x450(Inherited: 0xB8) 
struct UDisplaceMeshTool : public USingleSelectionMeshEditingTool
{
	struct UDisplaceMeshCommonProperties* CommonProperties;  // 0xB8(0x8)
	struct UDisplaceMeshDirectionalFilterProperties* DirectionalFilterProperties;  // 0xC0(0x8)
	struct UDisplaceMeshTextureMapProperties* TextureMapProperties;  // 0xC8(0x8)
	struct UDisplaceMeshPerlinNoiseProperties* NoiseProperties;  // 0xD0(0x8)
	struct UDisplaceMeshSineWaveProperties* SineWaveProperties;  // 0xD8(0x8)
	struct UCurveFloat* ActiveContrastCurveTarget;  // 0xE0(0x8)
	char pad_232[824];  // 0xE8(0x338)
	struct AInternalToolFrameworkActor* PreviewMeshActor;  // 0x420(0x8)
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0x428(0x8)
	char pad_1072[32];  // 0x430(0x20)

}; 



// Class MeshModelingToolsExp.DrawPolyPathProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UDrawPolyPathProperties : public UInteractiveToolPropertySet
{
	uint8_t  WidthMode;  // 0xA8(0x4)
	float Width;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bRoundedCorners : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	uint8_t  RadiusMode;  // 0xB4(0x4)
	float CornerRadius;  // 0xB8(0x4)
	int32_t RadialSlices;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bSinglePolyGroup : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	uint8_t  ExtrudeMode;  // 0xC4(0x4)
	float ExtrudeHeight;  // 0xC8(0x4)
	float RampStartRatio;  // 0xCC(0x4)

}; 



// Class MeshModelingToolsExp.WeldMeshEdgesTool
// Size: 0xE8(Inherited: 0xB8) 
struct UWeldMeshEdgesTool : public USingleSelectionMeshEditingTool
{
	struct UWeldMeshEdgesToolProperties* Settings;  // 0xB8(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* PreviewCompute;  // 0xC0(0x8)
	struct UMeshElementsVisualizer* MeshElementsDisplay;  // 0xC8(0x8)
	struct UWeldMeshEdgesOperatorFactory* OperatorFactory;  // 0xD0(0x8)
	char pad_216[16];  // 0xD8(0x10)

}; 



// Class MeshModelingToolsExp.FlattenBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UFlattenBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float Depth;  // 0xB0(0x4)
	uint8_t  WhichSide;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.EditUVIslandsToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UEditUVIslandsToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.DrawPolyPathExtrudeProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UDrawPolyPathExtrudeProperties : public UInteractiveToolPropertySet
{
	uint8_t  Direction;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.PlaneBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UPlaneBrushOpProps : public UBasePlaneBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float Depth;  // 0xB0(0x4)
	uint8_t  WhichSide;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.DynamicMeshBrushTool
// Size: 0x2B0(Inherited: 0x270) 
struct UDynamicMeshBrushTool : public UBaseBrushTool
{
	struct UPreviewMesh* PreviewMesh;  // 0x270(0x8)
	char pad_632[56];  // 0x278(0x38)

}; 



// Class MeshModelingToolsExp.DynamicMeshBrushProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UDynamicMeshBrushProperties : public UInteractiveToolPropertySet
{
	struct FBrushToolRadius BrushSize;  // 0xA8(0x14)
	float BrushFalloffAmount;  // 0xBC(0x4)
	float Depth;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bHitBackFaces : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)

}; 



// Class MeshModelingToolsExp.MeshConstraintProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UMeshConstraintProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bPreserveSharpEdges : 1;  // 0xA8(0x1)
	uint8_t  MeshBoundaryConstraint;  // 0xA9(0x1)
	uint8_t  GroupBoundaryConstraint;  // 0xAA(0x1)
	uint8_t  MaterialBoundaryConstraint;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bPreventNormalFlips : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingToolsExp.DynamicSculptToolActions
// Size: 0xB0(Inherited: 0xA8) 
struct UDynamicSculptToolActions : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void DiscardAttributes(); // Function MeshModelingToolsExp.DynamicSculptToolActions.DiscardAttributes
}; 



// Class MeshModelingToolsExp.BrushRemeshProperties
// Size: 0xC8(Inherited: 0xB8) 
struct UBrushRemeshProperties : public URemeshProperties
{
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bEnableRemeshing : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t TriangleSize;  // 0xBC(0x4)
	int32_t PreserveDetail;  // 0xC0(0x4)
	int32_t Iterations;  // 0xC4(0x4)

}; 



// Class MeshModelingToolsExp.FixedPlaneBrushProperties
// Size: 0xF0(Inherited: 0xA8) 
struct UFixedPlaneBrushProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bPropertySetEnabled : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bShowGizmo : 1;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)
	struct FVector position;  // 0xB0(0x18)
	char pad_200[8];  // 0xC8(0x8)
	struct FQuat Rotation;  // 0xD0(0x20)

}; 



// Class MeshModelingToolsExp.DynamicMeshSculptTool
// Size: 0x1000(Inherited: 0xF8) 
struct UDynamicMeshSculptTool : public UMeshSurfacePointTool
{
	struct UDynamicMeshBrushProperties* BrushProperties;  // 0xF8(0x8)
	struct UDynamicMeshBrushSculptProperties* SculptProperties;  // 0x100(0x8)
	struct USculptMaxBrushProperties* SculptMaxBrushProperties;  // 0x108(0x8)
	struct UKelvinBrushProperties* KelvinBrushProperties;  // 0x110(0x8)
	struct UBrushRemeshProperties* RemeshProperties;  // 0x118(0x8)
	struct UFixedPlaneBrushProperties* GizmoProperties;  // 0x120(0x8)
	struct UMeshEditingViewProperties* ViewProperties;  // 0x128(0x8)
	struct UDynamicSculptToolActions* SculptToolActions;  // 0x130(0x8)
	char pad_312[88];  // 0x138(0x58)
	struct UBrushStampIndicator* BrushIndicator;  // 0x190(0x8)
	struct UMaterialInstanceDynamic* BrushIndicatorMaterial;  // 0x198(0x8)
	struct UPreviewMesh* BrushIndicatorMesh;  // 0x1A0(0x8)
	struct UOctreeDynamicMeshComponent* DynamicMeshComponent;  // 0x1A8(0x8)
	struct UMaterialInstanceDynamic* ActiveOverrideMaterial;  // 0x1B0(0x8)
	char pad_440[3624];  // 0x1B8(0xE28)
	struct UCombinedTransformGizmo* PlaneTransformGizmo;  // 0xFE0(0x8)
	struct UTransformProxy* PlaneTransformProxy;  // 0xFE8(0x8)
	char pad_4080[16];  // 0xFF0(0x10)

}; 



// Class MeshModelingToolsExp.EditNormalsToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UEditNormalsToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.EditNormalsToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UEditNormalsToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bRecomputeNormals : 1;  // 0xA8(0x1)
	uint8_t  NormalCalculationMethod;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bFixInconsistentNormals : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bInvertNormals : 1;  // 0xAB(0x1)
	uint8_t  SplitNormalMethod;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	float SharpEdgeAngleThreshold;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bAllowSharpVertices : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.SeamSculptToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct USeamSculptToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.EditNormalsAdvancedProperties
// Size: 0xA8(Inherited: 0xA8) 
struct UEditNormalsAdvancedProperties : public UInteractiveToolPropertySet
{

}; 



// Class MeshModelingToolsExp.MeshSelectionToolActionPropertySet
// Size: 0xB0(Inherited: 0xA8) 
struct UMeshSelectionToolActionPropertySet : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

}; 



// Class MeshModelingToolsExp.EditNormalsOperatorFactory
// Size: 0x40(Inherited: 0x28) 
struct UEditNormalsOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UEditNormalsTool* Tool;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)

}; 



// Class MeshModelingToolsExp.EditNormalsTool
// Size: 0x140(Inherited: 0xB8) 
struct UEditNormalsTool : public UMultiSelectionMeshEditingTool
{
	struct UEditNormalsToolProperties* BasicProperties;  // 0xB8(0x8)
	struct UEditNormalsAdvancedProperties* AdvancedProperties;  // 0xC0(0x8)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews;  // 0xC8(0x10)
	char pad_216[104];  // 0xD8(0x68)

}; 



// Class MeshModelingToolsExp.EditPivotToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UEditPivotToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.EditPivotToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UEditPivotToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnableSnapDragging : 1;  // 0xA8(0x1)
	uint8_t  RotationMode;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)

}; 



// Class MeshModelingToolsExp.EditPivotToolActionPropertySet
// Size: 0xB8(Inherited: 0xA8) 
struct UEditPivotToolActionPropertySet : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bUseWorldBox : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

	void WorldOrigin(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.WorldOrigin
	void Top(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Top
	void Right(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Right
	void Left(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Left
	void Front(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Front
	void Center(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Center
	void Bottom(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Bottom
	void Back(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Back
}; 



// Class MeshModelingToolsExp.BasePlaneBrushOpProps
// Size: 0xA8(Inherited: 0xA8) 
struct UBasePlaneBrushOpProps : public UMeshSculptBrushOpProps
{

}; 



// Class MeshModelingToolsExp.EditUVIslandsTool
// Size: 0x430(Inherited: 0xF8) 
struct UEditUVIslandsTool : public UMeshSurfacePointTool
{
	struct UExistingMeshMaterialProperties* MaterialSettings;  // 0xF8(0x8)
	struct UMaterialInstanceDynamic* CheckerMaterial;  // 0x100(0x8)
	struct UWorld* TargetWorld;  // 0x108(0x8)
	struct AInternalToolFrameworkActor* PreviewMeshActor;  // 0x110(0x8)
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0x118(0x8)
	struct UPolygonSelectionMechanic* SelectionMechanic;  // 0x120(0x8)
	char pad_296[8];  // 0x128(0x8)
	struct UMultiTransformer* MultiTransformer;  // 0x130(0x8)
	char pad_312[760];  // 0x138(0x2F8)

}; 



// Class MeshModelingToolsExp.ExtractCollisionToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UExtractCollisionToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  CollisionType;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bWeldEdges : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bOutputSeparateMeshes : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bShowPreview : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bShowInputMesh : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingToolsExp.RevolveBoundaryOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct URevolveBoundaryOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct URevolveBoundaryTool* RevolveBoundaryTool;  // 0x30(0x8)

}; 



// Class MeshModelingToolsExp.ExtractCollisionGeometryTool
// Size: 0x330(Inherited: 0xB8) 
struct UExtractCollisionGeometryTool : public USingleSelectionMeshEditingTool
{
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xB8(0x8)
	struct UExtractCollisionToolProperties* Settings;  // 0xC0(0x8)
	struct UCollisionGeometryVisualizationProperties* VizSettings;  // 0xC8(0x8)
	struct UPhysicsObjectToolPropertySet* ObjectProps;  // 0xD0(0x8)
	struct UPreviewGeometry* PreviewElements;  // 0xD8(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0xE0(0x8)
	char pad_232[584];  // 0xE8(0x248)

}; 



// Class MeshModelingToolsExp.ViewAlignedPlaneBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UViewAlignedPlaneBrushOpProps : public UBasePlaneBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float Depth;  // 0xB0(0x4)
	uint8_t  WhichSide;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.HoleFillToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UHoleFillToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.SmoothHoleFillProperties
// Size: 0xD0(Inherited: 0xA8) 
struct USmoothHoleFillProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bConstrainToHoleInterior : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t RemeshingExteriorRegionWidth;  // 0xAC(0x4)
	int32_t SmoothingExteriorRegionWidth;  // 0xB0(0x4)
	int32_t SmoothingInteriorRegionWidth;  // 0xB4(0x4)
	float InteriorSmoothness;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	double FillDensityScalar;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bProjectDuringRemesh : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)

}; 



// Class MeshModelingToolsExp.MeshInspectorToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UMeshInspectorToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.HoleFillToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UHoleFillToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  FillType;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bRemoveIsolatedTriangles : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bQuickFillSmallHoles : 1;  // 0xAA(0x1)
	char pad_171[5];  // 0xAB(0x5)

}; 



// Class MeshModelingToolsExp.HoleFillToolActions
// Size: 0xB0(Inherited: 0xA8) 
struct UHoleFillToolActions : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void SelectAll(); // Function MeshModelingToolsExp.HoleFillToolActions.SelectAll
	void Clear(); // Function MeshModelingToolsExp.HoleFillToolActions.Clear
}; 



// Class MeshModelingToolsExp.HoleFillStatisticsProperties
// Size: 0xF8(Inherited: 0xA8) 
struct UHoleFillStatisticsProperties : public UInteractiveToolPropertySet
{
	struct FString InitialHoles;  // 0xA8(0x10)
	struct FString SelectedHoles;  // 0xB8(0x10)
	struct FString SuccessfulFills;  // 0xC8(0x10)
	struct FString FailedFills;  // 0xD8(0x10)
	struct FString RemainingHoles;  // 0xE8(0x10)

}; 



// Class MeshModelingToolsExp.HoleFillOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct UHoleFillOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UHoleFillTool* FillTool;  // 0x30(0x8)

}; 



// Class MeshModelingToolsExp.HoleFillTool
// Size: 0x240(Inherited: 0xB8) 
struct UHoleFillTool : public USingleSelectionMeshEditingTool
{
	struct USmoothHoleFillProperties* SmoothHoleFillProperties;  // 0xB8(0x8)
	struct UHoleFillToolProperties* Properties;  // 0xC0(0x8)
	struct UHoleFillToolActions* Actions;  // 0xC8(0x8)
	struct UHoleFillStatisticsProperties* Statistics;  // 0xD0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xD8(0x8)
	struct UPolygonSelectionMechanic* SelectionMechanic;  // 0xE0(0x8)
	char pad_232[344];  // 0xE8(0x158)

}; 



// Class MeshModelingToolsExp.MeshSculptBrushOpProps
// Size: 0xA8(Inherited: 0xA8) 
struct UMeshSculptBrushOpProps : public UInteractiveToolPropertySet
{

}; 



// Class MeshModelingToolsExp.RemeshMeshToolProperties
// Size: 0xD8(Inherited: 0xB8) 
struct URemeshMeshToolProperties : public URemeshProperties
{
	int32_t TargetTriangleCount;  // 0xB8(0x4)
	uint8_t  SmoothingType;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool bDiscardAttributes : 1;  // 0xBD(0x1)
	char pad_190_1 : 7;  // 0xBE(0x1)
	bool bShowGroupColors : 1;  // 0xBE(0x1)
	uint8_t  RemeshType;  // 0xBF(0x1)
	int32_t RemeshIterations;  // 0xC0(0x4)
	int32_t MaxRemeshIterations;  // 0xC4(0x4)
	int32_t ExtraProjectionIterations;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool bUseTargetEdgeLength : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	float TargetEdgeLength;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool bReproject : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)

}; 



// Class MeshModelingToolsExp.BaseKelvinletBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UBaseKelvinletBrushOpProps : public UMeshSculptBrushOpProps
{
	float Stiffness;  // 0xA8(0x4)
	float Incompressiblity;  // 0xAC(0x4)
	int32_t BrushSteps;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.ScaleKelvinletBrushOpProps
// Size: 0xC0(Inherited: 0xB8) 
struct UScaleKelvinletBrushOpProps : public UBaseKelvinletBrushOpProps
{
	float Strength;  // 0xB8(0x4)
	float Falloff;  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.IterativeOffsetProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UIterativeOffsetProperties : public UInteractiveToolPropertySet
{
	int32_t Steps;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bOffsetBoundaries : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	float SmoothingPerStep;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bReprojectSmooth : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.PullKelvinletBrushOpProps
// Size: 0xC0(Inherited: 0xB8) 
struct UPullKelvinletBrushOpProps : public UBaseKelvinletBrushOpProps
{
	float Falloff;  // 0xB8(0x4)
	float Depth;  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.SharpPullKelvinletBrushOpProps
// Size: 0xC0(Inherited: 0xB8) 
struct USharpPullKelvinletBrushOpProps : public UBaseKelvinletBrushOpProps
{
	float Falloff;  // 0xB8(0x4)
	float Depth;  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.TwistKelvinletBrushOpProps
// Size: 0xC0(Inherited: 0xB8) 
struct UTwistKelvinletBrushOpProps : public UBaseKelvinletBrushOpProps
{
	float Strength;  // 0xB8(0x4)
	float Falloff;  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.MeshAttributePaintTool
// Size: 0x7D0(Inherited: 0x2B0) 
struct UMeshAttributePaintTool : public UDynamicMeshBrushTool
{
	struct UMeshAttributePaintBrushOperationProperties* BrushActionProps;  // 0x2B0(0x8)
	struct UMeshAttributePaintToolProperties* AttribProps;  // 0x2B8(0x8)
	char pad_704[1296];  // 0x2C0(0x510)

}; 



// Class MeshModelingToolsExp.LatticeDeformerToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct ULatticeDeformerToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.LatticeDeformerToolProperties
// Size: 0xD0(Inherited: 0xA8) 
struct ULatticeDeformerToolProperties : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)
	int32_t XAxisResolution;  // 0xB0(0x4)
	int32_t YAxisResolution;  // 0xB4(0x4)
	int32_t ZAxisResolution;  // 0xB8(0x4)
	float Padding;  // 0xBC(0x4)
	uint8_t  InterpolationType;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool bDeformNormals : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool bCanChangeResolution : 1;  // 0xC2(0x1)
	char pad_195[1];  // 0xC3(0x1)
	uint8_t  GizmoCoordinateSystem;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bSetPivotMode : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool bSoftDeformation : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)

	void Constrain(); // Function MeshModelingToolsExp.LatticeDeformerToolProperties.Constrain
	void ClearConstraints(); // Function MeshModelingToolsExp.LatticeDeformerToolProperties.ClearConstraints
}; 



// Class MeshModelingToolsExp.LatticeDeformerOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct ULatticeDeformerOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct ULatticeDeformerTool* LatticeDeformerTool;  // 0x30(0x8)

}; 



// Class MeshModelingToolsExp.LatticeDeformerTool
// Size: 0x160(Inherited: 0xB8) 
struct ULatticeDeformerTool : public USingleSelectionMeshEditingTool
{
	char pad_184[32];  // 0xB8(0x20)
	struct ULatticeControlPointsMechanic* ControlPointsMechanic;  // 0xD8(0x8)
	struct ULatticeDeformerToolProperties* Settings;  // 0xE0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bLatticeDeformed : 1;  // 0xF0(0x1)
	char pad_241[111];  // 0xF1(0x6F)

}; 



// Class MeshModelingToolsExp.MeshAnalysisProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UMeshAnalysisProperties : public UInteractiveToolPropertySet
{
	struct FString SurfaceArea;  // 0xA8(0x10)
	struct FString Volume;  // 0xB8(0x10)

}; 



// Class MeshModelingToolsExp.MeshAttributePaintToolBuilder
// Size: 0x70(Inherited: 0x30) 
struct UMeshAttributePaintToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{
	char pad_48[64];  // 0x30(0x40)

}; 



// Class MeshModelingToolsExp.MeshAttributePaintBrushOperationProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UMeshAttributePaintBrushOperationProperties : public UInteractiveToolPropertySet
{
	uint8_t  BrushAction;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.MeshAttributePaintToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UMeshAttributePaintToolProperties : public UInteractiveToolPropertySet
{
	struct FString Attribute;  // 0xA8(0x10)
	char pad_184[16];  // 0xB8(0x10)

	struct TArray<struct FString> GetAttributeNames(); // Function MeshModelingToolsExp.MeshAttributePaintToolProperties.GetAttributeNames
}; 



// Class MeshModelingToolsExp.MeshBoundaryToolBase
// Size: 0x1B0(Inherited: 0xB8) 
struct UMeshBoundaryToolBase : public USingleSelectionMeshEditingTool
{
	char pad_184[232];  // 0xB8(0xE8)
	struct UPolygonSelectionMechanic* SelectionMechanic;  // 0x1A0(0x8)
	char pad_424[8];  // 0x1A8(0x8)

}; 



// Class MeshModelingToolsExp.GroupPaintBrushOpProps
// Size: 0xB0(Inherited: 0xA8) 
struct UGroupPaintBrushOpProps : public UMeshSculptBrushOpProps
{
	int32_t Group;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bOnlyPaintUngrouped : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingToolsExp.MeshVertexSculptToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UMeshVertexSculptToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.MeshGroupPaintToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UMeshGroupPaintToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.GroupPaintBrushFilterProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UGroupPaintBrushFilterProperties : public UInteractiveToolPropertySet
{
	uint8_t  PrimaryBrushType;  // 0xA8(0x1)
	uint8_t  SubToolType;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float BrushSize;  // 0xAC(0x4)
	uint8_t  BrushAreaMode;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bHitBackFaces : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	int32_t SetGroup;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bOnlySetUngrouped : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t EraseGroup;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bOnlyEraseCurrent : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	float AngleThreshold;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bUVSeams : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool bNormalSeams : 1;  // 0xC9(0x1)
	uint8_t  VisibilityFilter;  // 0xCA(0x1)
	char pad_203[1];  // 0xCB(0x1)
	int32_t MinTriVertCount;  // 0xCC(0x4)

}; 



// Class MeshModelingToolsExp.MeshGroupPaintToolActionPropertySet
// Size: 0xB0(Inherited: 0xA8) 
struct UMeshGroupPaintToolActionPropertySet : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

}; 



// Class MeshModelingToolsExp.MeshGroupPaintToolFreezeActions
// Size: 0xB0(Inherited: 0xB0) 
struct UMeshGroupPaintToolFreezeActions : public UMeshGroupPaintToolActionPropertySet
{

	void UnfreezeAll(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.UnfreezeAll
	void ShrinkCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.ShrinkCurrent
	void GrowCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.GrowCurrent
	void FreezeOthers(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.FreezeOthers
	void FreezeCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.FreezeCurrent
	void FloodFillCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.FloodFillCurrent
	void ClearCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.ClearCurrent
	void ClearAll(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.ClearAll
}; 



// Class MeshModelingToolsExp.SeamSculptTool
// Size: 0x3A0(Inherited: 0x2B0) 
struct USeamSculptTool : public UDynamicMeshBrushTool
{
	struct USeamSculptToolProperties* Settings;  // 0x2B0(0x8)
	struct UPreviewGeometry* PreviewGeom;  // 0x2B8(0x8)
	char pad_704[224];  // 0x2C0(0xE0)

}; 



// Class MeshModelingToolsExp.MeshSculptToolBase
// Size: 0xB90(Inherited: 0xF8) 
struct UMeshSculptToolBase : public UMeshSurfacePointTool
{
	struct USculptBrushProperties* BrushProperties;  // 0xF8(0x8)
	struct UWorkPlaneProperties* GizmoProperties;  // 0x100(0x8)
	char pad_264[280];  // 0x108(0x118)
	struct TMap<int32_t, struct UMeshSculptBrushOpProps*> BrushOpPropSets;  // 0x220(0x50)
	char pad_624[80];  // 0x270(0x50)
	struct TMap<int32_t, struct UMeshSculptBrushOpProps*> SecondaryBrushOpPropSets;  // 0x2C0(0x50)
	char pad_784[1776];  // 0x310(0x6F0)
	struct UMeshEditingViewProperties* ViewProperties;  // 0xA00(0x8)
	struct UMaterialInstanceDynamic* ActiveOverrideMaterial;  // 0xA08(0x8)
	struct UBrushStampIndicator* BrushIndicator;  // 0xA10(0x8)
	char pad_2584_1 : 7;  // 0xA18(0x1)
	bool bIsVolumetricIndicator : 1;  // 0xA18(0x1)
	char pad_2585[7];  // 0xA19(0x7)
	struct UMaterialInstanceDynamic* BrushIndicatorMaterial;  // 0xA20(0x8)
	struct UPreviewMesh* BrushIndicatorMesh;  // 0xA28(0x8)
	struct UCombinedTransformGizmo* PlaneTransformGizmo;  // 0xA30(0x8)
	struct UTransformProxy* PlaneTransformProxy;  // 0xA38(0x8)
	char pad_2624[336];  // 0xA40(0x150)

}; 



// Class MeshModelingToolsExp.SplitMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USplitMeshesToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.MeshVertexSculptTool
// Size: 0x1480(Inherited: 0xB90) 
struct UMeshVertexSculptTool : public UMeshSculptToolBase
{
	struct UVertexBrushSculptProperties* SculptProperties;  // 0xB88(0x8)
	struct UVertexBrushAlphaProperties* AlphaProperties;  // 0xB90(0x8)
	struct UTexture2D* BrushAlpha;  // 0xB98(0x8)
	struct AInternalToolFrameworkActor* PreviewMeshActor;  // 0xBA0(0x8)
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0xBA8(0x8)
	char pad_3000[2248];  // 0xBB8(0x8C8)

}; 



// Class MeshModelingToolsExp.MeshGroupPaintTool
// Size: 0xFA0(Inherited: 0xB90) 
struct UMeshGroupPaintTool : public UMeshSculptToolBase
{
	struct UPolygroupLayersProperties* PolygroupLayerProperties;  // 0xB88(0x8)
	struct UGroupPaintBrushFilterProperties* FilterProperties;  // 0xB90(0x8)
	struct UGroupPaintBrushOpProps* PaintBrushOpProperties;  // 0xB98(0x8)
	struct UGroupEraseBrushOpProps* EraseBrushOpProperties;  // 0xBA0(0x8)
	struct UMeshGroupPaintToolFreezeActions* FreezeActions;  // 0xBA8(0x8)
	struct UPolyLassoMarqueeMechanic* PolyLassoMechanic;  // 0xBB8(0x8)
	struct AInternalToolFrameworkActor* PreviewMeshActor;  // 0xBC0(0x8)
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0xBC8(0x8)
	struct UMeshElementsVisualizer* MeshElementsDisplay;  // 0xBD0(0x8)
	char pad_3032[968];  // 0xBD8(0x3C8)

}; 



// Class MeshModelingToolsExp.MeshInspectorProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UMeshInspectorProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bWireframe : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bBoundaryEdges : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bBowtieVertices : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bPolygonBorders : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bUVSeams : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bUVBowties : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool bMissingUVs : 1;  // 0xAE(0x1)
	char pad_175_1 : 7;  // 0xAF(0x1)
	bool bNormalSeams : 1;  // 0xAF(0x1)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bNormalVectors : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bTangentVectors : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	float NormalLength;  // 0xB4(0x4)
	float TangentLength;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.MeshInspectorTool
// Size: 0x158(Inherited: 0xB8) 
struct UMeshInspectorTool : public USingleSelectionMeshEditingTool
{
	struct UMeshInspectorProperties* Settings;  // 0xB8(0x8)
	struct UExistingMeshMaterialProperties* MaterialSettings;  // 0xC0(0x8)
	char pad_200[8];  // 0xC8(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0xD0(0x8)
	struct ULineSetComponent* DrawnLineSet;  // 0xD8(0x8)
	struct UMaterialInterface* DefaultMaterial;  // 0xE0(0x8)
	char pad_232[112];  // 0xE8(0x70)

}; 



// Class MeshModelingToolsExp.MoveBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UMoveBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float Depth;  // 0xB0(0x4)
	struct FModelingToolsAxisFilter AxisFilters;  // 0xB4(0x3)
	char pad_183[1];  // 0xB7(0x1)

}; 



// Class MeshModelingToolsExp.PinchBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UPinchBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float Depth;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bPerpDamping : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.FixedPlaneBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct UFixedPlaneBrushOpProps : public UBasePlaneBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	float Depth;  // 0xB0(0x4)
	uint8_t  WhichSide;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class MeshModelingToolsExp.StandardSculptBrushOpProps
// Size: 0xB0(Inherited: 0xA8) 
struct UStandardSculptBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.ViewAlignedSculptBrushOpProps
// Size: 0xB0(Inherited: 0xA8) 
struct UViewAlignedSculptBrushOpProps : public UMeshSculptBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.SculptBrushProperties
// Size: 0xE0(Inherited: 0xA8) 
struct USculptBrushProperties : public UInteractiveToolPropertySet
{
	struct FBrushToolRadius BrushSize;  // 0xA8(0x14)
	float BrushFalloffAmount;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bShowFalloff : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	float Depth;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bHitBackFaces : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float FlowRate;  // 0xCC(0x4)
	float Spacing;  // 0xD0(0x4)
	float Lazyness;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bShowPerBrushProps : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool bShowLazyness : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool bShowFlowRate : 1;  // 0xDA(0x1)
	char pad_219_1 : 7;  // 0xDB(0x1)
	bool bShowSpacing : 1;  // 0xDB(0x1)
	char pad_220[4];  // 0xDC(0x4)

}; 



// Class MeshModelingToolsExp.KelvinBrushProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UKelvinBrushProperties : public UInteractiveToolPropertySet
{
	float FalloffDistance;  // 0xA8(0x4)
	float Stiffness;  // 0xAC(0x4)
	float Incompressiblity;  // 0xB0(0x4)
	int32_t BrushSteps;  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.WorkPlaneProperties
// Size: 0xF0(Inherited: 0xA8) 
struct UWorkPlaneProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bPropertySetEnabled : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bShowGizmo : 1;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)
	struct FVector position;  // 0xB0(0x18)
	char pad_200[8];  // 0xC8(0x8)
	struct FQuat Rotation;  // 0xD0(0x20)

}; 



// Class MeshModelingToolsExp.SculptMaxBrushProperties
// Size: 0xB0(Inherited: 0xA8) 
struct USculptMaxBrushProperties : public UInteractiveToolPropertySet
{
	float MaxHeight;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bFreezeCurrentHeight : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingToolsExp.MeshSelectionToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UMeshSelectionToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.MeshSelectionMeshEditActions
// Size: 0xB0(Inherited: 0xB0) 
struct UMeshSelectionMeshEditActions : public UMeshSelectionToolActionPropertySet
{

	void Separate(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Separate
	void FlipNormals(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.FlipNormals
	void Duplicate(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Duplicate
	void Disconnect(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Disconnect
	void Delete(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Delete
	void CreatePolygroup(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.CreatePolygroup
}; 



// Class MeshModelingToolsExp.BaseSmoothBrushOpProps
// Size: 0xA8(Inherited: 0xA8) 
struct UBaseSmoothBrushOpProps : public UMeshSculptBrushOpProps
{

}; 



// Class MeshModelingToolsExp.MirrorTool
// Size: 0x168(Inherited: 0xB8) 
struct UMirrorTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UMirrorToolProperties* Settings;  // 0xC0(0x8)
	struct UMirrorToolActionPropertySet* ToolActions;  // 0xC8(0x8)
	struct TArray<struct UDynamicMeshReplacementChangeTarget*> MeshesToMirror;  // 0xD0(0x10)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews;  // 0xE0(0x10)
	char pad_240[48];  // 0xF0(0x30)
	struct UConstructionPlaneMechanic* PlaneMechanic;  // 0x120(0x8)
	char pad_296[64];  // 0x128(0x40)

}; 



// Class MeshModelingToolsExp.SmoothBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct USmoothBrushOpProps : public UBaseSmoothBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreserveUVFlow : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 



// Class MeshModelingToolsExp.MeshSpaceDeformerToolProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UMeshSpaceDeformerToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  SelectedOperationType;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float UpperBoundsInterval;  // 0xAC(0x4)
	float LowerBoundsInterval;  // 0xB0(0x4)
	float BendDegrees;  // 0xB4(0x4)
	float TwistDegrees;  // 0xB8(0x4)
	uint8_t  FlareProfileType;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float FlarePercentY;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bLockXAndYFlaring : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	float FlarePercentX;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool bLockBottom : 1;  // 0xCC(0x1)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool bShowOriginalMesh : 1;  // 0xCD(0x1)
	char pad_206_1 : 7;  // 0xCE(0x1)
	bool bDrawVisualization : 1;  // 0xCE(0x1)
	char pad_207_1 : 7;  // 0xCF(0x1)
	bool bAlignToNormalOnCtrlClick : 1;  // 0xCF(0x1)

}; 



// Class MeshModelingToolsExp.SecondarySmoothBrushOpProps
// Size: 0xB8(Inherited: 0xA8) 
struct USecondarySmoothBrushOpProps : public UBaseSmoothBrushOpProps
{
	float Strength;  // 0xA8(0x4)
	float Falloff;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreserveUVFlow : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 



// Class MeshModelingToolsExp.MeshSpaceDeformerToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UMeshSpaceDeformerToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.MeshSpaceDeformerToolActionPropertySet
// Size: 0xB0(Inherited: 0xA8) 
struct UMeshSpaceDeformerToolActionPropertySet : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void ShiftToCenter(); // Function MeshModelingToolsExp.MeshSpaceDeformerToolActionPropertySet.ShiftToCenter
}; 



// Class MeshModelingToolsExp.MeshSpaceDeformerTool
// Size: 0x2C0(Inherited: 0xB8) 
struct UMeshSpaceDeformerTool : public USingleSelectionMeshEditingTool
{
	struct UMeshSpaceDeformerToolProperties* Settings;  // 0xB8(0x8)
	struct UMeshSpaceDeformerToolActionPropertySet* ToolActions;  // 0xC0(0x8)
	struct UGizmoTransformChangeStateTarget* StateTarget;  // 0xC8(0x8)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0xD0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xD8(0x8)
	char pad_224[16];  // 0xE0(0x10)
	struct UPreviewMesh* OriginalMeshPreview;  // 0xF0(0x8)
	struct UIntervalGizmo* IntervalGizmo;  // 0xF8(0x8)
	struct UCombinedTransformGizmo* TransformGizmo;  // 0x100(0x8)
	struct UTransformProxy* TransformProxy;  // 0x108(0x8)
	struct UGizmoLocalFloatParameterSource* UpIntervalSource;  // 0x110(0x8)
	struct UGizmoLocalFloatParameterSource* DownIntervalSource;  // 0x118(0x8)
	struct UGizmoLocalFloatParameterSource* ForwardIntervalSource;  // 0x120(0x8)
	char pad_296[408];  // 0x128(0x198)

}; 



// Class MeshModelingToolsExp.MeshStatisticsProperties
// Size: 0xD8(Inherited: 0xA8) 
struct UMeshStatisticsProperties : public UInteractiveToolPropertySet
{
	struct FString Mesh;  // 0xA8(0x10)
	struct FString UV;  // 0xB8(0x10)
	struct FString Attributes;  // 0xC8(0x10)

}; 



// Class MeshModelingToolsExp.VertexBrushSculptProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UVertexBrushSculptProperties : public UInteractiveToolPropertySet
{
	uint8_t  PrimaryBrushType;  // 0xA8(0x1)
	uint8_t  PrimaryFalloffType;  // 0xA9(0x1)
	uint8_t  BrushFilter;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bFreezeTarget : 1;  // 0xAB(0x1)
	struct TWeakObjectPtr<UMeshVertexSculptTool> Tool;  // 0xAC(0x8)
	char pad_180[4];  // 0xB4(0x4)

}; 



// Class MeshModelingToolsExp.VertexBrushAlphaProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UVertexBrushAlphaProperties : public UInteractiveToolPropertySet
{
	struct UTexture2D* Alpha;  // 0xA8(0x8)
	float RotationAngle;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bRandomize : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	float RandomRange;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)

}; 



// Class MeshModelingToolsExp.MirrorToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UMirrorToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.MirrorToolProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UMirrorToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  OperationMode;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bCropAlongMirrorPlaneFirst : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bWeldVerticesOnMirrorPlane : 1;  // 0xAA(0x1)
	char pad_171[5];  // 0xAB(0x5)
	double PlaneTolerance;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bAllowBowtieVertexCreation : 1;  // 0xB8(0x1)
	uint8_t  CtrlClickBehavior;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool bButtonsOnlyChangeOrientation : 1;  // 0xBA(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool bShowPreview : 1;  // 0xBB(0x1)
	uint8_t  SaveMode;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)

}; 



// Class MeshModelingToolsExp.MirrorOperatorFactory
// Size: 0x40(Inherited: 0x28) 
struct UMirrorOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UMirrorTool* MirrorTool;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)

}; 



// Class MeshModelingToolsExp.MirrorToolActionPropertySet
// Size: 0xB0(Inherited: 0xA8) 
struct UMirrorToolActionPropertySet : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void Up(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Up
	void ShiftToCenter(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.ShiftToCenter
	void Right(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Right
	void Left(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Left
	void Forward(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Forward
	void Down(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Down
	void Backward(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Backward
}; 



// Class MeshModelingToolsExp.OffsetMeshToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UOffsetMeshToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  OffsetType;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float Distance;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bCreateShell : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 



// Class MeshModelingToolsExp.OffsetWeightMapSetProperties
// Size: 0xD0(Inherited: 0xC8) 
struct UOffsetWeightMapSetProperties : public UWeightMapSetProperties
{
	float MinDistance;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class MeshModelingToolsExp.ImplicitOffsetProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UImplicitOffsetProperties : public UInteractiveToolPropertySet
{
	float Smoothness;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bPreserveUVs : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingToolsExp.OffsetMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UOffsetMeshToolBuilder : public UBaseMeshProcessingToolBuilder
{

}; 



// Class MeshModelingToolsExp.PhysicsInspectorTool
// Size: 0x100(Inherited: 0xB8) 
struct UPhysicsInspectorTool : public UMultiSelectionMeshEditingTool
{
	struct UCollisionGeometryVisualizationProperties* VizSettings;  // 0xB8(0x8)
	struct TArray<struct UPhysicsObjectToolPropertySet*> ObjectData;  // 0xC0(0x10)
	struct UMaterialInterface* LineMaterial;  // 0xD0(0x8)
	struct TArray<struct UPreviewGeometry*> PreviewElements;  // 0xD8(0x10)
	char pad_232[24];  // 0xE8(0x18)

}; 



// Class MeshModelingToolsExp.PlaneCutToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UPlaneCutToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.PlaneCutToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UPlaneCutToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bKeepBothHalves : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float SpacingBetweenHalves;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bShowPreview : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bFillCutHole : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool bFillSpans : 1;  // 0xB2(0x1)
	char pad_179[5];  // 0xB3(0x5)

}; 



// Class MeshModelingToolsExp.PlaneCutOperatorFactory
// Size: 0x40(Inherited: 0x28) 
struct UPlaneCutOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UPlaneCutTool* CutTool;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)

}; 



// Class MeshModelingToolsExp.PlaneCutTool
// Size: 0x1A0(Inherited: 0xB8) 
struct UPlaneCutTool : public UMultiSelectionMeshEditingTool
{
	struct UPlaneCutToolProperties* BasicProperties;  // 0xB8(0x8)
	struct UAcceptOutputProperties* AcceptProperties;  // 0xC0(0x8)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews;  // 0xC8(0x10)
	struct TArray<struct UDynamicMeshReplacementChangeTarget*> MeshesToCut;  // 0xD8(0x10)
	struct UConstructionPlaneMechanic* PlaneMechanic;  // 0xE8(0x8)
	char pad_240[176];  // 0xF0(0xB0)

	void FlipPlane(); // Function MeshModelingToolsExp.PlaneCutTool.FlipPlane
	void Cut(); // Function MeshModelingToolsExp.PlaneCutTool.Cut
}; 



// Class MeshModelingToolsExp.ProjectToTargetToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UProjectToTargetToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.ProjectToTargetToolProperties
// Size: 0xF8(Inherited: 0xD8) 
struct UProjectToTargetToolProperties : public URemeshMeshToolProperties
{
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bWorldSpace : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool bParallel : 1;  // 0xD9(0x1)
	char pad_218[2];  // 0xDA(0x2)
	int32_t FaceProjectionPassesPerRemeshIteration;  // 0xDC(0x4)
	float SurfaceProjectionSpeed;  // 0xE0(0x4)
	float NormalAlignmentSpeed;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bSmoothInFillAreas : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float FillAreaDistanceMultiplier;  // 0xEC(0x4)
	float FillAreaSmoothMultiplier;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)

}; 



// Class MeshModelingToolsExp.RemeshMeshTool
// Size: 0x108(Inherited: 0xB8) 
struct URemeshMeshTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct URemeshMeshToolProperties* BasicProperties;  // 0xC0(0x8)
	struct UMeshStatisticsProperties* MeshStatisticsProperties;  // 0xC8(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xD0(0x8)
	struct UMeshElementsVisualizer* MeshElementsDisplay;  // 0xD8(0x8)
	char pad_224[40];  // 0xE0(0x28)

}; 



// Class MeshModelingToolsExp.SkinWeightsPaintToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct USkinWeightsPaintToolProperties : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)
	struct FBoneReference CurrentBone;  // 0xB0(0x10)
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class MeshModelingToolsExp.ProjectToTargetTool
// Size: 0x118(Inherited: 0x108) 
struct UProjectToTargetTool : public URemeshMeshTool
{
	char pad_264[16];  // 0x108(0x10)

}; 



// Class MeshModelingToolsExp.TransformMeshesToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UTransformMeshesToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  TransformMode;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bApplyToInstances : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bSetPivotMode : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bEnableSnapDragging : 1;  // 0xAB(0x1)
	uint8_t  SnapDragSource;  // 0xAC(0x1)
	uint8_t  RotationMode;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool bHaveInstances : 1;  // 0xAE(0x1)
	char pad_175[1];  // 0xAF(0x1)

}; 



// Class MeshModelingToolsExp.RemeshMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct URemeshMeshToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.RemoveOccludedTrianglesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct URemoveOccludedTrianglesToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.RemoveOccludedTrianglesToolProperties
// Size: 0xD8(Inherited: 0xA8) 
struct URemoveOccludedTrianglesToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  OcclusionTestMethod;  // 0xA8(0x1)
	uint8_t  TriangleSampling;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)
	double WindingIsoValue;  // 0xB0(0x8)
	int32_t AddRandomRays;  // 0xB8(0x4)
	int32_t AddTriangleSamples;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bOnlySelfOcclude : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t ShrinkRemoval;  // 0xC4(0x4)
	double MinAreaIsland;  // 0xC8(0x8)
	int32_t MinTriCountIsland;  // 0xD0(0x4)
	uint8_t  Action;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)

}; 



// Class MeshModelingToolsExp.VoxelSolidifyMeshesToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UVoxelSolidifyMeshesToolProperties : public UInteractiveToolPropertySet
{
	double WindingThreshold;  // 0xA8(0x8)
	double ExtendBounds;  // 0xB0(0x8)
	int32_t SurfaceSearchSteps;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bSolidAtBoundaries : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool bApplyThickenShells : 1;  // 0xBD(0x1)
	char pad_190[2];  // 0xBE(0x2)
	double ThickenShells;  // 0xC0(0x8)

}; 



// Class MeshModelingToolsExp.RemoveOccludedTrianglesAdvancedProperties
// Size: 0xB0(Inherited: 0xA8) 
struct URemoveOccludedTrianglesAdvancedProperties : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

}; 



// Class MeshModelingToolsExp.RemoveOccludedTrianglesTool
// Size: 0x1D0(Inherited: 0xB8) 
struct URemoveOccludedTrianglesTool : public UMultiSelectionMeshEditingTool
{
	struct URemoveOccludedTrianglesToolProperties* BasicProperties;  // 0xB8(0x8)
	struct UPolygroupLayersProperties* PolygroupLayersProperties;  // 0xC0(0x8)
	struct URemoveOccludedTrianglesAdvancedProperties* AdvancedProperties;  // 0xC8(0x8)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews;  // 0xD0(0x10)
	struct TArray<struct UPreviewMesh*> PreviewCopies;  // 0xE0(0x10)
	char pad_240[224];  // 0xF0(0xE0)

}; 



// Class MeshModelingToolsExp.RevolveBoundaryToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct URevolveBoundaryToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.SeamSculptToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct USeamSculptToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bShowWireframe : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bHitBackFaces : 1;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)

}; 



// Class MeshModelingToolsExp.SelfUnionMeshesToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct USelfUnionMeshesToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bTrimFlaps : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bTryFixHoles : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bTryCollapseEdges : 1;  // 0xAA(0x1)
	char pad_171[1];  // 0xAB(0x1)
	float WindingThreshold;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bShowNewBoundaryEdges : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bOnlyUseFirstMeshMaterials : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)

}; 



// Class MeshModelingToolsExp.SelfUnionMeshesTool
// Size: 0x130(Inherited: 0x100) 
struct USelfUnionMeshesTool : public UBaseCreateFromSelectedTool
{
	struct USelfUnionMeshesToolProperties* Properties;  // 0x100(0x8)
	struct ULineSetComponent* DrawnLineSet;  // 0x108(0x8)
	char pad_272[32];  // 0x110(0x20)

}; 



// Class MeshModelingToolsExp.SelfUnionMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USelfUnionMeshesToolBuilder : public UBaseCreateFromSelectedToolBuilder
{

}; 



// Class MeshModelingToolsExp.SetCollisionGeometryToolProperties
// Size: 0xD8(Inherited: 0xA8) 
struct USetCollisionGeometryToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  GeometryType;  // 0xA8(0x4)
	uint8_t  InputMode;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bUseWorldSpace : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bRemoveContained : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool bEnableMaxCount : 1;  // 0xB2(0x1)
	char pad_179[1];  // 0xB3(0x1)
	int32_t MaxCount;  // 0xB4(0x4)
	float MinThickness;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bDetectBoxes : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool bDetectSpheres : 1;  // 0xBD(0x1)
	char pad_190_1 : 7;  // 0xBE(0x1)
	bool bDetectCapsules : 1;  // 0xBE(0x1)
	char pad_191_1 : 7;  // 0xBF(0x1)
	bool bSimplifyHulls : 1;  // 0xBF(0x1)
	int32_t HullTargetFaceCount;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bSimplifyPolygons : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	float HullTolerance;  // 0xC8(0x4)
	uint8_t  SweepAxis;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bAppendToExisting : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	uint8_t  SetCollisionType;  // 0xD4(0x4)

}; 



// Class MeshModelingToolsExp.SetCollisionGeometryTool
// Size: 0x250(Inherited: 0xB8) 
struct USetCollisionGeometryTool : public UMultiSelectionMeshEditingTool
{
	struct USetCollisionGeometryToolProperties* Settings;  // 0xB8(0x8)
	struct UPolygroupLayersProperties* PolygroupLayerProperties;  // 0xC0(0x8)
	struct UCollisionGeometryVisualizationProperties* VizSettings;  // 0xC8(0x8)
	struct UPhysicsObjectToolPropertySet* CollisionProps;  // 0xD0(0x8)
	struct UMaterialInterface* LineMaterial;  // 0xD8(0x8)
	struct UPreviewGeometry* PreviewGeom;  // 0xE0(0x8)
	char pad_232[360];  // 0xE8(0x168)

}; 



// Class MeshModelingToolsExp.SkinWeightsBindingToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USkinWeightsBindingToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.SkinWeightsBindingToolProperties
// Size: 0xE0(Inherited: 0xA8) 
struct USkinWeightsBindingToolProperties : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)
	struct FBoneReference CurrentBone;  // 0xB0(0x10)
	uint8_t  BindingType;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	float Stiffness;  // 0xC4(0x4)
	int32_t MaxInfluences;  // 0xC8(0x4)
	int32_t VoxelResolution;  // 0xCC(0x4)
	char pad_208[16];  // 0xD0(0x10)

}; 



// Class MeshModelingToolsExp.SkinWeightsBindingTool
// Size: 0x2E8(Inherited: 0xB8) 
struct USkinWeightsBindingTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct USkinWeightsBindingToolProperties* Properties;  // 0xC0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xC8(0x8)
	char pad_208[536];  // 0xD0(0x218)

}; 



// Class MeshModelingToolsExp.SkinWeightsPaintToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct USkinWeightsPaintToolBuilder : public UMeshSurfacePointMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.SkinWeightsPaintTool
// Size: 0x9A0(Inherited: 0x2B0) 
struct USkinWeightsPaintTool : public UDynamicMeshBrushTool
{
	struct USkinWeightsPaintToolProperties* ToolProps;  // 0x2B0(0x8)
	char pad_696[1768];  // 0x2B8(0x6E8)

}; 



// Class MeshModelingToolsExp.SmoothMeshToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct USmoothMeshToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  SmoothingType;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MeshModelingToolsExp.IterativeSmoothProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UIterativeSmoothProperties : public UInteractiveToolPropertySet
{
	float SmoothingPerStep;  // 0xA8(0x4)
	int32_t Steps;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bSmoothBoundary : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 



// Class MeshModelingToolsExp.DiffusionSmoothProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UDiffusionSmoothProperties : public UInteractiveToolPropertySet
{
	float SmoothingPerStep;  // 0xA8(0x4)
	int32_t Steps;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreserveUVs : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 



// Class MeshModelingToolsExp.SmoothWeightMapSetProperties
// Size: 0xD0(Inherited: 0xC8) 
struct USmoothWeightMapSetProperties : public UWeightMapSetProperties
{
	float MinSmoothMultiplier;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class MeshModelingToolsExp.SmoothMeshTool
// Size: 0x430(Inherited: 0x400) 
struct USmoothMeshTool : public UBaseMeshProcessingTool
{
	struct USmoothMeshToolProperties* SmoothProperties;  // 0x400(0x8)
	struct UIterativeSmoothProperties* IterativeProperties;  // 0x408(0x8)
	struct UDiffusionSmoothProperties* DiffusionProperties;  // 0x410(0x8)
	struct UImplicitSmoothProperties* ImplicitProperties;  // 0x418(0x8)
	struct USmoothWeightMapSetProperties* WeightMapProperties;  // 0x420(0x8)
	char pad_1064[8];  // 0x428(0x8)

}; 



// Class MeshModelingToolsExp.SmoothMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USmoothMeshToolBuilder : public UBaseMeshProcessingToolBuilder
{

}; 



// Class MeshModelingToolsExp.SplitMeshesToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct USplitMeshesToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bTransferMaterials : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MeshModelingToolsExp.SplitMeshesTool
// Size: 0xF0(Inherited: 0xB8) 
struct USplitMeshesTool : public UMultiSelectionMeshEditingTool
{
	struct USplitMeshesToolProperties* BasicProperties;  // 0xB8(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xC0(0x8)
	char pad_200[40];  // 0xC8(0x28)

}; 



// Class MeshModelingToolsExp.TransferMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UTransferMeshToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.TransferMeshToolProperties
// Size: 0x120(Inherited: 0xA8) 
struct UTransferMeshToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bTransferMaterials : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FString SourceLOD;  // 0xB0(0x10)
	struct FString TargetLod;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bIsStaticMeshSource : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct TArray<struct FString> SourceLODNamesList;  // 0xD8(0x10)
	char pad_232[16];  // 0xE8(0x10)
	struct TArray<struct FString> TargetLODNamesList;  // 0xF8(0x10)
	char pad_264[16];  // 0x108(0x10)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool bIsStaticMeshTarget : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)

	struct TArray<struct FString> GetTargetLODNamesFunc(); // Function MeshModelingToolsExp.TransferMeshToolProperties.GetTargetLODNamesFunc
	struct TArray<struct FString> GetSourceLODNamesFunc(); // Function MeshModelingToolsExp.TransferMeshToolProperties.GetSourceLODNamesFunc
}; 



// Class MeshModelingToolsExp.TransferMeshTool
// Size: 0xC8(Inherited: 0xB8) 
struct UTransferMeshTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UTransferMeshToolProperties* BasicProperties;  // 0xC0(0x8)

}; 



// Class MeshModelingToolsExp.TransformMeshesTool
// Size: 0x190(Inherited: 0xB8) 
struct UTransformMeshesTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UTransformMeshesToolProperties* TransformProps;  // 0xC0(0x8)
	struct TArray<struct FTransformMeshesTarget> ActiveGizmos;  // 0xC8(0x10)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0xD8(0x8)
	char pad_224[176];  // 0xE0(0xB0)

}; 



// Class MeshModelingToolsExp.VolumeToMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UVolumeToMeshToolBuilder : public UInteractiveToolBuilder
{

}; 



// Class MeshModelingToolsExp.VolumeToMeshToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UVolumeToMeshToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bWeldEdges : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bAutoRepair : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bOptimizeMesh : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bShowWireframe : 1;  // 0xAB(0x1)
	char pad_172[4];  // 0xAC(0x4)

}; 



// Class MeshModelingToolsExp.VolumeToMeshTool
// Size: 0x308(Inherited: 0x98) 
struct UVolumeToMeshTool : public UInteractiveTool
{
	struct UVolumeToMeshToolProperties* Settings;  // 0x98(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xA0(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0xA8(0x8)
	 TargetVolume;  // 0xB0(0x1C)
	char pad_204[4];  // 0xCC(0x4)
	struct ULineSetComponent* VolumeEdgesSet;  // 0xD0(0x8)
	char pad_216[560];  // 0xD8(0x230)

}; 



// Class MeshModelingToolsExp.VoxelMorphologyMeshesToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UVoxelMorphologyMeshesToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  Operation;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	double Distance;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bVoxWrap : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool bRemoveInternalsAfterVoxWrap : 1;  // 0xB9(0x1)
	char pad_186[6];  // 0xBA(0x6)
	double ThickenShells;  // 0xC0(0x8)

}; 



// Class MeshModelingToolsExp.VoxelBlendMeshesTool
// Size: 0x120(Inherited: 0x118) 
struct UVoxelBlendMeshesTool : public UBaseVoxelTool
{
	struct UVoxelBlendMeshesToolProperties* BlendProperties;  // 0x118(0x8)

}; 



// Class MeshModelingToolsExp.VoxelBlendMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UVoxelBlendMeshesToolBuilder : public UBaseCreateFromSelectedToolBuilder
{

}; 



// Class MeshModelingToolsExp.VoxelMorphologyMeshesTool
// Size: 0x120(Inherited: 0x118) 
struct UVoxelMorphologyMeshesTool : public UBaseVoxelTool
{
	struct UVoxelMorphologyMeshesToolProperties* MorphologyProperties;  // 0x118(0x8)

}; 



// Class MeshModelingToolsExp.VoxelMorphologyMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UVoxelMorphologyMeshesToolBuilder : public UBaseCreateFromSelectedToolBuilder
{

}; 



// Class MeshModelingToolsExp.VoxelSolidifyMeshesTool
// Size: 0x120(Inherited: 0x118) 
struct UVoxelSolidifyMeshesTool : public UBaseVoxelTool
{
	struct UVoxelSolidifyMeshesToolProperties* SolidifyProperties;  // 0x118(0x8)

}; 



// Class MeshModelingToolsExp.VoxelSolidifyMeshesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UVoxelSolidifyMeshesToolBuilder : public UBaseCreateFromSelectedToolBuilder
{

}; 



// Class MeshModelingToolsExp.WeldMeshEdgesToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UWeldMeshEdgesToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingToolsExp.WeldMeshEdgesToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UWeldMeshEdgesToolProperties : public UInteractiveToolPropertySet
{
	float Tolerance;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bOnlyUnique : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingToolsExp.WeldMeshEdgesOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct UWeldMeshEdgesOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UWeldMeshEdgesTool* WeldMeshEdgesTool;  // 0x30(0x8)

}; 



