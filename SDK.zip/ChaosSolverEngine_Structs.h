#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction ChaosSolverEngine.OnChaosPhysicsCollision__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FOnChaosPhysicsCollision__DelegateSignature
{
	struct FChaosPhysicsCollisionInfo CollisionInfo;  // 0x0(0xC0)

}; 
// ScriptStruct ChaosSolverEngine.ChaosPhysicsCollisionInfo
// Size: 0xC0(Inherited: 0x0) 
struct FChaosPhysicsCollisionInfo
{
	struct UPrimitiveComponent* Component;  // 0x0(0x8)
	struct UPrimitiveComponent* OtherComponent;  // 0x8(0x8)
	struct FVector Location;  // 0x10(0x18)
	struct FVector Normal;  // 0x28(0x18)
	struct FVector AccumulatedImpulse;  // 0x40(0x18)
	struct FVector Velocity;  // 0x58(0x18)
	struct FVector OtherVelocity;  // 0x70(0x18)
	struct FVector AngularVelocity;  // 0x88(0x18)
	struct FVector OtherAngularVelocity;  // 0xA0(0x18)
	float Mass;  // 0xB8(0x4)
	float OtherMass;  // 0xBC(0x4)

}; 
// ScriptStruct ChaosSolverEngine.ChaosBreakEvent
// Size: 0x58(Inherited: 0x0) 
struct FChaosBreakEvent
{
	struct UPrimitiveComponent* Component;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	struct FVector Velocity;  // 0x20(0x18)
	struct FVector AngularVelocity;  // 0x38(0x18)
	float Mass;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct ChaosSolverEngine.ChaosDebugSubstepControl
// Size: 0x3(Inherited: 0x0) 
struct FChaosDebugSubstepControl
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPause : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bSubstep : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bStep : 1;  // 0x2(0x1)

}; 
// ScriptStruct ChaosSolverEngine.ChaosRemovalEvent
// Size: 0x28(Inherited: 0x0) 
struct FChaosRemovalEvent
{
	struct UPrimitiveComponent* Component;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	float Mass;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ChaosSolverEngine.BreakEventCallbackWrapper
// Size: 0x40(Inherited: 0x0) 
struct FBreakEventCallbackWrapper
{
	char pad_0[64];  // 0x0(0x40)

}; 
// ScriptStruct ChaosSolverEngine.RemovalEventCallbackWrapper
// Size: 0x40(Inherited: 0x0) 
struct FRemovalEventCallbackWrapper
{
	char pad_0[64];  // 0x0(0x40)

}; 
// ScriptStruct ChaosSolverEngine.ChaosHandlerSet
// Size: 0x58(Inherited: 0x0) 
struct FChaosHandlerSet
{
	char pad_0[8];  // 0x0(0x8)
	struct TSet<struct UObject*> ChaosHandlers;  // 0x8(0x50)

}; 
// Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
// Size: 0x1A8(Inherited: 0x0) 
struct FConvertPhysicsCollisionToHitResult
{
	struct FChaosPhysicsCollisionInfo PhysicsCollision;  // 0x0(0xC0)
	struct FHitResult ReturnValue;  // 0xC0(0xE8)

}; 
// Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
// Size: 0x1(Inherited: 0x0) 
struct FSetSolverActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
