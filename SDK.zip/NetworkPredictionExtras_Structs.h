#pragma once 
#include "SDK.h" 
 
 
// Function NetworkPredictionExtras.PhysicsMovementComponent.SetEnableTargetYaw
// Size: 0x1(Inherited: 0x0) 
struct FSetEnableTargetYaw
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTargetYaw : 1;  // 0x0(0x1)

}; 
// Function NetworkPredictionExtras.BaseMovementComponent.OnBeginOverlap
// Size: 0x108(Inherited: 0x0) 
struct FOnBeginOverlap
{
	struct UPrimitiveComponent* OverlappedComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0xE8)

}; 
// Function NetworkPredictionExtras.BaseMovementComponent.PhysicsVolumeChanged
// Size: 0x8(Inherited: 0x0) 
struct FPhysicsVolumeChanged
{
	struct APhysicsVolume* NewVolume;  // 0x0(0x8)

}; 
// DelegateFunction NetworkPredictionExtras.MockCharacterAbilityComponent.MockCharacterAbilityNotifyStateChange__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FMockCharacterAbilityNotifyStateChange__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewStateValue : 1;  // 0x0(0x1)

}; 
// Function NetworkPredictionExtras.MockFlyingAbilityComponent.IsBlinking
// Size: 0x1(Inherited: 0x0) 
struct FIsBlinking
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function NetworkPredictionExtras.MockFlyingAbilityComponent.GetBlinkWarmupTimeSeconds
// Size: 0x4(Inherited: 0x0) 
struct FGetBlinkWarmupTimeSeconds
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct NetworkPredictionExtras.MockPhysicsInputCmd
// Size: 0x20(Inherited: 0x0) 
struct FMockPhysicsInputCmd
{
	struct FVector MovementInput;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bJumpedPressed : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bChargePressed : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility.GetStamina
// Size: 0x4(Inherited: 0x0) 
struct FGetStamina
{
	float ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction NetworkPredictionExtras.MockCharacterAbilityComponent.MockCharacterAbilityBlinkCueEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FMockCharacterAbilityBlinkCueEvent__DelegateSignature
{
	struct FVector DestinationLocation;  // 0x0(0x18)
	int32_t RandomValue;  // 0x18(0x4)
	float ElapsedTimeSeconds;  // 0x1C(0x4)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility.GetMaxStamina
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxStamina
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct NetworkPredictionExtras.SimpleLocalState
// Size: 0x8(Inherited: 0x0) 
struct FSimpleLocalState
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function NetworkPredictionExtras.MockCharacterAbilityComponent.IsJumping
// Size: 0x1(Inherited: 0x0) 
struct FIsJumping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function NetworkPredictionExtras.MockFlyingAbilityComponent.IsDashing
// Size: 0x1(Inherited: 0x0) 
struct FIsDashing
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function NetworkPredictionExtras.MockFlyingAbilityComponent.IsSprinting
// Size: 0x1(Inherited: 0x0) 
struct FIsSprinting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityBlinkCueEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FMockAbilityBlinkCueEvent__DelegateSignature
{
	struct FVector DestinationLocation;  // 0x0(0x18)
	int32_t RandomValue;  // 0x18(0x4)
	float ElapsedTimeSeconds;  // 0x1C(0x4)

}; 
// DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityNotifyStateChange__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FMockAbilityNotifyStateChange__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewStateValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityPhysicsGunFireEvent__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FMockAbilityPhysicsGunFireEvent__DelegateSignature
{
	struct FVector Start;  // 0x0(0x18)
	struct FVector End;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bHasCooldown : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TArray<struct FVector_NetQuantize100> HitLocations;  // 0x38(0x10)
	float ElapsedTimeSeconds;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct NetworkPredictionExtras.PhysicsMovementLocalState
// Size: 0x78(Inherited: 0x0) 
struct FPhysicsMovementLocalState
{
	char pad_0[120];  // 0x0(0x78)

}; 
// ScriptStruct NetworkPredictionExtras.SimpleNetState
// Size: 0x8(Inherited: 0x0) 
struct FSimpleNetState
{
	int32_t ButtonPressedCounter;  // 0x0(0x4)
	int32_t Counter;  // 0x4(0x4)

}; 
// DelegateFunction NetworkPredictionExtras.MockPhysicsComponent.MockPhysicsNotifyStateChange__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FMockPhysicsNotifyStateChange__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewStateValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction NetworkPredictionExtras.MockPhysicsComponent.PhysicsChargeCueEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FPhysicsChargeCueEvent__DelegateSignature
{
	struct FVector Location;  // 0x0(0x18)
	float ElapsedTimeSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// DelegateFunction NetworkPredictionExtras.MockPhysicsComponent.PhysicsJumpCueEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FPhysicsJumpCueEvent__DelegateSignature
{
	struct FVector Location;  // 0x0(0x18)
	float ElapsedTimeSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function NetworkPredictionExtras.PhysicsMovementComponent.SetAutoBrakeStrength
// Size: 0x4(Inherited: 0x0) 
struct FSetAutoBrakeStrength
{
	float BrakeStrength;  // 0x0(0x4)

}; 
// Function NetworkPredictionExtras.PhysicsMovementComponent.SetAutoTargetYawDamp
// Size: 0x4(Inherited: 0x0) 
struct FSetAutoTargetYawDamp
{
	float YawDamp;  // 0x0(0x4)

}; 
// Function NetworkPredictionExtras.PhysicsMovementComponent.SetAutoTargetYawStrength
// Size: 0x4(Inherited: 0x0) 
struct FSetAutoTargetYawStrength
{
	float Strength;  // 0x0(0x4)

}; 
// Function NetworkPredictionExtras.PhysicsMovementComponent.SetEnableKeepUpright
// Size: 0x1(Inherited: 0x0) 
struct FSetEnableKeepUpright
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bKeepUpright : 1;  // 0x0(0x1)

}; 
// ScriptStruct NetworkPredictionExtras.PhysicsInputCmd
// Size: 0x70(Inherited: 0x0) 
struct FPhysicsInputCmd
{
	struct FVector Force;  // 0x0(0x18)
	struct FVector Torque;  // 0x18(0x18)
	struct FVector Acceleration;  // 0x30(0x18)
	struct FVector AngularAcceleration;  // 0x48(0x18)
	float TargetYaw;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool bJumpedPressed : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool bBrakesPressed : 1;  // 0x65(0x1)
	char pad_102[10];  // 0x66(0xA)

}; 
// ScriptStruct NetworkPredictionExtras.PhysicsMovementNetState
// Size: 0x38(Inherited: 0x0) 
struct FPhysicsMovementNetState
{
	float ForceMultiplier;  // 0x0(0x4)
	float JumpStrength;  // 0x4(0x4)
	float AutoFaceTargetYawStrength;  // 0x8(0x4)
	float AutoFaceTargetYawDamp;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bEnableAutoFaceTargetYaw : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bEnableKeepUpright : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	float AutoBrakeStrength;  // 0x14(0x4)
	int32_t RandValue;  // 0x18(0x4)
	int32_t JumpCooldownMS;  // 0x1C(0x4)
	int32_t JumpCount;  // 0x20(0x4)
	int32_t CheckSum;  // 0x24(0x4)
	int32_t RecoveryFrame;  // 0x28(0x4)
	int32_t JumpStartFrame;  // 0x2C(0x4)
	int32_t InAirFrame;  // 0x30(0x4)
	int32_t KickFrame;  // 0x34(0x4)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.SetMaxMoveSpeed
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxMoveSpeed
{
	float NewMaxMoveSpeed;  // 0x0(0x4)

}; 
// Function NetworkPredictionExtras.PhysicsSimpleComponent.SetCounter
// Size: 0x4(Inherited: 0x0) 
struct FSetCounter
{
	int32_t NewValue;  // 0x0(0x4)

}; 
// ScriptStruct NetworkPredictionExtras.SimpleInputCmd
// Size: 0x20(Inherited: 0x0) 
struct FSimpleInputCmd
{
	struct FVector MovementDir;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bButtonPressed : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bLegit : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function NetworkPredictionExtras.MockRootMotionComponent.PlayRootMotionSource
// Size: 0x8(Inherited: 0x0) 
struct FPlayRootMotionSource
{
	struct UMockRootMotionSource* Source;  // 0x0(0x8)

}; 
// ScriptStruct NetworkPredictionExtras.RootMotionSourceCache
// Size: 0x10(Inherited: 0x0) 
struct FRootMotionSourceCache
{
	struct UMockRootMotionSource* Instance;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)

}; 
// ScriptStruct NetworkPredictionExtras.SimpleParametricMotion
// Size: 0x80(Inherited: 0x0) 
struct FSimpleParametricMotion
{
	struct FVector ParametricDelta;  // 0x0(0x18)
	float MinTime;  // 0x18(0x4)
	float MaxTime;  // 0x1C(0x4)
	char pad_32[96];  // 0x20(0x60)

}; 
// Function NetworkPredictionExtras.MockRootMotionComponent.CreateRootMotionSource
// Size: 0x10(Inherited: 0x0) 
struct FCreateRootMotionSource
{
	UMockRootMotionSource* Source;  // 0x0(0x8)
	struct UMockRootMotionSource* ReturnValue;  // 0x8(0x8)

}; 
// Function NetworkPredictionExtras.MockRootMotionComponent.Input_PlayRootMotionSource
// Size: 0x8(Inherited: 0x0) 
struct FInput_PlayRootMotionSource
{
	struct UMockRootMotionSource* Source;  // 0x0(0x8)

}; 
// Function NetworkPredictionExtras.MockRootMotionComponent.Input_PlayRootMotionSourceByClass
// Size: 0x8(Inherited: 0x0) 
struct FInput_PlayRootMotionSourceByClass
{
	UMockRootMotionSource* Source;  // 0x0(0x8)

}; 
// Function NetworkPredictionExtras.MockRootMotionComponent.PlayRootMotionSourceByClass
// Size: 0x8(Inherited: 0x0) 
struct FPlayRootMotionSourceByClass
{
	UMockRootMotionSource* Source;  // 0x0(0x8)

}; 
// Function NetworkPredictionExtras.MockRootMotionSource_MoveToLocation.SetDestination
// Size: 0x18(Inherited: 0x0) 
struct FSetDestination
{
	struct FVector InDestination;  // 0x0(0x18)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.AddMaxMoveSpeed
// Size: 0x4(Inherited: 0x0) 
struct FAddMaxMoveSpeed
{
	float AdditiveMaxMoveSpeed;  // 0x0(0x4)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.GetMaxMoveSpeed
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxMoveSpeed
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter_MockAbility.GetMockCharacterAbilityComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetMockCharacterAbilityComponent
{
	struct UMockCharacterAbilityComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility.GetMockFlyingAbilityComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetMockFlyingAbilityComponent
{
	struct UMockFlyingAbilityComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function NetworkPredictionExtras.ParametricMovementComponent.EnableInterpolationMode
// Size: 0x1(Inherited: 0x0) 
struct FEnableInterpolationMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValue : 1;  // 0x0(0x1)

}; 
