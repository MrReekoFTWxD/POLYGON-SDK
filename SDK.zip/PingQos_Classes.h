#pragma once 
#include <PingQos_Structs.h>
 
 
 
// Class PingQos.PingQosSubsystem
// Size: 0x60(Inherited: 0x30) 
struct UPingQosSubsystem : public UEngineSubsystem
{
	struct FMulticastInlineDelegate OnPingCompleted;  // 0x30(0x10)
	struct TArray<struct FPingQosInfo> PingInfos;  // 0x40(0x10)
	char pad_80[16];  // 0x50(0x10)

	bool Update(); // Function PingQos.PingQosSubsystem.Update
	void Init(struct TArray<struct FPingQosInfo> SetInfo); // Function PingQos.PingQosSubsystem.Init
}; 



