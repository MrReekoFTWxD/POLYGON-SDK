#pragma once 
#include "SDK.h" 
 
 
// Function OpenCVHelper.OpenCVBlueprintFunctionLibrary.OpenCVArucoDetectMarkers
// Size: 0x78(Inherited: 0x0) 
struct FOpenCVArucoDetectMarkers
{
	struct UTextureRenderTarget2D* InRenderTarget;  // 0x0(0x8)
	uint8_t  InDictionary;  // 0x8(0x1)
	uint8_t  InDictionarySize;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bDebugDrawMarkers : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool bEstimatePose : 1;  // 0xB(0x1)
	float InMarkerLengthInMeters;  // 0xC(0x4)
	struct FOpenCVLensDistortionParametersBase InLensDistortionParameters;  // 0x10(0x48)
	struct UTexture2D* OutDebugTexture;  // 0x58(0x8)
	struct TArray<struct FOpenCVArucoDetectedMarker> OutDetectedMarkers;  // 0x60(0x10)
	int32_t ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)

}; 
// ScriptStruct OpenCVHelper.OpenCVLensDistortionParametersBase
// Size: 0x48(Inherited: 0x0) 
struct FOpenCVLensDistortionParametersBase
{
	float K1;  // 0x0(0x4)
	float K2;  // 0x4(0x4)
	float P1;  // 0x8(0x4)
	float P2;  // 0xC(0x4)
	float K3;  // 0x10(0x4)
	float K4;  // 0x14(0x4)
	float K5;  // 0x18(0x4)
	float K6;  // 0x1C(0x4)
	struct FVector2D F;  // 0x20(0x10)
	struct FVector2D C;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bUseFisheyeModel : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct OpenCVHelper.OpenCVArucoDetectedMarker
// Size: 0x80(Inherited: 0x0) 
struct FOpenCVArucoDetectedMarker
{
	int32_t ID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FVector2D> Corners;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform Pose;  // 0x20(0x60)

}; 
// Function OpenCVHelper.OpenCVBlueprintFunctionLibrary.OpenCVChessboardDetectCorners
// Size: 0x38(Inherited: 0x0) 
struct FOpenCVChessboardDetectCorners
{
	struct UTextureRenderTarget2D* InRenderTarget;  // 0x0(0x8)
	struct FIntPoint InPatternSize;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDebugDrawCorners : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UTexture2D* OutDebugTexture;  // 0x18(0x8)
	struct TArray<struct FVector2D> OutDetectedCorners;  // 0x20(0x10)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
