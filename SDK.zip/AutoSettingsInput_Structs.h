#pragma once 
#include "SDK.h" 
 
 
// Function AutoSettingsInput.InputMappingManager.GetPlayerActionMapping
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayerActionMapping
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName ActionName;  // 0x8(0x8)
	int32_t MappingGroup;  // 0x10(0x4)
	struct FGameplayTag KeyGroup;  // 0x14(0x8)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bUsePlayerKeyGroup : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FInputActionKeyMapping ReturnValue;  // 0x20(0x28)

}; 
// DelegateFunction AutoSettingsInput.CapturePromptClosedEvent__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCapturePromptClosedEvent__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function AutoSettingsInput.KeyLabel.GetIcon
// Size: 0x8(Inherited: 0x0) 
struct FGetIcon
{
	struct UTexture* ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction AutoSettingsInput.ChordCapturedEvent__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FChordCapturedEvent__DelegateSignature
{
	struct FCapturedInput CapturedInput;  // 0x0(0x28)

}; 
// DelegateFunction AutoSettingsInput.ChordRejectedEvent__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FChordRejectedEvent__DelegateSignature
{
	struct FCapturedInput CapturedInput;  // 0x0(0x28)

}; 
// DelegateFunction AutoSettingsInput.OnMappingsChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnMappingsChanged__DelegateSignature
{
	struct APlayerController* Player;  // 0x0(0x8)

}; 
// Function AutoSettingsInput.InputMappingManager.InitializePlayerInputOverridesStatic
// Size: 0x10(Inherited: 0x0) 
struct FInitializePlayerInputOverridesStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AutoSettingsInput.CapturedInput
// Size: 0x28(Inherited: 0x0) 
struct FCapturedInput
{
	struct FInputChord Chord;  // 0x0(0x20)
	float AxisScale;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct AutoSettingsInput.KeyIconPair
// Size: 0x20(Inherited: 0x0) 
struct FKeyIconPair
{
	struct FKey Key;  // 0x0(0x18)
	struct UTexture* Icon;  // 0x18(0x8)

}; 
// ScriptStruct AutoSettingsInput.KeyIconSet
// Size: 0x80(Inherited: 0x0) 
struct FKeyIconSet
{
	struct FGameplayTagContainer Tags;  // 0x0(0x20)
	struct TMap<struct FKey, struct TSoftObjectPtr<UTexture>> IconMap;  // 0x20(0x50)
	struct TArray<struct FKeyIconPair> Icons;  // 0x70(0x10)

}; 
// ScriptStruct AutoSettingsInput.KeyGroup
// Size: 0x20(Inherited: 0x0) 
struct FKeyGroup
{
	struct FGameplayTag KeyGroupTag;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUseGamepadKeys : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bUseNonGamepadKeys : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct TArray<struct FKey> Keys;  // 0x10(0x10)

}; 
// Function AutoSettingsInput.KeyLabel.GetIconVisibility
// Size: 0x1(Inherited: 0x0) 
struct FGetIconVisibility
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// ScriptStruct AutoSettingsInput.KeyScale
// Size: 0x20(Inherited: 0x0) 
struct FKeyScale
{
	struct FKey Key;  // 0x0(0x18)
	float Scale;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerAxisMappings
// Size: 0x38(Inherited: 0x0) 
struct FGetPlayerAxisMappings
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName AxisName;  // 0x8(0x8)
	float Scale;  // 0x10(0x4)
	int32_t MappingGroup;  // 0x14(0x4)
	struct FGameplayTag KeyGroup;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bUsePlayerKeyGroup : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FInputAxisKeyMapping> ReturnValue;  // 0x28(0x10)

}; 
// ScriptStruct AutoSettingsInput.MappingGroupLink
// Size: 0x10(Inherited: 0x0) 
struct FMappingGroupLink
{
	struct TArray<int32_t> MappingGroups;  // 0x0(0x10)

}; 
// Function AutoSettingsInput.AutoSettingsPlayer.SaveInputMappings
// Size: 0xA0(Inherited: 0x0) 
struct FSaveInputMappings
{
	struct FPlayerInputMappings InputMappings;  // 0x0(0xA0)

}; 
// ScriptStruct AutoSettingsInput.AxisAssociation
// Size: 0x50(Inherited: 0x0) 
struct FAxisAssociation
{
	struct FKey AxisKey;  // 0x0(0x18)
	struct FKey AnalogKey;  // 0x18(0x18)
	struct TArray<struct FKeyScale> ButtonKeys;  // 0x30(0x10)
	struct TArray<struct FKeyScale> BooleanKeys;  // 0x40(0x10)

}; 
// Function AutoSettingsInput.InputMappingManager.AddPlayerAxisOverride
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerAxisOverride
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputAxisKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// ScriptStruct AutoSettingsInput.KeyFriendlyName
// Size: 0x30(Inherited: 0x0) 
struct FKeyFriendlyName
{
	struct FKey Key;  // 0x0(0x18)
	struct FText FriendlyName;  // 0x18(0x18)

}; 
// Function AutoSettingsInput.AutoSettingsInputProjectConfig.LoadKeyIcons
// Size: 0x30(Inherited: 0x0) 
struct FLoadKeyIcons
{
	struct FGameplayTagContainer KeyIconTags;  // 0x0(0x20)
	struct TArray<struct UTexture*> ReturnValue;  // 0x20(0x10)

}; 
// ScriptStruct AutoSettingsInput.InputMappingGroup
// Size: 0x50(Inherited: 0x0) 
struct FInputMappingGroup
{
	struct TArray<struct FConfigActionKeyMapping> ActionMappings;  // 0x0(0x10)
	struct TArray<struct FConfigAxisKeyMapping> AxisMappings;  // 0x10(0x10)
	struct TArray<struct FConfigActionKeyMapping> UnboundActionMappings;  // 0x20(0x10)
	struct TArray<struct FConfigAxisKeyMapping> UnboundAxisMappings;  // 0x30(0x10)
	char pad_64[16];  // 0x40(0x10)

}; 
// ScriptStruct AutoSettingsInput.InputMappingPreset
// Size: 0x40(Inherited: 0x0) 
struct FInputMappingPreset
{
	struct FGameplayTag PresetTag;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUseDefaultMappings : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FInputMappingLayout InputLayout;  // 0x10(0x20)
	struct TArray<struct FInputMappingGroup> MappingGroups;  // 0x30(0x10)

}; 
// ScriptStruct AutoSettingsInput.ConfigAxisKeyMapping
// Size: 0x30(Inherited: 0x28) 
struct FConfigAxisKeyMapping : public FInputAxisKeyMapping
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsDefault : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AutoSettingsInput.KeyLabel.GetDisplayName
// Size: 0x18(Inherited: 0x0) 
struct FGetDisplayName
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// ScriptStruct AutoSettingsInput.ConfigActionKeyMapping
// Size: 0x30(Inherited: 0x28) 
struct FConfigActionKeyMapping : public FInputActionKeyMapping
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsDefault : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct AutoSettingsInput.InputMappingLayout
// Size: 0x20(Inherited: 0x0) 
struct FInputMappingLayout
{
	struct TArray<struct FInputMappingGroup> MappingGroups;  // 0x0(0x10)
	char pad_16[16];  // 0x10(0x10)

}; 
// Function AutoSettingsInput.InputMappingManager.AddPlayerActionOverride
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerActionOverride
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputActionKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// ScriptStruct AutoSettingsInput.PlayerInputMappings
// Size: 0xA0(Inherited: 0x0) 
struct FPlayerInputMappings
{
	struct FString PlayerId;  // 0x0(0x10)
	int32_t PlayerIndex;  // 0x10(0x4)
	struct FGameplayTag BasePresetTag;  // 0x14(0x8)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bNullBasePreset : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FInputMappingLayout MappingOverrides;  // 0x20(0x20)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Custom : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FInputMappingPreset Preset;  // 0x48(0x40)
	struct FGameplayTag PlayerKeyGroup;  // 0x88(0x8)
	char pad_144[16];  // 0x90(0x10)

}; 
// Function AutoSettingsInput.KeyLabel.GetIconBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetIconBrush
{
	struct FSlateBrush ReturnValue;  // 0x0(0xD0)

}; 
// Function AutoSettingsInput.InputLabel.MappingsChanged
// Size: 0x8(Inherited: 0x0) 
struct FMappingsChanged
{
	struct APlayerController* Player;  // 0x0(0x8)

}; 
// Function AutoSettingsInput.InputMappingManager.OnRegisteredPlayerControllerDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FOnRegisteredPlayerControllerDestroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function AutoSettingsInput.InputMappingManager.GetDefaultInputPresets
// Size: 0x10(Inherited: 0x0) 
struct FGetDefaultInputPresets
{
	struct TArray<struct FInputMappingPreset> ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettingsInput.InputMapping.BindChord
// Size: 0x28(Inherited: 0x0) 
struct FBindChord
{
	struct FCapturedInput CapturedInput;  // 0x0(0x28)

}; 
// Function AutoSettingsInput.BindCaptureButton.ChordCaptured
// Size: 0x28(Inherited: 0x0) 
struct FChordCaptured
{
	struct FCapturedInput CapturedInput;  // 0x0(0x28)

}; 
// Function AutoSettingsInput.AutoSettingsInputProjectConfig.GetKeyFriendlyNameStatic
// Size: 0x30(Inherited: 0x0) 
struct FGetKeyFriendlyNameStatic
{
	struct FKey Key;  // 0x0(0x18)
	struct FText ReturnValue;  // 0x18(0x18)

}; 
// Function AutoSettingsInput.AutoSettingsInputProjectConfig.GetKeyGroupStatic
// Size: 0x20(Inherited: 0x0) 
struct FGetKeyGroupStatic
{
	struct FKey Key;  // 0x0(0x18)
	struct FGameplayTag ReturnValue;  // 0x18(0x8)

}; 
// Function AutoSettingsInput.AutoSettingsPlayer.GetDefaultInputMappingPreset
// Size: 0x40(Inherited: 0x0) 
struct FGetDefaultInputMappingPreset
{
	struct FInputMappingPreset ReturnValue;  // 0x0(0x40)

}; 
// Function AutoSettingsInput.AutoSettingsPlayer.GetInputMappings
// Size: 0xA8(Inherited: 0x0) 
struct FGetInputMappings
{
	struct FPlayerInputMappings InputMappings;  // 0x0(0xA0)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
// Function AutoSettingsInput.AutoSettingsPlayer.GetUniquePlayerIdentifier
// Size: 0x10(Inherited: 0x0) 
struct FGetUniquePlayerIdentifier
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettingsInput.BindCaptureButton.InitializePrompt
// Size: 0x8(Inherited: 0x0) 
struct FInitializePrompt
{
	struct UBindCapturePrompt* PromptWidget;  // 0x0(0x8)

}; 
// Function AutoSettingsInput.BindCaptureButton.StartCapture
// Size: 0x8(Inherited: 0x0) 
struct FStartCapture
{
	struct UBindCapturePrompt* ReturnValue;  // 0x0(0x8)

}; 
// Function AutoSettingsInput.BindCapturePrompt.GetKeyGroup
// Size: 0x8(Inherited: 0x0) 
struct FGetKeyGroup
{
	struct FGameplayTag ReturnValue;  // 0x0(0x8)

}; 
// Function AutoSettingsInput.BindCapturePrompt.IsKeyAllowed
// Size: 0x20(Inherited: 0x0) 
struct FIsKeyAllowed
{
	struct FKey PrimaryKey;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function AutoSettingsInput.GlobalKeyIconTagManager.GetIconForKey
// Size: 0x48(Inherited: 0x0) 
struct FGetIconForKey
{
	struct FKey InKey;  // 0x0(0x18)
	struct FGameplayTagContainer IconTags;  // 0x18(0x20)
	float AxisScale;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UTexture* ReturnValue;  // 0x40(0x8)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerMappingsByKey
// Size: 0x40(Inherited: 0x0) 
struct FGetPlayerMappingsByKey
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FKey Key;  // 0x8(0x18)
	struct TArray<struct FInputActionKeyMapping> Actions;  // 0x20(0x10)
	struct TArray<struct FInputAxisKeyMapping> Axes;  // 0x30(0x10)

}; 
// Function AutoSettingsInput.GlobalKeyIconTagManager.SetGlobalKeyIconTags
// Size: 0x20(Inherited: 0x0) 
struct FSetGlobalKeyIconTags
{
	struct FGameplayTagContainer InGlobalIconTags;  // 0x0(0x20)

}; 
// Function AutoSettingsInput.InputMappingManager.AddPlayerActionOverrideStatic
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerActionOverrideStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputActionKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function AutoSettingsInput.InputMappingManager.AddPlayerAxisOverrideStatic
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerAxisOverrideStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputAxisKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function AutoSettingsInput.InputMappingManager.SetPlayerInputPresetStatic
// Size: 0x48(Inherited: 0x0) 
struct FSetPlayerInputPresetStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputMappingPreset Preset;  // 0x8(0x40)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerActionMappings
// Size: 0x30(Inherited: 0x0) 
struct FGetPlayerActionMappings
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName ActionName;  // 0x8(0x8)
	int32_t MappingGroup;  // 0x10(0x4)
	struct FGameplayTag KeyGroup;  // 0x14(0x8)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bUsePlayerKeyGroup : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct TArray<struct FInputActionKeyMapping> ReturnValue;  // 0x20(0x10)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerActionMappingStatic
// Size: 0x40(Inherited: 0x0) 
struct FGetPlayerActionMappingStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName ActionName;  // 0x8(0x8)
	int32_t MappingGroup;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FInputActionKeyMapping ReturnValue;  // 0x18(0x28)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerAxisMapping
// Size: 0x50(Inherited: 0x0) 
struct FGetPlayerAxisMapping
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName AxisName;  // 0x8(0x8)
	float Scale;  // 0x10(0x4)
	int32_t MappingGroup;  // 0x14(0x4)
	struct FGameplayTag KeyGroup;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bUsePlayerKeyGroup : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FInputAxisKeyMapping ReturnValue;  // 0x28(0x28)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerAxisMappingStatic
// Size: 0x40(Inherited: 0x0) 
struct FGetPlayerAxisMappingStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName AxisName;  // 0x8(0x8)
	float Scale;  // 0x10(0x4)
	int32_t MappingGroup;  // 0x14(0x4)
	struct FInputAxisKeyMapping ReturnValue;  // 0x18(0x28)

}; 
// Function AutoSettingsInput.InputMappingManager.GetPlayerInputMappingsStatic
// Size: 0xA8(Inherited: 0x0) 
struct FGetPlayerInputMappingsStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FPlayerInputMappings ReturnValue;  // 0x8(0xA0)

}; 
// Function AutoSettingsInput.InputMappingManager.SetPlayerInputPresetByTag
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerInputPresetByTag
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FGameplayTag PresetTag;  // 0x8(0x8)

}; 
// Function AutoSettingsInput.KeyLabel.HasValidKey
// Size: 0x1(Inherited: 0x0) 
struct FHasValidKey
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettingsInput.InputMappingManager.SetPlayerKeyGroupStatic
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerKeyGroupStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FGameplayTag KeyGroup;  // 0x8(0x8)

}; 
// Function AutoSettingsInput.KeyLabel.GetDisplayNameVisibility
// Size: 0x1(Inherited: 0x0) 
struct FGetDisplayNameVisibility
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function AutoSettingsInput.KeyLabel.HasIcon
// Size: 0x1(Inherited: 0x0) 
struct FHasIcon
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
