#pragma once 
#include <DataContainer_Structs.h>
 
 
 
// Class DataContainer.DataContainerValue_Int32
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_Int32 : public UDataContainerValue_Base
{
	int32_t Data;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class DataContainer.DataContainerValue_UObject
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_UObject : public UDataContainerValue_Base
{
	struct UObject* Data;  // 0x38(0x8)

}; 



// Class DataContainer.DataContainerObject
// Size: 0x88(Inherited: 0x28) 
struct UDataContainerObject : public UObject
{
	struct TMap<struct FString, struct UDataContainerValue_Base*> Values;  // 0x28(0x50)
	struct FString OptionalData;  // 0x78(0x10)

	struct UDataContainerObject* ConstructDataObject(struct UObject* WorldContextObject); // Function DataContainer.DataContainerObject.ConstructDataObject
}; 



// Class DataContainer.DataContainerValue_Base
// Size: 0x38(Inherited: 0x28) 
struct UDataContainerValue_Base : public UObject
{
	struct FString OptionalData;  // 0x28(0x10)

}; 



// Class DataContainer.DataContainerValue_Float
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_Float : public UDataContainerValue_Base
{
	float Data;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class DataContainer.DataContainerValue_Bool
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_Bool : public UDataContainerValue_Base
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Data : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 



// Class DataContainer.DataContainerValue_FloatArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_FloatArray : public UDataContainerValue_Base
{
	struct TArray<float> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_BoolArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_BoolArray : public UDataContainerValue_Base
{
	struct TArray<bool> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_FString
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_FString : public UDataContainerValue_Base
{
	struct FString Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_Int32Array
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_Int32Array : public UDataContainerValue_Base
{
	struct TArray<int32_t> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_Uint8
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_Uint8 : public UDataContainerValue_Base
{
	char Data;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 



// Class DataContainer.DataContainerValue_Uint8Array
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_Uint8Array : public UDataContainerValue_Base
{
	struct TArray<char> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_FStringArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_FStringArray : public UDataContainerValue_Base
{
	struct TArray<struct FString> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_FVector
// Size: 0x50(Inherited: 0x38) 
struct UDataContainerValue_FVector : public UDataContainerValue_Base
{
	struct FVector Data;  // 0x38(0x18)

}; 



// Class DataContainer.DataContainerValue_FVectorArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_FVectorArray : public UDataContainerValue_Base
{
	struct TArray<struct FVector> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_DataObject
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_DataObject : public UDataContainerValue_Base
{
	struct UDataContainerObject* Data;  // 0x38(0x8)

}; 



// Class DataContainer.DataContainerValue_DataObjectArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_DataObjectArray : public UDataContainerValue_Base
{
	struct TArray<struct UDataContainerObject*> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_UObjectArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_UObjectArray : public UDataContainerValue_Base
{
	struct TArray<struct UObject*> Data;  // 0x38(0x10)

}; 



// Class DataContainer.DataContainerValue_UClass
// Size: 0x40(Inherited: 0x38) 
struct UDataContainerValue_UClass : public UDataContainerValue_Base
{
	UObject* Data;  // 0x38(0x8)

}; 



// Class DataContainer.DataContainerValue_UClassArray
// Size: 0x48(Inherited: 0x38) 
struct UDataContainerValue_UClassArray : public UDataContainerValue_Base
{
	struct TArray<UObject*> Data;  // 0x38(0x10)

}; 



