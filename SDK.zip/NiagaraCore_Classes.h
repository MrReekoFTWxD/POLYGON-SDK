#pragma once 
#include <NiagaraCore_Structs.h>
 
 
 
// Class NiagaraCore.NiagaraMergeable
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraMergeable : public UObject
{

}; 



// Class NiagaraCore.NiagaraDataInterfaceBase
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraDataInterfaceBase : public UNiagaraMergeable
{

}; 



