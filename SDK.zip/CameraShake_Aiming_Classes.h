#pragma once 
#include <CameraShake_Aiming_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_Aiming.CameraShake_Aiming_C
// Size: 0x230(Inherited: 0x230) 
struct UCameraShake_Aiming_C : public UMatineeCameraShake
{

}; 



