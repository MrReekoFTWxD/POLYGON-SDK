#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NiagaraShader.SimulationStageMetaData
// Size: 0x68(Inherited: 0x0) 
struct FSimulationStageMetaData
{
	struct FName SimulationStageName;  // 0x0(0x8)
	struct FName EnabledBinding;  // 0x8(0x8)
	struct FName IterationSource;  // 0x10(0x8)
	uint8_t  ExecuteBehavior;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	char bWritesParticles : 1;  // 0x1C(0x1)
	char bPartialParticleUpdate : 1;  // 0x1C(0x1)
	char bParticleIterationStateEnabled : 1;  // 0x1C(0x1)
	char pad_28_1 : 5;  // 0x1C(0x1)
	char pad_29[4];  // 0x1D(0x4)
	struct FName ParticleIterationStateBinding;  // 0x20(0x8)
	char pad_40[4];  // 0x28(0x4)
	struct FIntPoint ParticleIterationStateRange;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct FName> OutputDestinations;  // 0x38(0x10)
	int32_t NumIterations;  // 0x48(0x4)
	struct FName NumIterationsBinding;  // 0x4C(0x8)
	uint8_t  GpuDispatchType;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FIntVector GpuDispatchNumThreads;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct NiagaraShader.NiagaraDataInterfaceGPUParamInfo
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraDataInterfaceGPUParamInfo
{
	struct FString DataInterfaceHLSLSymbol;  // 0x0(0x10)
	struct FString DIClassName;  // 0x10(0x10)
	struct TArray<struct FNiagaraDataInterfaceGeneratedFunction> GeneratedFunctions;  // 0x20(0x10)

}; 
// ScriptStruct NiagaraShader.NiagaraDataInterfaceGeneratedFunction
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraDataInterfaceGeneratedFunction
{
	char pad_0[40];  // 0x0(0x28)

}; 
// ScriptStruct NiagaraShader.NiagaraCompileEvent
// Size: 0x68(Inherited: 0x0) 
struct FNiagaraCompileEvent
{
	uint8_t  Severity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Message;  // 0x8(0x10)
	struct FString ShortDescription;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bDismissable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FGuid NodeGuid;  // 0x2C(0x10)
	struct FGuid PinGuid;  // 0x3C(0x10)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FGuid> StackGuids;  // 0x50(0x10)
	uint8_t  Source;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
