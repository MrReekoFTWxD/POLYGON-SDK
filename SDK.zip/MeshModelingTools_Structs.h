#pragma once 
#include "SDK.h" 
 
 
// Function MeshModelingTools.MeshUVChannelProperties.GetUVChannelNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetUVChannelNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
