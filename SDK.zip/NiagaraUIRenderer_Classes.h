#pragma once 
#include <NiagaraUIRenderer_Structs.h>
 
 
 
// Class NiagaraUIRenderer.NiagaraSystemWidget
// Size: 0x1B0(Inherited: 0x128) 
struct UNiagaraSystemWidget : public UWidget
{
	struct UNiagaraSystem* NiagaraSystemReference;  // 0x128(0x8)
	struct TMap<struct UMaterialInterface*, struct UMaterialInterface*> MaterialRemapList;  // 0x130(0x50)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool AutoActivate : 1;  // 0x180(0x1)
	char pad_385_1 : 7;  // 0x181(0x1)
	bool TickWhenPaused : 1;  // 0x181(0x1)
	char pad_386_1 : 7;  // 0x182(0x1)
	bool FakeDepthScale : 1;  // 0x182(0x1)
	char pad_387[1];  // 0x183(0x1)
	float FakeDepthScaleDistance;  // 0x184(0x4)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool ShowDebugSystemInWorld : 1;  // 0x188(0x1)
	char pad_393_1 : 7;  // 0x189(0x1)
	bool DisableWarnings : 1;  // 0x189(0x1)
	char pad_394[22];  // 0x18A(0x16)
	struct ANiagaraUIActor* NiagaraActor;  // 0x1A0(0x8)
	struct UNiagaraUIComponent* NiagaraComponent;  // 0x1A8(0x8)

	void UpdateTickWhenPaused(bool NewTickWhenPaused); // Function NiagaraUIRenderer.NiagaraSystemWidget.UpdateTickWhenPaused
	void UpdateNiagaraSystemReference(struct UNiagaraSystem* NewNiagaraSystem); // Function NiagaraUIRenderer.NiagaraSystemWidget.UpdateNiagaraSystemReference
	struct UNiagaraUIComponent* GetNiagaraComponent(); // Function NiagaraUIRenderer.NiagaraSystemWidget.GetNiagaraComponent
	void DeactivateSystem(); // Function NiagaraUIRenderer.NiagaraSystemWidget.DeactivateSystem
	void ActivateSystem(bool Reset); // Function NiagaraUIRenderer.NiagaraSystemWidget.ActivateSystem
}; 



// Class NiagaraUIRenderer.NiagaraUIActor
// Size: 0x278(Inherited: 0x278) 
struct ANiagaraUIActor : public AActor
{

}; 



// Class NiagaraUIRenderer.NiagaraUIComponent
// Size: 0x7D0(Inherited: 0x7D0) 
struct UNiagaraUIComponent : public UNiagaraComponent
{

}; 



