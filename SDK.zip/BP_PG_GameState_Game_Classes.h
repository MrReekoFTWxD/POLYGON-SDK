#pragma once 
#include <BP_PG_GameState_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_GameState_Game.BP_PG_GameState_Game_C
// Size: 0x478(Inherited: 0x470) 
struct ABP_PG_GameState_Game_C : public APG_GameState_Game
{
	struct USceneComponent* DefaultSceneRoot;  // 0x470(0x8)

}; 



