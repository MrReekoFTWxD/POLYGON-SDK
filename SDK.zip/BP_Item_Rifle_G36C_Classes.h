#pragma once 
#include <BP_Item_Rifle_G36C_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Rifle_G36C.BP_Item_Rifle_G36C_C
// Size: 0x598(Inherited: 0x590) 
struct ABP_Item_Rifle_G36C_C : public AItem_Weapon_Rifle
{
	struct UStaticMeshComponent* Sight;  // 0x590(0x8)

}; 



