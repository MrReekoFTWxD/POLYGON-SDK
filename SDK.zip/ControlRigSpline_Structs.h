#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ControlRigSpline.ControlRigSplineImpl
// Size: 0x60(Inherited: 0x0) 
struct FControlRigSplineImpl
{
	char pad_0[96];  // 0x0(0x60)

}; 
// ScriptStruct ControlRigSpline.RigUnit_TransformFromControlRigSpline
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_TransformFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	struct FVector UpVector;  // 0x20(0x18)
	float Roll;  // 0x38(0x4)
	float U;  // 0x3C(0x4)
	struct FTransform Transform;  // 0x40(0x60)

}; 
// ScriptStruct ControlRigSpline.ControlRigSpline
// Size: 0x18(Inherited: 0x0) 
struct FControlRigSpline
{
	char pad_0[24];  // 0x0(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_SetSplinePoints
// Size: 0x100(Inherited: 0xD0) 
struct FRigUnit_SetSplinePoints : public FRigUnitMutable
{
	struct TArray<struct FVector> Points;  // 0xD0(0x10)
	struct FControlRigSpline Spline;  // 0xE0(0x18)
	char pad_248[8];  // 0xF8(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_TangentFromControlRigSpline
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_TangentFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float U;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector Tangent;  // 0x28(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitChainToSplineCurve
// Size: 0x2A0(Inherited: 0xD0) 
struct FRigUnit_FitChainToSplineCurve : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0xD0(0x10)
	struct FControlRigSpline Spline;  // 0xE0(0x18)
	uint8_t  Alignment;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float Minimum;  // 0xFC(0x4)
	float Maximum;  // 0x100(0x4)
	int32_t SamplingPrecision;  // 0x104(0x4)
	struct FVector PrimaryAxis;  // 0x108(0x18)
	struct FVector SecondaryAxis;  // 0x120(0x18)
	struct FVector PoleVectorPosition;  // 0x138(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0x150(0x10)
	uint8_t  RotationEaseType;  // 0x160(0x1)
	char pad_353[3];  // 0x161(0x3)
	float Weight;  // 0x164(0x4)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool bPropagateToChildren : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0x170(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x200(0x98)
	char pad_664[8];  // 0x298(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ControlRigSplineBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_ControlRigSplineBase : public FRigUnit
{

}; 
// ScriptStruct ControlRigSpline.RigUnit_PositionFromControlRigSpline
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_PositionFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float U;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector position;  // 0x28(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ControlRigSplineFromPoints
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_ControlRigSplineFromPoints : public FRigUnit_ControlRigSplineBase
{
	struct TArray<struct FVector> Points;  // 0x8(0x10)
	uint8_t  SplineMode;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t SamplesPerSegment;  // 0x1C(0x4)
	float Compression;  // 0x20(0x4)
	float Stretch;  // 0x24(0x4)
	struct FControlRigSpline Spline;  // 0x28(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_DrawControlRigSpline
// Size: 0x100(Inherited: 0xD0) 
struct FRigUnit_DrawControlRigSpline : public FRigUnitMutable
{
	struct FControlRigSpline Spline;  // 0xD0(0x18)
	struct FLinearColor Color;  // 0xE8(0x10)
	float Thickness;  // 0xF8(0x4)
	int32_t Detail;  // 0xFC(0x4)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ParameterAtPercentage
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_ParameterAtPercentage : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float Percentage;  // 0x20(0x4)
	float U;  // 0x24(0x4)

}; 
// ScriptStruct ControlRigSpline.RigUnit_GetLengthControlRigSpline
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_GetLengthControlRigSpline : public FRigUnit
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float Length;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitChainToSplineCurveItemArray
// Size: 0x2A0(Inherited: 0xD0) 
struct FRigUnit_FitChainToSplineCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0xD0(0x10)
	struct FControlRigSpline Spline;  // 0xE0(0x18)
	uint8_t  Alignment;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float Minimum;  // 0xFC(0x4)
	float Maximum;  // 0x100(0x4)
	int32_t SamplingPrecision;  // 0x104(0x4)
	struct FVector PrimaryAxis;  // 0x108(0x18)
	struct FVector SecondaryAxis;  // 0x120(0x18)
	struct FVector PoleVectorPosition;  // 0x138(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0x150(0x10)
	uint8_t  RotationEaseType;  // 0x160(0x1)
	char pad_353[3];  // 0x161(0x3)
	float Weight;  // 0x164(0x4)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool bPropagateToChildren : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0x170(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x200(0x98)
	char pad_664[8];  // 0x298(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitSplineCurveToChain
// Size: 0x100(Inherited: 0xD0) 
struct FRigUnit_FitSplineCurveToChain : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0xD0(0x10)
	struct FControlRigSpline Spline;  // 0xE0(0x18)
	char pad_248[8];  // 0xF8(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitSplineCurveToChainItemArray
// Size: 0x100(Inherited: 0xD0) 
struct FRigUnit_FitSplineCurveToChainItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0xD0(0x10)
	struct FControlRigSpline Spline;  // 0xE0(0x18)
	char pad_248[8];  // 0xF8(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ClosestParameterFromControlRigSpline
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_ClosestParameterFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	struct FVector position;  // 0x20(0x18)
	float U;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
