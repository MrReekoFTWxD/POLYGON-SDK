#pragma once 
#include <POLYGON_Structs.h>
 
 
 
// Class POLYGON.ServerGameInstance
// Size: 0x38(Inherited: 0x28) 
struct UServerGameInstance : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void OnGSDKShutdown(); // Function POLYGON.ServerGameInstance.OnGSDKShutdown
	void OnGSDKServerActive(); // Function POLYGON.ServerGameInstance.OnGSDKServerActive
	void OnGSDKReadyForPlayers(); // Function POLYGON.ServerGameInstance.OnGSDKReadyForPlayers
	bool OnGSDKHealthCheck(); // Function POLYGON.ServerGameInstance.OnGSDKHealthCheck
}; 



// Class POLYGON.BallisticMaterialResponseMap
// Size: 0x80(Inherited: 0x30) 
struct UBallisticMaterialResponseMap : public UDataAsset
{
	struct TMap<struct UPhysicalMaterial*, struct FBallisticMaterialResponseMapEntry> List;  // 0x30(0x50)

}; 



// Class POLYGON.PlayerCoreComponent
// Size: 0x148(Inherited: 0xB0) 
struct UPlayerCoreComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnSetTotalProgress;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnNewLevelReceived;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnAddedGameScore;  // 0xD0(0x10)
	int32_t PremiumScore;  // 0xE0(0x4)
	int32_t TotalProgress;  // 0xE4(0x4)
	int32_t Currency;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bHasPremiumAccount : 1;  // 0xF0(0x1)
	char pad_241[87];  // 0xF1(0x57)

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.PlayerCoreComponent.UpdatePlayerCombinedInfo
	void OnRep_TotalProgress(); // Function POLYGON.PlayerCoreComponent.OnRep_TotalProgress
	void NotifyAddedGameScore_client(struct TArray<struct FScoreInfo> ScoreInfos); // Function POLYGON.PlayerCoreComponent.NotifyAddedGameScore_client
	struct FLevelInfo GetNextLevelInfo(); // Function POLYGON.PlayerCoreComponent.GetNextLevelInfo
	struct FLevelInfo GetNextLevelByLevelID(struct FName LevelID); // Function POLYGON.PlayerCoreComponent.GetNextLevelByLevelID
	struct FLevelInfo GetLevelByProgress(int32_t Progress); // Function POLYGON.PlayerCoreComponent.GetLevelByProgress
	struct FLevelInfo GetCurrentLevelInfo(); // Function POLYGON.PlayerCoreComponent.GetCurrentLevelInfo
	void AddCurrency(int32_t AddCurrency); // Function POLYGON.PlayerCoreComponent.AddCurrency
}; 



// Class POLYGON.ClientBackendComponent
// Size: 0x130(Inherited: 0xF0) 
struct UClientBackendComponent : public UGeneralBackendComponent
{
	struct FMulticastInlineDelegate OnSetPlayerId;  // 0xF0(0x10)
	struct FMulticastInlineDelegate OnUpdatePlayerCombinedInfo;  // 0x100(0x10)
	struct FString PlayerMasterId;  // 0x110(0x10)
	struct UPlayFabJsonObject* PlayerCombinedInfo;  // 0x120(0x8)
	struct UPlayFabJsonObject* PlayerExperiments;  // 0x128(0x8)

	void SetPlayerId(struct FString newPlayerMasterId); // Function POLYGON.ClientBackendComponent.SetPlayerId
	void SetPlayerCombinedInfo(struct UPlayFabJsonObject* newPlayerCombinedInfo, struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.ClientBackendComponent.SetPlayerCombinedInfo
	void SerPlayerExperiments(struct UPlayFabJsonObject* Experiments); // Function POLYGON.ClientBackendComponent.SerPlayerExperiments
	bool IsClientLoggedIn(); // Function POLYGON.ClientBackendComponent.IsClientLoggedIn
	void GiveVipLocal(struct FString ID); // Function POLYGON.ClientBackendComponent.GiveVipLocal
	struct UPlayFabJsonObject* GetPlayerExperiments(); // Function POLYGON.ClientBackendComponent.GetPlayerExperiments
	struct UPlayFabJsonObject* GetPlayerCombinedInfo(); // Function POLYGON.ClientBackendComponent.GetPlayerCombinedInfo
}; 



// Class POLYGON.PG_GameState_Game
// Size: 0x470(Inherited: 0x2E8) 
struct APG_GameState_Game : public AGameState
{
	struct FMulticastInlineDelegate OnChangeGameState;  // 0x2E8(0x10)
	struct FMulticastInlineDelegate OnGameTimer;  // 0x2F8(0x10)
	struct FMulticastInlineDelegate OnCanMovePlayers;  // 0x308(0x10)
	struct FMulticastInlineDelegate OnTeamWon;  // 0x318(0x10)
	struct FMulticastInlineDelegate OnChangePlayersArray;  // 0x328(0x10)
	struct FMulticastInlineDelegate OnChangeTeamAlphaArray;  // 0x338(0x10)
	struct FMulticastInlineDelegate OnChangeTeamBravoArray;  // 0x348(0x10)
	struct FMulticastInlineDelegate OnChangeTotalScore;  // 0x358(0x10)
	uint8_t  GameState;  // 0x368(0x1)
	char pad_873[7];  // 0x369(0x7)
	struct FMapInfo CurrentMapInfo;  // 0x370(0x88)
	uint16_t GameTimer;  // 0x3F8(0x2)
	char pad_1018_1 : 7;  // 0x3FA(0x1)
	bool bCanMovePlayers : 1;  // 0x3FA(0x1)
	uint8_t  WinningTeam;  // 0x3FB(0x1)
	char pad_1020[4];  // 0x3FC(0x4)
	struct TArray<struct APG_PlayerState_Game*> Players;  // 0x400(0x10)
	struct TArray<struct APG_PlayerState_Game*> TeamAlpha;  // 0x410(0x10)
	struct TArray<struct APG_PlayerState_Game*> TeamBravo;  // 0x420(0x10)
	struct TArray<struct ATeamBase*> AllTeamBases;  // 0x430(0x10)
	struct TArray<struct AControlPoint*> AllControlPoints;  // 0x440(0x10)
	struct TArray<struct APlayerStart*> PlayerStarts;  // 0x450(0x10)
	uint16_t ScoreAlphaTeam;  // 0x460(0x2)
	uint16_t ScoreBravoTeam;  // 0x462(0x2)
	char pad_1124[12];  // 0x464(0xC)

	void SetCanMovePlayers(bool newMoveState); // Function POLYGON.PG_GameState_Game.SetCanMovePlayers
	void OnRep_WinningTeam(); // Function POLYGON.PG_GameState_Game.OnRep_WinningTeam
	void OnRep_TeamBravo(); // Function POLYGON.PG_GameState_Game.OnRep_TeamBravo
	void OnRep_TeamAlpha(); // Function POLYGON.PG_GameState_Game.OnRep_TeamAlpha
	void OnRep_ScoreBravoTeam(); // Function POLYGON.PG_GameState_Game.OnRep_ScoreBravoTeam
	void OnRep_ScoreAlphaTeam(); // Function POLYGON.PG_GameState_Game.OnRep_ScoreAlphaTeam
	void OnRep_Players(); // Function POLYGON.PG_GameState_Game.OnRep_Players
	void OnRep_GameTimer(); // Function POLYGON.PG_GameState_Game.OnRep_GameTimer
	void OnRep_GameState(); // Function POLYGON.PG_GameState_Game.OnRep_GameState
	void OnRep_CanMovePlayers(); // Function POLYGON.PG_GameState_Game.OnRep_CanMovePlayers
	void NotifyPlayerWasKicked(struct FString badGuyName, bool bNameWasOptimized); // Function POLYGON.PG_GameState_Game.NotifyPlayerWasKicked
	int32_t GetScoreBravoTeam(); // Function POLYGON.PG_GameState_Game.GetScoreBravoTeam
	int32_t GetScoreAlphaTeam(); // Function POLYGON.PG_GameState_Game.GetScoreAlphaTeam
	int32_t GetMaxScoreForWin(); // Function POLYGON.PG_GameState_Game.GetMaxScoreForWin
	int32_t GetGameTimer(); // Function POLYGON.PG_GameState_Game.GetGameTimer
}; 



// Class POLYGON.TraceProjectile
// Size: 0x488(Inherited: 0x278) 
struct ATraceProjectile : public AActor
{
	struct FVector Velocity;  // 0x278(0x18)
	struct FRandomStream RandomStream;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool OwnerSafe : 1;  // 0x298(0x1)
	char pad_665[103];  // 0x299(0x67)
	struct UParticleSystemComponent* ActiveTraceComponent;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool DebugEnabled : 1;  // 0x308(0x1)
	char pad_777[3];  // 0x309(0x3)
	float DebugTrailTime;  // 0x30C(0x4)
	float DebugTrailWidth;  // 0x310(0x4)
	struct FLinearColor DebugTrailColorFast;  // 0x314(0x10)
	struct FLinearColor DebugTrailColorSlow;  // 0x324(0x10)
	char pad_820_1 : 7;  // 0x334(0x1)
	bool DebugPooling : 1;  // 0x334(0x1)
	char pad_821[3];  // 0x335(0x3)
	struct FVector Wind;  // 0x338(0x18)
	uint8_t  AtmosphereType;  // 0x350(0x1)
	char pad_849[3];  // 0x351(0x3)
	float SeaLevelAirDensity;  // 0x354(0x4)
	float SeaLevelSpeedOfSound;  // 0x358(0x4)
	char pad_860[4];  // 0x35C(0x4)
	struct UCurveFloat* AirDensityCurve;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool SpeedOfSoundVariesWithAltitude : 1;  // 0x368(0x1)
	char pad_873[7];  // 0x369(0x7)
	struct UCurveFloat* SpeedOfSoundCurve;  // 0x370(0x8)
	char pad_888[4];  // 0x378(0x4)
	float SeaLevelAirPressure;  // 0x37C(0x4)
	float SeaLevelAirTemperature;  // 0x380(0x4)
	float TemperatureLapseRate;  // 0x384(0x4)
	float TropopauseAltitude;  // 0x388(0x4)
	float SpecificGasConstant;  // 0x38C(0x4)
	struct FVector WorldCenterLocation;  // 0x390(0x18)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool SphericalAltitude : 1;  // 0x3A8(0x1)
	char pad_937[3];  // 0x3A9(0x3)
	float SeaLevelRadius;  // 0x3AC(0x4)
	char pad_944_1 : 7;  // 0x3B0(0x1)
	bool OverrideGravity : 1;  // 0x3B0(0x1)
	char pad_945[7];  // 0x3B1(0x7)
	struct FVector Gravity;  // 0x3B8(0x18)
	char pad_976_1 : 7;  // 0x3D0(0x1)
	bool SafeLaunch : 1;  // 0x3D0(0x1)
	char pad_977_1 : 7;  // 0x3D1(0x1)
	bool SafeLaunchIgnoreAttachParent : 1;  // 0x3D1(0x1)
	char pad_978_1 : 7;  // 0x3D2(0x1)
	bool SafeLaunchIgnoreAllAttached : 1;  // 0x3D2(0x1)
	char pad_979[1];  // 0x3D3(0x1)
	float SafeDelay;  // 0x3D4(0x4)
	struct TArray<struct AActor*> SafeLaunchIgnoredActors;  // 0x3D8(0x10)
	float MuzzleVelocityMin;  // 0x3E8(0x4)
	float MuzzleVelocityMax;  // 0x3EC(0x4)
	float Spread;  // 0x3F0(0x4)
	float Mass;  // 0x3F4(0x4)
	float Diameter;  // 0x3F8(0x4)
	float FormFactor;  // 0x3FC(0x4)
	struct UCurveFloat* MachDragCurve;  // 0x400(0x8)
	float GrazingAngleExponent;  // 0x408(0x4)
	float MinPenetration;  // 0x40C(0x4)
	float MaxPenetration;  // 0x410(0x4)
	float PenetrationNormalization;  // 0x414(0x4)
	float PenetrationNormalizationGrazing;  // 0x418(0x4)
	float PenetrationEntryAngleSpread;  // 0x41C(0x4)
	float PenetrationExitAngleSpread;  // 0x420(0x4)
	float RicochetProbability;  // 0x424(0x4)
	float RicochetProbabilityGrazing;  // 0x428(0x4)
	float RicochetRestitution;  // 0x42C(0x4)
	float RicochetFriction;  // 0x430(0x4)
	float RicochetSpread;  // 0x434(0x4)
	char pad_1080_1 : 7;  // 0x438(0x1)
	bool SpeedControlsRicochetProbability : 1;  // 0x438(0x1)
	char pad_1081_1 : 7;  // 0x439(0x1)
	bool AddImpulse : 1;  // 0x439(0x1)
	char pad_1082[2];  // 0x43A(0x2)
	float ImpulseMultiplier;  // 0x43C(0x4)
	uint8_t  DefaultPenTraceType;  // 0x440(0x1)
	char pad_1089[7];  // 0x441(0x7)
	struct UBallisticMaterialResponseMap* MaterialResponseMap;  // 0x448(0x8)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool MaterialDensityControlsPenetrationDepth : 1;  // 0x450(0x1)
	char pad_1105_1 : 7;  // 0x451(0x1)
	bool MaterialRestitutionControlsRicochet : 1;  // 0x451(0x1)
	char pad_1106_1 : 7;  // 0x452(0x1)
	bool AllowComponentCollisions : 1;  // 0x452(0x1)
	char ECollisionChannel TraceChannel;  // 0x453(0x1)
	char pad_1108_1 : 7;  // 0x454(0x1)
	bool TraceComplex : 1;  // 0x454(0x1)
	char pad_1109[3];  // 0x455(0x3)
	float CollisionMargin;  // 0x458(0x4)
	float DespawnVelocity;  // 0x45C(0x4)
	struct TArray<struct AActor*> IgnoredActors;  // 0x460(0x10)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool DoFirstStepImmediately : 1;  // 0x470(0x1)
	char pad_1137_1 : 7;  // 0x471(0x1)
	bool RandomFirstStepDelta : 1;  // 0x471(0x1)
	char pad_1138[2];  // 0x472(0x2)
	int32_t MaxTracesPerStep;  // 0x474(0x4)
	char pad_1144_1 : 7;  // 0x478(0x1)
	bool Retrace : 1;  // 0x478(0x1)
	char pad_1145_1 : 7;  // 0x479(0x1)
	bool RetraceOnAnotherChannel : 1;  // 0x479(0x1)
	char ECollisionChannel RetraceChannel;  // 0x47A(0x1)
	char pad_1147_1 : 7;  // 0x47B(0x1)
	bool RotateActor : 1;  // 0x47B(0x1)
	char pad_1148_1 : 7;  // 0x47C(0x1)
	bool RotateRandomRoll : 1;  // 0x47C(0x1)
	char pad_1149_1 : 7;  // 0x47D(0x1)
	bool EnablePooling : 1;  // 0x47D(0x1)
	char pad_1150[2];  // 0x47E(0x2)
	struct UParticleSystem* TraceFX;  // 0x480(0x8)

	struct FVector UpdateVelocity(struct FVector& Location, struct FVector& previousVelocity, float DeltaTime); // Function POLYGON.TraceProjectile.UpdateVelocity
	void SpawnWithExactVelocity(ATraceProjectile* bulletClass, struct AItem_Weapon_General* weapon, struct FVector& SpawnLocation, struct FVector& startVelocity, char RandomSeed); // Function POLYGON.TraceProjectile.SpawnWithExactVelocity
	void Spawn(ATraceProjectile* bulletClass, struct AItem_Weapon_General* weapon, struct FVector& SpawnLocation, struct FVector& startVelocity, char RandomSeed); // Function POLYGON.TraceProjectile.Spawn
	void OnTrajectoryUpdateReceived(struct FVector& Location, struct FVector& OldVelocity, struct FVector& NewVelocity); // Function POLYGON.TraceProjectile.OnTrajectoryUpdateReceived
	void OnTrace(struct FVector& StartLocation, struct FVector& EndLocation); // Function POLYGON.TraceProjectile.OnTrace
	void OnImpact(bool ricochet, bool passedThrough, struct FVector& exitVelocity, struct FVector& Impulse, float PenetrationDepth, struct FHitResult& HitResult); // Function POLYGON.TraceProjectile.OnImpact
	void OnDeactivated(); // Function POLYGON.TraceProjectile.OnDeactivated
	void Deactivate(); // Function POLYGON.TraceProjectile.Deactivate
	bool CollisionFilter(struct FHitResult& HitResult); // Function POLYGON.TraceProjectile.CollisionFilter
}; 



// Class POLYGON.ChatSystemComponent
// Size: 0xC0(Inherited: 0xB0) 
struct UChatSystemComponent : public UActorComponent
{
	struct TArray<struct FGameChatMessage> ChatHistory;  // 0xB0(0x10)

	void SentMessage_Multicast(struct FGameChatMessage Message); // Function POLYGON.ChatSystemComponent.SentMessage_Multicast
	void SendMessage_Server(struct FGameChatMessage Message); // Function POLYGON.ChatSystemComponent.SendMessage_Server
}; 



// Class POLYGON.SupportBox_Ammo
// Size: 0x2A8(Inherited: 0x2A8) 
struct ASupportBox_Ammo : public ASupportBox
{

}; 



// Class POLYGON.ClientGameInstance
// Size: 0x88(Inherited: 0x28) 
struct UClientGameInstance : public UObject
{
	struct FMulticastInlineDelegate OnSetMasterId;  // 0x28(0x10)
	struct FText KickReason;  // 0x38(0x18)
	char pad_80[16];  // 0x50(0x10)
	struct UPlayFabJsonObject* PlayerCombinedInfo;  // 0x60(0x8)
	struct TArray<struct UUserEntry*> UsersCache;  // 0x68(0x10)
	char pad_120[16];  // 0x78(0x10)

	void SetServerTime(struct FDateTime& serverTime); // Function POLYGON.ClientGameInstance.SetServerTime
	void SetPlayerId(struct FString newPlayerMasterId); // Function POLYGON.ClientGameInstance.SetPlayerId
	void SetPlayerCombinedInfo(struct UPlayFabJsonObject* newPlayerCombinedInfo); // Function POLYGON.ClientGameInstance.SetPlayerCombinedInfo
	void HandleNetworkFailure(struct UWorld* World, struct UNetDriver* NetDriver, char ENetworkFailure FailureType, struct FString ErrorString); // Function POLYGON.ClientGameInstance.HandleNetworkFailure
	struct FDateTime GetServerTime(); // Function POLYGON.ClientGameInstance.GetServerTime
	struct FString GetPlayerMasterId(); // Function POLYGON.ClientGameInstance.GetPlayerMasterId
	struct UPlayFabJsonObject* GetPlayerCombinedInfo(); // Function POLYGON.ClientGameInstance.GetPlayerCombinedInfo
}; 



// Class POLYGON.PG_GameMode_Game_StandBy
// Size: 0x360(Inherited: 0x360) 
struct APG_GameMode_Game_StandBy : public AGameMode
{

}; 



// Class POLYGON.GeneralBackendComponent
// Size: 0xF0(Inherited: 0xB0) 
struct UGeneralBackendComponent : public UActorComponent
{
	char pad_176[64];  // 0xB0(0x40)

}; 



// Class POLYGON.Item_Watch_General
// Size: 0x2D0(Inherited: 0x2C8) 
struct AItem_Watch_General : public AItem_General
{
	struct UStaticMeshComponent* WatchMesh;  // 0x2C8(0x8)

}; 



// Class POLYGON.DataManagerLibrary
// Size: 0x28(Inherited: 0x28) 
struct UDataManagerLibrary : public UBlueprintFunctionLibrary
{

	struct UDataTable* GetDataTable_MapsInfo(); // Function POLYGON.DataManagerLibrary.GetDataTable_MapsInfo
	struct UDataTable* GetDataTable_LevelInfo(); // Function POLYGON.DataManagerLibrary.GetDataTable_LevelInfo
	struct UDataTable* GetDataTable_ItemReferences(); // Function POLYGON.DataManagerLibrary.GetDataTable_ItemReferences
	struct UDataTable* GetDataTable_BattlePass_Season_3(); // Function POLYGON.DataManagerLibrary.GetDataTable_BattlePass_Season_3
}; 



// Class POLYGON.ControlPoint
// Size: 0x2E8(Inherited: 0x278) 
struct AControlPoint : public AActor
{
	struct FMulticastInlineDelegate OnCapturedTeam;  // 0x278(0x10)
	struct FMulticastInlineDelegate OnIsCapture;  // 0x288(0x10)
	struct FMulticastInlineDelegate OnChangeCapturePoints;  // 0x298(0x10)
	uint8_t  ControlPointName;  // 0x2A8(0x1)
	uint8_t  CapturedTeam;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool bIsCapture : 1;  // 0x2AA(0x1)
	char pad_683[1];  // 0x2AB(0x1)
	int32_t CapturePointsAlphaTeam;  // 0x2AC(0x4)
	int32_t CapturePointsBravoTeam;  // 0x2B0(0x4)
	char pad_692[4];  // 0x2B4(0x4)
	struct TArray<struct APG_PlayerState_Game*> CapturePlayersAlphaTeam;  // 0x2B8(0x10)
	struct TArray<struct APG_PlayerState_Game*> CapturePlayersBravoTeam;  // 0x2C8(0x10)
	char pad_728[8];  // 0x2D8(0x8)
	struct USceneComponent* Root;  // 0x2E0(0x8)

	void OnRep_IsCapture(); // Function POLYGON.ControlPoint.OnRep_IsCapture
	void OnRep_CapturePointsBravoTeam(); // Function POLYGON.ControlPoint.OnRep_CapturePointsBravoTeam
	void OnRep_CapturePointsAlphaTeam(); // Function POLYGON.ControlPoint.OnRep_CapturePointsAlphaTeam
	void OnRep_CapturedTeam(); // Function POLYGON.ControlPoint.OnRep_CapturedTeam
	struct FString GetControlPointNameAsString(); // Function POLYGON.ControlPoint.GetControlPointNameAsString
	struct FString GetControlPointNameAsOneLetter(); // Function POLYGON.ControlPoint.GetControlPointNameAsOneLetter
	bool ContainsCharacter(struct ACharacter* Character); // Function POLYGON.ControlPoint.ContainsCharacter
}; 



// Class POLYGON.Item_Weapon_Sniper
// Size: 0x590(Inherited: 0x590) 
struct AItem_Weapon_Sniper : public AItem_Weapon_General
{

}; 



// Class POLYGON.Item_Weapon_Pistol
// Size: 0x590(Inherited: 0x590) 
struct AItem_Weapon_Pistol : public AItem_Weapon_General
{
	struct UAnimSequence* NoAmmoWeaponAnimation;  // 0x588(0x8)

}; 



// Class POLYGON.EOSPartyId
// Size: 0x38(Inherited: 0x28) 
struct UEOSPartyId : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToString(); // Function POLYGON.EOSPartyId.ToString
}; 



// Class POLYGON.PG_PlayerState_Game
// Size: 0x430(Inherited: 0x3A8) 
struct APG_PlayerState_Game : public APG_PlayerState_Base
{
	struct FMulticastInlineDelegate OnSetTeam;  // 0x3A8(0x10)
	struct FMulticastInlineDelegate OnChangeNumberKills;  // 0x3B8(0x10)
	struct FMulticastInlineDelegate OnChangeNumberDeaths;  // 0x3C8(0x10)
	struct FMulticastInlineDelegate OnVoteKick;  // 0x3D8(0x10)
	char pad_1000[8];  // 0x3E8(0x8)
	struct TArray<struct APG_PlayerState_Game*> VoteKickPlayers;  // 0x3F0(0x10)
	uint8_t  Team;  // 0x400(0x1)
	char NumberKills;  // 0x401(0x1)
	char NumberDeaths;  // 0x402(0x1)
	char NumberKillsByMe;  // 0x403(0x1)
	char NumberKillsOfMe;  // 0x404(0x1)
	char pad_1029[7];  // 0x405(0x7)
	char pad_1036_1 : 7;  // 0x40C(0x1)
	bool bIsAdmin : 1;  // 0x40C(0x1)
	char pad_1037_1 : 7;  // 0x40D(0x1)
	bool bIsPatron : 1;  // 0x40D(0x1)
	char pad_1038[2];  // 0x40E(0x2)
	struct UPlayerCoreComponent* PlayerCoreComponent;  // 0x410(0x8)
	struct UInventoryComponent_Game* InventoryComponent;  // 0x418(0x8)
	struct USquadComponent* SquadComponent;  // 0x420(0x8)
	struct UChatSystemComponent* ChatSystemComponent;  // 0x428(0x8)

	void SetTeam(uint8_t  newTeam); // Function POLYGON.PG_PlayerState_Game.SetTeam
	void OnRep_VoteKickPlayers(); // Function POLYGON.PG_PlayerState_Game.OnRep_VoteKickPlayers
	void OnRep_Team(); // Function POLYGON.PG_PlayerState_Game.OnRep_Team
	void OnRep_NumberKills(); // Function POLYGON.PG_PlayerState_Game.OnRep_NumberKills
	void OnRep_NumberDeaths(); // Function POLYGON.PG_PlayerState_Game.OnRep_NumberDeaths
	bool CustomIsInactive(); // Function POLYGON.PG_PlayerState_Game.CustomIsInactive
}; 



// Class POLYGON.EOSPartyMemberId
// Size: 0x38(Inherited: 0x28) 
struct UEOSPartyMemberId : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToString(); // Function POLYGON.EOSPartyMemberId.ToString
}; 



// Class POLYGON.EOSSubsystemAvanced
// Size: 0x38(Inherited: 0x30) 
struct UEOSSubsystemAvanced : public UGameInstanceSubsystem
{
	char pad_48[8];  // 0x30(0x8)

	void StartLogin(struct FDelegate OnLoginComplete); // Function POLYGON.EOSSubsystemAvanced.StartLogin
	void StartCreateParty(struct UObject* WorldContextObject, int32_t PartyTypeId, struct FDelegate onDone); // Function POLYGON.EOSSubsystemAvanced.StartCreateParty
	struct TArray<struct UEOSPartyMemberId*> GetPartyMembers(struct UObject* WorldContextObject, struct UEOSPartyId* PartyId); // Function POLYGON.EOSSubsystemAvanced.GetPartyMembers
	struct TArray<struct UEOSPartyId*> GetJoinedParties(struct UObject* WorldContextObject); // Function POLYGON.EOSSubsystemAvanced.GetJoinedParties
}; 



// Class POLYGON.ServerBackendComponent
// Size: 0xF0(Inherited: 0xF0) 
struct UServerBackendComponent : public UGeneralBackendComponent
{

}; 



// Class POLYGON.Item_Weapon_Grenade
// Size: 0x318(Inherited: 0x2C8) 
struct AItem_Weapon_Grenade : public AItem_General
{
	float GrenadeDamage;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)
	struct UParticleSystem* ExplosionFX;  // 0x2D0(0x8)
	struct USoundBase* SoundExplosion;  // 0x2D8(0x8)
	UCameraShakeBase* ExplosionCameraShakeFirst;  // 0x2E0(0x8)
	UCameraShakeBase* ExplosionCameraShakeSecond;  // 0x2E8(0x8)
	UCameraShakeBase* GrenadeThrowCameraShake;  // 0x2F0(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x2F8(0x8)
	struct URadialForceComponent* RadialForce;  // 0x300(0x8)
	struct USphereComponent* GrenadeSphereRadius;  // 0x308(0x8)
	struct USmoothSync* SmoothSyncComponent;  // 0x310(0x8)

	void OnMeshHit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function POLYGON.Item_Weapon_Grenade.OnMeshHit
}; 



// Class POLYGON.FOVManagerComponent
// Size: 0xC8(Inherited: 0xB0) 
struct UFOVManagerComponent : public UActorComponent
{
	float DefaultCameraFOV;  // 0xB0(0x4)
	float CurrentCameraFOV;  // 0xB4(0x4)
	float DefaultMeshFOV;  // 0xB8(0x4)
	float CurrentMeshFOV;  // 0xBC(0x4)
	struct UMaterialParameterCollection* MaterialCollection_CorrectFOV;  // 0xC0(0x8)

	void SetMeshFOV(float newMeshFOV); // Function POLYGON.FOVManagerComponent.SetMeshFOV
	void SetDefaultCameraFOV(float newDefaultCameraFOV); // Function POLYGON.FOVManagerComponent.SetDefaultCameraFOV
	void SetCameraFOV(float newCameraFOV); // Function POLYGON.FOVManagerComponent.SetCameraFOV
	void HardResetMeshFOV(); // Function POLYGON.FOVManagerComponent.HardResetMeshFOV
	void HardResetCameraFOV(); // Function POLYGON.FOVManagerComponent.HardResetCameraFOV
}; 



// Class POLYGON.UserEntry
// Size: 0x28(Inherited: 0x28) 
struct UUserEntry : public UObject
{

}; 



// Class POLYGON.GameSettings
// Size: 0x38(Inherited: 0x38) 
struct UGameSettings : public UDeveloperSettings
{

}; 



// Class POLYGON.HealthStatsComponent
// Size: 0x120(Inherited: 0xB0) 
struct UHealthStatsComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnChangeHealth;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnHealthProtection;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnIsAlive;  // 0xD0(0x10)
	char Health;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool bIsAlive : 1;  // 0xE1(0x1)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool bHealthProtection : 1;  // 0xE2(0x1)
	char pad_227[1];  // 0xE3(0x1)
	float LastTimeTakeDamage;  // 0xE4(0x4)
	float Stamina;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct TArray<struct FPlayerAssist> KillAssists;  // 0xF0(0x10)
	char pad_256[32];  // 0x100(0x20)

	void OnRep_HealthProtection(); // Function POLYGON.HealthStatsComponent.OnRep_HealthProtection
	void OnRep_Health(char previousHealth); // Function POLYGON.HealthStatsComponent.OnRep_Health
	void KillSelf_server(); // Function POLYGON.HealthStatsComponent.KillSelf_server
	int32_t GetStamina(); // Function POLYGON.HealthStatsComponent.GetStamina
	bool GetHealthProtection(); // Function POLYGON.HealthStatsComponent.GetHealthProtection
	int32_t GetHealth(); // Function POLYGON.HealthStatsComponent.GetHealth
}; 



// Class POLYGON.InteractInterface
// Size: 0x28(Inherited: 0x28) 
struct UInteractInterface : public UInterface
{

	void StopInteract(struct APG_Character* Character); // Function POLYGON.InteractInterface.StopInteract
	void StartInteract(struct APG_Character* Character); // Function POLYGON.InteractInterface.StartInteract
	void SetPlayerLooks(struct APG_Character* Character, bool bIsLooks); // Function POLYGON.InteractInterface.SetPlayerLooks
}; 



// Class POLYGON.Item_Module_Skin
// Size: 0x2E8(Inherited: 0x2E0) 
struct AItem_Module_Skin : public AItem_Module_General
{
	struct UMaterialInstance* SkinMaterial;  // 0x2E0(0x8)

}; 



// Class POLYGON.InventoryComponent_Base
// Size: 0xB0(Inherited: 0xB0) 
struct UInventoryComponent_Base : public UActorComponent
{

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.InventoryComponent_Base.UpdatePlayerCombinedInfo
}; 



// Class POLYGON.MenuCharacter
// Size: 0x2C0(Inherited: 0x278) 
struct AMenuCharacter : public AActor
{
	struct TWeakObjectPtr<AMenuCharacter> CharacterInstance;  // 0x278(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x280(0x8)
	struct UStaticMeshComponent* Hair;  // 0x288(0x8)
	struct UStaticMeshComponent* Hat;  // 0x290(0x8)
	struct UStaticMeshComponent* Mask;  // 0x298(0x8)
	struct UStaticMeshComponent* Jacket;  // 0x2A0(0x8)
	struct UStaticMeshComponent* Chevron;  // 0x2A8(0x8)
	struct UStaticMeshComponent* Backpack;  // 0x2B0(0x8)
	struct AItem_Weapon_General* weapon;  // 0x2B8(0x8)

}; 



// Class POLYGON.InventoryComponent_Game
// Size: 0x118(Inherited: 0xB0) 
struct UInventoryComponent_Game : public UInventoryComponent_Base
{
	struct FMulticastInlineDelegate OnSetCurrentWeapon;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnSetPrimaryWeapon;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnSetSecondaryWeapon;  // 0xD0(0x10)
	struct FMulticastInlineDelegate OnChangeNumberGrenades;  // 0xE0(0x10)
	struct AItem_Weapon_General* CurrentWeapon;  // 0xF0(0x8)
	struct AItem_Weapon_General* PrimaryWeapon;  // 0xF8(0x8)
	struct AItem_Weapon_General* SecondaryWeapon;  // 0x100(0x8)
	char GrenadesNumber;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	AItem_Watch_General* WatchClass;  // 0x110(0x8)

	struct TArray<struct FString> SetWeaponModules(struct FString weaponInstanceId, struct TArray<struct FString>& itemsInstanceId); // Function POLYGON.InventoryComponent_Game.SetWeaponModules
	void RequestSetWeaponModules_server(struct FString weaponInstanceId, struct TArray<struct FString> itemsInstanceId); // Function POLYGON.InventoryComponent_Game.RequestSetWeaponModules_server
	void RequestEquipItems_server(struct TArray<struct FString> itemsInstanceId); // Function POLYGON.InventoryComponent_Game.RequestEquipItems_server
	void OnRep_SecondaryWeapon(); // Function POLYGON.InventoryComponent_Game.OnRep_SecondaryWeapon
	void OnRep_PrimaryWeapon(); // Function POLYGON.InventoryComponent_Game.OnRep_PrimaryWeapon
	void OnRep_GrenadesNumber(); // Function POLYGON.InventoryComponent_Game.OnRep_GrenadesNumber
	void OnRep_CurrentWeapon(struct AItem_Weapon_General* previousWeapon); // Function POLYGON.InventoryComponent_Game.OnRep_CurrentWeapon
	struct TArray<struct FString> EquipItems(struct TArray<struct FString>& itemsInstanceId); // Function POLYGON.InventoryComponent_Game.EquipItems
	void AddGrenate_server(char Number); // Function POLYGON.InventoryComponent_Game.AddGrenate_server
}; 



// Class POLYGON.PG_PlayerController_Base
// Size: 0x800(Inherited: 0x7C8) 
struct APG_PlayerController_Base : public APlayerController
{
	struct FMulticastInlineDelegate OnSetPlayerState;  // 0x7C8(0x10)
	float MouseSensitivity;  // 0x7D8(0x4)
	float ScopeSensitivityMultiplier;  // 0x7DC(0x4)
	char pad_2016_1 : 7;  // 0x7E0(0x1)
	bool bIsInvertMouse : 1;  // 0x7E0(0x1)
	char pad_2017[3];  // 0x7E1(0x3)
	int32_t AimMode;  // 0x7E4(0x4)
	int32_t CrouchMode;  // 0x7E8(0x4)
	int32_t LeanMode;  // 0x7EC(0x4)
	int32_t SprintMode;  // 0x7F0(0x4)
	char pad_2036[4];  // 0x7F4(0x4)
	struct UFOVManagerComponent* FOVManagerComponent;  // 0x7F8(0x8)

	void ShowError(struct FText& ErrorMessage, struct FText& ErrorDetails); // Function POLYGON.PG_PlayerController_Base.ShowError
}; 



// Class POLYGON.InventoryComponent_Menu
// Size: 0xB0(Inherited: 0xB0) 
struct UInventoryComponent_Menu : public UInventoryComponent_Base
{

}; 



// Class POLYGON.Item_General
// Size: 0x2C8(Inherited: 0x278) 
struct AItem_General : public AActor
{
	struct FString ItemId;  // 0x278(0x10)
	uint8_t  ItemType;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct FText ItemName;  // 0x290(0x18)
	struct UTexture2D* ItemIcon;  // 0x2A8(0x8)
	int32_t ItemPrice;  // 0x2B0(0x4)
	char pad_692[4];  // 0x2B4(0x4)
	struct FString customData;  // 0x2B8(0x10)

}; 



// Class POLYGON.Item_Module_General
// Size: 0x2E0(Inherited: 0x2C8) 
struct AItem_Module_General : public AItem_General
{
	uint8_t  WeaponModuleType;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	int32_t LevelRequired;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool bIsPremium : 1;  // 0x2D0(0x1)
	char pad_721[7];  // 0x2D1(0x7)
	struct UTexture2D* ModuleWhiteIcon;  // 0x2D8(0x8)

}; 



// Class POLYGON.Item_Module_Accessory
// Size: 0x2F0(Inherited: 0x2E0) 
struct AItem_Module_Accessory : public AItem_Module_General
{
	struct FName MountingSocket;  // 0x2E0(0x8)
	struct UStaticMeshComponent* ModuleMesh;  // 0x2E8(0x8)

}; 



// Class POLYGON.Item_Module_Flashlight
// Size: 0x308(Inherited: 0x2F0) 
struct AItem_Module_Flashlight : public AItem_Module_Accessory
{
	struct FMulticastInlineDelegate OnEnable;  // 0x2F0(0x10)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool bIsEnable : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)

	void SetFlashlightEnable_server(bool isEnable); // Function POLYGON.Item_Module_Flashlight.SetFlashlightEnable_server
	void SetFlashlightEnable(bool isEnable, bool bCallOnServer); // Function POLYGON.Item_Module_Flashlight.SetFlashlightEnable
	void OnSetCurrentWeapon(struct AItem_Weapon_General* previousWeapon); // Function POLYGON.Item_Module_Flashlight.OnSetCurrentWeapon
	void OnRep_IsEnable(bool oldState); // Function POLYGON.Item_Module_Flashlight.OnRep_IsEnable
	void OnChangeEnableState(bool bPlaySound); // Function POLYGON.Item_Module_Flashlight.OnChangeEnableState
}; 



// Class POLYGON.Item_Module_Optic
// Size: 0x310(Inherited: 0x2E0) 
struct AItem_Module_Optic : public AItem_Module_General
{
	struct FName MountingSocket;  // 0x2E0(0x8)
	float FOV;  // 0x2E8(0x4)
	float StepsImpact;  // 0x2EC(0x4)
	float BackwardRecoilMultiplier;  // 0x2F0(0x4)
	float BlurPower;  // 0x2F4(0x4)
	float BlurRadius;  // 0x2F8(0x4)
	float BlurDensity;  // 0x2FC(0x4)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool bIsScope : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct UStaticMeshComponent* ModuleMesh;  // 0x308(0x8)

	void ToggleAiming(bool IsAiming); // Function POLYGON.Item_Module_Optic.ToggleAiming
}; 



// Class POLYGON.PG_PlayerState_Base
// Size: 0x3A8(Inherited: 0x390) 
struct APG_PlayerState_Base : public APlayerState
{
	struct FMulticastInlineDelegate OnPlayerNameChanged;  // 0x390(0x10)
	struct UClientBackendComponent* ClientBackendComponent;  // 0x3A0(0x8)

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.PG_PlayerState_Base.UpdatePlayerCombinedInfo
	void SetPlayerName(struct FString PlayerName); // Function POLYGON.PG_PlayerState_Base.SetPlayerName
	struct FUniqueNetIdRepl GetUniqueNetId(); // Function POLYGON.PG_PlayerState_Base.GetUniqueNetId
}; 



// Class POLYGON.PG_Character
// Size: 0x720(Inherited: 0x600) 
struct APG_Character : public ACharacter
{
	char pad_1536[8];  // 0x600(0x8)
	struct FMulticastInlineDelegate OnSetPlayerState;  // 0x608(0x10)
	struct FMulticastInlineDelegate OnSetActorHiddenInGame;  // 0x618(0x10)
	char pad_1576[1];  // 0x628(0x1)
	uint8_t  PlayerAction;  // 0x629(0x1)
	char pad_1578[2];  // 0x62A(0x2)
	float LeanBodyAlpha;  // 0x62C(0x4)
	char RespawnCounter;  // 0x630(0x1)
	char pad_1585[11];  // 0x631(0xB)
	float ControllerPitchRotation;  // 0x63C(0x4)
	float ControllerYawRotation;  // 0x640(0x4)
	char pad_1604[12];  // 0x644(0xC)
	struct AActor* FocusActor;  // 0x650(0x8)
	char pad_1624[8];  // 0x658(0x8)
	struct AActor* CurrentInteractActor;  // 0x660(0x8)
	char pad_1640[8];  // 0x668(0x8)
	struct UParticleSystem* ParticleDamageBlood;  // 0x670(0x8)
	struct USoundBase* SoundBullet;  // 0x678(0x8)
	struct UArrowComponent* ViewArrow;  // 0x680(0x8)
	struct USceneComponent* ArmsRoot;  // 0x688(0x8)
	struct USceneComponent* ArmsLean;  // 0x690(0x8)
	struct USkeletalMeshComponent* Arms;  // 0x698(0x8)
	char pad_1696[8];  // 0x6A0(0x8)
	struct UCameraComponent* FirstPersonCamera;  // 0x6A8(0x8)
	struct USpringArmComponent* ThirdPersonCameraBoom;  // 0x6B0(0x8)
	struct UCameraComponent* ThirdPersonCamera;  // 0x6B8(0x8)
	struct UInputComponent* PlayerInputComponent;  // 0x6C0(0x8)
	struct UWidgetComponent* WidgetPlayerMarker;  // 0x6C8(0x8)
	struct USpringArmComponent* SpectatorCameraBoom;  // 0x6D0(0x8)
	struct USceneCaptureComponent2D* SpectatorCameraCapture;  // 0x6D8(0x8)
	struct UStaticMeshComponent* Hair;  // 0x6E0(0x8)
	struct UStaticMeshComponent* Hat;  // 0x6E8(0x8)
	struct UStaticMeshComponent* Mask;  // 0x6F0(0x8)
	struct UStaticMeshComponent* Chevron;  // 0x6F8(0x8)
	struct UStaticMeshComponent* Backpack;  // 0x700(0x8)
	struct AItem_Watch_General* Watch;  // 0x708(0x8)
	struct UHealthStatsComponent* HealthStatsComponent;  // 0x710(0x8)
	struct UWeaponComponent* WeaponComponent;  // 0x718(0x8)

	void TickPose(); // Function POLYGON.PG_Character.TickPose
	void StopInteractWithObject_server(); // Function POLYGON.PG_Character.StopInteractWithObject_server
	void StopInteractWithObject(); // Function POLYGON.PG_Character.StopInteractWithObject
	void StartShooting(); // Function POLYGON.PG_Character.StartShooting
	void StartInteractWithObject_server(struct AActor* interactActor); // Function POLYGON.PG_Character.StartInteractWithObject_server
	void StartInteractWithObject(); // Function POLYGON.PG_Character.StartInteractWithObject
	void SetNeutralizationVignetteImpact(float newNeutralizationVignetteImpact); // Function POLYGON.PG_Character.SetNeutralizationVignetteImpact
	void SetIsSprinting_server(bool NewState); // Function POLYGON.PG_Character.SetIsSprinting_server
	void Respawn_client(struct FVector_NetQuantize NewLocation, struct FVector_NetQuantizeNormal newRotator); // Function POLYGON.PG_Character.Respawn_client
	void Respawn(); // Function POLYGON.PG_Character.Respawn
	void RefreshBoneTransforms(); // Function POLYGON.PG_Character.RefreshBoneTransforms
	void PlayerLooks(); // Function POLYGON.PG_Character.PlayerLooks
	void OnRep_RespawnCounter(char PreviousValue); // Function POLYGON.PG_Character.OnRep_RespawnCounter
	void OnRep_PlayerAction(uint8_t  previousAction); // Function POLYGON.PG_Character.OnRep_PlayerAction
	void NotifyDeathWithImpulse_multicast(struct APG_PlayerState_Game* killer, uint8_t  deathType, struct FVector_NetQuantize Impulse, char BoneIndex); // Function POLYGON.PG_Character.NotifyDeathWithImpulse_multicast
	void NotifyDeath_multicast(struct APG_PlayerState_Game* killer, uint8_t  deathType); // Function POLYGON.PG_Character.NotifyDeath_multicast
	void LeanBody_server(int8_t LeanBodyAlpha); // Function POLYGON.PG_Character.LeanBody_server
	void HitAtProtectedCharacter(); // Function POLYGON.PG_Character.HitAtProtectedCharacter
	uint8_t  GetTeam(); // Function POLYGON.PG_Character.GetTeam
	uint8_t  GetPlayerAction(); // Function POLYGON.PG_Character.GetPlayerAction
	float GetNeutralizationVignetteImpact(); // Function POLYGON.PG_Character.GetNeutralizationVignetteImpact
	bool GetIsSprinting(); // Function POLYGON.PG_Character.GetIsSprinting
	struct UCameraComponent* GetActiveCamera(); // Function POLYGON.PG_Character.GetActiveCamera
	void EventTakeDamage(struct FVector& Origin); // Function POLYGON.PG_Character.EventTakeDamage
	void DeathEvent(struct APG_PlayerState_Game* killer, uint8_t  deathType); // Function POLYGON.PG_Character.DeathEvent
	void ChangeIsAlive(); // Function POLYGON.PG_Character.ChangeIsAlive
	void CameraNeutralizationEffectEvent(float Damage); // Function POLYGON.PG_Character.CameraNeutralizationEffectEvent
	void ActionWhenWeaponHit_client(struct APG_Character* characterInstigator, char hitBoneIndex); // Function POLYGON.PG_Character.ActionWhenWeaponHit_client
	void ActionWhenTakeDamage_client(struct AActor* DamageCauser); // Function POLYGON.PG_Character.ActionWhenTakeDamage_client
}; 



// Class POLYGON.PG_AnimInstance
// Size: 0x350(Inherited: 0x350) 
struct UPG_AnimInstance : public UAnimInstance
{

}; 



// Class POLYGON.Item_Module_Strap
// Size: 0x2E8(Inherited: 0x2E0) 
struct AItem_Module_Strap : public AItem_Module_General
{
	struct UStaticMeshComponent* StrapMesh;  // 0x2E0(0x8)

}; 



// Class POLYGON.Item_Weapon_General
// Size: 0x590(Inherited: 0x2C8) 
struct AItem_Weapon_General : public AItem_General
{
	struct FMulticastInlineDelegate OnChangeCurrentNumberAmmo;  // 0x2C8(0x10)
	struct FMulticastInlineDelegate OnChangeStockAmmo;  // 0x2D8(0x10)
	struct FMulticastInlineDelegate OnSetWeaponModules;  // 0x2E8(0x10)
	struct FMulticastInlineDelegate OnApplyWeaponDamage;  // 0x2F8(0x10)
	char pad_776[24];  // 0x308(0x18)
	uint8_t  WeaponClass;  // 0x320(0x1)
	uint8_t  WeaponSlot;  // 0x321(0x1)
	uint8_t  WeaponShootingType;  // 0x322(0x1)
	char pad_803[1];  // 0x323(0x1)
	int32_t WeaponDamage;  // 0x324(0x4)
	float DamageMultiplierHead;  // 0x328(0x4)
	char pad_812[4];  // 0x32C(0x4)
	struct UCurveFloat* DamageCurve;  // 0x330(0x8)
	int32_t MaxMagazineAmmo;  // 0x338(0x4)
	int32_t MaxStockAmmo;  // 0x33C(0x4)
	float TimeBetweenShots;  // 0x340(0x4)
	float WeaponUpRecoil;  // 0x344(0x4)
	float WeaponBackwardRecoil;  // 0x348(0x4)
	float WeaponRecoilAlphaPerShot;  // 0x34C(0x4)
	float WeaponRecoilLift;  // 0x350(0x4)
	float AccuracyHip;  // 0x354(0x4)
	float AccuracySight;  // 0x358(0x4)
	float SpreadShot;  // 0x35C(0x4)
	float Mobility;  // 0x360(0x4)
	char pad_868[4];  // 0x364(0x4)
	ATraceProjectile* ProjectileClass;  // 0x368(0x8)
	float MuzzleVelocityMultiplier;  // 0x370(0x4)
	char pad_884[4];  // 0x374(0x4)
	struct TMap<AItem_Module_General*, struct FDataContainerObjectWrapper> RelatedModules;  // 0x378(0x50)
	struct UTexture2D* WeaponWhileIcon;  // 0x3C8(0x8)
	int32_t LevelRequired;  // 0x3D0(0x4)
	char pad_980_1 : 7;  // 0x3D4(0x1)
	bool bIsPremium : 1;  // 0x3D4(0x1)
	char pad_981_1 : 7;  // 0x3D5(0x1)
	bool bIsAvailable : 1;  // 0x3D5(0x1)
	char pad_982[2];  // 0x3D6(0x2)
	struct UParticleSystem* SleeveFX;  // 0x3D8(0x8)
	UCameraShakeBase* ShotCameraShake;  // 0x3E0(0x8)
	struct UAnimSequence* IdleCharacterAnimation;  // 0x3E8(0x8)
	struct UAnimMontage* ReloadCharacterAnimation;  // 0x3F0(0x8)
	struct UAnimMontage* ReloadFullCharacterAnimation;  // 0x3F8(0x8)
	struct UAnimMontage* ShotCharacterAnimation;  // 0x400(0x8)
	struct UAnimMontage* EndShotCharacterAnimation;  // 0x408(0x8)
	struct UAnimMontage* BoltCharacterAnimation;  // 0x410(0x8)
	struct UAnimSequence* ShotWeaponAnimation;  // 0x418(0x8)
	struct UAnimSequence* BoltWeaponAnimation;  // 0x420(0x8)
	struct UAnimSequence* ReloadWeaponAnimation;  // 0x428(0x8)
	struct UAnimSequence* ReloadFullWeaponAnimation;  // 0x430(0x8)
	struct FVector PositionAdjustment;  // 0x438(0x18)
	struct FTransform LeftHandOffset;  // 0x450(0x60)
	struct FVector SprintLiftWeapon;  // 0x4B0(0x18)
	struct USoundBase* SoundShot;  // 0x4C8(0x8)
	struct USoundBase* SoundBlankShot;  // 0x4D0(0x8)
	struct TArray<struct USoundBase*> CustomSounds;  // 0x4D8(0x10)
	char CallHardReset;  // 0x4E8(0x1)
	char pad_1257[3];  // 0x4E9(0x3)
	int32_t CurrentMagazineAmmo;  // 0x4EC(0x4)
	uint16_t CurrentStockAmmo;  // 0x4F0(0x2)
	char ReloadCaller;  // 0x4F2(0x1)
	char pad_1267[5];  // 0x4F3(0x5)
	struct TArray<struct TWeakObjectPtr<ATraceProjectile>> PoolProjectiles;  // 0x4F8(0x10)
	char pad_1288[4];  // 0x508(0x4)
	float CurrentSpread;  // 0x50C(0x4)
	struct TArray<struct AItem_Module_General*> CurrentWeaponModules;  // 0x510(0x10)
	struct FWeaponShot WeaponShot;  // 0x520(0x20)
	struct FVector_NetQuantize WeaponHitOfShortShot;  // 0x540(0x18)
	char pad_1368[16];  // 0x558(0x10)
	struct UAudioComponent* ActiveSoundShot;  // 0x568(0x8)
	struct USkeletalMeshComponent* WeaponMesh;  // 0x570(0x8)
	struct UStaticMeshComponent* Magazine;  // 0x578(0x8)
	struct UStaticMeshComponent* PicatinnyRail;  // 0x580(0x8)
	char pad_1416[8];  // 0x588(0x8)

	void SetWeaponModules(struct UPlayFabJsonObject* modules); // Function POLYGON.Item_Weapon_General.SetWeaponModules
	void RequestReload_server(char currentNumberAmmo); // Function POLYGON.Item_Weapon_General.RequestReload_server
	void OnRep_WeaponShot(struct FWeaponShot previousShot); // Function POLYGON.Item_Weapon_General.OnRep_WeaponShot
	void OnRep_WeaponHitOfShortShot(struct FVector_NetQuantize PreviousValue); // Function POLYGON.Item_Weapon_General.OnRep_WeaponHitOfShortShot
	void OnRep_ReloadCaller(char PreviousValue); // Function POLYGON.Item_Weapon_General.OnRep_ReloadCaller
	void OnRep_CurrentWeaponModules(); // Function POLYGON.Item_Weapon_General.OnRep_CurrentWeaponModules
	void OnRep_CurrentStockAmmo(); // Function POLYGON.Item_Weapon_General.OnRep_CurrentStockAmmo
	void OnRep_CallHardReset(char PreviousValue); // Function POLYGON.Item_Weapon_General.OnRep_CallHardReset
	void NotifyServerTraceHit(struct FWeaponHitOnCharacter hitOnCharacter); // Function POLYGON.Item_Weapon_General.NotifyServerTraceHit
	void NotifyServerOfShot(struct FWeaponShot WeaponShot); // Function POLYGON.Item_Weapon_General.NotifyServerOfShot
	void NotifyServerHitWithEnergy(struct FWeaponHitOnCharacter hitOnCharacter, char energy); // Function POLYGON.Item_Weapon_General.NotifyServerHitWithEnergy
	void NotifyServerHit(struct FWeaponHitOnCharacter hitOnCharacter); // Function POLYGON.Item_Weapon_General.NotifyServerHit
	struct FVector GetForwardShot(); // Function POLYGON.Item_Weapon_General.GetForwardShot
	int32_t GetCurrentStockAmmo(); // Function POLYGON.Item_Weapon_General.GetCurrentStockAmmo
	void CockBolt_server(); // Function POLYGON.Item_Weapon_General.CockBolt_server
	void CockBolt_multicast(); // Function POLYGON.Item_Weapon_General.CockBolt_multicast
	void AddStockAmmo_server(int8_t addAmmo); // Function POLYGON.Item_Weapon_General.AddStockAmmo_server
}; 



// Class POLYGON.PG_GameMode_Base
// Size: 0x360(Inherited: 0x360) 
struct APG_GameMode_Base : public AGameMode
{

}; 



// Class POLYGON.Item_Weapon_Rifle
// Size: 0x590(Inherited: 0x590) 
struct AItem_Weapon_Rifle : public AItem_Weapon_General
{

}; 



// Class POLYGON.SquadComponent
// Size: 0x100(Inherited: 0xB0) 
struct USquadComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnMembersUpdate;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnIsMemberMySquad;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnCooldownStarted;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bIsMemberMySquad : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct TArray<struct APG_PlayerState_Game*> Members;  // 0xE8(0x10)
	char CooldownCounter;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float CooldownStartTime;  // 0xFC(0x4)

	void OnRep_Members(); // Function POLYGON.SquadComponent.OnRep_Members
	void OnRep_CooldownCounter(); // Function POLYGON.SquadComponent.OnRep_CooldownCounter
}; 



// Class POLYGON.PG_FunctionLibraryKit
// Size: 0x28(Inherited: 0x28) 
struct UPG_FunctionLibraryKit : public UBlueprintFunctionLibrary
{

	struct FString ParseOption(struct FString Options, struct FString Key, struct FString Separator); // Function POLYGON.PG_FunctionLibraryKit.ParseOption
	uint8_t  GetRegionEnum(struct FString regionName); // Function POLYGON.PG_FunctionLibraryKit.GetRegionEnum
	struct FString GetProjectVersion(); // Function POLYGON.PG_FunctionLibraryKit.GetProjectVersion
	int32_t GetBuildNumber(); // Function POLYGON.PG_FunctionLibraryKit.GetBuildNumber
	void ExitGame(); // Function POLYGON.PG_FunctionLibraryKit.ExitGame
}; 



// Class POLYGON.PG_GameInstance
// Size: 0x1B8(Inherited: 0x1A8) 
struct UPG_GameInstance : public UGameInstance
{
	struct UServerGameInstance* ServerGameInstance;  // 0x1A8(0x8)
	struct UClientGameInstance* ClientGameInstance;  // 0x1B0(0x8)

	struct UServerGameInstance* GetServerGameInstance(); // Function POLYGON.PG_GameInstance.GetServerGameInstance
	struct UClientGameInstance* GetClientGameInstance(); // Function POLYGON.PG_GameInstance.GetClientGameInstance
}; 



// Class POLYGON.PG_BeaconHostObject
// Size: 0x2A0(Inherited: 0x2A0) 
struct APG_BeaconHostObject : public AOnlineBeaconHostObject
{

}; 



// Class POLYGON.PG_GameMode_Game
// Size: 0x3C0(Inherited: 0x360) 
struct APG_GameMode_Game : public APG_GameMode_Base
{
	struct AOnlineBeaconHost* Beacon;  // 0x360(0x8)
	struct TArray<struct FBeaconSlotRequest> PlayersQueue;  // 0x368(0x10)
	struct TArray<struct UReservedSlot*> ReservedSlots;  // 0x378(0x10)
	struct TArray<struct FString> BlackListPlayersID;  // 0x388(0x10)
	char pad_920[16];  // 0x398(0x10)
	int32_t TotalGameTime;  // 0x3A8(0x4)
	char pad_940[4];  // 0x3AC(0x4)
	struct UPlayFabJsonObject* ServerData;  // 0x3B0(0x8)
	struct UServerBackendComponent* ServerBackendComponent;  // 0x3B8(0x8)

	void LoginPlayer(struct APG_PlayerController_Game* PlayerController, struct FString PlayerMasterId); // Function POLYGON.PG_GameMode_Game.LoginPlayer
}; 



// Class POLYGON.PG_GameMode_Menu
// Size: 0x360(Inherited: 0x360) 
struct APG_GameMode_Menu : public APG_GameMode_Base
{

}; 



// Class POLYGON.PG_BeaconClient
// Size: 0x338(Inherited: 0x308) 
struct APG_BeaconClient : public AOnlineBeaconClient
{
	char pad_776[48];  // 0x308(0x30)

	void SendNumberInQueue_client(char Number); // Function POLYGON.PG_BeaconClient.SendNumberInQueue_client
	void ResponseReserveSlot_client(char Payload); // Function POLYGON.PG_BeaconClient.ResponseReserveSlot_client
	void RequestReserveSlot_server(struct TArray<struct FUniqueNetIdRepl> unequeIds, bool isUsedMatchmaker); // Function POLYGON.PG_BeaconClient.RequestReserveSlot_server
	void RequestReserveSlot(struct TArray<struct FUniqueNetIdRepl>& unequeIds, bool isUsedMatchmaker, struct FDelegate onResponseReserveSlot, struct FDelegate onPutInQueue); // Function POLYGON.PG_BeaconClient.RequestReserveSlot
	void LeaveQueue(); // Function POLYGON.PG_BeaconClient.LeaveQueue
	bool ConnectToServer(struct FString IP, int32_t BeaconPort, struct FDelegate onConnectedStateChange); // Function POLYGON.PG_BeaconClient.ConnectToServer
}; 



// Class POLYGON.PG_PlayerController_Game
// Size: 0x820(Inherited: 0x800) 
struct APG_PlayerController_Game : public APG_PlayerController_Base
{
	struct FMulticastInlineDelegate OnDeployIsAvailable;  // 0x800(0x10)
	float TimeVoteKick;  // 0x810(0x4)
	char pad_2068_1 : 7;  // 0x814(0x1)
	bool bDeployIsAvailable : 1;  // 0x814(0x1)
	char pad_2069[11];  // 0x815(0xB)

	void VoteKick(struct APG_PlayerState_Game* badGuy); // Function POLYGON.PG_PlayerController_Game.VoteKick
	void StopInteractionEvent(); // Function POLYGON.PG_PlayerController_Game.StopInteractionEvent
	void StopInteraction_Client(); // Function POLYGON.PG_PlayerController_Game.StopInteraction_Client
	void StartInteractionEvent(float interactionTime); // Function POLYGON.PG_PlayerController_Game.StartInteractionEvent
	void StartInteraction_Client(float interactionTime); // Function POLYGON.PG_PlayerController_Game.StartInteraction_Client
	void SetVisibleLoadingScreen(bool IsVisible); // Function POLYGON.PG_PlayerController_Game.SetVisibleLoadingScreen
	void RequestSpawnOnSquadMember_server(struct APG_PlayerState_Game* squadMember); // Function POLYGON.PG_PlayerController_Game.RequestSpawnOnSquadMember_server
	void RequestSpawnOnControlPoint_server(uint8_t  spawnToControlPoint); // Function POLYGON.PG_PlayerController_Game.RequestSpawnOnControlPoint_server
	void RequestSpawnOnBase_server(); // Function POLYGON.PG_PlayerController_Game.RequestSpawnOnBase_server
	void OnRep_DeployIsAvailable(); // Function POLYGON.PG_PlayerController_Game.OnRep_DeployIsAvailable
	void LoginPlayer_server(struct FString PlayerMasterId); // Function POLYGON.PG_PlayerController_Game.LoginPlayer_server
	void EventClientReset(); // Function POLYGON.PG_PlayerController_Game.EventClientReset
	void DisplayMessageToChatEvent(struct FGameChatMessage Message); // Function POLYGON.PG_PlayerController_Game.DisplayMessageToChatEvent
}; 



// Class POLYGON.PG_PlayerController_Menu
// Size: 0x800(Inherited: 0x800) 
struct APG_PlayerController_Menu : public APG_PlayerController_Base
{

}; 



// Class POLYGON.PG_PlayerState_Menu
// Size: 0x3B0(Inherited: 0x3A8) 
struct APG_PlayerState_Menu : public APG_PlayerState_Base
{
	struct UInventoryComponent_Menu* InventoryComponent;  // 0x3A8(0x8)

}; 



// Class POLYGON.ReservedSlot
// Size: 0x78(Inherited: 0x28) 
struct UReservedSlot : public UObject
{
	char pad_40[80];  // 0x28(0x50)

}; 



// Class POLYGON.SupportBox
// Size: 0x2A8(Inherited: 0x278) 
struct ASupportBox : public AActor
{
	char pad_632[24];  // 0x278(0x18)
	struct UStaticMeshComponent* BoxMesh;  // 0x290(0x8)
	struct UWidgetComponent* WidgetTypeSupportBox;  // 0x298(0x8)
	struct UWidgetComponent* InteractionWidget;  // 0x2A0(0x8)

}; 



// Class POLYGON.SupportBox_Health
// Size: 0x2A8(Inherited: 0x2A8) 
struct ASupportBox_Health : public ASupportBox
{

}; 



// Class POLYGON.TeamBase
// Size: 0x280(Inherited: 0x278) 
struct ATeamBase : public AActor
{
	uint8_t  Team;  // 0x278(0x1)
	char pad_633[7];  // 0x279(0x7)

}; 



// Class POLYGON.WeaponComponent
// Size: 0x190(Inherited: 0xB0) 
struct UWeaponComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnAiming;  // 0xB0(0x10)
	char pad_192[29];  // 0xC0(0x1D)
	char pad_221_1 : 7;  // 0xDD(0x1)
	bool bIsAiming : 1;  // 0xDD(0x1)
	char pad_222_1 : 7;  // 0xDE(0x1)
	bool bWeaponIsDown : 1;  // 0xDE(0x1)
	char pad_223[1];  // 0xDF(0x1)
	struct UParticleSystem* FireFXLocal;  // 0xE0(0x8)
	struct UParticleSystem* FireFXSimulate;  // 0xE8(0x8)
	struct UParticleSystem* HitFX_Metal;  // 0xF0(0x8)
	struct UParticleSystem* HitFX_Stone;  // 0xF8(0x8)
	struct UParticleSystem* HitFX_Dirt;  // 0x100(0x8)
	struct UParticleSystem* HitFX_Wood;  // 0x108(0x8)
	struct UParticleSystem* HitFX_Water;  // 0x110(0x8)
	struct UParticleSystem* HitFX_Glass;  // 0x118(0x8)
	struct UParticleSystem* HitFX_Blood;  // 0x120(0x8)
	struct UMaterialInterface* DecalImpact;  // 0x128(0x8)
	struct USoundBase* SoundCharacterHit;  // 0x130(0x8)
	struct USoundBase* SoundCharacterHit_Protection;  // 0x138(0x8)
	struct USoundBase* SoundRicochetHit;  // 0x140(0x8)
	struct USoundBase* SoundBodyHit;  // 0x148(0x8)
	struct USoundBase* SoundAiming;  // 0x150(0x8)
	struct UAnimMontage* AnimAiming;  // 0x158(0x8)
	struct UAnimMontage* AnimChangeWeapon;  // 0x160(0x8)
	struct UAnimMontage* AnimThrowGrenade;  // 0x168(0x8)
	struct UAnimMontage* AnimLowThrowGrenade;  // 0x170(0x8)
	UCameraShakeBase* CameraShake_Aiming;  // 0x178(0x8)
	char pad_384[16];  // 0x180(0x10)

	void ToggleAiming_server(); // Function POLYGON.WeaponComponent.ToggleAiming_server
	void SetWeaponRecoilIsActive_Backward(); // Function POLYGON.WeaponComponent.SetWeaponRecoilIsActive_Backward
	void SetWeaponRecoilAlpha_Yaw(float newYawRecoil); // Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Yaw
	void SetWeaponRecoilAlpha_Roll(float newRollRecoil); // Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Roll
	void SetWantsToAiming_server(bool NewState); // Function POLYGON.WeaponComponent.SetWantsToAiming_server
	void SetStrivingWeaponRecoilAlpha_Pitch(float newStrivingPitchRecoil); // Function POLYGON.WeaponComponent.SetStrivingWeaponRecoilAlpha_Pitch
	void SelectWeaponSlot_server(char Slot); // Function POLYGON.WeaponComponent.SelectWeaponSlot_server
	void OnSetSecondaryWeapon(); // Function POLYGON.WeaponComponent.OnSetSecondaryWeapon
	void OnSetPrimaryWeapon(); // Function POLYGON.WeaponComponent.OnSetPrimaryWeapon
	void OnSetPlayerState(); // Function POLYGON.WeaponComponent.OnSetPlayerState
	void OnSetCurrentWeapon(struct AItem_Weapon_General* OldCurrentWeapon); // Function POLYGON.WeaponComponent.OnSetCurrentWeapon
	void OnRep_IsAiming(); // Function POLYGON.WeaponComponent.OnRep_IsAiming
	void NotifyServerThrowGrenade(); // Function POLYGON.WeaponComponent.NotifyServerThrowGrenade
	bool IsWantsToAiming(); // Function POLYGON.WeaponComponent.IsWantsToAiming
	bool IsAiming(); // Function POLYGON.WeaponComponent.IsAiming
	float GetWeaponRecoilAlpha_Yaw(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Yaw
	float GetWeaponRecoilAlpha_Roll(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Roll
	float GetWeaponRecoilAlpha_Pitch(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Pitch
	float GetWeaponRecoilAlpha_Backward(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Backward
	bool GetIsShooting(); // Function POLYGON.WeaponComponent.GetIsShooting
	struct AItem_Weapon_General* GetCurrentWeapon(); // Function POLYGON.WeaponComponent.GetCurrentWeapon
}; 



