#pragma once 
#include <BP_Item_Optic_StandartSight_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Optic_StandartSight.BP_Item_Optic_StandartSight_C
// Size: 0x310(Inherited: 0x310) 
struct ABP_Item_Optic_StandartSight_C : public AItem_Module_Optic
{

}; 



