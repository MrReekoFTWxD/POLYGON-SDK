#pragma once 
#include <BP_Item_Skin_Mk14_04_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Skin_Mk14_04.BP_Item_Skin_Mk14_04_C
// Size: 0x2F0(Inherited: 0x2E8) 
struct ABP_Item_Skin_Mk14_04_C : public AItem_Module_Skin
{
	struct USceneComponent* DefaultSceneRoot;  // 0x2E8(0x8)

}; 



