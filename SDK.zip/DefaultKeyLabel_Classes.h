#pragma once 
#include <DefaultKeyLabel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultKeyLabel.DefaultKeyLabel_C
// Size: 0x318(Inherited: 0x300) 
struct UDefaultKeyLabel_C : public UKeyLabel
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x300(0x8)
	struct UImage* IconImage;  // 0x308(0x8)
	struct UTextBlock* LabelText;  // 0x310(0x8)

	void UpdateKeyLabel(); // Function DefaultKeyLabel.DefaultKeyLabel_C.UpdateKeyLabel
	void ExecuteUbergraph_DefaultKeyLabel(int32_t EntryPoint); // Function DefaultKeyLabel.DefaultKeyLabel_C.ExecuteUbergraph_DefaultKeyLabel
}; 



