#pragma once 
#include <NetworkPredictionExtras_Structs.h>
 
 
 
// Class NetworkPredictionExtras.BaseMovementComponent
// Size: 0x2C0(Inherited: 0x2A0) 
struct UBaseMovementComponent : public UNetworkPredictionComponent
{
	struct USceneComponent* UpdatedComponent;  // 0x2A0(0x8)
	struct UPrimitiveComponent* UpdatedPrimitive;  // 0x2A8(0x8)
	char pad_688[16];  // 0x2B0(0x10)

	void PhysicsVolumeChanged(struct APhysicsVolume* NewVolume); // Function NetworkPredictionExtras.BaseMovementComponent.PhysicsVolumeChanged
	void OnBeginOverlap(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function NetworkPredictionExtras.BaseMovementComponent.OnBeginOverlap
}; 



// Class NetworkPredictionExtras.CharacterMotionComponent
// Size: 0x2E0(Inherited: 0x2C0) 
struct UCharacterMotionComponent : public UBaseMovementComponent
{
	char pad_704[32];  // 0x2C0(0x20)

}; 



// Class NetworkPredictionExtras.MockRootMotionSourceClassMap
// Size: 0x50(Inherited: 0x28) 
struct UMockRootMotionSourceClassMap : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct TSoftClassPtr<UObject>> SourceList;  // 0x30(0x10)
	char pad_64[16];  // 0x40(0x10)

}; 



// Class NetworkPredictionExtras.FlyingMovementComponent
// Size: 0x2E0(Inherited: 0x2C0) 
struct UFlyingMovementComponent : public UBaseMovementComponent
{
	char pad_704[32];  // 0x2C0(0x20)

}; 



// Class NetworkPredictionExtras.MockPhysicsComponent
// Size: 0x330(Inherited: 0x2C0) 
struct UMockPhysicsComponent : public UBaseMovementComponent
{
	char pad_704[8];  // 0x2C0(0x8)
	struct FMockPhysicsInputCmd PendingInputCmd;  // 0x2C8(0x20)
	struct FMulticastInlineDelegate OnJumpActivatedEvent;  // 0x2E8(0x10)
	struct FMulticastInlineDelegate OnChargeActivatedEvent;  // 0x2F8(0x10)
	struct FMulticastInlineDelegate OnChargeStateChange;  // 0x308(0x10)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool bIsCharging : 1;  // 0x318(0x1)
	char pad_793[23];  // 0x319(0x17)

}; 



// Class NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn
// Size: 0x328(Inherited: 0x2F8) 
struct ANetworkPredictionExtrasFlyingPawn : public APawn
{
	uint8_t  InputPreset;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool bFakeAutonomousProxy : 1;  // 0x2F9(0x1)
	char pad_762[6];  // 0x2FA(0x6)
	struct UFlyingMovementComponent* FlyingMovementComponent;  // 0x300(0x8)
	char pad_776[32];  // 0x308(0x20)

	void SetMaxMoveSpeed(float NewMaxMoveSpeed); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.SetMaxMoveSpeed
	void PrintDebug(); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.PrintDebug
	float GetMaxMoveSpeed(); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.GetMaxMoveSpeed
	void AddMaxMoveSpeed(float AdditiveMaxMoveSpeed); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn.AddMaxMoveSpeed
}; 



// Class NetworkPredictionExtras.MockFlyingAbilityComponent
// Size: 0x360(Inherited: 0x2E0) 
struct UMockFlyingAbilityComponent : public UFlyingMovementComponent
{
	char pad_736[8];  // 0x2E0(0x8)
	struct FMulticastInlineDelegate OnSprintStateChange;  // 0x2E8(0x10)
	struct FMulticastInlineDelegate OnDashStateChange;  // 0x2F8(0x10)
	struct FMulticastInlineDelegate OnBlinkStateChange;  // 0x308(0x10)
	struct FMulticastInlineDelegate OnBlinkActivateEvent;  // 0x318(0x10)
	struct FMulticastInlineDelegate OnBlinkActivateEventRollback;  // 0x328(0x10)
	struct FMulticastInlineDelegate OnPhysicsGunFirEvent;  // 0x338(0x10)
	char pad_840[24];  // 0x348(0x18)

	void MockAbilityPhysicsGunFireEvent__DelegateSignature(struct FVector Start, struct FVector End, bool bHasCooldown, struct TArray<struct FVector_NetQuantize100>& HitLocations, float ElapsedTimeSeconds); // DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityPhysicsGunFireEvent__DelegateSignature
	void MockAbilityNotifyStateChange__DelegateSignature(bool bNewStateValue); // DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityNotifyStateChange__DelegateSignature
	void MockAbilityBlinkCueRollback__DelegateSignature(); // DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityBlinkCueRollback__DelegateSignature
	void MockAbilityBlinkCueEvent__DelegateSignature(struct FVector DestinationLocation, int32_t RandomValue, float ElapsedTimeSeconds); // DelegateFunction NetworkPredictionExtras.MockFlyingAbilityComponent.MockAbilityBlinkCueEvent__DelegateSignature
	bool IsSprinting(); // Function NetworkPredictionExtras.MockFlyingAbilityComponent.IsSprinting
	bool IsDashing(); // Function NetworkPredictionExtras.MockFlyingAbilityComponent.IsDashing
	bool IsBlinking(); // Function NetworkPredictionExtras.MockFlyingAbilityComponent.IsBlinking
	float GetStamina(); // Function NetworkPredictionExtras.MockFlyingAbilityComponent.GetStamina
	float GetMaxStamina(); // Function NetworkPredictionExtras.MockFlyingAbilityComponent.GetMaxStamina
	float GetBlinkWarmupTimeSeconds(); // Function NetworkPredictionExtras.MockFlyingAbilityComponent.GetBlinkWarmupTimeSeconds
}; 



// Class NetworkPredictionExtras.MockCharacterAbilityComponent
// Size: 0x360(Inherited: 0x2E0) 
struct UMockCharacterAbilityComponent : public UCharacterMotionComponent
{
	char pad_736[8];  // 0x2E0(0x8)
	struct FMulticastInlineDelegate OnSprintStateChange;  // 0x2E8(0x10)
	struct FMulticastInlineDelegate OnDashStateChange;  // 0x2F8(0x10)
	struct FMulticastInlineDelegate OnBlinkStateChange;  // 0x308(0x10)
	struct FMulticastInlineDelegate OnJumpStateChange;  // 0x318(0x10)
	struct FMulticastInlineDelegate OnBlinkActivateEvent;  // 0x328(0x10)
	struct FMulticastInlineDelegate OnBlinkActivateEventRollback;  // 0x338(0x10)
	char pad_840[24];  // 0x348(0x18)

	void MockCharacterAbilityNotifyStateChange__DelegateSignature(bool bNewStateValue); // DelegateFunction NetworkPredictionExtras.MockCharacterAbilityComponent.MockCharacterAbilityNotifyStateChange__DelegateSignature
	void MockCharacterAbilityBlinkCueRollback__DelegateSignature(); // DelegateFunction NetworkPredictionExtras.MockCharacterAbilityComponent.MockCharacterAbilityBlinkCueRollback__DelegateSignature
	void MockCharacterAbilityBlinkCueEvent__DelegateSignature(struct FVector DestinationLocation, int32_t RandomValue, float ElapsedTimeSeconds); // DelegateFunction NetworkPredictionExtras.MockCharacterAbilityComponent.MockCharacterAbilityBlinkCueEvent__DelegateSignature
	bool IsSprinting(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.IsSprinting
	bool IsJumping(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.IsJumping
	bool IsDashing(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.IsDashing
	bool IsBlinking(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.IsBlinking
	float GetStamina(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.GetStamina
	float GetMaxStamina(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.GetMaxStamina
	float GetBlinkWarmupTimeSeconds(); // Function NetworkPredictionExtras.MockCharacterAbilityComponent.GetBlinkWarmupTimeSeconds
}; 



// Class NetworkPredictionExtras.MockNetworkSimulationComponent
// Size: 0x2B0(Inherited: 0x2A0) 
struct UMockNetworkSimulationComponent : public UNetworkPredictionComponent
{
	char pad_672[16];  // 0x2A0(0x10)

}; 



// Class NetworkPredictionExtras.MockPhysicsGrenadeComponent
// Size: 0x1F0(Inherited: 0x1D0) 
struct UMockPhysicsGrenadeComponent : public UNetworkPredictionPhysicsComponent
{
	struct FMulticastInlineDelegate OnExplode;  // 0x1C8(0x10)
	float FuseTimeSeconds;  // 0x1D8(0x4)
	float Radius;  // 0x1DC(0x4)
	float Magnitude;  // 0x1E0(0x4)
	char pad_492[4];  // 0x1EC(0x4)

}; 



// Class NetworkPredictionExtras.MockRootMotionComponent
// Size: 0x380(Inherited: 0x2C0) 
struct UMockRootMotionComponent : public UBaseMovementComponent
{
	char pad_704[168];  // 0x2C0(0xA8)
	struct FRootMotionSourceCache RootMotionSourceCache;  // 0x368(0x10)
	char pad_888[8];  // 0x378(0x8)

	void PlayRootMotionSourceByClass(UMockRootMotionSource* Source); // Function NetworkPredictionExtras.MockRootMotionComponent.PlayRootMotionSourceByClass
	void PlayRootMotionSource(struct UMockRootMotionSource* Source); // Function NetworkPredictionExtras.MockRootMotionComponent.PlayRootMotionSource
	void Input_PlayRootMotionSourceByClass(UMockRootMotionSource* Source); // Function NetworkPredictionExtras.MockRootMotionComponent.Input_PlayRootMotionSourceByClass
	void Input_PlayRootMotionSource(struct UMockRootMotionSource* Source); // Function NetworkPredictionExtras.MockRootMotionComponent.Input_PlayRootMotionSource
	struct UMockRootMotionSource* CreateRootMotionSource(UMockRootMotionSource* Source); // Function NetworkPredictionExtras.MockRootMotionComponent.CreateRootMotionSource
}; 



// Class NetworkPredictionExtras.MockRootMotionSource
// Size: 0x28(Inherited: 0x28) 
struct UMockRootMotionSource : public UObject
{

}; 



// Class NetworkPredictionExtras.MockRootMotionSource_Montage
// Size: 0x50(Inherited: 0x28) 
struct UMockRootMotionSource_Montage : public UMockRootMotionSource
{
	struct UAnimMontage* Montage;  // 0x28(0x8)
	float PlayRate;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FVector TranslationScale;  // 0x38(0x18)

}; 



// Class NetworkPredictionExtras.MockRootMotionSource_Curve
// Size: 0x50(Inherited: 0x28) 
struct UMockRootMotionSource_Curve : public UMockRootMotionSource
{
	struct UCurveVector* Curve;  // 0x28(0x8)
	float PlayRate;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FVector TranslationScale;  // 0x38(0x18)

}; 



// Class NetworkPredictionExtras.MockRootMotionSource_MoveToLocation
// Size: 0x50(Inherited: 0x28) 
struct UMockRootMotionSource_MoveToLocation : public UMockRootMotionSource
{
	struct FVector Destination;  // 0x28(0x18)
	float Velocity;  // 0x40(0x4)
	float SnapToTolerance;  // 0x44(0x4)
	char pad_72[8];  // 0x48(0x8)

	void SetDestination(struct FVector& InDestination); // Function NetworkPredictionExtras.MockRootMotionSource_MoveToLocation.SetDestination
}; 



// Class NetworkPredictionExtras.NetworkPredictionExtrasCharacter
// Size: 0x330(Inherited: 0x2F8) 
struct ANetworkPredictionExtrasCharacter : public APawn
{
	uint8_t  InputPreset;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool bFakeAutonomousProxy : 1;  // 0x2F9(0x1)
	char pad_762[6];  // 0x2FA(0x6)
	struct UCharacterMotionComponent* CharacterMotionComponent;  // 0x300(0x8)
	char pad_776[40];  // 0x308(0x28)

	void SetMaxMoveSpeed(float NewMaxMoveSpeed); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter.SetMaxMoveSpeed
	void PrintDebug(); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter.PrintDebug
	float GetMaxMoveSpeed(); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter.GetMaxMoveSpeed
	void AddMaxMoveSpeed(float AdditiveMaxMoveSpeed); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter.AddMaxMoveSpeed
}; 



// Class NetworkPredictionExtras.NetworkPredictionExtrasCharacter_MockAbility
// Size: 0x338(Inherited: 0x330) 
struct ANetworkPredictionExtrasCharacter_MockAbility : public ANetworkPredictionExtrasCharacter
{
	uint8_t  AbilityInputPreset;  // 0x330(0x1)
	char pad_817[7];  // 0x331(0x7)

	float GetStamina(); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter_MockAbility.GetStamina
	struct UMockCharacterAbilityComponent* GetMockCharacterAbilityComponent(); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter_MockAbility.GetMockCharacterAbilityComponent
	float GetMaxStamina(); // Function NetworkPredictionExtras.NetworkPredictionExtrasCharacter_MockAbility.GetMaxStamina
}; 



// Class NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility
// Size: 0x330(Inherited: 0x328) 
struct ANetworkPredictionExtrasFlyingPawn_MockAbility : public ANetworkPredictionExtrasFlyingPawn
{
	uint8_t  AbilityInputPreset;  // 0x328(0x1)
	char pad_809[7];  // 0x329(0x7)

	float GetStamina(); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility.GetStamina
	struct UMockFlyingAbilityComponent* GetMockFlyingAbilityComponent(); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility.GetMockFlyingAbilityComponent
	float GetMaxStamina(); // Function NetworkPredictionExtras.NetworkPredictionExtrasFlyingPawn_MockAbility.GetMaxStamina
}; 



// Class NetworkPredictionExtras.NetworkPredictionExtrasGameMode
// Size: 0x360(Inherited: 0x360) 
struct ANetworkPredictionExtrasGameMode : public AGameMode
{

}; 



// Class NetworkPredictionExtras.NetworkPredictionExtrasGameState
// Size: 0x2E8(Inherited: 0x2E8) 
struct ANetworkPredictionExtrasGameState : public AGameState
{

}; 



// Class NetworkPredictionExtras.ParametricMovementComponent
// Size: 0x360(Inherited: 0x2C0) 
struct UParametricMovementComponent : public UBaseMovementComponent
{
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bDisableParametricMovementSimulation : 1;  // 0x2C0(0x1)
	char pad_705[15];  // 0x2C1(0xF)
	struct FSimpleParametricMotion ParametricMotion;  // 0x2D0(0x80)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool bEnableDependentSimulation : 1;  // 0x350(0x1)
	char pad_849_1 : 7;  // 0x351(0x1)
	bool bEnableInterpolation : 1;  // 0x351(0x1)
	char pad_850_1 : 7;  // 0x352(0x1)
	bool bEnableForceNetUpdate : 1;  // 0x352(0x1)
	char pad_851[1];  // 0x353(0x1)
	float ParentNetUpdateFrequency;  // 0x354(0x4)
	char pad_856[8];  // 0x358(0x8)

	void EnableInterpolationMode(bool bValue); // Function NetworkPredictionExtras.ParametricMovementComponent.EnableInterpolationMode
}; 



// Class NetworkPredictionExtras.PhysicsMovementComponent
// Size: 0x198(Inherited: 0xC0) 
struct UPhysicsMovementComponent : public UNetworkPhysicsComponent
{
	struct FNetworkPredictionAsyncProxy NetworkPredictionProxy;  // 0xC0(0x10)
	struct FPhysicsMovementNetState MovementState;  // 0xD0(0x38)
	struct FPhysicsInputCmd PendingInputCmd;  // 0x108(0x70)
	struct FMulticastInlineDelegate OnGenerateLocalInputCmd;  // 0x178(0x10)
	struct APlayerController* CachedPC;  // 0x188(0x8)
	char pad_400[8];  // 0x190(0x8)

	void SetEnableTargetYaw(bool bTargetYaw); // Function NetworkPredictionExtras.PhysicsMovementComponent.SetEnableTargetYaw
	void SetEnableKeepUpright(bool bKeepUpright); // Function NetworkPredictionExtras.PhysicsMovementComponent.SetEnableKeepUpright
	void SetAutoTargetYawStrength(float Strength); // Function NetworkPredictionExtras.PhysicsMovementComponent.SetAutoTargetYawStrength
	void SetAutoTargetYawDamp(float YawDamp); // Function NetworkPredictionExtras.PhysicsMovementComponent.SetAutoTargetYawDamp
	void SetAutoBrakeStrength(float BrakeStrength); // Function NetworkPredictionExtras.PhysicsMovementComponent.SetAutoBrakeStrength
	void OnGenerateLocalInputCmd__DelegateSignature(); // DelegateFunction NetworkPredictionExtras.PhysicsMovementComponent.OnGenerateLocalInputCmd__DelegateSignature
}; 



// Class NetworkPredictionExtras.PhysicsSimpleComponent
// Size: 0x118(Inherited: 0xC0) 
struct UPhysicsSimpleComponent : public UNetworkPhysicsComponent
{
	struct FNetworkPredictionAsyncProxy NetworkPredictionProxy;  // 0xC0(0x10)
	struct FSimpleNetState SimpleState;  // 0xD0(0x8)
	struct FSimpleInputCmd PendingInputCmd;  // 0xD8(0x20)
	struct FMulticastInlineDelegate OnGenerateLocalInputCmd;  // 0xF8(0x10)
	struct APlayerController* CachedPC;  // 0x108(0x8)
	char pad_272[8];  // 0x110(0x8)

	void SetCounter(int32_t NewValue); // Function NetworkPredictionExtras.PhysicsSimpleComponent.SetCounter
	void OnGenerateLocalInputCmd__DelegateSignature(); // DelegateFunction NetworkPredictionExtras.PhysicsSimpleComponent.OnGenerateLocalInputCmd__DelegateSignature
}; 



