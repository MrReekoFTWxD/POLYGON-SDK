#pragma once 
#include "SDK.h" 
 
 
// Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.DrawDisplacementMapToRenderTarget
// Size: 0x18(Inherited: 0x0) 
struct FDrawDisplacementMapToRenderTarget
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UTextureRenderTarget2D* OutputRenderTarget;  // 0x8(0x8)
	struct UTexture2D* PreComputedUndistortDisplacementMap;  // 0x10(0x8)

}; 
// ScriptStruct OpenCVLensDistortion.OpenCVCameraViewInfo
// Size: 0xC(Inherited: 0x0) 
struct FOpenCVCameraViewInfo
{
	float HorizontalFOV;  // 0x0(0x4)
	float VerticalFOV;  // 0x4(0x4)
	float FocalLengthRatio;  // 0x8(0x4)

}; 
// ScriptStruct OpenCVLensDistortion.OpenCVLensDistortionParameters
// Size: 0x48(Inherited: 0x48) 
struct FOpenCVLensDistortionParameters : public FOpenCVLensDistortionParametersBase
{

}; 
// Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.CreateUndistortUVDisplacementMap
// Size: 0x68(Inherited: 0x0) 
struct FCreateUndistortUVDisplacementMap
{
	struct FOpenCVLensDistortionParameters LensParameters;  // 0x0(0x48)
	struct FIntPoint ImageSize;  // 0x48(0x8)
	float CroppingFactor;  // 0x50(0x4)
	struct FOpenCVCameraViewInfo CameraViewInfo;  // 0x54(0xC)
	struct UTexture2D* ReturnValue;  // 0x60(0x8)

}; 
// Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.EqualEqual_CompareLensDistortionModels
// Size: 0x98(Inherited: 0x0) 
struct FEqualEqual_CompareLensDistortionModels
{
	struct FOpenCVLensDistortionParameters A;  // 0x0(0x48)
	struct FOpenCVLensDistortionParameters B;  // 0x48(0x48)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.NotEqual_CompareLensDistortionModels
// Size: 0x98(Inherited: 0x0) 
struct FNotEqual_CompareLensDistortionModels
{
	struct FOpenCVLensDistortionParameters A;  // 0x0(0x48)
	struct FOpenCVLensDistortionParameters B;  // 0x48(0x48)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
