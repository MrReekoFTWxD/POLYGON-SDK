#pragma once 
#include <AnimationLocomotionLibraryRuntime_Structs.h>
 
 
 
// Class AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimDistanceMatchingLibrary : public UBlueprintFunctionLibrary
{

	struct FSequencePlayerReference SetPlayrateToMatchSpeed(struct FSequencePlayerReference& SequencePlayer, float SpeedToMatch, struct FVector2D PlayRateClamp); // Function AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.SetPlayrateToMatchSpeed
	struct FSequenceEvaluatorReference DistanceMatchToTarget(struct FSequenceEvaluatorReference& SequenceEvaluator, float DistanceToTarget, struct FName DistanceCurveName); // Function AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.DistanceMatchToTarget
	struct FSequenceEvaluatorReference AdvanceTimeByDistanceMatching(struct FAnimUpdateContext& UpdateContext, struct FSequenceEvaluatorReference& SequenceEvaluator, float DistanceTraveled, struct FName DistanceCurveName, struct FVector2D PlayRateClamp); // Function AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.AdvanceTimeByDistanceMatching
}; 



// Class AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimCharacterMovementLibrary : public UBlueprintFunctionLibrary
{

	struct FVector PredictGroundMovementStopLocation(struct FVector& Velocity, bool bUseSeparateBrakingFriction, float BrakingFriction, float GroundFriction, float BrakingFrictionFactor, float BrakingDecelerationWalking); // Function AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary.PredictGroundMovementStopLocation
	struct FVector PredictGroundMovementPivotLocation(struct FVector& Acceleration, struct FVector& Velocity, float GroundFriction); // Function AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary.PredictGroundMovementPivotLocation
}; 



