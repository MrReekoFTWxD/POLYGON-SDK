#pragma once 
#include <BP_Item_Strap_M24_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_M24_01.BP_Item_Strap_M24_01_C
// Size: 0x2E8(Inherited: 0x2E8) 
struct ABP_Item_Strap_M24_01_C : public AItem_Module_Strap
{

}; 



