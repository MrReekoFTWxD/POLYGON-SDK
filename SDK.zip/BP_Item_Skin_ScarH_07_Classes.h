#pragma once 
#include <BP_Item_Skin_ScarH_07_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Skin_ScarH_07.BP_Item_Skin_ScarH_07_C
// Size: 0x2F0(Inherited: 0x2E8) 
struct ABP_Item_Skin_ScarH_07_C : public AItem_Module_Skin
{
	struct USceneComponent* DefaultSceneRoot;  // 0x2E8(0x8)

}; 



