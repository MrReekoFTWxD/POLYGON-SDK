#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Optic_CollimatorSight_02.BP_Item_Optic_CollimatorSight_02_C.SetCorrectiveFovMaterial
// Size: 0x1(Inherited: 0x1) 
struct FSetCorrectiveFovMaterial : public FSetCorrectiveFovMaterial
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool useFovMaterial : 1;  // 0x0(0x1)

}; 
// Function BP_Item_Optic_CollimatorSight_02.BP_Item_Optic_CollimatorSight_02_C.ExecuteUbergraph_BP_Item_Optic_CollimatorSight_02
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Optic_CollimatorSight_02
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UMaterialInterface* Temp_object_Variable;  // 0x8(0x8)
	struct UMaterialInterface* Temp_object_Variable_2;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_Event_useFovMaterial : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UMaterialInterface* K2Node_Select_Default;  // 0x20(0x8)

}; 
