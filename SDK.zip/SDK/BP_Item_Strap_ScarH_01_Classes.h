#pragma once 
#include <BP_Item_Strap_ScarH_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_ScarH_01.BP_Item_Strap_ScarH_01_C
// Size: 0x350(Inherited: 0x350) 
struct ABP_Item_Strap_ScarH_01_C : public AItem_Module_Strap
{

}; 



