#pragma once 
#include <BP_PG_GameMode_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_GameMode_Menu.BP_PG_GameMode_Menu_C
// Size: 0x380(Inherited: 0x378) 
struct ABP_PG_GameMode_Menu_C : public APG_GameMode_Menu
{
	struct USceneComponent* DefaultSceneRoot;  // 0x378(0x8)

}; 



