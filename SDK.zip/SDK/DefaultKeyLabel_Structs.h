#pragma once 
#include "SDK.h" 
 
 
// Function DefaultKeyLabel.DefaultKeyLabel_C.ExecuteUbergraph_DefaultKeyLabel
// Size: 0x102(Inherited: 0x0) 
struct FExecuteUbergraph_DefaultKeyLabel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText CallFunc_GetDisplayName_ReturnValue;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_HasIcon_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[15];  // 0x21(0xF)
	struct FSlateBrush CallFunc_GetIconBrush_ReturnValue;  // 0x30(0xD0)
	uint8_t  CallFunc_GetIconVisibility_ReturnValue;  // 0x100(0x1)
	uint8_t  CallFunc_GetDisplayNameVisibility_ReturnValue;  // 0x101(0x1)

}; 
