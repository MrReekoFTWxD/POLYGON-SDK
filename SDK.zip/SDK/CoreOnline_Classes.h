#pragma once 
#include <CoreOnline_Structs.h>
 
 
 
