#pragma once 
#include <ExtendedMathUtility_Structs.h>
 
 
 
// Class ExtendedMathUtility.ExtendedMathUtility
// Size: 0x28(Inherited: 0x28) 
struct UExtendedMathUtility : public UBlueprintFunctionLibrary
{

	struct FVector VInterpToExtended(struct FVector Current, struct FVector Target, float DeltaTime, float interpSpeed_X, float interpSpeed_Y, float interpSpeed_Z); // Function ExtendedMathUtility.ExtendedMathUtility.VInterpToExtended
	struct FRotator RInterpToExtended(struct FRotator Current, struct FRotator Target, float DeltaTime, float interpSpeed_Pitch, float interpSpeed_Yaw, float interpSpeed_Roll); // Function ExtendedMathUtility.ExtendedMathUtility.RInterpToExtended
	bool IsNegative_Int(int32_t intToCheck); // Function ExtendedMathUtility.ExtendedMathUtility.IsNegative_Int
	bool IsNegative_Float(float floatToCheck); // Function ExtendedMathUtility.ExtendedMathUtility.IsNegative_Float
}; 



