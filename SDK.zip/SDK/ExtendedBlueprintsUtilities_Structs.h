#pragma once 
#include "SDK.h" 
 
 
// Function ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary.SpawnActorFromTemplate
// Size: 0x80(Inherited: 0x0) 
struct FSpawnActorFromTemplate
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct AActor* templateActor;  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x60)
	struct AActor* Owner;  // 0x70(0x8)
	struct AActor* ReturnValue;  // 0x78(0x8)

}; 
// Function ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary.ClassDefaultObject
// Size: 0x10(Inherited: 0x0) 
struct FClassDefaultObject
{
	UObject* objectClass;  // 0x0(0x8)
	struct AActor* ReturnValue;  // 0x8(0x8)

}; 
// Function ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary.GetDefaultComponentsByClass
// Size: 0x20(Inherited: 0x0) 
struct FGetDefaultComponentsByClass
{
	UObject* ActorClass;  // 0x0(0x8)
	UObject* ComponentClass;  // 0x8(0x8)
	struct TArray<struct UActorComponent*> outArray;  // 0x10(0x10)

}; 
