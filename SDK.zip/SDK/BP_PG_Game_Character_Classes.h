#pragma once 
#include <BP_PG_Game_Character_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_Game_Character.BP_PG_Game_Character_C
// Size: 0x868(Inherited: 0x730) 
struct ABP_PG_Game_Character_C : public APG_Game_Character
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x730(0x8)
	struct UStaticMeshComponent* SM_Chr_Attach_Patch_Squad_03;  // 0x738(0x8)
	struct UStaticMeshComponent* SM_Item_Crowbar_01;  // 0x740(0x8)
	struct UStaticMeshComponent* SM_Item_Pencil_01;  // 0x748(0x8)
	struct UStaticMeshComponent* Equipment_PouchB_01;  // 0x750(0x8)
	struct UStaticMeshComponent* Equipment_Glowstick_03;  // 0x758(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_01;  // 0x760(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_02;  // 0x768(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_04;  // 0x770(0x8)
	struct UStaticMeshComponent* Equipment_Glowstick_01;  // 0x778(0x8)
	struct UStaticMeshComponent* Equipment_Glowstick_02;  // 0x780(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_03;  // 0x788(0x8)
	struct UStaticMeshComponent* Equipment_Radio_02;  // 0x790(0x8)
	struct UStaticMeshComponent* Equipment_Radio_01;  // 0x798(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_04;  // 0x7A0(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_07;  // 0x7A8(0x8)
	struct UStaticMeshComponent* Equipment_TactFlashlight_01;  // 0x7B0(0x8)
	struct UStaticMeshComponent* Equipment_Grenade_Flash_01;  // 0x7B8(0x8)
	struct UStaticMeshComponent* Equipment_Grenade_Smoke_01;  // 0x7C0(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_03;  // 0x7C8(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_04;  // 0x7D0(0x8)
	struct UStaticMeshComponent* Equipment_Scissors_01;  // 0x7D8(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_06;  // 0x7E0(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_05;  // 0x7E8(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_02;  // 0x7F0(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_01;  // 0x7F8(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_01;  // 0x800(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_02;  // 0x808(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_03;  // 0x810(0x8)
	struct UStaticMeshComponent* Equipment_Belt;  // 0x818(0x8)
	struct UStaticMeshComponent* Holster_mesh;  // 0x820(0x8)
	struct UArrowComponent* Arrow1;  // 0x828(0x8)
	float Timeline_NeutralizationVignetteImpact_Aplha_C3DAEC164EEEDF0B1E076F90BD0F5BC3;  // 0x830(0x4)
	char ETimelineDirection Timeline_NeutralizationVignetteImpact__Direction_C3DAEC164EEEDF0B1E076F90BD0F5BC3;  // 0x834(0x1)
	char pad_2101[3];  // 0x835(0x3)
	struct UTimelineComponent* Timeline_NeutralizationVignetteImpact;  // 0x838(0x8)
	float Timeline_PostProcessScopeBlurWeight_Alpha_3680AFA946185937314F8B81F52A2B4F;  // 0x840(0x4)
	char ETimelineDirection Timeline_PostProcessScopeBlurWeight__Direction_3680AFA946185937314F8B81F52A2B4F;  // 0x844(0x1)
	char pad_2117[3];  // 0x845(0x3)
	struct UTimelineComponent* Timeline_PostProcessScopeBlurWeight;  // 0x848(0x8)
	struct UMaterialInstanceDynamic* MI_ScopeBlur;  // 0x850(0x8)
	struct UMaterialInstanceDynamic* MI_GunBlur;  // 0x858(0x8)
	double SaveNeutralizationFire;  // 0x860(0x8)

	void SetCorrectiveFovMaterialImplementation(bool useFovMaterial); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.SetCorrectiveFovMaterialImplementation
	void SetVisibleMarkerByDistance(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.SetVisibleMarkerByDistance
	void OnAiming(struct AItem_Module_Optic* Optic); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.OnAiming
	void SetPlayerLooksOverride(struct APG_Game_Character* Character, bool IsLooks); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.SetPlayerLooksOverride
	void UserConstructionScript(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.UserConstructionScript
	void Timeline_NeutralizationVignetteImpact__FinishedFunc(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.Timeline_NeutralizationVignetteImpact__FinishedFunc
	void Timeline_NeutralizationVignetteImpact__UpdateFunc(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.Timeline_NeutralizationVignetteImpact__UpdateFunc
	void Timeline_PostProcessScopeBlurWeight__FinishedFunc(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.Timeline_PostProcessScopeBlurWeight__FinishedFunc
	void Timeline_PostProcessScopeBlurWeight__UpdateFunc(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.Timeline_PostProcessScopeBlurWeight__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.ReceiveBeginPlay
	void BndEvt__BP_PG_Character_WeaponComponent_K2Node_ComponentBoundEvent_0_OnAimingDelegate__DelegateSignature(struct AItem_Module_Optic* OpticItem); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.BndEvt__BP_PG_Character_WeaponComponent_K2Node_ComponentBoundEvent_0_OnAimingDelegate__DelegateSignature
	void OnIsAlive_Event(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.OnIsAlive_Event
	void SetPlayerLooks(struct APG_Game_Character* Character, bool bIsLooks); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.SetPlayerLooks
	void CameraNeutralizationEffectEvent(float Damage); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.CameraNeutralizationEffectEvent
	void EventTakeDamage(struct FVector& Origin); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.EventTakeDamage
	void Respawn(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.Respawn
	void HitAtProtectedCharacter(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.HitAtProtectedCharacter
	void DeathEvent(struct APG_PlayerState_Game* killer, uint8_t  deathType); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.DeathEvent
	void OnJumped(); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.OnJumped
	void SetCorrectiveFovMaterial(bool useFovMaterial); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.SetCorrectiveFovMaterial
	void ExecuteUbergraph_BP_PG_Game_Character(int32_t EntryPoint); // Function BP_PG_Game_Character.BP_PG_Game_Character_C.ExecuteUbergraph_BP_PG_Game_Character
}; 



