#pragma once 
#include "SDK.h" 
 
 
// Function BI_SpawnTarget.BI_SpawnTarget_C.GetTargetReference
// Size: 0x8(Inherited: 0x0) 
struct FGetTargetReference
{
	struct AActor* Reference;  // 0x0(0x8)

}; 
// Function BI_SpawnTarget.BI_SpawnTarget_C.SetAsSpawnTarget
// Size: 0x1(Inherited: 0x0) 
struct FSetAsSpawnTarget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSpawnTarget : 1;  // 0x0(0x1)

}; 
