#pragma once 
#include <DefaultAxisLabel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultAxisLabel.DefaultAxisLabel_C
// Size: 0x2C0(Inherited: 0x2C0) 
struct UDefaultAxisLabel_C : public UAxisLabel
{

}; 



