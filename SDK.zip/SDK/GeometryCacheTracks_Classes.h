#pragma once 
#include <GeometryCacheTracks_Structs.h>
 
 
 
// Class GeometryCacheTracks.MovieSceneGeometryCacheSection
// Size: 0x138(Inherited: 0xF0) 
struct UMovieSceneGeometryCacheSection : public UMovieSceneSection
{
	struct FMovieSceneGeometryCacheParams Params;  // 0xF0(0x48)

}; 



// Class GeometryCacheTracks.MovieSceneGeometryCacheTrack
// Size: 0xB0(Inherited: 0x98) 
struct UMovieSceneGeometryCacheTrack : public UMovieSceneNameableTrack
{
	char pad_152[8];  // 0x98(0x8)
	struct TArray<struct UMovieSceneSection*> AnimationSections;  // 0xA0(0x10)

}; 



