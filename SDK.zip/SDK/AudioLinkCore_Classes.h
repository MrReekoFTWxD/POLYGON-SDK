#pragma once 
#include <AudioLinkCore_Structs.h>
 
 
 
// Class AudioLinkCore.AudioLinkSettingsAbstract
// Size: 0x38(Inherited: 0x28) 
struct UAudioLinkSettingsAbstract : public UObject
{
	char pad_40[16];  // 0x28(0x10)

}; 



