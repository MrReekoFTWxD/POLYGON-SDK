#pragma once 
#include <DataContainer_Structs.h>
 
 
 
// Class DataContainer.DataContainerValue_Bool
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_Bool : public UDataContainerValue_Base
{
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Data : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 



// Class DataContainer.DataContainerAsset
// Size: 0x38(Inherited: 0x30) 
struct UDataContainerAsset : public UDataAsset
{
	struct UDataContainerValue_DataObject* Data;  // 0x30(0x8)

}; 



// Class DataContainer.DataContainerValue_Int32
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_Int32 : public UDataContainerValue_Base
{
	int32_t Data;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 



// Class DataContainer.DataContainerValue_UObject
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_UObject : public UDataContainerValue_Base
{
	struct UObject* Data;  // 0x50(0x8)

}; 



// Class DataContainer.DataContainerValue_Base
// Size: 0x50(Inherited: 0x28) 
struct UDataContainerValue_Base : public UObject
{
	struct FString OptionalData;  // 0x28(0x10)
	struct FName DataType;  // 0x38(0x8)
	struct FString Tooltip;  // 0x40(0x10)

	struct UDataContainerValue_Base* FindDataContainerValue(struct FString tagPath); // Function DataContainer.DataContainerValue_Base.FindDataContainerValue
}; 



// Class DataContainer.DataContainerValue_DataObject
// Size: 0xA0(Inherited: 0x50) 
struct UDataContainerValue_DataObject : public UDataContainerValue_Base
{
	struct TMap<struct FName, struct UDataContainerValue_Base*> Values;  // 0x50(0x50)

}; 



// Class DataContainer.DataContainerValue_DataObjectArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_DataObjectArray : public UDataContainerValue_Base
{
	struct TArray<struct UDataContainerValue_DataObject*> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_BoolArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_BoolArray : public UDataContainerValue_Base
{
	struct TArray<bool> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_FString
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_FString : public UDataContainerValue_Base
{
	struct FString Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_Int32Array
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_Int32Array : public UDataContainerValue_Base
{
	struct TArray<int32_t> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_Float
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_Float : public UDataContainerValue_Base
{
	float Data;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 



// Class DataContainer.DataContainerValue_FloatArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_FloatArray : public UDataContainerValue_Base
{
	struct TArray<float> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_FTextArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_FTextArray : public UDataContainerValue_Base
{
	struct TArray<struct FText> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_Uint8
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_Uint8 : public UDataContainerValue_Base
{
	char Data;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 



// Class DataContainer.DataContainerValue_Uint8Array
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_Uint8Array : public UDataContainerValue_Base
{
	struct TArray<char> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_FStringArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_FStringArray : public UDataContainerValue_Base
{
	struct TArray<struct FString> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_FText
// Size: 0x68(Inherited: 0x50) 
struct UDataContainerValue_FText : public UDataContainerValue_Base
{
	struct FText Data;  // 0x50(0x18)

}; 



// Class DataContainer.DataContainerValue_TSoftClassPtrArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_TSoftClassPtrArray : public UDataContainerValue_Base
{
	struct TArray<struct TSoftClassPtr<UObject>> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_TSoftObjectPtr
// Size: 0x80(Inherited: 0x50) 
struct UDataContainerValue_TSoftObjectPtr : public UDataContainerValue_Base
{
	struct TSoftObjectPtr<UObject> Data;  // 0x50(0x30)

}; 



// Class DataContainer.DataContainerValue_FVector
// Size: 0x68(Inherited: 0x50) 
struct UDataContainerValue_FVector : public UDataContainerValue_Base
{
	struct FVector Data;  // 0x50(0x18)

}; 



// Class DataContainer.DataContainerValue_TSoftObjectPtrArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_TSoftObjectPtrArray : public UDataContainerValue_Base
{
	struct TArray<struct TSoftObjectPtr<UObject>> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_FVectorArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_FVectorArray : public UDataContainerValue_Base
{
	struct TArray<struct FVector> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_UObjectArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_UObjectArray : public UDataContainerValue_Base
{
	struct TArray<struct UObject*> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_UClass
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_UClass : public UDataContainerValue_Base
{
	UObject* Data;  // 0x50(0x8)

}; 



// Class DataContainer.DataContainerValue_TSoftClassPtr
// Size: 0x80(Inherited: 0x50) 
struct UDataContainerValue_TSoftClassPtr : public UDataContainerValue_Base
{
	struct TSoftClassPtr<UObject> Data;  // 0x50(0x30)

}; 



// Class DataContainer.DataContainerValue_UClassArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_UClassArray : public UDataContainerValue_Base
{
	struct TArray<UObject*> Data;  // 0x50(0x10)

}; 



// Class DataContainer.DataContainerValue_DataTable
// Size: 0x58(Inherited: 0x50) 
struct UDataContainerValue_DataTable : public UDataContainerValue_Base
{
	struct UDataTable* Data;  // 0x50(0x8)

}; 



// Class DataContainer.DataContainerValue_DataTableArray
// Size: 0x60(Inherited: 0x50) 
struct UDataContainerValue_DataTableArray : public UDataContainerValue_Base
{
	struct TArray<struct UDataTable*> Data;  // 0x50(0x10)

}; 



