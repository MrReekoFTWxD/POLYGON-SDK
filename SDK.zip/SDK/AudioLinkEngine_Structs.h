#pragma once 
#include "SDK.h" 
 
 
// Function AudioLinkEngine.AudioLinkBlueprintInterface.IsLinkPlaying
// Size: 0x1(Inherited: 0x0) 
struct FIsLinkPlaying
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AudioLinkEngine.AudioLinkBlueprintInterface.PlayLink
// Size: 0x4(Inherited: 0x0) 
struct FPlayLink
{
	float StartTime;  // 0x0(0x4)

}; 
// Function AudioLinkEngine.AudioLinkBlueprintInterface.SetLinkSound
// Size: 0x8(Inherited: 0x0) 
struct FSetLinkSound
{
	struct USoundBase* NewSound;  // 0x0(0x8)

}; 
