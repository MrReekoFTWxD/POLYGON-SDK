#pragma once 
#include <CameraShake_FootStep_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_FootStep.CameraShake_FootStep_C
// Size: 0x210(Inherited: 0x210) 
struct UCameraShake_FootStep_C : public ULegacyCameraShake
{

}; 



