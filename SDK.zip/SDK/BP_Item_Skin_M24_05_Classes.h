#pragma once 
#include <BP_Item_Skin_M24_05_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Skin_M24_05.BP_Item_Skin_M24_05_C
// Size: 0x360(Inherited: 0x358) 
struct ABP_Item_Skin_M24_05_C : public AItem_Module_Skin
{
	struct USceneComponent* DefaultSceneRoot;  // 0x358(0x8)

}; 



