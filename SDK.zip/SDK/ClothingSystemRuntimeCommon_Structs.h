#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ClothingSystemRuntimeCommon.ClothConstraintSetup_Legacy
// Size: 0x10(Inherited: 0x0) 
struct FClothConstraintSetup_Legacy
{
	float Stiffness;  // 0x0(0x4)
	float StiffnessMultiplier;  // 0x4(0x4)
	float StretchLimit;  // 0x8(0x4)
	float CompressionLimit;  // 0xC(0x4)

}; 
// ScriptStruct ClothingSystemRuntimeCommon.PointWeightMap
// Size: 0x10(Inherited: 0x0) 
struct FPointWeightMap
{
	struct TArray<float> Values;  // 0x0(0x10)

}; 
// ScriptStruct ClothingSystemRuntimeCommon.ClothConfig_Legacy
// Size: 0x130(Inherited: 0x0) 
struct FClothConfig_Legacy
{
	uint8_t  WindMethod;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FClothConstraintSetup_Legacy VerticalConstraintConfig;  // 0x4(0x10)
	struct FClothConstraintSetup_Legacy HorizontalConstraintConfig;  // 0x14(0x10)
	struct FClothConstraintSetup_Legacy BendConstraintConfig;  // 0x24(0x10)
	struct FClothConstraintSetup_Legacy ShearConstraintConfig;  // 0x34(0x10)
	float SelfCollisionRadius;  // 0x44(0x4)
	float SelfCollisionStiffness;  // 0x48(0x4)
	float SelfCollisionCullScale;  // 0x4C(0x4)
	struct FVector Damping;  // 0x50(0x18)
	float Friction;  // 0x68(0x4)
	float WindDragCoefficient;  // 0x6C(0x4)
	float WindLiftCoefficient;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct FVector LinearDrag;  // 0x78(0x18)
	struct FVector AngularDrag;  // 0x90(0x18)
	struct FVector LinearInertiaScale;  // 0xA8(0x18)
	struct FVector AngularInertiaScale;  // 0xC0(0x18)
	struct FVector CentrifugalInertiaScale;  // 0xD8(0x18)
	float SolverFrequency;  // 0xF0(0x4)
	float StiffnessFrequency;  // 0xF4(0x4)
	float GravityScale;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct FVector GravityOverride;  // 0x100(0x18)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool bUseGravityOverride : 1;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float TetherStiffness;  // 0x11C(0x4)
	float TetherLimit;  // 0x120(0x4)
	float CollisionThickness;  // 0x124(0x4)
	float AnimDriveSpringStiffness;  // 0x128(0x4)
	float AnimDriveDamperStiffness;  // 0x12C(0x4)

}; 
// ScriptStruct ClothingSystemRuntimeCommon.ClothPhysicalMeshData
// Size: 0xD8(Inherited: 0x0) 
struct FClothPhysicalMeshData
{
	struct TArray<struct FVector3f> Vertices;  // 0x0(0x10)
	struct TArray<struct FVector3f> Normals;  // 0x10(0x10)
	struct TArray<uint32_t> Indices;  // 0x20(0x10)
	struct TMap<uint32_t, struct FPointWeightMap> WeightMaps;  // 0x30(0x50)
	struct TArray<float> InverseMasses;  // 0x80(0x10)
	struct TArray<struct FClothVertBoneData> BoneData;  // 0x90(0x10)
	struct TArray<uint32_t> SelfCollisionIndices;  // 0xA0(0x10)
	struct FClothTetherData EuclideanTethers;  // 0xB0(0x10)
	struct FClothTetherData GeodesicTethers;  // 0xC0(0x10)
	int32_t MaxBoneWeights;  // 0xD0(0x4)
	int32_t NumFixedVerts;  // 0xD4(0x4)

}; 
// ScriptStruct ClothingSystemRuntimeCommon.ClothLODDataCommon
// Size: 0x148(Inherited: 0x0) 
struct FClothLODDataCommon
{
	struct FClothPhysicalMeshData PhysicalMeshData;  // 0x0(0xD8)
	struct FClothCollisionData CollisionData;  // 0xD8(0x40)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool bUseMultipleInfluences : 1;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float SkinningKernelRadius;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bSmoothTransition : 1;  // 0x120(0x1)
	char pad_289[39];  // 0x121(0x27)

}; 
// ScriptStruct ClothingSystemRuntimeCommon.ClothTetherData
// Size: 0x10(Inherited: 0x0) 
struct FClothTetherData
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct ClothingSystemRuntimeCommon.ClothParameterMask_Legacy
// Size: 0x30(Inherited: 0x0) 
struct FClothParameterMask_Legacy
{
	struct FName MaskName;  // 0x0(0x8)
	uint8_t  CurrentTarget;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float MaxValue;  // 0xC(0x4)
	float MinValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<float> Values;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnabled : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
