#pragma once 
#include <CableComponent_Structs.h>
 
 
 
// Class CableComponent.CableActor
// Size: 0x298(Inherited: 0x290) 
struct ACableActor : public AActor
{
	struct UCableComponent* CableComponent;  // 0x290(0x8)

}; 



// Class CableComponent.CableComponent
// Size: 0x620(Inherited: 0x570) 
struct UCableComponent : public UMeshComponent
{
	char pad_1392_1 : 7;  // 0x570(0x1)
	bool bAttachStart : 1;  // 0x570(0x1)
	char pad_1393_1 : 7;  // 0x571(0x1)
	bool bAttachEnd : 1;  // 0x571(0x1)
	char pad_1394[6];  // 0x572(0x6)
	struct FComponentReference AttachEndTo;  // 0x578(0x28)
	struct FName AttachEndToSocketName;  // 0x5A0(0x8)
	struct FVector EndLocation;  // 0x5A8(0x18)
	float CableLength;  // 0x5C0(0x4)
	int32_t NumSegments;  // 0x5C4(0x4)
	float SubstepTime;  // 0x5C8(0x4)
	int32_t SolverIterations;  // 0x5CC(0x4)
	char pad_1488_1 : 7;  // 0x5D0(0x1)
	bool bEnableStiffness : 1;  // 0x5D0(0x1)
	char pad_1489_1 : 7;  // 0x5D1(0x1)
	bool bUseSubstepping : 1;  // 0x5D1(0x1)
	char pad_1490_1 : 7;  // 0x5D2(0x1)
	bool bSkipCableUpdateWhenNotVisible : 1;  // 0x5D2(0x1)
	char pad_1491_1 : 7;  // 0x5D3(0x1)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered : 1;  // 0x5D3(0x1)
	char pad_1492_1 : 7;  // 0x5D4(0x1)
	bool bEnableCollision : 1;  // 0x5D4(0x1)
	char pad_1493[3];  // 0x5D5(0x3)
	float CollisionFriction;  // 0x5D8(0x4)
	char pad_1500[4];  // 0x5DC(0x4)
	struct FVector CableForce;  // 0x5E0(0x18)
	float CableGravityScale;  // 0x5F8(0x4)
	float CableWidth;  // 0x5FC(0x4)
	int32_t NumSides;  // 0x600(0x4)
	float TileMaterial;  // 0x604(0x4)
	char pad_1544[24];  // 0x608(0x18)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor
}; 



