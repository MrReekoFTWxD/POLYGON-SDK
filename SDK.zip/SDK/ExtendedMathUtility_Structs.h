#pragma once 
#include "SDK.h" 
 
 
// Function ExtendedMathUtility.ExtendedMathUtility.RInterpToExtended
// Size: 0x58(Inherited: 0x0) 
struct FRInterpToExtended
{
	struct FRotator Current;  // 0x0(0x18)
	struct FRotator Target;  // 0x18(0x18)
	float DeltaTime;  // 0x30(0x4)
	float interpSpeed_Pitch;  // 0x34(0x4)
	float interpSpeed_Yaw;  // 0x38(0x4)
	float interpSpeed_Roll;  // 0x3C(0x4)
	struct FRotator ReturnValue;  // 0x40(0x18)

}; 
// Function ExtendedMathUtility.ExtendedMathUtility.IsNegative_Float
// Size: 0x8(Inherited: 0x0) 
struct FIsNegative_Float
{
	float floatToCheck;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ExtendedMathUtility.ExtendedMathUtility.IsNegative_Int
// Size: 0x8(Inherited: 0x0) 
struct FIsNegative_Int
{
	int32_t intToCheck;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ExtendedMathUtility.ExtendedMathUtility.VInterpToExtended
// Size: 0x58(Inherited: 0x0) 
struct FVInterpToExtended
{
	struct FVector Current;  // 0x0(0x18)
	struct FVector Target;  // 0x18(0x18)
	float DeltaTime;  // 0x30(0x4)
	float interpSpeed_X;  // 0x34(0x4)
	float interpSpeed_Y;  // 0x38(0x4)
	float interpSpeed_Z;  // 0x3C(0x4)
	struct FVector ReturnValue;  // 0x40(0x18)

}; 
