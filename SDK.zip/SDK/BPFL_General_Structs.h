#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_General.BPFL_General_C.GetActorRelativeLocation
// Size: 0xA8(Inherited: 0x0) 
struct FGetActorRelativeLocation
{
	struct AActor* ParentActor;  // 0x0(0x8)
	struct AActor* ChildActor;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector ReturnValue;  // 0x18(0x18)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x30(0x18)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x48(0x18)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x60(0x18)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x78(0x18)
	struct FVector CallFunc_LessLess_VectorRotator_ReturnValue;  // 0x90(0x18)

}; 
// Function BPFL_General.BPFL_General_C.GetDefaultModuleClassByType
// Size: 0x68(Inherited: 0x0) 
struct FGetDefaultModuleClassByType
{
	uint8_t  ModuleType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	AItem_Module_General* DefaultModuleClass;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	AItem_Module_General* Temp_class_Variable;  // 0x20(0x8)
	AItem_Module_General* Temp_class_Variable_2;  // 0x28(0x8)
	AItem_Module_General* Temp_class_Variable_3;  // 0x30(0x8)
	AItem_Module_General* Temp_class_Variable_4;  // 0x38(0x8)
	AItem_Module_General* Temp_class_Variable_5;  // 0x40(0x8)
	AItem_Module_General* Temp_class_Variable_6;  // 0x48(0x8)
	AItem_Module_General* Temp_class_Variable_7;  // 0x50(0x8)
	AItem_Module_General* Temp_class_Variable_8;  // 0x58(0x8)
	AItem_Module_General* K2Node_Select_Default;  // 0x60(0x8)

}; 
// Function BPFL_General.BPFL_General_C.GetGameInstance
// Size: 0x21(Inherited: 0x0) 
struct FGetGameInstance
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UBP_PG_GameInstance_C* MyGameIntance;  // 0x8(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct UBP_PG_GameInstance_C* K2Node_DynamicCast_AsBP_PG_Game_Instance;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_General.BPFL_General_C.GetGameModeBP_Game
// Size: 0x21(Inherited: 0x0) 
struct FGetGameModeBP_Game
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ABP_PG_GameMode_Game_C* MyGameMode;  // 0x8(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct ABP_PG_GameMode_Game_C* K2Node_DynamicCast_AsBP_PG_Game_Mode_Game;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_General.BPFL_General_C.GetGameStateBP
// Size: 0x21(Inherited: 0x0) 
struct FGetGameStateBP
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ABP_PG_GameState_Game_C* MyGameState;  // 0x8(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct ABP_PG_GameState_Game_C* K2Node_DynamicCast_AsBP_PG_Game_State_Game;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_General.BPFL_General_C.GetRareColor
// Size: 0xA4(Inherited: 0x0) 
struct FGetRareColor
{
	uint8_t  Rare;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor NewParam;  // 0x10(0x10)
	uint8_t  Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x24(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x34(0x10)
	struct FLinearColor Temp_struct_Variable_3;  // 0x44(0x10)
	struct FLinearColor Temp_struct_Variable_4;  // 0x54(0x10)
	struct FLinearColor Temp_struct_Variable_5;  // 0x64(0x10)
	struct FLinearColor Temp_struct_Variable_6;  // 0x74(0x10)
	struct FLinearColor Temp_struct_Variable_7;  // 0x84(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x94(0x10)

}; 
