#pragma once 
#include <Actions_Structs.h>
 
 
 
// Class Actions.Action
// Size: 0xA8(Inherited: 0x28) 
struct UAction : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bWantsToTick : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float TickRate;  // 0x2C(0x4)
	uint8_t  State;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TSet<struct UAction*> ChildrenActions;  // 0x38(0x50)
	struct FMulticastInlineDelegate OnActivationDelegate;  // 0x88(0x10)
	struct FMulticastInlineDelegate OnFinishedDelegate;  // 0x98(0x10)

	bool Succeeded(); // Function Actions.Action.Succeeded
	void Succeed(); // Function Actions.Action.Succeed
	void ReceiveTick(float DeltaTime); // Function Actions.Action.ReceiveTick
	void ReceiveFinished(uint8_t  Reason); // Function Actions.Action.ReceiveFinished
	bool ReceiveCanActivate(); // Function Actions.Action.ReceiveCanActivate
	void ReceiveActivate(); // Function Actions.Action.ReceiveActivate
	bool IsRunning(); // Function Actions.Action.IsRunning
	float GetTickRate(); // Function Actions.Action.GetTickRate
	uint8_t  GetState(); // Function Actions.Action.GetState
	struct UAction* GetParentAction(); // Function Actions.Action.GetParentAction
	struct UObject* GetParent(); // Function Actions.Action.GetParent
	struct UActorComponent* GetOwnerComponent(); // Function Actions.Action.GetOwnerComponent
	struct AActor* GetOwnerActor(); // Function Actions.Action.GetOwnerActor
	struct UObject* GetOwner(); // Function Actions.Action.GetOwner
	bool Failed(); // Function Actions.Action.Failed
	void Fail(struct FName Error); // Function Actions.Action.Fail
	void Activate(); // Function Actions.Action.Activate
}; 



// Class Actions.BTT_RunAction
// Size: 0x88(Inherited: 0x70) 
struct UBTT_RunAction : public UBTTaskNode
{
	struct UAction* ActionType;  // 0x70(0x8)
	struct UAction* Action;  // 0x78(0x8)
	struct UBehaviorTreeComponent* OwnerComp;  // 0x80(0x8)

	void OnRunActionFinished(uint8_t  Reason); // Function Actions.BTT_RunAction.OnRunActionFinished
}; 



// Class Actions.ActionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UActionLibrary : public UBlueprintFunctionLibrary
{

	struct UAction* CreateAction(struct UObject* Owner, UAction* Type, bool bAutoActivate); // Function Actions.ActionLibrary.CreateAction
}; 



// Class Actions.ActionsSubsystem
// Size: 0x98(Inherited: 0x30) 
struct UActionsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[8];  // 0x30(0x8)
	struct TSet<struct FRootAction> RootActions;  // 0x38(0x50)
	struct TArray<struct FActionsTickGroup> TickGroups;  // 0x88(0x10)

	void CancelAllByOwner(struct UObject* Object); // Function Actions.ActionsSubsystem.CancelAllByOwner
	void CancelAllByClass(UObject* actionClass, struct TArray<struct UAction*> ignoreActions); // Function Actions.ActionsSubsystem.CancelAllByClass
}; 



