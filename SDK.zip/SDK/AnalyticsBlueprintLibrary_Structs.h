#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnalyticsBlueprintLibrary.AnalyticsEventAttr
// Size: 0x20(Inherited: 0x0) 
struct FAnalyticsEventAttr
{
	struct FString Name;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetSessionId
// Size: 0x10(Inherited: 0x0) 
struct FGetSessionId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGivenWithAttributes
// Size: 0x28(Inherited: 0x0) 
struct FRecordCurrencyGivenWithAttributes
{
	struct FString GameCurrencyType;  // 0x0(0x10)
	int32_t GameCurrencyAmount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x18(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSession
// Size: 0x1(Inherited: 0x0) 
struct FStartSession
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetBuildInfo
// Size: 0x10(Inherited: 0x0) 
struct FSetBuildInfo
{
	struct FString BuildInfo;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetUserId
// Size: 0x10(Inherited: 0x0) 
struct FGetUserId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.MakeEventAttribute
// Size: 0x40(Inherited: 0x0) 
struct FMakeEventAttribute
{
	struct FString AttributeName;  // 0x0(0x10)
	struct FString AttributeValue;  // 0x10(0x10)
	struct FAnalyticsEventAttr ReturnValue;  // 0x20(0x20)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyPurchase
// Size: 0x40(Inherited: 0x0) 
struct FRecordCurrencyPurchase
{
	struct FString GameCurrencyType;  // 0x0(0x10)
	int32_t GameCurrencyAmount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString RealCurrencyType;  // 0x18(0x10)
	float RealMoneyCost;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString PaymentProvider;  // 0x30(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGiven
// Size: 0x18(Inherited: 0x0) 
struct FRecordCurrencyGiven
{
	struct FString GameCurrencyType;  // 0x0(0x10)
	int32_t GameCurrencyAmount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetGender
// Size: 0x10(Inherited: 0x0) 
struct FSetGender
{
	struct FString Gender;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithAttributes
// Size: 0x30(Inherited: 0x0) 
struct FRecordProgressWithAttributes
{
	struct FString ProgressType;  // 0x0(0x10)
	struct FString ProgressName;  // 0x10(0x10)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x20(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordError
// Size: 0x10(Inherited: 0x0) 
struct FRecordError
{
	struct FString Error;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordErrorWithAttributes
// Size: 0x20(Inherited: 0x0) 
struct FRecordErrorWithAttributes
{
	struct FString Error;  // 0x0(0x10)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x10(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSessionWithAttributes
// Size: 0x18(Inherited: 0x0) 
struct FStartSessionWithAttributes
{
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEvent
// Size: 0x10(Inherited: 0x0) 
struct FRecordEvent
{
	struct FString EventName;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttribute
// Size: 0x30(Inherited: 0x0) 
struct FRecordEventWithAttribute
{
	struct FString EventName;  // 0x0(0x10)
	struct FString AttributeName;  // 0x10(0x10)
	struct FString AttributeValue;  // 0x20(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttributes
// Size: 0x20(Inherited: 0x0) 
struct FRecordEventWithAttributes
{
	struct FString EventName;  // 0x0(0x10)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x10(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetLocation
// Size: 0x10(Inherited: 0x0) 
struct FSetLocation
{
	struct FString Location;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordItemPurchase
// Size: 0x28(Inherited: 0x0) 
struct FRecordItemPurchase
{
	struct FString ItemId;  // 0x0(0x10)
	struct FString Currency;  // 0x10(0x10)
	int32_t PerItemCost;  // 0x20(0x4)
	int32_t ItemQuantity;  // 0x24(0x4)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgress
// Size: 0x20(Inherited: 0x0) 
struct FRecordProgress
{
	struct FString ProgressType;  // 0x0(0x10)
	struct FString ProgressName;  // 0x10(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithFullHierarchyAndAttributes
// Size: 0x30(Inherited: 0x0) 
struct FRecordProgressWithFullHierarchyAndAttributes
{
	struct FString ProgressType;  // 0x0(0x10)
	struct TArray<struct FString> ProgressNames;  // 0x10(0x10)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x20(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchase
// Size: 0x18(Inherited: 0x0) 
struct FRecordSimpleCurrencyPurchase
{
	struct FString GameCurrencyType;  // 0x0(0x10)
	int32_t GameCurrencyAmount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchaseWithAttributes
// Size: 0x28(Inherited: 0x0) 
struct FRecordSimpleCurrencyPurchaseWithAttributes
{
	struct FString GameCurrencyType;  // 0x0(0x10)
	int32_t GameCurrencyAmount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x18(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchase
// Size: 0x18(Inherited: 0x0) 
struct FRecordSimpleItemPurchase
{
	struct FString ItemId;  // 0x0(0x10)
	int32_t ItemQuantity;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchaseWithAttributes
// Size: 0x28(Inherited: 0x0) 
struct FRecordSimpleItemPurchaseWithAttributes
{
	struct FString ItemId;  // 0x0(0x10)
	int32_t ItemQuantity;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FAnalyticsEventAttr> Attributes;  // 0x18(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetAge
// Size: 0x4(Inherited: 0x0) 
struct FSetAge
{
	int32_t Age;  // 0x0(0x4)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetSessionId
// Size: 0x10(Inherited: 0x0) 
struct FSetSessionId
{
	struct FString SessionId;  // 0x0(0x10)

}; 
// Function AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetUserId
// Size: 0x10(Inherited: 0x0) 
struct FSetUserId
{
	struct FString UserId;  // 0x0(0x10)

}; 
