#pragma once 
#include <BP_Item_Strap_M24_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_M24_01.BP_Item_Strap_M24_01_C
// Size: 0x350(Inherited: 0x350) 
struct ABP_Item_Strap_M24_01_C : public AItem_Module_Strap
{

}; 



