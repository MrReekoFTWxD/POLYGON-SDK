#pragma once 
#include "SDK.h" 
 
 
// Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.CacheGunModulesValues
// Size: 0x1A0(Inherited: 0x0) 
struct FCacheGunModulesValues
{
	struct AItem_Module_General* L_ModuleIt;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AItem_Module_Underbarrel_Grip* K2Node_DynamicCast_AsItem_Module_Underbarrel_Grip;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_DoesSocketExist_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x40(0x60)
	struct FVector CallFunc_BreakTransform_Location;  // 0xA0(0x18)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xB8(0x18)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xD0(0x18)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0xE8(0x18)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct FVector CallFunc_GetActorRelativeLocation_ReturnValue;  // 0x108(0x18)
	struct FVector CallFunc_Divide_VectorVector_ReturnValue;  // 0x120(0x18)
	struct AItem_Module_General* CallFunc_Array_Get_Item;  // 0x138(0x8)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x140(0x18)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x158(0x18)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x178(0x18)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x194(0x4)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x19C(0x4)

}; 
// ScriptStruct ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.AnimBlueprintGeneratedConstantData
// Size: 0x138(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_110;  // 0x4(0x8)
	struct FInputScaleBiasClampConstants __StructProperty_111;  // 0xC(0x2C)
	float __FloatProperty_112;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UBlendProfile* __BlendProfile_113;  // 0x40(0x8)
	struct UCurveFloat* __CurveFloat_114;  // 0x48(0x8)
	uint8_t  __EnumProperty_115;  // 0x50(0x1)
	uint8_t  __EnumProperty_116;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct TArray<float> __ArrayProperty_117;  // 0x58(0x10)
	char ESequenceEvalReinit __ByteProperty_118;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool __BoolProperty_119 : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	float __FloatProperty_120;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool __BoolProperty_121 : 1;  // 0x70(0x1)
	uint8_t  __EnumProperty_122;  // 0x71(0x1)
	char EAnimGroupRole __ByteProperty_123;  // 0x72(0x1)
	char pad_115[1];  // 0x73(0x1)
	struct FName __NameProperty_124;  // 0x74(0x8)
	char pad_124[4];  // 0x7C(0x4)
	struct FAnimNodeFunctionRef __StructProperty_125;  // 0x80(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0xA0(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x120(0x18)

}; 
// Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.ExecuteUbergraph_ABP_CharacterPG_Menu
// Size: 0x78(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_CharacterPG_Menu
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x18(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x28(0x10)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x38(0x8)
	struct ABP_PG_PlayerController_Menu_C* K2Node_DynamicCast_AsBP_PG_Player_Controller_Menu;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct ABP_PG_PlayerState_Menu_C* K2Node_DynamicCast_AsBP_PG_Player_State_Menu;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct TArray<struct ABP_PG_Menu_Character_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x60(0x10)
	struct ABP_PG_Menu_Character_C* CallFunc_Array_Get_Item;  // 0x70(0x8)

}; 
// ScriptStruct ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.AnimBlueprintGeneratedMutableData
// Size: 0x20(Inherited: 0x1) 
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
	char pad_1[7];  // 0x1(0x7)
	struct UAnimSequenceBase* __AnimSequenceBase;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool __BoolProperty_1 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UAnimSequenceBase* __AnimSequenceBase_2;  // 0x18(0x8)

}; 
