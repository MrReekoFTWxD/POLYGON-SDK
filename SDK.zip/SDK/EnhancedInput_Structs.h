#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction EnhancedInput.EnhancedInputActionHandlerDynamicSignature__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FEnhancedInputActionHandlerDynamicSignature__DelegateSignature
{
	struct FInputActionValue ActionValue;  // 0x0(0x20)
	float ElapsedTime;  // 0x20(0x4)
	float TriggeredTime;  // 0x24(0x4)
	struct UInputAction* SourceAction;  // 0x28(0x8)

}; 
// Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToBool
// Size: 0x28(Inherited: 0x0) 
struct FConv_InputActionValueToBool
{
	struct FInputActionValue InValue;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EnhancedInput.InputActionValue
// Size: 0x20(Inherited: 0x0) 
struct FInputActionValue
{
	char pad_0[32];  // 0x0(0x20)

}; 
// DelegateFunction EnhancedInput.InputDebugKeyHandlerDynamicSignature__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FInputDebugKeyHandlerDynamicSignature__DelegateSignature
{
	struct FKey Key;  // 0x0(0x18)
	struct FInputActionValue ActionValue;  // 0x18(0x20)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.AddPlayerMappedKey
// Size: 0x28(Inherited: 0x0) 
struct FAddPlayerMappedKey
{
	struct FName MappingName;  // 0x0(0x8)
	struct FKey NewKey;  // 0x8(0x18)
	struct FModifyContextOptions Options;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t ReturnValue;  // 0x24(0x4)

}; 
// Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValueOfType
// Size: 0x40(Inherited: 0x0) 
struct FMakeInputActionValueOfType
{
	double X;  // 0x0(0x8)
	double Y;  // 0x8(0x8)
	double Z;  // 0x10(0x8)
	uint8_t  ValueType;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FInputActionValue ReturnValue;  // 0x20(0x20)

}; 
// ScriptStruct EnhancedInput.BlueprintEnhancedInputActionBinding
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintEnhancedInputActionBinding
{
	struct UInputAction* InputAction;  // 0x0(0x8)
	uint8_t  TriggerEvent;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FName FunctionNameToBind;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.GetAllPlayerMappableActionKeyMappings
// Size: 0x10(Inherited: 0x0) 
struct FGetAllPlayerMappableActionKeyMappings
{
	struct TArray<struct FEnhancedActionKeyMapping> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct EnhancedInput.PlayerMappableKeyOptions
// Size: 0x40(Inherited: 0x0) 
struct FPlayerMappableKeyOptions
{
	struct UObject* MetaData;  // 0x0(0x8)
	struct FName Name;  // 0x8(0x8)
	struct FText DisplayName;  // 0x10(0x18)
	struct FText DisplayCategory;  // 0x28(0x18)

}; 
// ScriptStruct EnhancedInput.MappingQueryIssue
// Size: 0x18(Inherited: 0x0) 
struct FMappingQueryIssue
{
	uint8_t  Issue;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UInputMappingContext* BlockingContext;  // 0x8(0x8)
	struct UInputAction* BlockingAction;  // 0x10(0x8)

}; 
// ScriptStruct EnhancedInput.EnhancedActionKeyMapping
// Size: 0x88(Inherited: 0x0) 
struct FEnhancedActionKeyMapping
{
	struct FPlayerMappableKeyOptions PlayerMappableOptions;  // 0x0(0x40)
	struct TArray<struct UInputTrigger*> Triggers;  // 0x40(0x10)
	struct TArray<struct UInputModifier*> Modifiers;  // 0x50(0x10)
	struct UInputAction* Action;  // 0x60(0x8)
	struct FKey Key;  // 0x68(0x18)
	char bIsPlayerMappable : 1;  // 0x80(0x1)
	char bShouldBeIgnored : 1;  // 0x80(0x1)
	char pad_128_1 : 6;  // 0x80(0x1)
	char pad_129[8];  // 0x81(0x8)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetDisplayName
// Size: 0x18(Inherited: 0x0) 
struct FGetDisplayName
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInContextSet
// Size: 0x50(Inherited: 0x0) 
struct FQueryMapKeyInContextSet
{
	struct TArray<struct UInputMappingContext*> PrioritizedActiveContexts;  // 0x0(0x10)
	struct UInputMappingContext* InputContext;  // 0x10(0x8)
	struct UInputAction* Action;  // 0x18(0x8)
	struct FKey Key;  // 0x20(0x18)
	struct TArray<struct FMappingQueryIssue> OutIssues;  // 0x38(0x10)
	uint8_t  BlockingIssues;  // 0x48(0x1)
	uint8_t  ReturnValue;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)

}; 
// Function EnhancedInput.EnhancedInputLibrary.GetBoundActionValue
// Size: 0x30(Inherited: 0x0) 
struct FGetBoundActionValue
{
	struct AActor* Actor;  // 0x0(0x8)
	struct UInputAction* Action;  // 0x8(0x8)
	struct FInputActionValue ReturnValue;  // 0x10(0x20)

}; 
// ScriptStruct EnhancedInput.ModifyContextOptions
// Size: 0x1(Inherited: 0x0) 
struct FModifyContextOptions
{
	char bIgnoreAllPressedKeysUntilRelease : 1;  // 0x0(0x1)
	char bForceImmediately : 1;  // 0x0(0x1)
	char pad_0_1 : 6;  // 0x0(0x1)

}; 
// ScriptStruct EnhancedInput.InjectedInputArray
// Size: 0x10(Inherited: 0x0) 
struct FInjectedInputArray
{
	char pad_0[16];  // 0x0(0x10)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInActiveContextSet
// Size: 0x40(Inherited: 0x0) 
struct FQueryMapKeyInActiveContextSet
{
	struct UInputMappingContext* InputContext;  // 0x0(0x8)
	struct UInputAction* Action;  // 0x8(0x8)
	struct FKey Key;  // 0x10(0x18)
	struct TArray<struct FMappingQueryIssue> OutIssues;  // 0x28(0x10)
	uint8_t  BlockingIssues;  // 0x38(0x1)
	uint8_t  ReturnValue;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// ScriptStruct EnhancedInput.InputActionInstance
// Size: 0x60(Inherited: 0x0) 
struct FInputActionInstance
{
	struct UInputAction* SourceAction;  // 0x0(0x8)
	char pad_8[11];  // 0x8(0xB)
	uint8_t  TriggerEvent;  // 0x13(0x1)
	float LastTriggeredWorldTime;  // 0x14(0x4)
	struct TArray<struct UInputTrigger*> Triggers;  // 0x18(0x10)
	struct TArray<struct UInputModifier*> Modifiers;  // 0x28(0x10)
	char pad_56[32];  // 0x38(0x20)
	float ElapsedProcessedTime;  // 0x58(0x4)
	float ElapsedTriggeredTime;  // 0x5C(0x4)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetMetadata
// Size: 0x8(Inherited: 0x0) 
struct FGetMetadata
{
	struct UObject* ReturnValue;  // 0x0(0x8)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.RemovePlayerMappedKey
// Size: 0x10(Inherited: 0x0) 
struct FRemovePlayerMappedKey
{
	struct FName MappingName;  // 0x0(0x8)
	struct FModifyContextOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function EnhancedInput.EnhancedInputPlatformData.GetContextRedirect
// Size: 0x10(Inherited: 0x0) 
struct FGetContextRedirect
{
	struct UInputMappingContext* InContext;  // 0x0(0x8)
	struct UInputMappingContext* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct EnhancedInput.BlueprintInputDebugKeyDelegateBinding
// Size: 0x30(Inherited: 0x0) 
struct FBlueprintInputDebugKeyDelegateBinding
{
	struct FInputChord InputChord;  // 0x0(0x20)
	char EInputEvent InputKeyEvent;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FName FunctionNameToBind;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bExecuteWhenPaused : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// ScriptStruct EnhancedInput.InputComboStepData
// Size: 0x10(Inherited: 0x0) 
struct FInputComboStepData
{
	struct UInputAction* ComboStepAction;  // 0x0(0x8)
	float TimeToPressKey;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function EnhancedInput.EnhancedInputLibrary.BreakInputActionValue
// Size: 0x40(Inherited: 0x0) 
struct FBreakInputActionValue
{
	struct FInputActionValue InActionValue;  // 0x0(0x20)
	double X;  // 0x20(0x8)
	double Y;  // 0x28(0x8)
	double Z;  // 0x30(0x8)
	uint8_t  Type;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EnhancedInput.EnhancedInputLibrary.RequestRebuildControlMappingsUsingContext
// Size: 0x10(Inherited: 0x0) 
struct FRequestRebuildControlMappingsUsingContext
{
	struct UInputMappingContext* Context;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForceImmediately : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis1D
// Size: 0x28(Inherited: 0x0) 
struct FConv_InputActionValueToAxis1D
{
	struct FInputActionValue InValue;  // 0x0(0x20)
	double ReturnValue;  // 0x20(0x8)

}; 
// Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis2D
// Size: 0x30(Inherited: 0x0) 
struct FConv_InputActionValueToAxis2D
{
	struct FInputActionValue InValue;  // 0x0(0x20)
	struct FVector2D ReturnValue;  // 0x20(0x10)

}; 
// Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis3D
// Size: 0x38(Inherited: 0x0) 
struct FConv_InputActionValueToAxis3D
{
	struct FInputActionValue ActionValue;  // 0x0(0x20)
	struct FVector ReturnValue;  // 0x20(0x18)

}; 
// Function EnhancedInput.InputModifier.ModifyRaw
// Size: 0x50(Inherited: 0x0) 
struct FModifyRaw
{
	struct UEnhancedPlayerInput* PlayerInput;  // 0x0(0x8)
	struct FInputActionValue CurrentValue;  // 0x8(0x20)
	float DeltaTime;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FInputActionValue ReturnValue;  // 0x30(0x20)

}; 
// Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToString
// Size: 0x30(Inherited: 0x0) 
struct FConv_InputActionValueToString
{
	struct FInputActionValue ActionValue;  // 0x0(0x20)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValue
// Size: 0x58(Inherited: 0x0) 
struct FMakeInputActionValue
{
	double X;  // 0x0(0x8)
	double Y;  // 0x8(0x8)
	double Z;  // 0x10(0x8)
	struct FInputActionValue MatchValueType;  // 0x18(0x20)
	struct FInputActionValue ReturnValue;  // 0x38(0x20)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.AddMappingContext
// Size: 0x10(Inherited: 0x0) 
struct FAddMappingContext
{
	struct UInputMappingContext* MappingContext;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	struct FModifyContextOptions Options;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function EnhancedInput.InputTrigger.GetTriggerType
// Size: 0x1(Inherited: 0x0) 
struct FGetTriggerType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.AddPlayerMappableConfig
// Size: 0x10(Inherited: 0x0) 
struct FAddPlayerMappableConfig
{
	struct UPlayerMappableInputConfig* Config;  // 0x0(0x8)
	struct FModifyContextOptions Options;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.GetPlayerMappedKey
// Size: 0x20(Inherited: 0x0) 
struct FGetPlayerMappedKey
{
	struct FName MappingName;  // 0x0(0x8)
	struct FKey ReturnValue;  // 0x8(0x18)

}; 
// Function EnhancedInput.InputTrigger.IsActuated
// Size: 0x28(Inherited: 0x0) 
struct FIsActuated
{
	struct FInputActionValue ForValue;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.HasMappingContext
// Size: 0x10(Inherited: 0x0) 
struct FHasMappingContext
{
	struct UInputMappingContext* MappingContext;  // 0x0(0x8)
	int32_t OutFoundPriority;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputForAction
// Size: 0x48(Inherited: 0x0) 
struct FInjectInputForAction
{
	struct UInputAction* Action;  // 0x0(0x8)
	struct FInputActionValue RawValue;  // 0x8(0x20)
	struct TArray<struct UInputModifier*> Modifiers;  // 0x28(0x10)
	struct TArray<struct UInputTrigger*> Triggers;  // 0x38(0x10)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.RemovePlayerMappableConfig
// Size: 0x10(Inherited: 0x0) 
struct FRemovePlayerMappableConfig
{
	struct UPlayerMappableInputConfig* Config;  // 0x0(0x8)
	struct FModifyContextOptions Options;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputVectorForAction
// Size: 0x40(Inherited: 0x0) 
struct FInjectInputVectorForAction
{
	struct UInputAction* Action;  // 0x0(0x8)
	struct FVector Value;  // 0x8(0x18)
	struct TArray<struct UInputModifier*> Modifiers;  // 0x20(0x10)
	struct TArray<struct UInputTrigger*> Triggers;  // 0x30(0x10)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.QueryKeysMappedToAction
// Size: 0x18(Inherited: 0x0) 
struct FQueryKeysMappedToAction
{
	struct UInputAction* Action;  // 0x0(0x8)
	struct TArray<struct FKey> ReturnValue;  // 0x8(0x10)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveAllPlayerMappedKeys
// Size: 0x1(Inherited: 0x0) 
struct FRemoveAllPlayerMappedKeys
{
	struct FModifyContextOptions Options;  // 0x0(0x1)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveMappingContext
// Size: 0x10(Inherited: 0x0) 
struct FRemoveMappingContext
{
	struct UInputMappingContext* MappingContext;  // 0x0(0x8)
	struct FModifyContextOptions Options;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function EnhancedInput.EnhancedInputSubsystemInterface.RequestRebuildControlMappings
// Size: 0x2(Inherited: 0x0) 
struct FRequestRebuildControlMappings
{
	struct FModifyContextOptions Options;  // 0x0(0x1)
	uint8_t  RebuildType;  // 0x1(0x1)

}; 
// Function EnhancedInput.InputMappingContext.MapKey
// Size: 0xA8(Inherited: 0x0) 
struct FMapKey
{
	struct UInputAction* Action;  // 0x0(0x8)
	struct FKey ToKey;  // 0x8(0x18)
	struct FEnhancedActionKeyMapping ReturnValue;  // 0x20(0x88)

}; 
// Function EnhancedInput.InputMappingContext.UnmapAction
// Size: 0x8(Inherited: 0x0) 
struct FUnmapAction
{
	struct UInputAction* Action;  // 0x0(0x8)

}; 
// Function EnhancedInput.InputMappingContext.UnmapAllKeysFromAction
// Size: 0x8(Inherited: 0x0) 
struct FUnmapAllKeysFromAction
{
	struct UInputAction* Action;  // 0x0(0x8)

}; 
// Function EnhancedInput.InputMappingContext.UnmapKey
// Size: 0x20(Inherited: 0x0) 
struct FUnmapKey
{
	struct UInputAction* Action;  // 0x0(0x8)
	struct FKey Key;  // 0x8(0x18)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetPlayerMappableKeys
// Size: 0x10(Inherited: 0x0) 
struct FGetPlayerMappableKeys
{
	struct TArray<struct FEnhancedActionKeyMapping> ReturnValue;  // 0x0(0x10)

}; 
// Function EnhancedInput.InputModifier.GetVisualizationColor
// Size: 0x50(Inherited: 0x0) 
struct FGetVisualizationColor
{
	struct FInputActionValue SampleValue;  // 0x0(0x20)
	struct FInputActionValue FinalValue;  // 0x20(0x20)
	struct FLinearColor ReturnValue;  // 0x40(0x10)

}; 
// Function EnhancedInput.InputTrigger.UpdateState
// Size: 0x30(Inherited: 0x0) 
struct FUpdateState
{
	struct UEnhancedPlayerInput* PlayerInput;  // 0x0(0x8)
	struct FInputActionValue ModifiedValue;  // 0x8(0x20)
	float DeltaTime;  // 0x28(0x4)
	uint8_t  ReturnValue;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetConfigName
// Size: 0x8(Inherited: 0x0) 
struct FGetConfigName
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetKeysBoundToAction
// Size: 0x18(Inherited: 0x0) 
struct FGetKeysBoundToAction
{
	struct UInputAction* InAction;  // 0x0(0x8)
	struct TArray<struct FEnhancedActionKeyMapping> ReturnValue;  // 0x8(0x10)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetMappingByName
// Size: 0x90(Inherited: 0x0) 
struct FGetMappingByName
{
	struct FName MappingName;  // 0x0(0x8)
	struct FEnhancedActionKeyMapping ReturnValue;  // 0x8(0x88)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.GetMappingContexts
// Size: 0x50(Inherited: 0x0) 
struct FGetMappingContexts
{
	struct TMap<struct UInputMappingContext*, int32_t> ReturnValue;  // 0x0(0x50)

}; 
// Function EnhancedInput.PlayerMappableInputConfig.IsDeprecated
// Size: 0x1(Inherited: 0x0) 
struct FIsDeprecated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
