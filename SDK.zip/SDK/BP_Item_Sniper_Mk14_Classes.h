#pragma once 
#include <BP_Item_Sniper_Mk14_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C
// Size: 0x760(Inherited: 0x750) 
struct ABP_Item_Sniper_Mk14_C : public AItem_Gun_Sniper
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x750(0x8)
	struct UStaticMeshComponent* PicatinnyRail;  // 0x758(0x8)

	void SetSight(); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.ReceiveBeginPlay
	void OnSetGunModules_Event(); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.OnSetGunModules_Event
	void ExecuteUbergraph_BP_Item_Sniper_Mk14(int32_t EntryPoint); // Function BP_Item_Sniper_Mk14.BP_Item_Sniper_Mk14_C.ExecuteUbergraph_BP_Item_Sniper_Mk14
}; 



