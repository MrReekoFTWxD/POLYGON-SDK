#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ControlRigSpline.ControlRigSplineImpl
// Size: 0x58(Inherited: 0x0) 
struct FControlRigSplineImpl
{
	char pad_0[88];  // 0x0(0x58)

}; 
// ScriptStruct ControlRigSpline.RigUnit_TransformFromControlRigSpline
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_TransformFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	struct FVector UpVector;  // 0x20(0x18)
	float Roll;  // 0x38(0x4)
	float U;  // 0x3C(0x4)
	struct FTransform Transform;  // 0x40(0x60)

}; 
// ScriptStruct ControlRigSpline.ControlRigSpline
// Size: 0x18(Inherited: 0x0) 
struct FControlRigSpline
{
	char pad_0[24];  // 0x0(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_SetSplinePoints
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_SetSplinePoints : public FRigUnitMutable
{
	struct TArray<struct FVector> Points;  // 0x40(0x10)
	struct FControlRigSpline Spline;  // 0x50(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_TangentFromControlRigSpline
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_TangentFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float U;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector Tangent;  // 0x28(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitChainToSplineCurve
// Size: 0x210(Inherited: 0x40) 
struct FRigUnit_FitChainToSplineCurve : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct FControlRigSpline Spline;  // 0x50(0x18)
	uint8_t  Alignment;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float Minimum;  // 0x6C(0x4)
	float Maximum;  // 0x70(0x4)
	int32_t SamplingPrecision;  // 0x74(0x4)
	struct FVector PrimaryAxis;  // 0x78(0x18)
	struct FVector SecondaryAxis;  // 0x90(0x18)
	struct FVector PoleVectorPosition;  // 0xA8(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0xC0(0x10)
	uint8_t  RotationEaseType;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float Weight;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bPropagateToChildren : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0xE0(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x170(0x98)
	char pad_520[8];  // 0x208(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ControlRigSplineBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_ControlRigSplineBase : public FRigUnit
{

}; 
// ScriptStruct ControlRigSpline.RigUnit_PositionFromControlRigSpline
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_PositionFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float U;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector position;  // 0x28(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ControlRigSplineFromPoints
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_ControlRigSplineFromPoints : public FRigUnit_ControlRigSplineBase
{
	struct TArray<struct FVector> Points;  // 0x8(0x10)
	uint8_t  SplineMode;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t SamplesPerSegment;  // 0x1C(0x4)
	float Compression;  // 0x20(0x4)
	float Stretch;  // 0x24(0x4)
	struct FControlRigSpline Spline;  // 0x28(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_DrawControlRigSpline
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_DrawControlRigSpline : public FRigUnitMutable
{
	struct FControlRigSpline Spline;  // 0x40(0x18)
	struct FLinearColor Color;  // 0x58(0x10)
	float Thickness;  // 0x68(0x4)
	int32_t Detail;  // 0x6C(0x4)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ParameterAtPercentage
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_ParameterAtPercentage : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float Percentage;  // 0x20(0x4)
	float U;  // 0x24(0x4)

}; 
// ScriptStruct ControlRigSpline.RigUnit_GetLengthControlRigSpline
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_GetLengthControlRigSpline : public FRigUnit
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	float Length;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitChainToSplineCurveItemArray
// Size: 0x210(Inherited: 0x40) 
struct FRigUnit_FitChainToSplineCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	struct FControlRigSpline Spline;  // 0x50(0x18)
	uint8_t  Alignment;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float Minimum;  // 0x6C(0x4)
	float Maximum;  // 0x70(0x4)
	int32_t SamplingPrecision;  // 0x74(0x4)
	struct FVector PrimaryAxis;  // 0x78(0x18)
	struct FVector SecondaryAxis;  // 0x90(0x18)
	struct FVector PoleVectorPosition;  // 0xA8(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0xC0(0x10)
	uint8_t  RotationEaseType;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float Weight;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bPropagateToChildren : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0xE0(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x170(0x98)
	char pad_520[8];  // 0x208(0x8)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitSplineCurveToChain
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_FitSplineCurveToChain : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct FControlRigSpline Spline;  // 0x50(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_FitSplineCurveToChainItemArray
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_FitSplineCurveToChainItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	struct FControlRigSpline Spline;  // 0x50(0x18)

}; 
// ScriptStruct ControlRigSpline.RigUnit_ClosestParameterFromControlRigSpline
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_ClosestParameterFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
	struct FControlRigSpline Spline;  // 0x8(0x18)
	struct FVector position;  // 0x20(0x18)
	float U;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
