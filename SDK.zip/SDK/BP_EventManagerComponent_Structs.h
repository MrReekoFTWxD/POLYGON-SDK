#pragma once 
#include "SDK.h" 
 
 
// Function BP_EventManagerComponent.BP_EventManagerComponent_C.ExecuteUbergraph_BP_EventManagerComponent
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EventManagerComponent
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
