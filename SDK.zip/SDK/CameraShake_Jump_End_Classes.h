#pragma once 
#include <CameraShake_Jump_End_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_Jump_End.CameraShake_Jump_End_C
// Size: 0x210(Inherited: 0x210) 
struct UCameraShake_Jump_End_C : public ULegacyCameraShake
{

}; 



