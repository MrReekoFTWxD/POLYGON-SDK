#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimationWarpingRuntime.FootPlacementInterpolationSettings
// Size: 0x24(Inherited: 0x0) 
struct FFootPlacementInterpolationSettings
{
	float UnplantLinearStiffness;  // 0x0(0x4)
	float UnplantLinearDamping;  // 0x4(0x4)
	float UnplantAngularStiffness;  // 0x8(0x4)
	float UnplantAngularDamping;  // 0xC(0x4)
	float FloorLinearStiffness;  // 0x10(0x4)
	float FloorLinearDamping;  // 0x14(0x4)
	float FloorAngularStiffness;  // 0x18(0x4)
	float FloorAngularDamping;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bEnableFloorInterpolation : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_StrideWarping
// Size: 0x238(Inherited: 0xC8) 
struct FAnimNode_StrideWarping : public FAnimNode_SkeletalControlBase
{
	uint8_t  Mode;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct FVector StrideDirection;  // 0xD0(0x18)
	float StrideScale;  // 0xE8(0x4)
	float LocomotionSpeed;  // 0xEC(0x4)
	float MinRootMotionSpeedThreshold;  // 0xF0(0x4)
	struct FBoneReference PelvisBone;  // 0xF4(0x10)
	struct FBoneReference IKFootRootBone;  // 0x104(0x10)
	char pad_276[4];  // 0x114(0x4)
	struct TArray<struct FStrideWarpingFootDefinition> FootDefinitions;  // 0x118(0x10)
	struct FInputClampConstants StrideScaleModifier;  // 0x128(0x14)
	char pad_316[4];  // 0x13C(0x4)
	struct FWarpingVectorValue FloorNormalDirection;  // 0x140(0x20)
	struct FWarpingVectorValue GravityDirection;  // 0x160(0x20)
	struct FIKFootPelvisPullDownSolver PelvisIKFootSolver;  // 0x180(0x70)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool bOrientStrideDirectionUsingFloorNormal : 1;  // 0x1F0(0x1)
	char pad_497_1 : 7;  // 0x1F1(0x1)
	bool bCompensateIKUsingFKThighRotation : 1;  // 0x1F1(0x1)
	char pad_498_1 : 7;  // 0x1F2(0x1)
	bool bClampIKUsingFKLimits : 1;  // 0x1F2(0x1)
	char pad_499[69];  // 0x1F3(0x45)

}; 
// ScriptStruct AnimationWarpingRuntime.FootPlacementTraceSettings
// Size: 0x1C(Inherited: 0x0) 
struct FFootPlacementTraceSettings
{
	float StartOffset;  // 0x0(0x4)
	float EndOffset;  // 0x4(0x4)
	float SweepRadius;  // 0x8(0x4)
	char ETraceTypeQuery ComplexTraceChannel;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float MaxGroundPenetration;  // 0x10(0x4)
	float SimpleCollisionInfluence;  // 0x14(0x4)
	char ETraceTypeQuery SimpleTraceChannel;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bEnabled : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)

}; 
// ScriptStruct AnimationWarpingRuntime.FootPlacemenLegDefinition
// Size: 0x44(Inherited: 0x0) 
struct FFootPlacemenLegDefinition
{
	struct FBoneReference FKFootBone;  // 0x0(0x10)
	struct FBoneReference IKFootBone;  // 0x10(0x10)
	struct FBoneReference BallBone;  // 0x20(0x10)
	int32_t NumBonesInLimb;  // 0x30(0x4)
	struct FName SpeedCurveName;  // 0x34(0x8)
	struct FName DisableLockCurveName;  // 0x3C(0x8)

}; 
// ScriptStruct AnimationWarpingRuntime.FootPlacementRootDefinition
// Size: 0x20(Inherited: 0x0) 
struct FFootPlacementRootDefinition
{
	struct FBoneReference PelvisBone;  // 0x0(0x10)
	struct FBoneReference IKRootBone;  // 0x10(0x10)

}; 
// ScriptStruct AnimationWarpingRuntime.FootPlacementPlantSettings
// Size: 0x34(Inherited: 0x0) 
struct FFootPlacementPlantSettings
{
	float SpeedThreshold;  // 0x0(0x4)
	float DistanceToGround;  // 0x4(0x4)
	uint8_t  LockType;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float UnplantRadius;  // 0xC(0x4)
	float ReplantRadiusRatio;  // 0x10(0x4)
	float UnplantAngle;  // 0x14(0x4)
	float ReplantAngleRatio;  // 0x18(0x4)
	float MaxExtensionRatio;  // 0x1C(0x4)
	float MinExtensionRatio;  // 0x20(0x4)
	float SeparatingDistance;  // 0x24(0x4)
	float UnalignmentSpeedThreshold;  // 0x28(0x4)
	float AnkleTwistReduction;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bAdjustHeelBeforePlanting : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)

}; 
// ScriptStruct AnimationWarpingRuntime.FootPlacementPelvisSettings
// Size: 0x1C(Inherited: 0x0) 
struct FFootPlacementPelvisSettings
{
	float MaxOffset;  // 0x0(0x4)
	float LinearStiffness;  // 0x4(0x4)
	float LinearDamping;  // 0x8(0x4)
	float HorizontalRebalancingWeight;  // 0xC(0x4)
	float MaxOffsetHorizontal;  // 0x10(0x4)
	float HeelLiftRatio;  // 0x14(0x4)
	uint8_t  PelvisHeightMode;  // 0x18(0x1)
	uint8_t  ActorMovementCompensationMode;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool bEnableInterpolation : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_FootPlacement
// Size: 0x410(Inherited: 0xC8) 
struct FAnimNode_FootPlacement : public FAnimNode_SkeletalControlBase
{
	uint8_t  PlantSpeedMode;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	struct FBoneReference IKFootRootBone;  // 0xCC(0x10)
	struct FBoneReference PelvisBone;  // 0xDC(0x10)
	struct FFootPlacementPelvisSettings PelvisSettings;  // 0xEC(0x1C)
	struct TArray<struct FFootPlacemenLegDefinition> LegDefinitions;  // 0x108(0x10)
	struct FFootPlacementPlantSettings PlantSettings;  // 0x118(0x34)
	struct FFootPlacementInterpolationSettings InterpolationSettings;  // 0x14C(0x24)
	struct FFootPlacementTraceSettings TraceSettings;  // 0x170(0x1C)
	char pad_396[644];  // 0x18C(0x284)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_OffsetRootBone
// Size: 0x190(Inherited: 0xC8) 
struct FAnimNode_OffsetRootBone : public FAnimNode_SkeletalControlBase
{
	char pad_200[200];  // 0xC8(0xC8)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_OrientationWarping
// Size: 0x198(Inherited: 0xC8) 
struct FAnimNode_OrientationWarping : public FAnimNode_SkeletalControlBase
{
	uint8_t  Mode;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float OrientationAngle;  // 0xCC(0x4)
	float LocomotionAngle;  // 0xD0(0x4)
	float MinRootMotionSpeedThreshold;  // 0xD4(0x4)
	float LocomotionAngleDeltaThreshold;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct TArray<struct FBoneReference> SpineBones;  // 0xE0(0x10)
	struct FBoneReference IKFootRootBone;  // 0xF0(0x10)
	struct TArray<struct FBoneReference> IKFootBones;  // 0x100(0x10)
	char EAxis RotationAxis;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float DistributedBoneOrientationAlpha;  // 0x114(0x4)
	float RotationInterpSpeed;  // 0x118(0x4)
	float WarpingAlpha;  // 0x11C(0x4)
	float OffsetAlpha;  // 0x120(0x4)
	float MaxOffsetAngle;  // 0x124(0x4)
	char pad_296[112];  // 0x128(0x70)

}; 
// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootDefinition
// Size: 0x28(Inherited: 0x0) 
struct FSlopeWarpingFootDefinition
{
	struct FBoneReference IKFootBone;  // 0x0(0x10)
	struct FBoneReference FKFootBone;  // 0x10(0x10)
	int32_t NumBonesInLimb;  // 0x20(0x4)
	float FootSize;  // 0x24(0x4)

}; 
// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootData
// Size: 0xB0(Inherited: 0x0) 
struct FSlopeWarpingFootData
{
	char pad_0[176];  // 0x0(0xB0)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_SlopeWarping
// Size: 0x2E0(Inherited: 0xC8) 
struct FAnimNode_SlopeWarping : public FAnimNode_SkeletalControlBase
{
	char pad_200[24];  // 0xC8(0x18)
	struct FBoneReference IKFootRootBone;  // 0xE0(0x10)
	struct FBoneReference PelvisBone;  // 0xF0(0x10)
	struct TArray<struct FSlopeWarpingFootDefinition> FeetDefinitions;  // 0x100(0x10)
	struct TArray<struct FSlopeWarpingFootData> FeetData;  // 0x110(0x10)
	struct FVectorRK4SpringInterpolator PelvisOffsetInterpolator;  // 0x120(0x8)
	char pad_296[88];  // 0x128(0x58)
	struct FVector GravityDir;  // 0x180(0x18)
	struct FVector CustomFloorOffset;  // 0x198(0x18)
	float CachedDeltaTime;  // 0x1B0(0x4)
	char pad_436[4];  // 0x1B4(0x4)
	struct FVector TargetFloorNormalWorldSpace;  // 0x1B8(0x18)
	struct FVectorRK4SpringInterpolator FloorNormalInterpolator;  // 0x1D0(0x8)
	char pad_472[88];  // 0x1D8(0x58)
	struct FVector TargetFloorOffsetLocalSpace;  // 0x230(0x18)
	struct FVectorRK4SpringInterpolator FloorOffsetInterpolator;  // 0x248(0x8)
	char pad_592[88];  // 0x250(0x58)
	float MaxStepHeight;  // 0x2A8(0x4)
	char bKeepMeshInsideOfCapsule : 1;  // 0x2AC(0x1)
	char bPullPelvisDown : 1;  // 0x2AC(0x1)
	char bUseCustomFloorOffset : 1;  // 0x2AC(0x1)
	char bWasOnGround : 1;  // 0x2AC(0x1)
	char bShowDebug : 1;  // 0x2AC(0x1)
	char bFloorSmoothingInitialized : 1;  // 0x2AC(0x1)
	char pad_684_1 : 2;  // 0x2AC(0x1)
	char pad_685[4];  // 0x2AD(0x4)
	struct FVector ActorLocation;  // 0x2B0(0x18)
	struct FVector GravityDirCompSpace;  // 0x2C8(0x18)

}; 
// ScriptStruct AnimationWarpingRuntime.StrideWarpingFootDefinition
// Size: 0x30(Inherited: 0x0) 
struct FStrideWarpingFootDefinition
{
	struct FBoneReference IKFootBone;  // 0x0(0x10)
	struct FBoneReference FKFootBone;  // 0x10(0x10)
	struct FBoneReference ThighBone;  // 0x20(0x10)

}; 
