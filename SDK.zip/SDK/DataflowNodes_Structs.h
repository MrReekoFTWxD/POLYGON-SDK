#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct DataflowNodes.SkeletalMeshBoneDataflowNode
// Size: 0xE8(Inherited: 0xD0) 
struct FSkeletalMeshBoneDataflowNode : public FDataflowNode
{
	struct FName BoneName;  // 0xD0(0x8)
	struct USkeletalMesh* SkeletalMesh;  // 0xD8(0x8)
	int32_t BoneIndexOut;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)

}; 
// ScriptStruct DataflowNodes.GetSkeletalMeshDataflowNode
// Size: 0xE0(Inherited: 0xD0) 
struct FGetSkeletalMeshDataflowNode : public FDataflowNode
{
	struct USkeletalMesh* SkeletalMesh;  // 0xD0(0x8)
	struct FName PropertyName;  // 0xD8(0x8)

}; 
// ScriptStruct DataflowNodes.GetStaticMeshDataflowNode
// Size: 0xE0(Inherited: 0xD0) 
struct FGetStaticMeshDataflowNode : public FDataflowNode
{
	struct UStaticMesh* StaticMesh;  // 0xD0(0x8)
	struct FName PropertyName;  // 0xD8(0x8)

}; 
