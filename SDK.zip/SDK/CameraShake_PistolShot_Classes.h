#pragma once 
#include <CameraShake_PistolShot_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_PistolShot.CameraShake_PistolShot_C
// Size: 0x210(Inherited: 0x210) 
struct UCameraShake_PistolShot_C : public ULegacyCameraShake
{

}; 



