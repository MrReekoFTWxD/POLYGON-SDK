#pragma once 
#include <AnimationBudgetAllocator_Structs.h>
 
 
 
// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
}; 



// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xFB0(Inherited: 0xF80) 
struct USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
	char pad_3968[32];  // 0xF80(0x20)
	char bAutoRegisterWithBudgetAllocator : 1;  // 0xFA0(0x1)
	char bAutoCalculateSignificance : 1;  // 0xFA0(0x1)
	char bShouldUseActorRenderedFlag : 1;  // 0xFA0(0x1)
	char pad_4000_1 : 5;  // 0xFA0(0x1)
	char pad_4001[16];  // 0xFA1(0x10)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
}; 



