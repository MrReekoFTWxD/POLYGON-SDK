#pragma once 
#include <CameraShake_Damage_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_Damage.CameraShake_Damage_C
// Size: 0x210(Inherited: 0x210) 
struct UCameraShake_Damage_C : public ULegacyCameraShake
{

}; 



