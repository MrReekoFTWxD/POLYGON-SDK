#pragma once 
#include <BP_Item_Strap_DefaultStrap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_DefaultStrap.BP_Item_Strap_DefaultStrap_C
// Size: 0x350(Inherited: 0x350) 
struct ABP_Item_Strap_DefaultStrap_C : public AItem_Module_Strap
{

}; 



