#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.ExecuteUbergraph_BP_Item_Accessory_Flashlight_01
// Size: 0x5B(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Accessory_Flashlight_01
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputActionEvent_Key;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool K2Node_Event_bPlaySound : 1;  // 0x22(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x24(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_2;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x27(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_3;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x30(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x38(0x8)
	struct APG_Game_Character* K2Node_DynamicCast_AsPG_Game_Character;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_4;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct AItem_Gun_General* CallFunc_GetCurrentGun_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x5A(0x1)

}; 
// Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.InpActEvt_Flashlight_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Flashlight_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.OnChangeEnableState
// Size: 0x1(Inherited: 0x1) 
struct FOnChangeEnableState : public FOnChangeEnableState
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bPlaySound : 1;  // 0x0(0x1)

}; 
