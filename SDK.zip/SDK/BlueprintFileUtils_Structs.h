#pragma once 
#include "SDK.h" 
 
 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.CopyFile
// Size: 0x28(Inherited: 0x0) 
struct FCopyFile
{
	struct FString DestFilename;  // 0x0(0x10)
	struct FString SrcFilename;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bReplace : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bEvenIfReadOnly : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool ReturnValue : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.DeleteDirectory
// Size: 0x18(Inherited: 0x0) 
struct FDeleteDirectory
{
	struct FString Directory;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bMustExist : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bDeleteRecursively : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool ReturnValue : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.DeleteFile
// Size: 0x18(Inherited: 0x0) 
struct FDeleteFile
{
	struct FString Filename;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bMustExist : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bEvenIfReadOnly : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool ReturnValue : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.DirectoryExists
// Size: 0x18(Inherited: 0x0) 
struct FDirectoryExists
{
	struct FString Directory;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.FileExists
// Size: 0x18(Inherited: 0x0) 
struct FFileExists
{
	struct FString Filename;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.FindFiles
// Size: 0x38(Inherited: 0x0) 
struct FFindFiles
{
	struct FString Directory;  // 0x0(0x10)
	struct TArray<struct FString> FoundFiles;  // 0x10(0x10)
	struct FString FileExtension;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.MakeDirectory
// Size: 0x18(Inherited: 0x0) 
struct FMakeDirectory
{
	struct FString Path;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bCreateTree : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.FindRecursive
// Size: 0x38(Inherited: 0x0) 
struct FFindRecursive
{
	struct FString StartDirectory;  // 0x0(0x10)
	struct TArray<struct FString> FoundPaths;  // 0x10(0x10)
	struct FString Wildcard;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bFindFiles : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bFindDirectories : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool ReturnValue : 1;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.GetUserDirectory
// Size: 0x10(Inherited: 0x0) 
struct FGetUserDirectory
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.MoveFile
// Size: 0x28(Inherited: 0x0) 
struct FMoveFile
{
	struct FString DestFilename;  // 0x0(0x10)
	struct FString SrcFilename;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bReplace : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bEvenIfReadOnly : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool ReturnValue : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
