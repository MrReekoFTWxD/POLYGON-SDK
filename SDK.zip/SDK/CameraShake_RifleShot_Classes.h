#pragma once 
#include <CameraShake_RifleShot_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_RifleShot.CameraShake_RifleShot_C
// Size: 0x210(Inherited: 0x210) 
struct UCameraShake_RifleShot_C : public ULegacyCameraShake
{

}; 



