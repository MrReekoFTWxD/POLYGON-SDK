#pragma once 
#include <AudioAnalyzer_Structs.h>
 
 
 
// Class AudioAnalyzer.AudioAnalyzerAssetBase
// Size: 0x28(Inherited: 0x28) 
struct UAudioAnalyzerAssetBase : public UObject
{

}; 



// Class AudioAnalyzer.AudioAnalyzerSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UAudioAnalyzerSubsystem : public UEngineSubsystem
{
	struct TArray<struct UAudioAnalyzer*> AudioAnalyzers;  // 0x30(0x10)
	char pad_64[16];  // 0x40(0x10)

}; 



// Class AudioAnalyzer.AudioAnalyzerSettings
// Size: 0x28(Inherited: 0x28) 
struct UAudioAnalyzerSettings : public UAudioAnalyzerAssetBase
{

}; 



// Class AudioAnalyzer.AudioAnalyzer
// Size: 0x90(Inherited: 0x28) 
struct UAudioAnalyzer : public UObject
{
	struct UAudioBus* AudioBus;  // 0x28(0x8)
	char pad_48[8];  // 0x30(0x8)
	struct UAudioAnalyzerSubsystem* AudioAnalyzerSubsystem;  // 0x38(0x8)
	char pad_64[80];  // 0x40(0x50)

	void StopAnalyzing(struct UObject* WorldContextObject); // Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing
	void StartAnalyzing(struct UObject* WorldContextObject, struct UAudioBus* AudioBusToAnalyze); // Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing
}; 



// Class AudioAnalyzer.AudioAnalyzerNRTSettings
// Size: 0x28(Inherited: 0x28) 
struct UAudioAnalyzerNRTSettings : public UAudioAnalyzerAssetBase
{

}; 



// Class AudioAnalyzer.AudioAnalyzerNRT
// Size: 0x78(Inherited: 0x28) 
struct UAudioAnalyzerNRT : public UAudioAnalyzerAssetBase
{
	struct USoundWave* Sound;  // 0x28(0x8)
	float DurationInSeconds;  // 0x30(0x4)
	char pad_52[68];  // 0x34(0x44)

}; 



