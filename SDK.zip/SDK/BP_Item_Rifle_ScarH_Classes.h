#pragma once 
#include <BP_Item_Rifle_ScarH_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Rifle_ScarH.BP_Item_Rifle_ScarH_C
// Size: 0x770(Inherited: 0x750) 
struct ABP_Item_Rifle_ScarH_C : public AItem_Gun_Rifle
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x750(0x8)
	struct UStaticMeshComponent* Aim_A_Base;  // 0x758(0x8)
	struct UStaticMeshComponent* Aim_B;  // 0x760(0x8)
	struct UStaticMeshComponent* Aim_A;  // 0x768(0x8)

	void SetSight(); // Function BP_Item_Rifle_ScarH.BP_Item_Rifle_ScarH_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Rifle_ScarH.BP_Item_Rifle_ScarH_C.ReceiveBeginPlay
	void OnSetGunModules_Event(); // Function BP_Item_Rifle_ScarH.BP_Item_Rifle_ScarH_C.OnSetGunModules_Event
	void ExecuteUbergraph_BP_Item_Rifle_ScarH(int32_t EntryPoint); // Function BP_Item_Rifle_ScarH.BP_Item_Rifle_ScarH_C.ExecuteUbergraph_BP_Item_Rifle_ScarH
}; 



