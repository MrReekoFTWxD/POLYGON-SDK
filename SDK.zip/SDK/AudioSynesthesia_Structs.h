#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction AudioSynesthesia.OnLatestOverallLoudnessResults__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnLatestOverallLoudnessResults__DelegateSignature
{
	struct FLoudnessResults LatestOverallLoudnessResults;  // 0x0(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnPerChannelMeterResults__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnPerChannelMeterResults__DelegateSignature
{
	int32_t ChannelIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FMeterResults> MeterResults;  // 0x8(0x10)

}; 
// ScriptStruct AudioSynesthesia.MeterResults
// Size: 0x14(Inherited: 0x0) 
struct FMeterResults
{
	float TimeSeconds;  // 0x0(0x4)
	float MeterValue;  // 0x4(0x4)
	float PeakValue;  // 0x8(0x4)
	int32_t NumSamplesClipping;  // 0xC(0x4)
	float ClippingValue;  // 0x10(0x4)

}; 
// ScriptStruct AudioSynesthesia.LoudnessResults
// Size: 0x10(Inherited: 0x0) 
struct FLoudnessResults
{
	float Loudness;  // 0x0(0x4)
	float NormalizedLoudness;  // 0x4(0x4)
	float PerceptualEnergy;  // 0x8(0x4)
	float TimeSeconds;  // 0xC(0x4)

}; 
// ScriptStruct AudioSynesthesia.SynesthesiaSpectrumResults
// Size: 0x18(Inherited: 0x0) 
struct FSynesthesiaSpectrumResults
{
	float TimeSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<float> SpectrumValues;  // 0x8(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnLatestOverallMeterResults__DelegateSignature
// Size: 0x14(Inherited: 0x0) 
struct FOnLatestOverallMeterResults__DelegateSignature
{
	struct FMeterResults LatestOverallMeterResults;  // 0x0(0x14)

}; 
// DelegateFunction AudioSynesthesia.OnLatestPerChannelMeterResults__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnLatestPerChannelMeterResults__DelegateSignature
{
	int32_t ChannelIndex;  // 0x0(0x4)
	struct FMeterResults LatestMeterResults;  // 0x4(0x14)

}; 
// Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime
// Size: 0x18(Inherited: 0x0) 
struct FGetChannelConstantQAtTime
{
	float InSeconds;  // 0x0(0x4)
	int32_t InChannel;  // 0x4(0x4)
	struct TArray<float> OutConstantQ;  // 0x8(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnLatestPerChannelLoudnessResults__DelegateSignature
// Size: 0x14(Inherited: 0x0) 
struct FOnLatestPerChannelLoudnessResults__DelegateSignature
{
	int32_t ChannelIndex;  // 0x0(0x4)
	struct FLoudnessResults LatestLoudnessResults;  // 0x4(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnLatestSpectrumResults__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLatestSpectrumResults__DelegateSignature
{
	int32_t ChannelIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSynesthesiaSpectrumResults LatestSpectrumResults;  // 0x8(0x18)

}; 
// DelegateFunction AudioSynesthesia.OnOverallLoudnessResults__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnOverallLoudnessResults__DelegateSignature
{
	struct TArray<struct FLoudnessResults> OverallLoudnessResults;  // 0x0(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnOverallMeterResults__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnOverallMeterResults__DelegateSignature
{
	struct TArray<struct FMeterResults> MeterResults;  // 0x0(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnPerChannelLoudnessResults__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnPerChannelLoudnessResults__DelegateSignature
{
	int32_t ChannelIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FLoudnessResults> LoudnessResults;  // 0x8(0x10)

}; 
// Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime
// Size: 0x18(Inherited: 0x0) 
struct FGetNormalizedChannelConstantQAtTime
{
	float InSeconds;  // 0x0(0x4)
	int32_t InChannel;  // 0x4(0x4)
	struct TArray<float> OutConstantQ;  // 0x8(0x10)

}; 
// DelegateFunction AudioSynesthesia.OnSpectrumResults__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnSpectrumResults__DelegateSignature
{
	int32_t ChannelIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FSynesthesiaSpectrumResults> SpectrumResults;  // 0x8(0x10)

}; 
// Function AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetCenterFrequencies
// Size: 0x18(Inherited: 0x0) 
struct FGetCenterFrequencies
{
	float InSampleRate;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<float> OutCenterFrequencies;  // 0x8(0x10)

}; 
// Function AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetNumCenterFrequencies
// Size: 0x4(Inherited: 0x0) 
struct FGetNumCenterFrequencies
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime
// Size: 0xC(Inherited: 0x0) 
struct FGetChannelLoudnessAtTime
{
	float InSeconds;  // 0x0(0x4)
	int32_t InChannel;  // 0x4(0x4)
	float OutLoudness;  // 0x8(0x4)

}; 
// Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime
// Size: 0x8(Inherited: 0x0) 
struct FGetLoudnessAtTime
{
	float InSeconds;  // 0x0(0x4)
	float OutLoudness;  // 0x4(0x4)

}; 
// Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime
// Size: 0xC(Inherited: 0x0) 
struct FGetNormalizedChannelLoudnessAtTime
{
	float InSeconds;  // 0x0(0x4)
	int32_t InChannel;  // 0x4(0x4)
	float OutLoudness;  // 0x8(0x4)

}; 
// Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime
// Size: 0x8(Inherited: 0x0) 
struct FGetNormalizedLoudnessAtTime
{
	float InSeconds;  // 0x0(0x4)
	float OutLoudness;  // 0x4(0x4)

}; 
// Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes
// Size: 0x30(Inherited: 0x0) 
struct FGetChannelOnsetsBetweenTimes
{
	float InStartSeconds;  // 0x0(0x4)
	float InEndSeconds;  // 0x4(0x4)
	int32_t InChannel;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<float> OutOnsetTimestamps;  // 0x10(0x10)
	struct TArray<float> OutOnsetStrengths;  // 0x20(0x10)

}; 
// Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes
// Size: 0x30(Inherited: 0x0) 
struct FGetNormalizedChannelOnsetsBetweenTimes
{
	float InStartSeconds;  // 0x0(0x4)
	float InEndSeconds;  // 0x4(0x4)
	int32_t InChannel;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<float> OutOnsetTimestamps;  // 0x10(0x10)
	struct TArray<float> OutOnsetStrengths;  // 0x20(0x10)

}; 
