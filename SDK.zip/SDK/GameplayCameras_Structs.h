#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct GameplayCameras.VOscillator
// Size: 0x24(Inherited: 0x0) 
struct FVOscillator
{
	struct FFOscillator X;  // 0x0(0xC)
	struct FFOscillator Y;  // 0xC(0xC)
	struct FFOscillator Z;  // 0x18(0xC)

}; 
// ScriptStruct GameplayCameras.FOscillator
// Size: 0xC(Inherited: 0x0) 
struct FFOscillator
{
	float Amplitude;  // 0x0(0x4)
	float Frequency;  // 0x4(0x4)
	char EInitialOscillatorOffset InitialOffset;  // 0x8(0x1)
	uint8_t  Waveform;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// ScriptStruct GameplayCameras.PerlinNoiseShaker
// Size: 0x8(Inherited: 0x0) 
struct FPerlinNoiseShaker
{
	float Amplitude;  // 0x0(0x4)
	float Frequency;  // 0x4(0x4)

}; 
// ScriptStruct GameplayCameras.ROscillator
// Size: 0x24(Inherited: 0x0) 
struct FROscillator
{
	struct FFOscillator Pitch;  // 0x0(0xC)
	struct FFOscillator Yaw;  // 0xC(0xC)
	struct FFOscillator Roll;  // 0x18(0xC)

}; 
// ScriptStruct GameplayCameras.CameraAnimationParams
// Size: 0x40(Inherited: 0x0) 
struct FCameraAnimationParams
{
	float PlayRate;  // 0x0(0x4)
	float Scale;  // 0x4(0x4)
	uint8_t  EaseInType;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float EaseInDuration;  // 0xC(0x4)
	uint8_t  EaseOutType;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float EaseOutDuration;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bLoop : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bRandomStartTime : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	float DurationOverride;  // 0x1C(0x4)
	uint8_t  PlaySpace;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FRotator UserPlaySpaceRot;  // 0x28(0x18)

}; 
// ScriptStruct GameplayCameras.CameraAnimationHandle
// Size: 0x4(Inherited: 0x0) 
struct FCameraAnimationHandle
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct GameplayCameras.ActiveCameraAnimationInfo
// Size: 0x70(Inherited: 0x0) 
struct FActiveCameraAnimationInfo
{
	struct UCameraAnimationSequence* Sequence;  // 0x0(0x8)
	struct FCameraAnimationParams Params;  // 0x8(0x40)
	struct FCameraAnimationHandle Handle;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct UCameraAnimationSequencePlayer* Player;  // 0x50(0x8)
	struct UCameraAnimationSequenceCameraStandIn* CameraStandIn;  // 0x58(0x8)
	float EaseInCurrentTime;  // 0x60(0x4)
	float EaseOutCurrentTime;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bIsEasingIn : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool bIsEasingOut : 1;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)

}; 
// ScriptStruct GameplayCameras.WaveOscillator
// Size: 0xC(Inherited: 0x0) 
struct FWaveOscillator
{
	float Amplitude;  // 0x0(0x4)
	float Frequency;  // 0x4(0x4)
	uint8_t  InitialOffsetType;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function GameplayCameras.LegacyCameraShake.BlueprintUpdateCameraShake
// Size: 0xF90(Inherited: 0x0) 
struct FBlueprintUpdateCameraShake
{
	float DeltaTime;  // 0x0(0x4)
	float Alpha;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)
	struct FMinimalViewInfo POV;  // 0x10(0x7C0)
	struct FMinimalViewInfo ModifiedPOV;  // 0x7D0(0x7C0)

}; 
// Function GameplayCameras.LegacyCameraShake.ReceiveIsFinished
// Size: 0x1(Inherited: 0x0) 
struct FReceiveIsFinished
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GameplayCameras.LegacyCameraShake.ReceivePlayShake
// Size: 0x4(Inherited: 0x0) 
struct FReceivePlayShake
{
	float Scale;  // 0x0(0x4)

}; 
// Function GameplayCameras.GameplayCamerasSubsystem.StopCameraAnimation
// Size: 0x10(Inherited: 0x0) 
struct FStopCameraAnimation
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FCameraAnimationHandle Handle;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bImmediate : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function GameplayCameras.LegacyCameraShake.ReceiveStopShake
// Size: 0x1(Inherited: 0x0) 
struct FReceiveStopShake
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bImmediately : 1;  // 0x0(0x1)

}; 
// Function GameplayCameras.LegacyCameraShake.StartLegacyCameraShake
// Size: 0x38(Inherited: 0x0) 
struct FStartLegacyCameraShake
{
	struct APlayerCameraManager* PlayerCameraManager;  // 0x0(0x8)
	ULegacyCameraShake* ShakeClass;  // 0x8(0x8)
	float Scale;  // 0x10(0x4)
	uint8_t  PlaySpace;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRotator UserPlaySpaceRot;  // 0x18(0x18)
	struct ULegacyCameraShake* ReturnValue;  // 0x30(0x8)

}; 
// Function GameplayCameras.LegacyCameraShake.StartLegacyCameraShakeFromSource
// Size: 0x40(Inherited: 0x0) 
struct FStartLegacyCameraShakeFromSource
{
	struct APlayerCameraManager* PlayerCameraManager;  // 0x0(0x8)
	ULegacyCameraShake* ShakeClass;  // 0x8(0x8)
	struct UCameraShakeSourceComponent* SourceComponent;  // 0x10(0x8)
	float Scale;  // 0x18(0x4)
	uint8_t  PlaySpace;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FRotator UserPlaySpaceRot;  // 0x20(0x18)
	struct ULegacyCameraShake* ReturnValue;  // 0x38(0x8)

}; 
// Function GameplayCameras.LegacyCameraShakeFunctionLibrary.Conv_LegacyCameraShake
// Size: 0x10(Inherited: 0x0) 
struct FConv_LegacyCameraShake
{
	struct UCameraShakeBase* CameraShake;  // 0x0(0x8)
	struct ULegacyCameraShake* ReturnValue;  // 0x8(0x8)

}; 
// Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifier
// Size: 0x18(Inherited: 0x0) 
struct FGetCameraAnimationCameraModifier
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t PlayerIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UCameraAnimationCameraModifier* ReturnValue;  // 0x10(0x8)

}; 
// Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifierFromID
// Size: 0x18(Inherited: 0x0) 
struct FGetCameraAnimationCameraModifierFromID
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t ControllerId;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UCameraAnimationCameraModifier* ReturnValue;  // 0x10(0x8)

}; 
// Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraAnimationCameraModifier
// Size: 0x10(Inherited: 0x0) 
struct FConv_CameraAnimationCameraModifier
{
	struct APlayerCameraManager* PlayerCameraManager;  // 0x0(0x8)
	struct UCameraAnimationCameraModifier* ReturnValue;  // 0x8(0x8)

}; 
// Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifierFromPlayerController
// Size: 0x10(Inherited: 0x0) 
struct FGetCameraAnimationCameraModifierFromPlayerController
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct UCameraAnimationCameraModifier* ReturnValue;  // 0x8(0x8)

}; 
// Function GameplayCameras.GameplayCamerasSubsystem.IsCameraAnimationActive
// Size: 0x10(Inherited: 0x0) 
struct FIsCameraAnimationActive
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FCameraAnimationHandle Handle;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function GameplayCameras.GameplayCamerasSubsystem.PlayCameraAnimation
// Size: 0x58(Inherited: 0x0) 
struct FPlayCameraAnimation
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct UCameraAnimationSequence* Sequence;  // 0x8(0x8)
	struct FCameraAnimationParams Params;  // 0x10(0x40)
	struct FCameraAnimationHandle ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// Function GameplayCameras.GameplayCamerasSubsystem.StopAllCameraAnimations
// Size: 0x10(Inherited: 0x0) 
struct FStopAllCameraAnimations
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bImmediate : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraShakePlaySpace
// Size: 0x2(Inherited: 0x0) 
struct FConv_CameraShakePlaySpace
{
	uint8_t  CameraAnimationPlaySpace;  // 0x0(0x1)
	uint8_t  ReturnValue;  // 0x1(0x1)

}; 
// Function GameplayCameras.GameplayCamerasSubsystem.StopAllCameraAnimationsOf
// Size: 0x18(Inherited: 0x0) 
struct FStopAllCameraAnimationsOf
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct UCameraAnimationSequence* Sequence;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bImmediate : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraAnimationPlaySpace
// Size: 0x2(Inherited: 0x0) 
struct FConv_CameraAnimationPlaySpace
{
	uint8_t  CameraShakePlaySpace;  // 0x0(0x1)
	uint8_t  ReturnValue;  // 0x1(0x1)

}; 
