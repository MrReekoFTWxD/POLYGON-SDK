#pragma once 
#include <BPFL_General_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_General.BPFL_General_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_General_C : public UBlueprintFunctionLibrary
{

	void GetRareColor(uint8_t  Rare, struct UObject* __WorldContext, struct FLinearColor& NewParam); // Function BPFL_General.BPFL_General_C.GetRareColor
	void GetDefaultModuleClassByType(uint8_t  ModuleType, struct UObject* __WorldContext, AItem_Module_General*& DefaultModuleClass); // Function BPFL_General.BPFL_General_C.GetDefaultModuleClassByType
	struct FVector GetActorRelativeLocation(struct AActor* ParentActor, struct AActor* ChildActor, struct UObject* __WorldContext); // Function BPFL_General.BPFL_General_C.GetActorRelativeLocation
	void GetGameInstance(struct UObject* __WorldContext, struct UBP_PG_GameInstance_C*& MyGameIntance); // Function BPFL_General.BPFL_General_C.GetGameInstance
	void GetGameModeBP_Game(struct UObject* __WorldContext, struct ABP_PG_GameMode_Game_C*& MyGameMode); // Function BPFL_General.BPFL_General_C.GetGameModeBP_Game
	void GetGameStateBP(struct UObject* __WorldContext, struct ABP_PG_GameState_Game_C*& MyGameState); // Function BPFL_General.BPFL_General_C.GetGameStateBP
}; 



