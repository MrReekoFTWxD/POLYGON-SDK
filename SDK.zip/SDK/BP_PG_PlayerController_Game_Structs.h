#pragma once 
#include "SDK.h" 
 
 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_HideInterface_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_HideInterface_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.Reset
// Size: 0x4(Inherited: 0x0) 
struct FReset
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x3(0x1)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_ChatAll_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ChatAll_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ToggleVisibilityInterface
// Size: 0xA9(Inherited: 0x0) 
struct FToggleVisibilityInterface
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ForceVisible : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool L_Visible : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x7(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable_7;  // 0xB(0x1)
	uint8_t  Temp_byte_Variable_8;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x34(0x4)
	uint8_t  Temp_byte_Variable_9;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TArray<struct UUI_TeamBaseMarker_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x40(0x10)
	struct UUI_TeamBaseMarker_C* CallFunc_Array_Get_Item;  // 0x50(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	uint8_t  K2Node_Select_Default;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5D(0x1)
	uint8_t  Temp_byte_Variable_10;  // 0x5E(0x1)
	char pad_95[1];  // 0x5F(0x1)
	struct TArray<struct UUI_ControlPointMarker_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_2;  // 0x60(0x10)
	struct UUI_ControlPointMarker_C* CallFunc_Array_Get_Item_2;  // 0x70(0x8)
	uint8_t  K2Node_Select_Default_2;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x80(0x1)
	uint8_t  K2Node_Select_Default_3;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x82(0x1)
	uint8_t  K2Node_Select_Default_4;  // 0x83(0x1)
	uint8_t  K2Node_Select_Default_5;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x85(0x1)
	char pad_134_1 : 7;  // 0x86(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x86(0x1)
	char pad_135[1];  // 0x87(0x1)
	struct TArray<struct UUI_PlayerMarker_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_3;  // 0x88(0x10)
	struct UUI_PlayerMarker_C* CallFunc_Array_Get_Item_3;  // 0x98(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA5(0x1)
	char pad_166_1 : 7;  // 0xA6(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0xA6(0x1)
	char pad_167_1 : 7;  // 0xA7(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xA7(0x1)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xA8(0x1)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.DisplayMessageToChatEvent
// Size: 0x20(Inherited: 0x20) 
struct FDisplayMessageToChatEvent : public FDisplayMessageToChatEvent
{
	struct FGameChatMessage Message;  // 0x0(0x20)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_MiddleMouseButton_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_MiddleMouseButton_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ExecuteUbergraph_BP_PG_PlayerController_Game
// Size: 0x258(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PG_PlayerController_Game
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x8(0x18)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x20(0x18)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	struct FKey Temp_struct_Variable;  // 0x40(0x18)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0x60(0x18)
	struct UUI_GeneralGameScreen_C* CallFunc_Create_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct TArray<struct FScoreInfoBlueprint> K2Node_CustomEvent_ScoreInfos;  // 0x88(0x10)
	struct APG_PlayerState_Game* K2Node_DynamicCast_AsPG_Player_State_Game;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FScoreInfoBlueprint CallFunc_Array_Get_Item;  // 0xA8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xBD(0x1)
	char pad_190_1 : 7;  // 0xBE(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xBE(0x1)
	char pad_191_1 : 7;  // 0xBF(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xBF(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC0(0x10)
	int32_t Temp_int_Variable;  // 0xD0(0x4)
	int32_t Temp_int_Variable_2;  // 0xD4(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationForward_ReturnValue;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool Temp_bool_Variable : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xE4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0xF4(0x10)
	char pad_260[4];  // 0x104(0x4)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0x108(0x18)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x128(0x18)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x141(0x1)
	char pad_322[6];  // 0x142(0x6)
	struct UUI_InteractionTime_C* CallFunc_Create_ReturnValue_2;  // 0x148(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x150(0x10)
	struct FGameChatMessage K2Node_Event_message;  // 0x160(0x20)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x180(0x10)
	float K2Node_Event_interactionTime;  // 0x190(0x4)
	char pad_404_1 : 7;  // 0x194(0x1)
	bool CallFunc_WithEditor_ReturnValue : 1;  // 0x194(0x1)
	char pad_405_1 : 7;  // 0x195(0x1)
	bool CallFunc_HasUserFocus_ReturnValue : 1;  // 0x195(0x1)
	char pad_406_1 : 7;  // 0x196(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x196(0x1)
	char pad_407_1 : 7;  // 0x197(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x197(0x1)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x198(0x18)
	struct APawn* K2Node_CustomEvent_OldPawn;  // 0x1B0(0x8)
	struct APawn* K2Node_CustomEvent_NewPawn;  // 0x1B8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x1C0(0x8)
	struct ABP_PG_Game_Character_C* K2Node_DynamicCast_AsBP_PG_Game_Character;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1D0(0x1)
	char pad_465_1 : 7;  // 0x1D1(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x1D1(0x1)
	char pad_466_1 : 7;  // 0x1D2(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x1D2(0x1)
	char pad_467[5];  // 0x1D3(0x5)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x1D8(0x18)
	struct FKey K2Node_InputActionEvent_Key;  // 0x1F0(0x18)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x210(0x8)
	struct ABP_PG_Game_Character_C* K2Node_DynamicCast_AsBP_PG_Game_Character_2;  // 0x218(0x8)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x220(0x1)
	char pad_545[3];  // 0x221(0x3)
	int32_t K2Node_Select_Default;  // 0x224(0x4)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x228(0x1)
	char pad_553_1 : 7;  // 0x229(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x229(0x1)
	char pad_554[6];  // 0x22A(0x6)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_3;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x238(0x1)
	char pad_569[3];  // 0x239(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x23C(0x10)
	char pad_588[4];  // 0x24C(0x4)
	double CallFunc_SetDoublePropertyByName_Value_ImplicitCast;  // 0x250(0x8)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OnAddedGameScore_Event
// Size: 0x10(Inherited: 0x0) 
struct FOnAddedGameScore_Event
{
	struct TArray<struct FScoreInfoBlueprint> ScoreInfos;  // 0x0(0x10)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_ChatTeam_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ChatTeam_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_N_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_N_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Escape_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Escape_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Scoreboard_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Scoreboard_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Scoreboard_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Scoreboard_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OnPossessedPawnChanged_Event
// Size: 0x10(Inherited: 0x0) 
struct FOnPossessedPawnChanged_Event
{
	struct APawn* OldPawn;  // 0x0(0x8)
	struct APawn* NewPawn;  // 0x8(0x8)

}; 
// Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.StartInteractionEvent
// Size: 0x4(Inherited: 0x4) 
struct FStartInteractionEvent : public FStartInteractionEvent
{
	float interactionTime;  // 0x0(0x4)

}; 
