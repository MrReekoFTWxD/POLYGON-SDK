#pragma once 
#include <BP_PG_GameMode_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_GameMode_Game.BP_PG_GameMode_Game_C
// Size: 0x3E0(Inherited: 0x3D8) 
struct ABP_PG_GameMode_Game_C : public APG_GameMode_Game
{
	struct USceneComponent* DefaultSceneRoot;  // 0x3D8(0x8)

}; 



