#pragma once 
#include <DefaultKeySeparator_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultKeySeparator.DefaultKeySeparator_C
// Size: 0x278(Inherited: 0x278) 
struct UDefaultKeySeparator_C : public UUserWidget
{

}; 



