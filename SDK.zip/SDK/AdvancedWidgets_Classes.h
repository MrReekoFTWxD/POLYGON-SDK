#pragma once 
#include <AdvancedWidgets_Structs.h>
 
 
 
// Class AdvancedWidgets.RadialSlider
// Size: 0x7E0(Inherited: 0x150) 
struct URadialSlider : public UWidget
{
	float Value;  // 0x150(0x4)
	struct FDelegate ValueDelegate;  // 0x154(0x10)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool bUseCustomDefaultValue : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	float CustomDefaultValue;  // 0x168(0x4)
	char pad_364[4];  // 0x16C(0x4)
	struct FRuntimeFloatCurve SliderRange;  // 0x170(0x88)
	struct TArray<float> ValueTags;  // 0x1F8(0x10)
	float SliderHandleStartAngle;  // 0x208(0x4)
	float SliderHandleEndAngle;  // 0x20C(0x4)
	float AngularOffset;  // 0x210(0x4)
	char pad_532[4];  // 0x214(0x4)
	struct FVector2D HandStartEndRatio;  // 0x218(0x10)
	char pad_552[8];  // 0x228(0x8)
	struct FSliderStyle WidgetStyle;  // 0x230(0x500)
	struct FLinearColor SliderBarColor;  // 0x730(0x10)
	struct FLinearColor SliderProgressColor;  // 0x740(0x10)
	struct FLinearColor SliderHandleColor;  // 0x750(0x10)
	struct FLinearColor CenterBackgroundColor;  // 0x760(0x10)
	char pad_1904_1 : 7;  // 0x770(0x1)
	bool Locked : 1;  // 0x770(0x1)
	char pad_1905_1 : 7;  // 0x771(0x1)
	bool MouseUsesStep : 1;  // 0x771(0x1)
	char pad_1906_1 : 7;  // 0x772(0x1)
	bool RequiresControllerLock : 1;  // 0x772(0x1)
	char pad_1907[1];  // 0x773(0x1)
	float StepSize;  // 0x774(0x4)
	char pad_1912_1 : 7;  // 0x778(0x1)
	bool IsFocusable : 1;  // 0x778(0x1)
	char pad_1913_1 : 7;  // 0x779(0x1)
	bool UseVerticalDrag : 1;  // 0x779(0x1)
	char pad_1914_1 : 7;  // 0x77A(0x1)
	bool ShowSliderHandle : 1;  // 0x77A(0x1)
	char pad_1915_1 : 7;  // 0x77B(0x1)
	bool ShowSliderHand : 1;  // 0x77B(0x1)
	char pad_1916[4];  // 0x77C(0x4)
	struct FMulticastInlineDelegate OnMouseCaptureBegin;  // 0x780(0x10)
	struct FMulticastInlineDelegate OnMouseCaptureEnd;  // 0x790(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureBegin;  // 0x7A0(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureEnd;  // 0x7B0(0x10)
	struct FMulticastInlineDelegate OnValueChanged;  // 0x7C0(0x10)
	char pad_2000[16];  // 0x7D0(0x10)

	void SetValueTags(struct TArray<float>& InValueTags); // Function AdvancedWidgets.RadialSlider.SetValueTags
	void SetValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetValue
	void SetUseVerticalDrag(bool InUseVerticalDrag); // Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag
	void SetStepSize(float InValue); // Function AdvancedWidgets.RadialSlider.SetStepSize
	void SetSliderRange(struct FRuntimeFloatCurve& InSliderRange); // Function AdvancedWidgets.RadialSlider.SetSliderRange
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderProgressColor
	void SetSliderHandleStartAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle
	void SetSliderHandleEndAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle
	void SetSliderHandleColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleColor
	void SetSliderBarColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderBarColor
	void SetShowSliderHandle(bool InShowSliderHandle); // Function AdvancedWidgets.RadialSlider.SetShowSliderHandle
	void SetShowSliderHand(bool InShowSliderHand); // Function AdvancedWidgets.RadialSlider.SetShowSliderHand
	void SetLocked(bool InValue); // Function AdvancedWidgets.RadialSlider.SetLocked
	void SetHandStartEndRatio(struct FVector2D InValue); // Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio
	void SetCustomDefaultValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor
	void SetAngularOffset(float InValue); // Function AdvancedWidgets.RadialSlider.SetAngularOffset
	float GetValue(); // Function AdvancedWidgets.RadialSlider.GetValue
	float GetNormalizedSliderHandlePosition(); // Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition
	float GetCustomDefaultValue(); // Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue
}; 



