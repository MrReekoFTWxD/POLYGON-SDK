#pragma once 
#include <BP_Item_Optic_DefaultOptic_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Optic_DefaultOptic.BP_Item_Optic_DefaultOptic_C
// Size: 0x388(Inherited: 0x388) 
struct ABP_Item_Optic_DefaultOptic_C : public AItem_Module_Optic
{

}; 



