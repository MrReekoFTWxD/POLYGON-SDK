#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct EyeTracker.EyeTrackerStereoGazeData
// Size: 0x80(Inherited: 0x0) 
struct FEyeTrackerStereoGazeData
{
	struct FVector LeftEyeOrigin;  // 0x0(0x18)
	struct FVector LeftEyeDirection;  // 0x18(0x18)
	struct FVector RightEyeOrigin;  // 0x30(0x18)
	struct FVector RightEyeDirection;  // 0x48(0x18)
	struct FVector FixationPoint;  // 0x60(0x18)
	float ConfidenceValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)

}; 
// ScriptStruct EyeTracker.EyeTrackerGazeData
// Size: 0x50(Inherited: 0x0) 
struct FEyeTrackerGazeData
{
	struct FVector GazeOrigin;  // 0x0(0x18)
	struct FVector GazeDirection;  // 0x18(0x18)
	struct FVector FixationPoint;  // 0x30(0x18)
	float ConfidenceValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// Function EyeTracker.EyeTrackerFunctionLibrary.GetGazeData
// Size: 0x58(Inherited: 0x0) 
struct FGetGazeData
{
	struct FEyeTrackerGazeData OutGazeData;  // 0x0(0x50)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EyeTracker.EyeTrackerFunctionLibrary.GetStereoGazeData
// Size: 0x88(Inherited: 0x0) 
struct FGetStereoGazeData
{
	struct FEyeTrackerStereoGazeData OutGazeData;  // 0x0(0x80)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function EyeTracker.EyeTrackerFunctionLibrary.IsEyeTrackerConnected
// Size: 0x1(Inherited: 0x0) 
struct FIsEyeTrackerConnected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function EyeTracker.EyeTrackerFunctionLibrary.SetEyeTrackedPlayer
// Size: 0x8(Inherited: 0x0) 
struct FSetEyeTrackedPlayer
{
	struct APlayerController* PlayerController;  // 0x0(0x8)

}; 
// Function EyeTracker.EyeTrackerFunctionLibrary.IsStereoGazeDataAvailable
// Size: 0x1(Inherited: 0x0) 
struct FIsStereoGazeDataAvailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
