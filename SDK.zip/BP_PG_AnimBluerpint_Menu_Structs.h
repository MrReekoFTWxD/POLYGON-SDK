#pragma once 
#include "SDK.h" 
 
 
// Function BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.ExecuteUbergraph_BP_PG_AnimBluerpint_Menu
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PG_AnimBluerpint_Menu
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// ScriptStruct BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.AnimBlueprintGeneratedConstantData
// Size: 0x118(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_26;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool __BoolProperty_27 : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float __FloatProperty_28;  // 0x10(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_29;  // 0x14(0x2C)
	float __FloatProperty_30;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UAnimSequenceBase* __AnimSequenceBase_31;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool __BoolProperty_32 : 1;  // 0x50(0x1)
	uint8_t  __EnumProperty_33;  // 0x51(0x1)
	char EAnimGroupRole __ByteProperty_34;  // 0x52(0x1)
	char pad_83[1];  // 0x53(0x1)
	struct FName __NameProperty_35;  // 0x54(0x8)
	char pad_92[4];  // 0x5C(0x4)
	struct FAnimNodeFunctionRef __StructProperty_36;  // 0x60(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x80(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x100(0x18)

}; 
