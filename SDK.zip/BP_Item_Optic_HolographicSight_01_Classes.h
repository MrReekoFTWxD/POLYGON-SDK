#pragma once 
#include <BP_Item_Optic_HolographicSight_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Optic_HolographicSight_01.BP_Item_Optic_HolographicSight_01_C
// Size: 0x310(Inherited: 0x310) 
struct ABP_Item_Optic_HolographicSight_01_C : public AItem_Module_Optic
{

}; 



