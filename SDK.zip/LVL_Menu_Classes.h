#pragma once 
#include <LVL_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass LVL_Menu.LVL_Menu_C
// Size: 0x288(Inherited: 0x280) 
struct ALVL_Menu_C : public ALevelScriptActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)

	void ReceiveBeginPlay(); // Function LVL_Menu.LVL_Menu_C.ReceiveBeginPlay
	void ExecuteUbergraph_LVL_Menu(int32_t EntryPoint); // Function LVL_Menu.LVL_Menu_C.ExecuteUbergraph_LVL_Menu
}; 



