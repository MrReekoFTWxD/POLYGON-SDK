#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct DataContainer.DataContainerObjectWrapper
// Size: 0x8(Inherited: 0x0) 
struct FDataContainerObjectWrapper
{
	struct UDataContainerObject* DataObject;  // 0x0(0x8)

}; 
// Function DataContainer.DataContainerObject.ConstructDataObject
// Size: 0x10(Inherited: 0x0) 
struct FConstructDataObject
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UDataContainerObject* ReturnValue;  // 0x8(0x8)

}; 
