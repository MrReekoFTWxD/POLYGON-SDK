#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C.ExecuteUbergraph_BP_Item_Rifle_AK47
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Rifle_AK47
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)

}; 
// Function BP_Item_Rifle_AK47.BP_Item_Rifle_AK47_C.SetSight
// Size: 0x3D(Inherited: 0x0) 
struct FSetSight
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AItem_Module_General* CallFunc_Array_Get_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AItem_Module_Optic* K2Node_DynamicCast_AsItem_Module_Optic;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43[1];  // 0x2B(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3C(0x1)

}; 
