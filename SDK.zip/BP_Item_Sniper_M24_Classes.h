#pragma once 
#include <BP_Item_Sniper_M24_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Sniper_M24.BP_Item_Sniper_M24_C
// Size: 0x590(Inherited: 0x590) 
struct ABP_Item_Sniper_M24_C : public AItem_Weapon_Sniper
{

	void UserConstructionScript(); // Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.UserConstructionScript
}; 



