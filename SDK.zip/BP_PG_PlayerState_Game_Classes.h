#pragma once 
#include <BP_PG_PlayerState_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_PlayerState_Game.BP_PG_PlayerState_Game_C
// Size: 0x438(Inherited: 0x430) 
struct ABP_PG_PlayerState_Game_C : public APG_PlayerState_Game
{
	struct USceneComponent* DefaultSceneRoot;  // 0x430(0x8)

}; 



