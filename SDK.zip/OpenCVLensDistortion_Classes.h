#pragma once 
#include <OpenCVLensDistortion_Structs.h>
 
 
 
// Class OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UOpenCVLensDistortionBlueprintLibrary : public UBlueprintFunctionLibrary
{

	bool NotEqual_CompareLensDistortionModels(struct FOpenCVLensDistortionParameters& A, struct FOpenCVLensDistortionParameters& B); // Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.NotEqual_CompareLensDistortionModels
	bool EqualEqual_CompareLensDistortionModels(struct FOpenCVLensDistortionParameters& A, struct FOpenCVLensDistortionParameters& B); // Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.EqualEqual_CompareLensDistortionModels
	void DrawDisplacementMapToRenderTarget(struct UObject* WorldContextObject, struct UTextureRenderTarget2D* OutputRenderTarget, struct UTexture2D* PreComputedUndistortDisplacementMap); // Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.DrawDisplacementMapToRenderTarget
	struct UTexture2D* CreateUndistortUVDisplacementMap(struct FOpenCVLensDistortionParameters& LensParameters, struct FIntPoint& ImageSize, float CroppingFactor, struct FOpenCVCameraViewInfo& CameraViewInfo); // Function OpenCVLensDistortion.OpenCVLensDistortionBlueprintLibrary.CreateUndistortUVDisplacementMap
}; 



