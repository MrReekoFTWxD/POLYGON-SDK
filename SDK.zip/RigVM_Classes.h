#pragma once 
#include <RigVM_Structs.h>
 
 
 
// Class RigVM.RigVM
// Size: 0x2C0(Inherited: 0x28) 
struct URigVM : public UObject
{
	struct URigVMMemoryStorage* WorkMemoryStorageObject;  // 0x28(0x8)
	struct URigVMMemoryStorage* LiteralMemoryStorageObject;  // 0x30(0x8)
	struct URigVMMemoryStorage* DebugMemoryStorageObject;  // 0x38(0x8)
	char pad_64[32];  // 0x40(0x20)
	struct FRigVMByteCode ByteCodeStorage;  // 0x60(0x30)
	char pad_144[8];  // 0x90(0x8)
	struct FRigVMInstructionArray Instructions;  // 0x98(0x10)
	char pad_168[8];  // 0xA8(0x8)
	struct FRigVMExecuteContext Context;  // 0xB0(0xC0)
	uint32_t NumExecutions;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	struct TArray<struct FName> FunctionNamesStorage;  // 0x178(0x10)
	char pad_392[32];  // 0x188(0x20)
	struct TArray<struct FRigVMParameter> Parameters;  // 0x1A8(0x10)
	struct TMap<struct FName, int32_t> ParametersNameMap;  // 0x1B8(0x50)
	char pad_520[152];  // 0x208(0x98)
	struct URigVM* DeferredVMToCopy;  // 0x2A0(0x8)
	char pad_680[24];  // 0x2A8(0x18)

	void SetParameterValueVector2D(struct FName& InParameterName, struct FVector2D& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueVector2D
	void SetParameterValueVector(struct FName& InParameterName, struct FVector& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueVector
	void SetParameterValueTransform(struct FName& InParameterName, struct FTransform& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueTransform
	void SetParameterValueString(struct FName& InParameterName, struct FString InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueString
	void SetParameterValueQuat(struct FName& InParameterName, struct FQuat& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueQuat
	void SetParameterValueName(struct FName& InParameterName, struct FName& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueName
	void SetParameterValueInt(struct FName& InParameterName, int32_t InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueInt
	void SetParameterValueFloat(struct FName& InParameterName, float InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueFloat
	void SetParameterValueDouble(struct FName& InParameterName, double InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueDouble
	void SetParameterValueBool(struct FName& InParameterName, bool InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueBool
	struct FRigVMStatistics GetStatistics(); // Function RigVM.RigVM.GetStatistics
	struct FString GetRigVMFunctionName(int32_t InFunctionIndex); // Function RigVM.RigVM.GetRigVMFunctionName
	struct FVector2D GetParameterValueVector2D(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueVector2D
	struct FVector GetParameterValueVector(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueVector
	struct FTransform GetParameterValueTransform(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueTransform
	struct FString GetParameterValueString(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueString
	struct FQuat GetParameterValueQuat(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueQuat
	struct FName GetParameterValueName(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueName
	int32_t GetParameterValueInt(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueInt
	float GetParameterValueFloat(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueFloat
	double GetParameterValueDouble(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueDouble
	bool GetParameterValueBool(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueBool
	bool Execute(struct FName& InEntryName); // Function RigVM.RigVM.Execute
	int32_t AddRigVMFunction(struct UScriptStruct* InRigVMStruct, struct FName& InMethodName); // Function RigVM.RigVM.AddRigVMFunction
}; 



// Class RigVM.RigVMMemoryStorageGeneratorClass
// Size: 0x268(Inherited: 0x230) 
struct URigVMMemoryStorageGeneratorClass : public UClass
{
	char pad_560[56];  // 0x230(0x38)

}; 



// Class RigVM.RigVMMemoryStorage
// Size: 0x28(Inherited: 0x28) 
struct URigVMMemoryStorage : public UObject
{

}; 



