#pragma once 
#include <DefaultComboBoxSetting_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultComboBoxSetting.DefaultComboBoxSetting_C
// Size: 0x308(Inherited: 0x308) 
struct UDefaultComboBoxSetting_C : public UComboBoxSetting
{

}; 



