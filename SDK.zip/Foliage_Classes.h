#pragma once 
#include <Foliage_Structs.h>
 
 
 
// Class Foliage.FoliageType
// Size: 0x4B8(Inherited: 0x28) 
struct UFoliageType : public UObject
{
	struct FGuid UpdateGuid;  // 0x28(0x10)
	float Density;  // 0x38(0x4)
	float DensityAdjustmentFactor;  // 0x3C(0x4)
	float Radius;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bSingleInstanceModeOverrideRadius : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float SingleInstanceModeRadius;  // 0x48(0x4)
	uint8_t  Scaling;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FFloatInterval ScaleX;  // 0x50(0x8)
	struct FFloatInterval ScaleY;  // 0x58(0x8)
	struct FFloatInterval ScaleZ;  // 0x60(0x8)
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[4];  // 0x68(0x30)
	char FoliageVertexColorMask VertexColorMask;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float VertexColorMaskThreshold;  // 0x9C(0x4)
	char VertexColorMaskInvert : 1;  // 0xA0(0x1)
	char pad_160_1 : 7;  // 0xA0(0x1)
	char pad_161[4];  // 0xA1(0x4)
	struct FFloatInterval ZOffset;  // 0xA4(0x8)
	char AlignToNormal : 1;  // 0xAC(0x1)
	char AverageNormal : 1;  // 0xAC(0x1)
	char AverageNormalSingleComponent : 1;  // 0xAC(0x1)
	char pad_172_1 : 5;  // 0xAC(0x1)
	char pad_173[4];  // 0xAD(0x4)
	float AlignMaxAngle;  // 0xB0(0x4)
	char RandomYaw : 1;  // 0xB4(0x1)
	char pad_180_1 : 7;  // 0xB4(0x1)
	char pad_181[4];  // 0xB5(0x4)
	float RandomPitchAngle;  // 0xB8(0x4)
	struct FFloatInterval GroundSlopeAngle;  // 0xBC(0x8)
	struct FFloatInterval Height;  // 0xC4(0x8)
	char pad_204[4];  // 0xCC(0x4)
	struct TArray<struct FName> LandscapeLayers;  // 0xD0(0x10)
	float MinimumLayerWeight;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct TArray<struct FName> ExclusionLandscapeLayers;  // 0xE8(0x10)
	float MinimumExclusionLayerWeight;  // 0xF8(0x4)
	struct FName LandscapeLayer;  // 0xFC(0x8)
	char CollisionWithWorld : 1;  // 0x104(0x1)
	char pad_260_1 : 7;  // 0x104(0x1)
	char pad_261[4];  // 0x105(0x4)
	struct FVector CollisionScale;  // 0x108(0x18)
	int32_t AverageNormalSampleCount;  // 0x120(0x4)
	char pad_292[4];  // 0x124(0x4)
	struct FBoxSphereBounds MeshBounds;  // 0x128(0x38)
	struct FVector LowBoundOriginRadius;  // 0x160(0x18)
	char EComponentMobility Mobility;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	struct FInt32Interval CullDistance;  // 0x17C(0x8)
	char bEnableStaticLighting : 1;  // 0x184(0x1)
	char CastShadow : 1;  // 0x184(0x1)
	char bAffectDynamicIndirectLighting : 1;  // 0x184(0x1)
	char bAffectDistanceFieldLighting : 1;  // 0x184(0x1)
	char bCastDynamicShadow : 1;  // 0x184(0x1)
	char bCastStaticShadow : 1;  // 0x184(0x1)
	char pad_388_1 : 2;  // 0x184(0x1)
	char pad_389[4];  // 0x185(0x4)
	char bCastContactShadow : 1;  // 0x188(0x1)
	char pad_392_1 : 7;  // 0x188(0x1)
	char pad_393[4];  // 0x189(0x4)
	char bCastShadowAsTwoSided : 1;  // 0x18C(0x1)
	char bReceivesDecals : 1;  // 0x18C(0x1)
	char bOverrideLightMapRes : 1;  // 0x18C(0x1)
	char pad_396_1 : 5;  // 0x18C(0x1)
	char pad_397[4];  // 0x18D(0x4)
	int32_t OverriddenLightMapRes;  // 0x190(0x4)
	uint8_t  LightmapType;  // 0x194(0x1)
	char pad_405[3];  // 0x195(0x3)
	char bUseAsOccluder : 1;  // 0x198(0x1)
	char pad_408_1 : 7;  // 0x198(0x1)
	char pad_409[4];  // 0x199(0x4)
	char bVisibleInRayTracing : 1;  // 0x19C(0x1)
	char bEvaluateWorldPositionOffset : 1;  // 0x19C(0x1)
	char pad_412_1 : 6;  // 0x19C(0x1)
	char pad_413[4];  // 0x19D(0x4)
	struct FBodyInstance BodyInstance;  // 0x1A0(0x190)
	char EHasCustomNavigableGeometry CustomNavigableGeometry;  // 0x330(0x1)
	struct FLightingChannels LightingChannels;  // 0x331(0x1)
	char pad_818[2];  // 0x332(0x2)
	char bRenderCustomDepth : 1;  // 0x334(0x1)
	char pad_820_1 : 7;  // 0x334(0x1)
	char pad_821[4];  // 0x335(0x4)
	uint8_t  CustomDepthStencilWriteMask;  // 0x338(0x1)
	char pad_825[3];  // 0x339(0x3)
	int32_t CustomDepthStencilValue;  // 0x33C(0x4)
	int32_t TranslucencySortPriority;  // 0x340(0x4)
	float CollisionRadius;  // 0x344(0x4)
	float ShadeRadius;  // 0x348(0x4)
	int32_t NumSteps;  // 0x34C(0x4)
	float InitialSeedDensity;  // 0x350(0x4)
	float AverageSpreadDistance;  // 0x354(0x4)
	float SpreadVariance;  // 0x358(0x4)
	int32_t SeedsPerStep;  // 0x35C(0x4)
	int32_t DistributionSeed;  // 0x360(0x4)
	float MaxInitialSeedOffset;  // 0x364(0x4)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool bCanGrowInShade : 1;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool bSpawnsInShade : 1;  // 0x369(0x1)
	char pad_874[2];  // 0x36A(0x2)
	float MaxInitialAge;  // 0x36C(0x4)
	float MaxAge;  // 0x370(0x4)
	float OverlapPriority;  // 0x374(0x4)
	struct FFloatInterval ProceduralScale;  // 0x378(0x8)
	struct FRuntimeFloatCurve ScaleCurve;  // 0x380(0x88)
	struct FFoliageDensityFalloff DensityFalloff;  // 0x408(0x90)
	int32_t ChangeCount;  // 0x498(0x4)
	char ReapplyDensity : 1;  // 0x49C(0x1)
	char ReapplyRadius : 1;  // 0x49C(0x1)
	char ReapplyAlignToNormal : 1;  // 0x49C(0x1)
	char ReapplyRandomYaw : 1;  // 0x49C(0x1)
	char ReapplyScaling : 1;  // 0x49C(0x1)
	char ReapplyScaleX : 1;  // 0x49C(0x1)
	char ReapplyScaleY : 1;  // 0x49C(0x1)
	char ReapplyScaleZ : 1;  // 0x49C(0x1)
	char ReapplyRandomPitchAngle : 1;  // 0x49D(0x1)
	char ReapplyGroundSlope : 1;  // 0x49D(0x1)
	char ReapplyHeight : 1;  // 0x49D(0x1)
	char ReapplyLandscapeLayers : 1;  // 0x49D(0x1)
	char ReapplyZOffset : 1;  // 0x49D(0x1)
	char ReapplyCollisionWithWorld : 1;  // 0x49D(0x1)
	char ReapplyVertexColorMask : 1;  // 0x49D(0x1)
	char bEnableDensityScaling : 1;  // 0x49D(0x1)
	char bEnableDiscardOnLoad : 1;  // 0x49E(0x1)
	char pad_1182_1 : 7;  // 0x49E(0x1)
	char pad_1183[2];  // 0x49F(0x2)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures;  // 0x4A0(0x10)
	int32_t VirtualTextureCullMips;  // 0x4B0(0x4)
	uint8_t  VirtualTextureRenderPassType;  // 0x4B4(0x1)
	char pad_1205[3];  // 0x4B5(0x3)

}; 



// Class Foliage.FoliageType_Actor
// Size: 0x4D0(Inherited: 0x4B8) 
struct UFoliageType_Actor : public UFoliageType
{
	AActor* ActorClass;  // 0x4B8(0x8)
	char pad_1216_1 : 7;  // 0x4C0(0x1)
	bool bShouldAttachToBaseComponent : 1;  // 0x4C0(0x1)
	char pad_1217_1 : 7;  // 0x4C1(0x1)
	bool bStaticMeshOnly : 1;  // 0x4C1(0x1)
	char pad_1218[6];  // 0x4C2(0x6)
	UFoliageInstancedStaticMeshComponent* StaticMeshOnlyComponentClass;  // 0x4C8(0x8)

}; 



// Class Foliage.FoliageStatistics
// Size: 0x28(Inherited: 0x28) 
struct UFoliageStatistics : public UBlueprintFunctionLibrary
{

	int32_t FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
	void FoliageOverlappingBoxTransforms(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box, struct TArray<struct FTransform>& OutTransforms); // Function Foliage.FoliageStatistics.FoliageOverlappingBoxTransforms
	int32_t FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box); // Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
}; 



// Class Foliage.FoliageInstancedStaticMeshComponent
// Size: 0x8D0(Inherited: 0x8A0) 
struct UFoliageInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
	struct FMulticastInlineDelegate OnInstanceTakePointDamage;  // 0x898(0x10)
	struct FMulticastInlineDelegate OnInstanceTakeRadialDamage;  // 0x8A8(0x10)
	char pad_2240_1 : 7;  // 0x8C0(0x1)
	bool bEnableDiscardOnLoad : 1;  // 0x8B8(0x1)
	struct FGuid GenerationGuid;  // 0x8BC(0x10)

}; 



// Class Foliage.FoliageType_InstancedStaticMesh
// Size: 0x4D8(Inherited: 0x4B8) 
struct UFoliageType_InstancedStaticMesh : public UFoliageType
{
	struct UStaticMesh* Mesh;  // 0x4B8(0x8)
	struct TArray<struct UMaterialInterface*> OverrideMaterials;  // 0x4C0(0x10)
	UFoliageInstancedStaticMeshComponent* ComponentClass;  // 0x4D0(0x8)

}; 



// Class Foliage.InstancedFoliageActor
// Size: 0x2D8(Inherited: 0x288) 
struct AInstancedFoliageActor : public AISMPartitionActor
{
	char pad_648[80];  // 0x288(0x50)

}; 



// Class Foliage.InteractiveFoliageActor
// Size: 0x318(Inherited: 0x288) 
struct AInteractiveFoliageActor : public AStaticMeshActor
{
	struct UCapsuleComponent* CapsuleComponent;  // 0x288(0x8)
	struct FVector TouchingActorEntryPosition;  // 0x290(0x18)
	struct FVector FoliageVelocity;  // 0x2A8(0x18)
	struct FVector FoliageForce;  // 0x2C0(0x18)
	struct FVector FoliagePosition;  // 0x2D8(0x18)
	float FoliageDamageImpulseScale;  // 0x2F0(0x4)
	float FoliageTouchImpulseScale;  // 0x2F4(0x4)
	float FoliageStiffness;  // 0x2F8(0x4)
	float FoliageStiffnessQuadratic;  // 0x2FC(0x4)
	float FoliageDamping;  // 0x300(0x4)
	float MaxDamageImpulse;  // 0x304(0x4)
	float MaxTouchImpulse;  // 0x308(0x4)
	float MaxForce;  // 0x30C(0x4)
	float Mass;  // 0x310(0x4)
	char pad_788[4];  // 0x314(0x4)

	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo); // Function Foliage.InteractiveFoliageActor.CapsuleTouched
}; 



// Class Foliage.InteractiveFoliageComponent
// Size: 0x5E0(Inherited: 0x5D0) 
struct UInteractiveFoliageComponent : public UStaticMeshComponent
{
	char pad_1488[16];  // 0x5D0(0x10)

}; 



// Class Foliage.ProceduralFoliageBlockingVolume
// Size: 0x348(Inherited: 0x2B0) 
struct AProceduralFoliageBlockingVolume : public AVolume
{
	struct AProceduralFoliageVolume* ProceduralFoliageVolume;  // 0x2B0(0x8)
	struct FFoliageDensityFalloff DensityFalloff;  // 0x2B8(0x90)

}; 



// Class Foliage.ProceduralFoliageComponent
// Size: 0xD8(Inherited: 0xB0) 
struct UProceduralFoliageComponent : public UActorComponent
{
	struct UProceduralFoliageSpawner* FoliageSpawner;  // 0xB0(0x8)
	float TileOverlap;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct AVolume* SpawningVolume;  // 0xC0(0x8)
	struct FGuid ProceduralGuid;  // 0xC8(0x10)

}; 



// Class Foliage.ProceduralFoliageSpawner
// Size: 0x68(Inherited: 0x28) 
struct UProceduralFoliageSpawner : public UObject
{
	int32_t RandomSeed;  // 0x28(0x4)
	float TileSize;  // 0x2C(0x4)
	int32_t NumUniqueTiles;  // 0x30(0x4)
	float MinimumQuadTreeSize;  // 0x34(0x4)
	char pad_56[8];  // 0x38(0x8)
	struct TArray<struct FFoliageTypeObject> FoliageTypes;  // 0x40(0x10)
	char pad_80[24];  // 0x50(0x18)

	void Simulate(int32_t NumSteps); // Function Foliage.ProceduralFoliageSpawner.Simulate
}; 



// Class Foliage.ProceduralFoliageTile
// Size: 0x170(Inherited: 0x28) 
struct UProceduralFoliageTile : public UObject
{
	struct UProceduralFoliageSpawner* FoliageSpawner;  // 0x28(0x8)
	char pad_48[160];  // 0x30(0xA0)
	struct TArray<struct FProceduralFoliageInstance> InstancesArray;  // 0xD0(0x10)
	char pad_224[144];  // 0xE0(0x90)

}; 



// Class Foliage.ProceduralFoliageVolume
// Size: 0x2B8(Inherited: 0x2B0) 
struct AProceduralFoliageVolume : public AVolume
{
	struct UProceduralFoliageComponent* ProceduralComponent;  // 0x2B0(0x8)

}; 



