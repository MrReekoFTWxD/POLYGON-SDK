#pragma once 
#include <Party_Structs.h>
 
 
 
// Class Party.SocialParty
// Size: 0x350(Inherited: 0x28) 
struct USocialParty : public UObject
{
	char pad_40[56];  // 0x28(0x38)
	APartyBeaconClient* ReservationBeaconClientClass;  // 0x60(0x8)
	ASpectatorBeaconClient* SpectatorBeaconClientClass;  // 0x68(0x8)
	char pad_112[16];  // 0x70(0x10)
	struct FUniqueNetIdRepl OwningLocalUserId;  // 0x80(0x30)
	struct FUniqueNetIdRepl CurrentLeaderId;  // 0xB0(0x30)
	struct TMap<struct FUniqueNetIdRepl, struct UPartyMember*> PartyMembersById;  // 0xE0(0x50)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnableAutomaticPartyRejoin : 1;  // 0x130(0x1)
	char pad_305[87];  // 0x131(0x57)
	double PlatformUserInviteCooldown;  // 0x188(0x8)
	double PrimaryUserInviteCooldown;  // 0x190(0x8)
	char pad_408[120];  // 0x198(0x78)
	struct APartyBeaconClient* ReservationBeaconClient;  // 0x210(0x8)
	char pad_536[8];  // 0x218(0x8)
	struct ASpectatorBeaconClient* SpectatorBeaconClient;  // 0x220(0x8)
	char pad_552[296];  // 0x228(0x128)

}; 



// Class Party.Chatroom
// Size: 0x58(Inherited: 0x28) 
struct UChatroom : public UObject
{
	struct FString CurrentChatRoomId;  // 0x28(0x10)
	int32_t MaxChatRoomRetries;  // 0x38(0x4)
	int32_t NumChatRoomRetries;  // 0x3C(0x4)
	char pad_64[24];  // 0x40(0x18)

}; 



// Class Party.SocialManager
// Size: 0x1A8(Inherited: 0x28) 
struct USocialManager : public UObject
{
	char pad_40[40];  // 0x28(0x28)
	struct TArray<struct USocialToolkit*> SocialToolkits;  // 0x50(0x10)
	struct USocialDebugTools* SocialDebugTools;  // 0x60(0x8)
	char pad_104[320];  // 0x68(0x140)

}; 



// Class Party.PartyMember
// Size: 0xF8(Inherited: 0x28) 
struct UPartyMember : public UObject
{
	char pad_40[72];  // 0x28(0x48)
	struct USocialUser* SocialUser;  // 0x70(0x8)
	char pad_120[128];  // 0x78(0x80)

}; 



// Class Party.SocialToolkit
// Size: 0x2A8(Inherited: 0x28) 
struct USocialToolkit : public UObject
{
	char pad_40[64];  // 0x28(0x40)
	struct USocialUser* LocalUser;  // 0x68(0x8)
	struct TArray<struct USocialUser*> AllUsers;  // 0x70(0x10)
	char pad_128[80];  // 0x80(0x50)
	struct ULocalPlayer* LocalPlayerOwner;  // 0xD0(0x8)
	struct USocialChatManager* SocialChatManager;  // 0xD8(0x8)
	char pad_224[456];  // 0xE0(0x1C8)

}; 



// Class Party.SocialChatChannel
// Size: 0xE8(Inherited: 0x28) 
struct USocialChatChannel : public UObject
{
	char pad_40[192];  // 0x28(0xC0)

}; 



// Class Party.SocialChatManager
// Size: 0x220(Inherited: 0x28) 
struct USocialChatManager : public UObject
{
	char pad_40[80];  // 0x28(0x50)
	struct TMap<struct TWeakObjectPtr<USocialUser>, struct USocialPrivateMessageChannel*> DirectChannelsByTargetUser;  // 0x78(0x50)
	struct TMap<struct FString, struct USocialChatRoom*> ChatRoomsById;  // 0xC8(0x50)
	struct TMap<struct FString, struct USocialReadOnlyChatChannel*> ReadOnlyChannelsByDisplayName;  // 0x118(0x50)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool bEnableChatSlashCommands : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct TMap<struct FUniqueNetIdRepl, struct USocialGroupChannel*> GroupChannels;  // 0x170(0x50)
	char pad_448[96];  // 0x1C0(0x60)

}; 



// Class Party.SocialChatRoom
// Size: 0xF8(Inherited: 0xE8) 
struct USocialChatRoom : public USocialChatChannel
{
	char pad_232[16];  // 0xE8(0x10)

}; 



// Class Party.SocialDebugTools
// Size: 0x88(Inherited: 0x28) 
struct USocialDebugTools : public UObject
{
	char pad_40[96];  // 0x28(0x60)

}; 



// Class Party.SocialGroupChannel
// Size: 0x98(Inherited: 0x28) 
struct USocialGroupChannel : public UObject
{
	struct USocialUser* SocialUser;  // 0x28(0x8)
	struct FUniqueNetIdRepl GroupID;  // 0x30(0x30)
	struct FText DisplayName;  // 0x60(0x18)
	struct TArray<struct USocialUser*> Members;  // 0x78(0x10)
	char pad_136[16];  // 0x88(0x10)

}; 



// Class Party.SocialPartyChatRoom
// Size: 0xF8(Inherited: 0xF8) 
struct USocialPartyChatRoom : public USocialChatRoom
{

}; 



// Class Party.SocialPrivateMessageChannel
// Size: 0xF0(Inherited: 0xE8) 
struct USocialPrivateMessageChannel : public USocialChatChannel
{
	struct USocialUser* TargetUser;  // 0xE8(0x8)

}; 



// Class Party.SocialReadOnlyChatChannel
// Size: 0xE8(Inherited: 0xE8) 
struct USocialReadOnlyChatChannel : public USocialChatChannel
{

}; 



// Class Party.SocialSettings
// Size: 0x60(Inherited: 0x28) 
struct USocialSettings : public UObject
{
	struct TArray<struct FName> OssNamesWithEnvironmentIdPrefix;  // 0x28(0x10)
	int32_t DefaultMaxPartySize;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bPreferPlatformInvites : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool bMustSendPrimaryInvites : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool bLeavePartyOnDisconnect : 1;  // 0x3E(0x1)
	char pad_63_1 : 7;  // 0x3F(0x1)
	bool bSetDesiredPrivacyOnLocalPlayerBecomesLeader : 1;  // 0x3F(0x1)
	float UserListAutoUpdateRate;  // 0x40(0x4)
	int32_t MinNicknameLength;  // 0x44(0x4)
	int32_t MaxNicknameLength;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FSocialPlatformDescription> SocialPlatformDescriptions;  // 0x50(0x10)

}; 



// Class Party.SocialUser
// Size: 0x1C0(Inherited: 0x28) 
struct USocialUser : public UObject
{
	char pad_40[408];  // 0x28(0x198)

}; 



