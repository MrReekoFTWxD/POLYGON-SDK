#pragma once 
#include "SDK.h" 
 
 
// Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetIntArrayParameter
{
	struct FName InName;  // 0x0(0x8)
	struct TArray<int32_t> InValue;  // 0x8(0x10)

}; 
// ScriptStruct AudioExtensions.AudioParameter
// Size: 0xA0(Inherited: 0x0) 
struct FAudioParameter
{
	struct FName ParamName;  // 0x0(0x8)
	float FloatParam;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool BoolParam : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t IntParam;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UObject* ObjectParam;  // 0x18(0x8)
	struct FString StringParam;  // 0x20(0x10)
	struct TArray<float> ArrayFloatParam;  // 0x30(0x10)
	struct TArray<bool> ArrayBoolParam;  // 0x40(0x10)
	struct TArray<int32_t> ArrayIntParam;  // 0x50(0x10)
	struct TArray<struct UObject*> ArrayObjectParam;  // 0x60(0x10)
	struct TArray<struct FString> ArrayStringParam;  // 0x70(0x10)
	uint8_t  ParamType;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FName TypeName;  // 0x84(0x8)
	char pad_140[20];  // 0x8C(0x14)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetBoolArrayParameter
{
	struct FName InName;  // 0x0(0x8)
	struct TArray<bool> InValue;  // 0x8(0x10)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter
// Size: 0xC(Inherited: 0x0) 
struct FSetIntParameter
{
	struct FName InName;  // 0x0(0x8)
	int32_t inInt;  // 0x8(0x4)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetFloatArrayParameter
{
	struct FName InName;  // 0x0(0x8)
	struct TArray<float> InValue;  // 0x8(0x10)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetStringArrayParameter
{
	struct FName InName;  // 0x0(0x8)
	struct TArray<struct FString> InValue;  // 0x8(0x10)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter
// Size: 0xC(Inherited: 0x0) 
struct FSetFloatParameter
{
	struct FName InName;  // 0x0(0x8)
	float InFloat;  // 0x8(0x4)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter
// Size: 0xC(Inherited: 0x0) 
struct FSetBoolParameter
{
	struct FName InName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool InBool : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetObjectArrayParameter
{
	struct FName InName;  // 0x0(0x8)
	struct TArray<struct UObject*> InValue;  // 0x8(0x10)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter
// Size: 0x10(Inherited: 0x0) 
struct FSetObjectParameter
{
	struct FName InName;  // 0x0(0x8)
	struct UObject* InValue;  // 0x8(0x8)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint
// Size: 0x10(Inherited: 0x0) 
struct FSetParameters_Blueprint
{
	struct TArray<struct FAudioParameter> InParameters;  // 0x0(0x10)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetStringParameter
{
	struct FName InName;  // 0x0(0x8)
	struct FString InValue;  // 0x8(0x10)

}; 
// Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter
// Size: 0x8(Inherited: 0x0) 
struct FSetTriggerParameter
{
	struct FName InName;  // 0x0(0x8)

}; 
