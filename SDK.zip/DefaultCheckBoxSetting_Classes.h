#pragma once 
#include <DefaultCheckBoxSetting_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultCheckBoxSetting.DefaultCheckBoxSetting_C
// Size: 0x2E8(Inherited: 0x2E8) 
struct UDefaultCheckBoxSetting_C : public UCheckBoxSetting
{

}; 



