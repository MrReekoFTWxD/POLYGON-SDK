#pragma once 
#include <BP_Item_Pistol_Glock17_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Pistol_Glock17.BP_Item_Pistol_Glock17_C
// Size: 0x590(Inherited: 0x590) 
struct ABP_Item_Pistol_Glock17_C : public AItem_Weapon_Pistol
{

}; 



