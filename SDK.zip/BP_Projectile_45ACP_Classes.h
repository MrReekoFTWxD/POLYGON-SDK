#pragma once 
#include <BP_Projectile_45ACP_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Projectile_45ACP.BP_Projectile_45ACP_C
// Size: 0x498(Inherited: 0x488) 
struct ABP_Projectile_45ACP_C : public ATraceProjectile
{
	struct UStaticMeshComponent* Cube;  // 0x488(0x8)
	struct USceneComponent* Scene;  // 0x490(0x8)

}; 



