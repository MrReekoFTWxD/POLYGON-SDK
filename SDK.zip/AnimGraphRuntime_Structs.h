#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimGraphRuntime.AnimationStateResultReference
// Size: 0x10(Inherited: 0x10) 
struct FAnimationStateResultReference : public FAnimNodeReference
{

}; 
// ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// Size: 0x2C(Inherited: 0x0) 
struct FAnimLegIKDefinition
{
	struct FBoneReference IKFootBone;  // 0x0(0x10)
	struct FBoneReference FKFootBone;  // 0x10(0x10)
	int32_t NumBonesInLimb;  // 0x20(0x4)
	float MinRotationAngle;  // 0x24(0x4)
	char EAxis FootBoneForwardAxis;  // 0x28(0x1)
	char EAxis HingeRotationAxis;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bEnableRotationLimit : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bEnableKneeTwistCorrection : 1;  // 0x2B(0x1)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CallFunction
// Size: 0x38(Inherited: 0x10) 
struct FAnimNode_CallFunction : public FAnimNode_Base
{
	struct FPoseLink Source;  // 0x10(0x10)
	char pad_32[20];  // 0x20(0x14)
	uint8_t  CallSite;  // 0x34(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AngularRangeLimit
// Size: 0x40(Inherited: 0x0) 
struct FAngularRangeLimit
{
	struct FVector LimitMin;  // 0x0(0x18)
	struct FVector LimitMax;  // 0x18(0x18)
	struct FBoneReference bone;  // 0x30(0x10)

}; 
// DelegateFunction AnimGraphRuntime.OnMontagePlayDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnMontagePlayDelegate__DelegateSignature
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// Size: 0xC8(Inherited: 0x10) 
struct FAnimNode_SkeletalControlBase : public FAnimNode_Base
{
	struct FComponentSpacePoseLink ComponentPose;  // 0x10(0x10)
	int32_t LODThreshold;  // 0x20(0x4)
	float ActualAlpha;  // 0x24(0x4)
	uint8_t  AlphaInputType;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAlphaBoolEnabled : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	float Alpha;  // 0x2C(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x30(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x38(0x48)
	struct FName AlphaCurveName;  // 0x80(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0x88(0x30)
	char pad_184[16];  // 0xB8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// Size: 0x188(Inherited: 0x90) 
struct FAnimNode_PoseDriver : public FAnimNode_PoseHandler
{
	struct FPoseLink SourcePose;  // 0x90(0x10)
	struct TArray<struct FBoneReference> SourceBones;  // 0xA0(0x10)
	struct TArray<struct FBoneReference> OnlyDriveBones;  // 0xB0(0x10)
	struct TArray<struct FPoseDriverTarget> PoseTargets;  // 0xC0(0x10)
	char pad_208[48];  // 0xD0(0x30)
	struct FBoneReference EvalSpaceBone;  // 0x100(0x10)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool bEvalFromRefPose : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FRBFParams RBFParams;  // 0x118(0x38)
	uint8_t  DriveSource;  // 0x150(0x1)
	uint8_t  DriveOutput;  // 0x151(0x1)
	char bOnlyDriveSelectedBones : 1;  // 0x152(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	char pad_339[2];  // 0x153(0x2)
	int32_t LODThreshold;  // 0x154(0x4)
	char pad_344[48];  // 0x158(0x30)

}; 
// ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// Size: 0x88(Inherited: 0x0) 
struct FAnimPhysConstraintSetup
{
	uint8_t  LinearXLimitType;  // 0x0(0x1)
	uint8_t  LinearYLimitType;  // 0x1(0x1)
	uint8_t  LinearZLimitType;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FVector LinearAxesMin;  // 0x8(0x18)
	struct FVector LinearAxesMax;  // 0x20(0x18)
	uint8_t  AngularConstraintType;  // 0x38(0x1)
	uint8_t  TwistAxis;  // 0x39(0x1)
	uint8_t  AngularTargetAxis;  // 0x3A(0x1)
	char pad_59[1];  // 0x3B(0x1)
	float ConeAngle;  // 0x3C(0x4)
	struct FVector AngularLimitsMin;  // 0x40(0x18)
	struct FVector AngularLimitsMax;  // 0x58(0x18)
	struct FVector AngularTarget;  // 0x70(0x18)

}; 
// ScriptStruct AnimGraphRuntime.IKFootPelvisPullDownSolver
// Size: 0x70(Inherited: 0x0) 
struct FIKFootPelvisPullDownSolver
{
	struct FVectorRK4SpringInterpolator PelvisAdjustmentInterp;  // 0x0(0x8)
	char pad_8[88];  // 0x8(0x58)
	float PelvisAdjustmentInterpAlpha;  // 0x60(0x4)
	float PelvisAdjustmentMaxDistance;  // 0x64(0x4)
	float PelvisAdjustmentErrorTolerance;  // 0x68(0x4)
	int32_t PelvisAdjustmentMaxIter;  // 0x6C(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Mirror_Standalone
// Size: 0x60(Inherited: 0x48) 
struct FAnimNode_Mirror_Standalone : public FAnimNode_MirrorBase
{
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bMirror : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UMirrorDataTable* MirrorDataTable;  // 0x50(0x8)
	float BlendTime;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bResetChild : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool bBoneMirroring : 1;  // 0x5D(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool bCurveMirroring : 1;  // 0x5E(0x1)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool bAttributeMirroring : 1;  // 0x5F(0x1)

}; 
// ScriptStruct AnimGraphRuntime.WarpingVectorValue
// Size: 0x20(Inherited: 0x0) 
struct FWarpingVectorValue
{
	uint8_t  Mode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector Value;  // 0x8(0x18)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// Size: 0x68(Inherited: 0x38) 
struct FAnimNode_BlendSpacePlayer : public FAnimNode_AssetPlayerBase
{
	char pad_56[40];  // 0x38(0x28)
	struct UBlendSpace* PreviousBlendSpace;  // 0x60(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// Size: 0x1D0(Inherited: 0x68) 
struct FAnimNode_AimOffsetLookAt : public FAnimNode_BlendSpacePlayer
{
	char pad_104[200];  // 0x68(0xC8)
	struct FPoseLink BasePose;  // 0x130(0x10)
	int32_t LODThreshold;  // 0x140(0x4)
	struct FName SourceSocketName;  // 0x144(0x8)
	struct FName PivotSocketName;  // 0x14C(0x8)
	char pad_340[4];  // 0x154(0x4)
	struct FVector LookAtLocation;  // 0x158(0x18)
	struct FVector SocketAxis;  // 0x170(0x18)
	float Alpha;  // 0x188(0x4)
	char pad_396[68];  // 0x18C(0x44)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// Size: 0x90(Inherited: 0x38) 
struct FAnimNode_PoseHandler : public FAnimNode_AssetPlayerBase
{
	struct UPoseAsset* PoseAsset;  // 0x38(0x8)
	char pad_64[80];  // 0x40(0x50)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// Size: 0xC8(Inherited: 0x10) 
struct FAnimNode_ApplyAdditive : public FAnimNode_Base
{
	struct FPoseLink Base;  // 0x10(0x10)
	struct FPoseLink Additive;  // 0x20(0x10)
	float Alpha;  // 0x30(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x34(0x8)
	int32_t LODThreshold;  // 0x3C(0x4)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x40(0x48)
	struct FName AlphaCurveName;  // 0x88(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0x90(0x30)
	char pad_192[4];  // 0xC0(0x4)
	uint8_t  AlphaInputType;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool bAlphaBoolEnabled : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// Size: 0x70(Inherited: 0x0) 
struct FAnimPhysPlanarLimit
{
	struct FBoneReference DrivingBone;  // 0x0(0x10)
	struct FTransform PlaneTransform;  // 0x10(0x60)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// Size: 0x68(Inherited: 0x10) 
struct FAnimNode_BlendBoneByChannel : public FAnimNode_Base
{
	struct FPoseLink A;  // 0x10(0x10)
	struct FPoseLink B;  // 0x20(0x10)
	struct TArray<struct FBlendBoneByChannelEntry> BoneDefinitions;  // 0x30(0x10)
	char pad_64[16];  // 0x40(0x10)
	float Alpha;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x58(0x8)
	char EBoneControlSpace TransformsSpace;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// Size: 0xA8(Inherited: 0x90) 
struct FAnimNode_PoseByName : public FAnimNode_PoseHandler
{
	struct FName PoseName;  // 0x90(0x8)
	float PoseWeight;  // 0x98(0x4)
	char pad_156[12];  // 0x9C(0xC)

}; 
// ScriptStruct AnimGraphRuntime.IKChain
// Size: 0x48(Inherited: 0x0) 
struct FIKChain
{
	char pad_0[72];  // 0x0(0x48)

}; 
// ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// Size: 0x30(Inherited: 0x0) 
struct FAnimPhysSphericalLimit
{
	struct FBoneReference DrivingBone;  // 0x0(0x10)
	struct FVector SphereLocalOffset;  // 0x10(0x18)
	float LimitRadius;  // 0x28(0x4)
	uint8_t  LimitType;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// Size: 0x5D0(Inherited: 0xC8) 
struct FAnimNode_AnimDynamics : public FAnimNode_SkeletalControlBase
{
	float LinearDampingOverride;  // 0xC8(0x4)
	float AngularDampingOverride;  // 0xCC(0x4)
	char pad_208[192];  // 0xD0(0xC0)
	struct FBoneReference RelativeSpaceBone;  // 0x190(0x10)
	struct FBoneReference BoundBone;  // 0x1A0(0x10)
	struct FBoneReference ChainEnd;  // 0x1B0(0x10)
	struct FVector BoxExtents;  // 0x1C0(0x18)
	struct FVector LocalJointOffset;  // 0x1D8(0x18)
	float GravityScale;  // 0x1F0(0x4)
	char pad_500[4];  // 0x1F4(0x4)
	struct FVector GravityOverride;  // 0x1F8(0x18)
	float LinearSpringConstant;  // 0x210(0x4)
	float AngularSpringConstant;  // 0x214(0x4)
	float WindScale;  // 0x218(0x4)
	char pad_540[4];  // 0x21C(0x4)
	struct FVector ComponentLinearAccScale;  // 0x220(0x18)
	struct FVector ComponentLinearVelScale;  // 0x238(0x18)
	struct FVector ComponentAppliedLinearAccClamp;  // 0x250(0x18)
	float AngularBiasOverride;  // 0x268(0x4)
	int32_t NumSolverIterationsPreUpdate;  // 0x26C(0x4)
	int32_t NumSolverIterationsPostUpdate;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	struct FAnimPhysConstraintSetup ConstraintSetup;  // 0x278(0x88)
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits;  // 0x300(0x10)
	float SphereCollisionRadius;  // 0x310(0x4)
	char pad_788[4];  // 0x314(0x4)
	struct FVector ExternalForce;  // 0x318(0x18)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits;  // 0x330(0x10)
	uint8_t  CollisionType;  // 0x340(0x1)
	uint8_t  SimulationSpace;  // 0x341(0x1)
	char pad_834[2];  // 0x342(0x2)
	char bUseSphericalLimits : 1;  // 0x344(0x1)
	char bUsePlanarLimit : 1;  // 0x344(0x1)
	char bDoUpdate : 1;  // 0x344(0x1)
	char bDoEval : 1;  // 0x344(0x1)
	char bOverrideLinearDamping : 1;  // 0x344(0x1)
	char bOverrideAngularBias : 1;  // 0x344(0x1)
	char bOverrideAngularDamping : 1;  // 0x344(0x1)
	char bEnableWind : 1;  // 0x344(0x1)
	char pad_837_1 : 1;  // 0x345(0x1)
	char bUseGravityOverride : 1;  // 0x345(0x1)
	char bGravityOverrideInSimSpace : 1;  // 0x345(0x1)
	char bLinearSpring : 1;  // 0x345(0x1)
	char bAngularSpring : 1;  // 0x345(0x1)
	char bChain : 1;  // 0x345(0x1)
	char pad_837_2 : 2;  // 0x345(0x1)
	char pad_838[11];  // 0x346(0xB)
	struct FRotationRetargetingInfo RetargetingSettings;  // 0x350(0x1A0)
	char pad_1264[224];  // 0x4F0(0xE0)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// Size: 0x128(Inherited: 0xC8) 
struct FAnimNode_ObserveBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToObserve;  // 0xC8(0x10)
	char EBoneControlSpace DisplaySpace;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool bRelativeToRefPose : 1;  // 0xD9(0x1)
	char pad_218[6];  // 0xDA(0x6)
	struct FVector Translation;  // 0xE0(0x18)
	struct FRotator Rotation;  // 0xF8(0x18)
	struct FVector Scale;  // 0x110(0x18)

}; 
// ScriptStruct AnimGraphRuntime.RotationRetargetingInfo
// Size: 0x1A0(Inherited: 0x0) 
struct FRotationRetargetingInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform Source;  // 0x10(0x60)
	struct FTransform Target;  // 0x70(0x60)
	uint8_t  RotationComponent;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct FVector TwistAxis;  // 0xD8(0x18)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bUseAbsoluteAngle : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	float SourceMinimum;  // 0xF4(0x4)
	float SourceMaximum;  // 0xF8(0x4)
	float TargetMinimum;  // 0xFC(0x4)
	float TargetMaximum;  // 0x100(0x4)
	uint8_t  EasingType;  // 0x104(0x1)
	char pad_261[3];  // 0x105(0x3)
	struct FRuntimeFloatCurve CustomCurve;  // 0x108(0x88)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool bFlipEasing : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	float EasingWeight;  // 0x194(0x4)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool bClamp : 1;  // 0x198(0x1)
	char pad_409[7];  // 0x199(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ApplyLimits
// Size: 0xE8(Inherited: 0xC8) 
struct FAnimNode_ApplyLimits : public FAnimNode_SkeletalControlBase
{
	struct TArray<struct FAngularRangeLimit> AngularRangeLimits;  // 0xC8(0x10)
	struct TArray<struct FVector> AngularOffsets;  // 0xD8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.PoseDriverTarget
// Size: 0xC8(Inherited: 0x0) 
struct FPoseDriverTarget
{
	struct TArray<struct FPoseDriverTransform> BoneTransforms;  // 0x0(0x10)
	struct FRotator TargetRotation;  // 0x10(0x18)
	float TargetScale;  // 0x28(0x4)
	uint8_t  DistanceMethod;  // 0x2C(0x1)
	uint8_t  FunctionType;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool bApplyCustomCurve : 1;  // 0x2E(0x1)
	char pad_47[1];  // 0x2F(0x1)
	struct FRichCurve CustomCurve;  // 0x30(0x80)
	struct FName DrivenName;  // 0xB0(0x8)
	char pad_184[8];  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bIsHidden : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)

}; 
// ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// Size: 0x24(Inherited: 0x0) 
struct FBlendBoneByChannelEntry
{
	struct FBoneReference SourceBone;  // 0x0(0x10)
	struct FBoneReference TargetBone;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bBlendTranslation : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bBlendRotation : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bBlendScale : 1;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// Size: 0x48(Inherited: 0x10) 
struct FAnimNode_BlendListBase : public FAnimNode_Base
{
	struct TArray<struct FPoseLink> BlendPose;  // 0x10(0x10)
	char pad_32[40];  // 0x20(0x28)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// Size: 0x48(Inherited: 0x48) 
struct FAnimNode_BlendListByBool : public FAnimNode_BlendListBase
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// Size: 0x48(Inherited: 0x48) 
struct FAnimNode_BlendListByEnum : public FAnimNode_BlendListBase
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// Size: 0x48(Inherited: 0x48) 
struct FAnimNode_BlendListByInt : public FAnimNode_BlendListBase
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// Size: 0x70(Inherited: 0x68) 
struct FAnimNode_BlendSpaceEvaluator : public FAnimNode_BlendSpacePlayer
{
	float NormalizedTime;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bTeleportToNormalizedTime : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceGraphBase
// Size: 0x68(Inherited: 0x10) 
struct FAnimNode_BlendSpaceGraphBase : public FAnimNode_Base
{
	float X;  // 0x10(0x4)
	float Y;  // 0x14(0x4)
	struct FName GroupName;  // 0x18(0x8)
	char EAnimGroupRole GroupRole;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UBlendSpace* BlendSpace;  // 0x28(0x8)
	struct TArray<struct FPoseLink> SamplePoseLinks;  // 0x30(0x10)
	char pad_64[40];  // 0x40(0x28)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// Size: 0x128(Inherited: 0xC8) 
struct FAnimNode_ModifyBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify;  // 0xC8(0x10)
	struct FVector Translation;  // 0xD8(0x18)
	struct FRotator Rotation;  // 0xF0(0x18)
	struct FVector Scale;  // 0x108(0x18)
	char EBoneModificationMode TranslationMode;  // 0x120(0x1)
	char EBoneModificationMode RotationMode;  // 0x121(0x1)
	char EBoneModificationMode ScaleMode;  // 0x122(0x1)
	char EBoneControlSpace TranslationSpace;  // 0x123(0x1)
	char EBoneControlSpace RotationSpace;  // 0x124(0x1)
	char EBoneControlSpace ScaleSpace;  // 0x125(0x1)
	char pad_294[2];  // 0x126(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceGraph
// Size: 0x68(Inherited: 0x68) 
struct FAnimNode_BlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceSampleResult
// Size: 0x20(Inherited: 0x20) 
struct FAnimNode_BlendSpaceSampleResult : public FAnimNode_Root
{

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayer
// Size: 0x28(Inherited: 0x0) 
struct FConvertToSequencePlayer
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FSequencePlayerReference ReturnValue;  // 0x18(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// Size: 0x40(Inherited: 0x10) 
struct FAnimNode_CurveSource : public FAnimNode_Base
{
	struct FPoseLink SourcePose;  // 0x10(0x10)
	struct FName SourceBinding;  // 0x20(0x8)
	float Alpha;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TScriptInterface<ICurveSourceInterface> CurveSource;  // 0x30(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// Size: 0x118(Inherited: 0xC8) 
struct FAnimNode_BoneDrivenController : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone;  // 0xC8(0x10)
	struct UCurveFloat* DrivingCurve;  // 0xD8(0x8)
	float Multiplier;  // 0xE0(0x4)
	float RangeMin;  // 0xE4(0x4)
	float RangeMax;  // 0xE8(0x4)
	float RemappedMin;  // 0xEC(0x4)
	float RemappedMax;  // 0xF0(0x4)
	struct FName ParameterName;  // 0xF4(0x8)
	struct FBoneReference TargetBone;  // 0xFC(0x10)
	uint8_t  DestinationMode;  // 0x10C(0x1)
	uint8_t  ModificationMode;  // 0x10D(0x1)
	char EComponentType SourceComponent;  // 0x10E(0x1)
	char bUseRange : 1;  // 0x10F(0x1)
	char bAffectTargetTranslationX : 1;  // 0x10F(0x1)
	char bAffectTargetTranslationY : 1;  // 0x10F(0x1)
	char bAffectTargetTranslationZ : 1;  // 0x10F(0x1)
	char bAffectTargetRotationX : 1;  // 0x10F(0x1)
	char bAffectTargetRotationY : 1;  // 0x10F(0x1)
	char bAffectTargetRotationZ : 1;  // 0x10F(0x1)
	char bAffectTargetScaleX : 1;  // 0x10F(0x1)
	char bAffectTargetScaleY : 1;  // 0x110(0x1)
	char bAffectTargetScaleZ : 1;  // 0x110(0x1)
	char pad_272_1 : 6;  // 0x110(0x1)
	char pad_273[8];  // 0x111(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CCDIK
// Size: 0x1C0(Inherited: 0xC8) 
struct FAnimNode_CCDIK : public FAnimNode_SkeletalControlBase
{
	struct FVector EffectorLocation;  // 0xC8(0x18)
	char EBoneControlSpace EffectorLocationSpace;  // 0xE0(0x1)
	char pad_225[15];  // 0xE1(0xF)
	struct FBoneSocketTarget EffectorTarget;  // 0xF0(0x90)
	struct FBoneReference TipBone;  // 0x180(0x10)
	struct FBoneReference RootBone;  // 0x190(0x10)
	float Precision;  // 0x1A0(0x4)
	int32_t MaxIterations;  // 0x1A4(0x4)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool bStartFromTail : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool bEnableRotationLimit : 1;  // 0x1A9(0x1)
	char pad_426[6];  // 0x1AA(0x6)
	struct TArray<float> RotationLimitPerJoints;  // 0x1B0(0x10)

}; 
// ScriptStruct AnimGraphRuntime.Constraint
// Size: 0x1C(Inherited: 0x0) 
struct FConstraint
{
	struct FBoneReference TargetBone;  // 0x0(0x10)
	uint8_t  OffsetOption;  // 0x10(0x1)
	uint8_t  TransformType;  // 0x11(0x1)
	struct FFilterOptionPerAxis PerAxis;  // 0x12(0x3)
	char pad_21[7];  // 0x15(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// Size: 0x108(Inherited: 0xC8) 
struct FAnimNode_Constraint : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify;  // 0xC8(0x10)
	struct TArray<struct FConstraint> ConstraintSetup;  // 0xD8(0x10)
	struct TArray<float> ConstraintWeights;  // 0xE8(0x10)
	char pad_248[16];  // 0xF8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// Size: 0xF0(Inherited: 0xC8) 
struct FAnimNode_CopyBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone;  // 0xC8(0x10)
	struct FBoneReference TargetBone;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bCopyTranslation : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool bCopyRotation : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool bCopyScale : 1;  // 0xEA(0x1)
	char EBoneControlSpace ControlSpace;  // 0xEB(0x1)
	char pad_236[4];  // 0xEC(0x4)

}; 
// ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// Size: 0x50(Inherited: 0x0) 
struct FRandomPlayerSequenceEntry
{
	struct UAnimSequence* Sequence;  // 0x0(0x8)
	float ChanceToPlay;  // 0x8(0x4)
	int32_t MinLoopCount;  // 0xC(0x4)
	int32_t MaxLoopCount;  // 0x10(0x4)
	float MinPlayRate;  // 0x14(0x4)
	float MaxPlayRate;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FAlphaBlend BlendIn;  // 0x20(0x30)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// Size: 0xF8(Inherited: 0xC8) 
struct FAnimNode_CopyBoneDelta : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone;  // 0xC8(0x10)
	struct FBoneReference TargetBone;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bCopyTranslation : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool bCopyRotation : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool bCopyScale : 1;  // 0xEA(0x1)
	uint8_t  CopyMode;  // 0xEB(0x1)
	float TranslationMultiplier;  // 0xEC(0x4)
	float RotationMultiplier;  // 0xF0(0x4)
	float ScaleMultiplier;  // 0xF4(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// Size: 0x100(Inherited: 0x10) 
struct FAnimNode_ModifyCurve : public FAnimNode_Base
{
	struct FPoseLink SourcePose;  // 0x10(0x10)
	struct TMap<struct FName, float> CurveMap;  // 0x20(0x50)
	struct TArray<float> CurveValues;  // 0x70(0x10)
	struct TArray<struct FName> CurveNames;  // 0x80(0x10)
	char pad_144[100];  // 0x90(0x64)
	float Alpha;  // 0xF4(0x4)
	uint8_t  ApplyMode;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// Size: 0x90(Inherited: 0x10) 
struct FAnimNode_PoseSnapshot : public FAnimNode_Base
{
	struct FName SnapshotName;  // 0x10(0x8)
	struct FPoseSnapshot Snapshot;  // 0x18(0x38)
	uint8_t  Mode;  // 0x50(0x1)
	char pad_81[63];  // 0x51(0x3F)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// Size: 0x38(Inherited: 0x10) 
struct FAnimNode_MakeDynamicAdditive : public FAnimNode_Base
{
	struct FPoseLink Base;  // 0x10(0x10)
	struct FPoseLink Additive;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bMeshSpaceAdditive : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// Size: 0x1D8(Inherited: 0x10) 
struct FAnimNode_CopyPoseFromMesh : public FAnimNode_Base
{
	struct TWeakObjectPtr<USkeletalMeshComponent> SourceMeshComponent;  // 0x10(0x8)
	char bUseAttachedParent : 1;  // 0x18(0x1)
	char bCopyCurves : 1;  // 0x18(0x1)
	char pad_24_1 : 6;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bCopyCustomAttributes : 1;  // 0x19(0x1)
	char bUseMeshPose : 1;  // 0x1A(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	char pad_27[2];  // 0x1B(0x2)
	struct FName RootBoneToCopy;  // 0x1C(0x8)
	char pad_36[436];  // 0x24(0x1B4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// Size: 0x1F0(Inherited: 0xC8) 
struct FAnimNode_Fabrik : public FAnimNode_SkeletalControlBase
{
	char pad_200[8];  // 0xC8(0x8)
	struct FTransform EffectorTransform;  // 0xD0(0x60)
	struct FBoneSocketTarget EffectorTarget;  // 0x130(0x90)
	struct FBoneReference TipBone;  // 0x1C0(0x10)
	struct FBoneReference RootBone;  // 0x1D0(0x10)
	float Precision;  // 0x1E0(0x4)
	int32_t MaxIterations;  // 0x1E4(0x4)
	char EBoneControlSpace EffectorTransformSpace;  // 0x1E8(0x1)
	char EBoneRotationSource EffectorRotationSource;  // 0x1E9(0x1)
	char pad_490[6];  // 0x1EA(0x6)

}; 
// ScriptStruct AnimGraphRuntime.PoseDriverTransform
// Size: 0x30(Inherited: 0x0) 
struct FPoseDriverTransform
{
	struct FVector TargetTranslation;  // 0x0(0x18)
	struct FRotator TargetRotation;  // 0x18(0x18)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// Size: 0x120(Inherited: 0xC8) 
struct FAnimNode_HandIKRetargeting : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference RightHandFK;  // 0xC8(0x10)
	struct FBoneReference LeftHandFK;  // 0xD8(0x10)
	struct FBoneReference RightHandIK;  // 0xE8(0x10)
	struct FBoneReference LeftHandIK;  // 0xF8(0x10)
	struct TArray<struct FBoneReference> IKBonesToMove;  // 0x108(0x10)
	float HandFKWeight;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// Size: 0xE0(Inherited: 0x10) 
struct FAnimNode_LayeredBoneBlend : public FAnimNode_Base
{
	struct FPoseLink BasePose;  // 0x10(0x10)
	struct TArray<struct FPoseLink> BlendPoses;  // 0x20(0x10)
	uint8_t  BlendMode;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TArray<struct UBlendProfile*> BlendMasks;  // 0x38(0x10)
	struct TArray<struct FInputBlendPose> LayerSetup;  // 0x48(0x10)
	struct TArray<float> BlendWeights;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bMeshSpaceRotationBlend : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool bMeshSpaceScaleBlend : 1;  // 0x69(0x1)
	char ECurveBlendOption CurveBlendOption;  // 0x6A(0x1)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool bBlendRootMotionBasedOnRootBone : 1;  // 0x6B(0x1)
	char pad_108[4];  // 0x6C(0x4)
	int32_t LODThreshold;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights;  // 0x78(0x10)
	struct FGuid SkeletonGuid;  // 0x88(0x10)
	struct FGuid VirtualBoneGuid;  // 0x98(0x10)
	char pad_168[56];  // 0xA8(0x38)

}; 
// ScriptStruct AnimGraphRuntime.IKChainLink
// Size: 0x70(Inherited: 0x0) 
struct FIKChainLink
{
	char pad_0[112];  // 0x0(0x70)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ResetRoot
// Size: 0xD8(Inherited: 0xC8) 
struct FAnimNode_ResetRoot : public FAnimNode_SkeletalControlBase
{
	char pad_200[16];  // 0xC8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimLegIKData
// Size: 0xE0(Inherited: 0x0) 
struct FAnimLegIKData
{
	char pad_0[224];  // 0x0(0xE0)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// Size: 0xF8(Inherited: 0xC8) 
struct FAnimNode_LegIK : public FAnimNode_SkeletalControlBase
{
	float ReachPrecision;  // 0xC8(0x4)
	int32_t MaxIterations;  // 0xCC(0x4)
	struct TArray<struct FAnimLegIKDefinition> LegsDefinition;  // 0xD0(0x10)
	char pad_224[24];  // 0xE0(0x18)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MirrorBase
// Size: 0x48(Inherited: 0x10) 
struct FAnimNode_MirrorBase : public FAnimNode_Base
{
	struct FPoseLink Source;  // 0x10(0x10)
	char pad_32[40];  // 0x20(0x28)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// Size: 0x250(Inherited: 0xC8) 
struct FAnimNode_LookAt : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify;  // 0xC8(0x10)
	char pad_216[8];  // 0xD8(0x8)
	struct FBoneSocketTarget LookAtTarget;  // 0xE0(0x90)
	struct FVector LookAtLocation;  // 0x170(0x18)
	struct FAxis LookAt_Axis;  // 0x188(0x20)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool bUseLookUpAxis : 1;  // 0x1A8(0x1)
	char EInterpolationBlend InterpolationType;  // 0x1A9(0x1)
	char pad_426[6];  // 0x1AA(0x6)
	struct FAxis LookUp_Axis;  // 0x1B0(0x20)
	float LookAtClamp;  // 0x1D0(0x4)
	float InterpolationTime;  // 0x1D4(0x4)
	float InterpolationTriggerThreashold;  // 0x1D8(0x4)
	char pad_476[116];  // 0x1DC(0x74)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer
// Size: 0x20(Inherited: 0x0) 
struct FK2_EndProfilingTimer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLog : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LogPrefix;  // 0x8(0x10)
	float ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Mirror
// Size: 0x48(Inherited: 0x48) 
struct FAnimNode_Mirror : public FAnimNode_MirrorBase
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// Size: 0x50(Inherited: 0x10) 
struct FAnimNode_MultiWayBlend : public FAnimNode_Base
{
	struct TArray<struct FPoseLink> Poses;  // 0x10(0x10)
	struct TArray<float> DesiredAlphas;  // 0x20(0x10)
	char pad_48[16];  // 0x30(0x10)
	struct FInputScaleBias AlphaScaleBias;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bAdditiveNode : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool bNormalizeAlpha : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// Size: 0xB0(Inherited: 0x90) 
struct FAnimNode_PoseBlendNode : public FAnimNode_PoseHandler
{
	struct FPoseLink SourcePose;  // 0x90(0x10)
	uint8_t  BlendOption;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UCurveFloat* CustomCurve;  // 0xA8(0x8)

}; 
// ScriptStruct AnimGraphRuntime.RBFParams
// Size: 0x38(Inherited: 0x0) 
struct FRBFParams
{
	int32_t TargetDimensions;  // 0x0(0x4)
	uint8_t  SolverType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Radius;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bAutomaticRadius : 1;  // 0xC(0x1)
	uint8_t  Function;  // 0xD(0x1)
	uint8_t  DistanceMethod;  // 0xE(0x1)
	char EBoneAxis TwistAxis;  // 0xF(0x1)
	float WeightThreshold;  // 0x10(0x4)
	uint8_t  NormalizeMethod;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FVector MedianReference;  // 0x18(0x18)
	float MedianMin;  // 0x30(0x4)
	float MedianMax;  // 0x34(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// Size: 0x78(Inherited: 0x10) 
struct FAnimNode_RandomPlayer : public FAnimNode_Base
{
	struct TArray<struct FRandomPlayerSequenceEntry> Entries;  // 0x10(0x10)
	char pad_32[80];  // 0x20(0x50)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bShuffleMode : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// Size: 0x10(Inherited: 0x10) 
struct FAnimNode_RefPose : public FAnimNode_Base
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// Size: 0x10(Inherited: 0x10) 
struct FAnimNode_MeshSpaceRefPose : public FAnimNode_Base
{

}; 
// ScriptStruct AnimGraphRuntime.SimSpaceSettings
// Size: 0x68(Inherited: 0x0) 
struct FSimSpaceSettings
{
	float MasterAlpha;  // 0x0(0x4)
	float VelocityScaleZ;  // 0x4(0x4)
	float MaxLinearVelocity;  // 0x8(0x4)
	float MaxAngularVelocity;  // 0xC(0x4)
	float MaxLinearAcceleration;  // 0x10(0x4)
	float MaxAngularAcceleration;  // 0x14(0x4)
	float ExternalLinearDrag;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FVector ExternalLinearDragV;  // 0x20(0x18)
	struct FVector ExternalLinearVelocity;  // 0x38(0x18)
	struct FVector ExternalAngularVelocity;  // 0x50(0x18)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RigidBody
// Size: 0x990(Inherited: 0xC8) 
struct FAnimNode_RigidBody : public FAnimNode_SkeletalControlBase
{
	struct UPhysicsAsset* OverridePhysicsAsset;  // 0xC8(0x8)
	char pad_208[296];  // 0xD0(0x128)
	struct FVector OverrideWorldGravity;  // 0x1F8(0x18)
	struct FVector ExternalForce;  // 0x210(0x18)
	struct FVector ComponentLinearAccScale;  // 0x228(0x18)
	struct FVector ComponentLinearVelScale;  // 0x240(0x18)
	struct FVector ComponentAppliedLinearAccClamp;  // 0x258(0x18)
	struct FSimSpaceSettings SimSpaceSettings;  // 0x270(0x68)
	float CachedBoundsScale;  // 0x2D8(0x4)
	struct FBoneReference BaseBoneRef;  // 0x2DC(0x10)
	char ECollisionChannel OverlapChannel;  // 0x2EC(0x1)
	uint8_t  SimulationSpace;  // 0x2ED(0x1)
	char pad_750_1 : 7;  // 0x2EE(0x1)
	bool bForceDisableCollisionBetweenConstraintBodies : 1;  // 0x2EE(0x1)
	char pad_751[1];  // 0x2EF(0x1)
	char bEnableWorldGeometry : 1;  // 0x2F0(0x1)
	char bOverrideWorldGravity : 1;  // 0x2F0(0x1)
	char bTransferBoneVelocities : 1;  // 0x2F0(0x1)
	char bFreezeIncomingPoseOnStart : 1;  // 0x2F0(0x1)
	char bClampLinearTranslationLimitToRefPose : 1;  // 0x2F0(0x1)
	char pad_752_1 : 3;  // 0x2F0(0x1)
	char pad_753[4];  // 0x2F1(0x4)
	float WorldSpaceMinimumScale;  // 0x2F4(0x4)
	float EvaluationResetTime;  // 0x2F8(0x4)
	char pad_764[1684];  // 0x2FC(0x694)

}; 
// ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// Size: 0x14(Inherited: 0x0) 
struct FSplineIKCachedBoneData
{
	struct FBoneReference bone;  // 0x0(0x10)
	int32_t RefSkeletonIndex;  // 0x10(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// Size: 0xA8(Inherited: 0x10) 
struct FAnimNode_RotateRootBone : public FAnimNode_Base
{
	struct FPoseLink BasePose;  // 0x10(0x10)
	float Pitch;  // 0x20(0x4)
	float Yaw;  // 0x24(0x4)
	struct FInputScaleBiasClamp PitchScaleBiasClamp;  // 0x28(0x30)
	struct FInputScaleBiasClamp YawScaleBiasClamp;  // 0x58(0x30)
	struct FRotator MeshToComponent;  // 0x88(0x18)
	char pad_160[8];  // 0xA0(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// Size: 0xF0(Inherited: 0xC8) 
struct FAnimNode_RotationMultiplier : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference TargetBone;  // 0xC8(0x10)
	struct FBoneReference SourceBone;  // 0xD8(0x10)
	float Multiplier;  // 0xE8(0x4)
	char EBoneAxis RotationAxisToRefer;  // 0xEC(0x1)
	char pad_237_1 : 7;  // 0xED(0x1)
	bool bIsAdditive : 1;  // 0xED(0x1)
	char pad_238[2];  // 0xEE(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// Size: 0x110(Inherited: 0x68) 
struct FAnimNode_RotationOffsetBlendSpace : public FAnimNode_BlendSpacePlayer
{
	struct FPoseLink BasePose;  // 0x68(0x10)
	int32_t LODThreshold;  // 0x78(0x4)
	float Alpha;  // 0x7C(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x80(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x88(0x48)
	struct FName AlphaCurveName;  // 0xD0(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0xD8(0x30)
	char pad_264[4];  // 0x108(0x4)
	uint8_t  AlphaInputType;  // 0x10C(0x1)
	char pad_269_1 : 7;  // 0x10D(0x1)
	bool bAlphaBoolEnabled : 1;  // 0x10D(0x1)
	char pad_270[2];  // 0x10E(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpaceGraph
// Size: 0x110(Inherited: 0x68) 
struct FAnimNode_RotationOffsetBlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
{
	struct FPoseLink BasePose;  // 0x68(0x10)
	int32_t LODThreshold;  // 0x78(0x4)
	float Alpha;  // 0x7C(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x80(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x88(0x48)
	struct FName AlphaCurveName;  // 0xD0(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0xD8(0x30)
	char pad_264[4];  // 0x108(0x4)
	uint8_t  AlphaInputType;  // 0x10C(0x1)
	char pad_269_1 : 7;  // 0x10D(0x1)
	bool bAlphaBoolEnabled : 1;  // 0x10D(0x1)
	char pad_270[2];  // 0x10E(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// Size: 0x88(Inherited: 0x10) 
struct FAnimNode_ScaleChainLength : public FAnimNode_Base
{
	struct FPoseLink InputPose;  // 0x10(0x10)
	float DefaultChainLength;  // 0x20(0x4)
	struct FBoneReference ChainStartBone;  // 0x24(0x10)
	struct FBoneReference ChainEndBone;  // 0x34(0x10)
	char pad_68[4];  // 0x44(0x4)
	struct FVector TargetLocation;  // 0x48(0x18)
	float Alpha;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x68(0x8)
	uint8_t  ChainInitialLength;  // 0x70(0x1)
	char pad_113[23];  // 0x71(0x17)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluatorBase
// Size: 0x40(Inherited: 0x38) 
struct FAnimNode_SequenceEvaluatorBase : public FAnimNode_AssetPlayerBase
{
	char pad_56[8];  // 0x38(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// Size: 0x40(Inherited: 0x40) 
struct FAnimNode_SequenceEvaluator : public FAnimNode_SequenceEvaluatorBase
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator_Standalone
// Size: 0x68(Inherited: 0x40) 
struct FAnimNode_SequenceEvaluator_Standalone : public FAnimNode_SequenceEvaluatorBase
{
	struct FName GroupName;  // 0x40(0x8)
	char EAnimGroupRole GroupRole;  // 0x48(0x1)
	uint8_t  Method;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool bIgnoreForRelevancyTest : 1;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	struct UAnimSequenceBase* Sequence;  // 0x50(0x8)
	float ExplicitTime;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bShouldLoop : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool bTeleportToExplicitTime : 1;  // 0x5D(0x1)
	char ESequenceEvalReinit ReinitializationBehavior;  // 0x5E(0x1)
	char pad_95[1];  // 0x5F(0x1)
	float StartPosition;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Slot
// Size: 0x48(Inherited: 0x10) 
struct FAnimNode_Slot : public FAnimNode_Base
{
	struct FPoseLink Source;  // 0x10(0x10)
	struct FName SlotName;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAlwaysUpdateSourcePose : 1;  // 0x28(0x1)
	char pad_41[31];  // 0x29(0x1F)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// Size: 0x270(Inherited: 0xC8) 
struct FAnimNode_SplineIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference StartBone;  // 0xC8(0x10)
	struct FBoneReference EndBone;  // 0xD8(0x10)
	uint8_t  BoneAxis;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool bAutoCalculateSpline : 1;  // 0xE9(0x1)
	char pad_234[2];  // 0xEA(0x2)
	int32_t PointCount;  // 0xEC(0x4)
	struct TArray<struct FTransform> ControlPoints;  // 0xF0(0x10)
	float Roll;  // 0x100(0x4)
	float TwistStart;  // 0x104(0x4)
	float TwistEnd;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct FAlphaBlend TwistBlend;  // 0x110(0x30)
	float Stretch;  // 0x140(0x4)
	float Offset;  // 0x144(0x4)
	char pad_328[296];  // 0x148(0x128)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// Size: 0x158(Inherited: 0xC8) 
struct FAnimNode_SpringBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SpringBone;  // 0xC8(0x10)
	float MaxDisplacement;  // 0xD8(0x4)
	float SpringStiffness;  // 0xDC(0x4)
	float SpringDamping;  // 0xE0(0x4)
	float ErrorResetThresh;  // 0xE4(0x4)
	char pad_232[108];  // 0xE8(0x6C)
	char bLimitDisplacement : 1;  // 0x154(0x1)
	char bTranslateX : 1;  // 0x154(0x1)
	char bTranslateY : 1;  // 0x154(0x1)
	char bTranslateZ : 1;  // 0x154(0x1)
	char bRotateX : 1;  // 0x154(0x1)
	char bRotateY : 1;  // 0x154(0x1)
	char bRotateZ : 1;  // 0x154(0x1)
	char pad_340_1 : 1;  // 0x154(0x1)
	char pad_341[4];  // 0x155(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_StateResult
// Size: 0x20(Inherited: 0x20) 
struct FAnimNode_StateResult : public FAnimNode_Root
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Sync
// Size: 0x30(Inherited: 0x10) 
struct FAnimNode_Sync : public FAnimNode_Base
{
	struct FPoseLink Source;  // 0x10(0x10)
	struct FName GroupName;  // 0x20(0x8)
	char EAnimGroupRole GroupRole;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct AnimGraphRuntime.RotationLimit
// Size: 0x30(Inherited: 0x0) 
struct FRotationLimit
{
	struct FVector LimitMin;  // 0x0(0x18)
	struct FVector LimitMax;  // 0x18(0x18)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Trail
// Size: 0x2A0(Inherited: 0xC8) 
struct FAnimNode_Trail : public FAnimNode_SkeletalControlBase
{
	char pad_200[104];  // 0xC8(0x68)
	struct FBoneReference TrailBone;  // 0x130(0x10)
	int32_t ChainLength;  // 0x140(0x4)
	char EAxis ChainBoneAxis;  // 0x144(0x1)
	char bInvertChainBoneAxis : 1;  // 0x145(0x1)
	char bLimitStretch : 1;  // 0x145(0x1)
	char bLimitRotation : 1;  // 0x145(0x1)
	char bUsePlanarLimit : 1;  // 0x145(0x1)
	char bActorSpaceFakeVel : 1;  // 0x145(0x1)
	char bReorientParentToChild : 1;  // 0x145(0x1)
	char pad_325_1 : 2;  // 0x145(0x1)
	char pad_326[3];  // 0x146(0x3)
	float MaxDeltaTime;  // 0x148(0x4)
	float RelaxationSpeedScale;  // 0x14C(0x4)
	struct FRuntimeFloatCurve TrailRelaxationSpeed;  // 0x150(0x88)
	struct FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor;  // 0x1D8(0x30)
	struct TArray<struct FRotationLimit> RotationLimits;  // 0x208(0x10)
	struct TArray<struct FVector> RotationOffsets;  // 0x218(0x10)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits;  // 0x228(0x10)
	float StretchLimit;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct FVector FakeVelocity;  // 0x240(0x18)
	struct FBoneReference BaseJoint;  // 0x258(0x10)
	float LastBoneRotationAnimAlphaBlend;  // 0x268(0x4)
	char pad_620[52];  // 0x26C(0x34)

}; 
// ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// Size: 0x30(Inherited: 0x0) 
struct FReferenceBoneFrame
{
	struct FBoneReference bone;  // 0x0(0x10)
	struct FAxis Axis;  // 0x10(0x20)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
// Size: 0x28(Inherited: 0x0) 
struct FCreateProxyObjectForPlayMontage
{
	struct USkeletalMeshComponent* InSkeletalMeshComponent;  // 0x0(0x8)
	struct UAnimMontage* MontageToPlay;  // 0x8(0x8)
	float PlayRate;  // 0x10(0x4)
	float StartingPosition;  // 0x14(0x4)
	struct FName StartingSection;  // 0x18(0x8)
	struct UPlayMontageCallbackProxy* ReturnValue;  // 0x20(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// Size: 0x168(Inherited: 0xC8) 
struct FAnimNode_TwistCorrectiveNode : public FAnimNode_SkeletalControlBase
{
	struct FReferenceBoneFrame BaseFrame;  // 0xC8(0x30)
	struct FReferenceBoneFrame TwistFrame;  // 0xF8(0x30)
	struct FAxis TwistPlaneNormalAxis;  // 0x128(0x20)
	float RangeMax;  // 0x148(0x4)
	float RemappedMin;  // 0x14C(0x4)
	float RemappedMax;  // 0x150(0x4)
	struct FAnimCurveParam Curve;  // 0x154(0xC)
	char pad_352[8];  // 0x160(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// Size: 0x270(Inherited: 0xC8) 
struct FAnimNode_TwoBoneIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference IKBone;  // 0xC8(0x10)
	float StartStretchRatio;  // 0xD8(0x4)
	float MaxStretchScale;  // 0xDC(0x4)
	struct FVector EffectorLocation;  // 0xE0(0x18)
	char pad_248[8];  // 0xF8(0x8)
	struct FBoneSocketTarget EffectorTarget;  // 0x100(0x90)
	struct FVector JointTargetLocation;  // 0x190(0x18)
	char pad_424[8];  // 0x1A8(0x8)
	struct FBoneSocketTarget JointTarget;  // 0x1B0(0x90)
	struct FAxis TwistAxis;  // 0x240(0x20)
	char EBoneControlSpace EffectorLocationSpace;  // 0x260(0x1)
	char EBoneControlSpace JointTargetLocationSpace;  // 0x261(0x1)
	char bAllowStretching : 1;  // 0x262(0x1)
	char bTakeRotationFromEffectorSpace : 1;  // 0x262(0x1)
	char bMaintainEffectorRelRot : 1;  // 0x262(0x1)
	char bAllowTwist : 1;  // 0x262(0x1)
	char pad_610_1 : 4;  // 0x262(0x1)
	char pad_611[14];  // 0x263(0xE)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// Size: 0xC8(Inherited: 0x10) 
struct FAnimNode_TwoWayBlend : public FAnimNode_Base
{
	struct FPoseLink A;  // 0x10(0x10)
	struct FPoseLink B;  // 0x20(0x10)
	uint8_t  AlphaInputType;  // 0x30(0x1)
	char bAlphaBoolEnabled : 1;  // 0x31(0x1)
	char pad_49_1 : 2;  // 0x31(0x1)
	char bResetChildOnActivation : 1;  // 0x31(0x1)
	char pad_49_2 : 4;  // 0x31(0x1)
	char pad_50[3];  // 0x32(0x3)
	float Alpha;  // 0x34(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x38(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x40(0x48)
	struct FName AlphaCurveName;  // 0x88(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0x90(0x30)
	char pad_192[8];  // 0xC0(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// Size: 0xBA0(Inherited: 0x890) 
struct FAnimSequencerInstanceProxy : public FAnimInstanceProxy
{
	char pad_2192[784];  // 0x890(0x310)

}; 
// ScriptStruct AnimGraphRuntime.PositionHistory
// Size: 0x30(Inherited: 0x0) 
struct FPositionHistory
{
	struct TArray<struct FVector> Positions;  // 0x0(0x10)
	float Range;  // 0x10(0x4)
	char pad_20[28];  // 0x14(0x1C)

}; 
// ScriptStruct AnimGraphRuntime.LinkedAnimGraphReference
// Size: 0x10(Inherited: 0x10) 
struct FLinkedAnimGraphReference : public FAnimNodeReference
{

}; 
// ScriptStruct AnimGraphRuntime.RBFEntry
// Size: 0x10(Inherited: 0x0) 
struct FRBFEntry
{
	struct TArray<float> Values;  // 0x0(0x10)

}; 
// ScriptStruct AnimGraphRuntime.RBFTarget
// Size: 0xA0(Inherited: 0x10) 
struct FRBFTarget : public FRBFEntry
{
	float ScaleFactor;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bApplyCustomCurve : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRichCurve CustomCurve;  // 0x18(0x80)
	uint8_t  DistanceMethod;  // 0x98(0x1)
	uint8_t  FunctionType;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)

}; 
// ScriptStruct AnimGraphRuntime.SequenceEvaluatorReference
// Size: 0x10(Inherited: 0x10) 
struct FSequenceEvaluatorReference : public FAnimNodeReference
{

}; 
// ScriptStruct AnimGraphRuntime.SequencePlayerReference
// Size: 0x10(Inherited: 0x10) 
struct FSequencePlayerReference : public FAnimNodeReference
{

}; 
// ScriptStruct AnimGraphRuntime.SkeletalControlReference
// Size: 0x10(Inherited: 0x10) 
struct FSkeletalControlReference : public FAnimNodeReference
{

}; 
// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResult
// Size: 0x28(Inherited: 0x0) 
struct FConvertToAnimationStateResult
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	struct FAnimationStateResultReference AnimationState;  // 0x10(0x10)
	uint8_t  Result;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResultPure
// Size: 0x28(Inherited: 0x0) 
struct FConvertToAnimationStateResultPure
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	struct FAnimationStateResultReference AnimationState;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingIn
// Size: 0x28(Inherited: 0x0) 
struct FIsStateBlendingIn
{
	struct FAnimUpdateContext UpdateContext;  // 0x0(0x10)
	struct FAnimationStateResultReference Node;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingOut
// Size: 0x28(Inherited: 0x0) 
struct FIsStateBlendingOut
{
	struct FAnimUpdateContext UpdateContext;  // 0x0(0x10)
	struct FAnimationStateResultReference Node;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToComponentSpacePoseContext
// Size: 0x28(Inherited: 0x0) 
struct FConvertToComponentSpacePoseContext
{
	struct FAnimExecutionContext Context;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FAnimComponentSpacePoseContext ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequenceEvaluatorLibrary.AdvanceTime
// Size: 0x38(Inherited: 0x0) 
struct FAdvanceTime
{
	struct FAnimUpdateContext UpdateContext;  // 0x0(0x10)
	struct FSequenceEvaluatorReference SequenceEvaluator;  // 0x10(0x10)
	float PlayRate;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FSequenceEvaluatorReference ReturnValue;  // 0x28(0x10)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToInitializationContext
// Size: 0x28(Inherited: 0x0) 
struct FConvertToInitializationContext
{
	struct FAnimExecutionContext Context;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FAnimInitializationContext ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToPoseContext
// Size: 0x28(Inherited: 0x0) 
struct FConvertToPoseContext
{
	struct FAnimExecutionContext Context;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FAnimPoseContext ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
// Size: 0x120(Inherited: 0x0) 
struct FK2_LookAt
{
	struct FTransform CurrentTransform;  // 0x0(0x60)
	struct FVector TargetPosition;  // 0x60(0x18)
	struct FVector LookAtVector;  // 0x78(0x18)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bUseUpVector : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FVector UpVector;  // 0x98(0x18)
	float ClampConeInDegree;  // 0xB0(0x4)
	char pad_180[12];  // 0xB4(0xC)
	struct FTransform ReturnValue;  // 0xC0(0x60)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToUpdateContext
// Size: 0x28(Inherited: 0x0) 
struct FConvertToUpdateContext
{
	struct FAnimExecutionContext Context;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FAnimUpdateContext ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SkeletalControlLibrary.GetAlpha
// Size: 0x18(Inherited: 0x0) 
struct FGetAlpha
{
	struct FSkeletalControlReference SkeletalControl;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimInstance
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimInstance
{
	struct FAnimExecutionContext Context;  // 0x0(0x10)
	struct UAnimInstance* ReturnValue;  // 0x10(0x8)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimNodeReference
// Size: 0x20(Inherited: 0x0) 
struct FGetAnimNodeReference
{
	struct UAnimInstance* Instance;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FAnimNodeReference ReturnValue;  // 0x10(0x10)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetCurrentWeight
// Size: 0x18(Inherited: 0x0) 
struct FGetCurrentWeight
{
	struct FAnimUpdateContext Context;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime
// Size: 0x18(Inherited: 0x0) 
struct FGetDeltaTime
{
	struct FAnimUpdateContext Context;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.CalculateDirection
// Size: 0x38(Inherited: 0x0) 
struct FCalculateDirection
{
	struct FVector Velocity;  // 0x0(0x18)
	struct FRotator BaseRotation;  // 0x18(0x18)
	float ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory
// Size: 0x60(Inherited: 0x0) 
struct FK2_CalculateVelocityFromPositionHistory
{
	float DeltaSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector position;  // 0x8(0x18)
	struct FPositionHistory History;  // 0x20(0x30)
	int32_t NumberOfSamples;  // 0x50(0x4)
	float VelocityMin;  // 0x54(0x4)
	float VelocityMax;  // 0x58(0x4)
	float ReturnValue;  // 0x5C(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets
// Size: 0x110(Inherited: 0x0) 
struct FK2_CalculateVelocityFromSockets
{
	float DeltaSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USkeletalMeshComponent* Component;  // 0x8(0x8)
	struct FName SocketOrBoneName;  // 0x10(0x8)
	struct FName ReferenceSocketOrBone;  // 0x18(0x8)
	char ERelativeTransformSpace SocketSpace;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FVector OffsetInBoneSpace;  // 0x28(0x18)
	struct FPositionHistory History;  // 0x40(0x30)
	int32_t NumberOfSamples;  // 0x70(0x4)
	float VelocityMin;  // 0x74(0x4)
	float VelocityMax;  // 0x78(0x4)
	uint8_t  EasingType;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct FRuntimeFloatCurve CustomCurve;  // 0x80(0x88)
	float ReturnValue;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets
// Size: 0x30(Inherited: 0x0) 
struct FK2_DirectionBetweenSockets
{
	struct USkeletalMeshComponent* Component;  // 0x0(0x8)
	struct FName SocketOrBoneNameFrom;  // 0x8(0x8)
	struct FName SocketOrBoneNameTo;  // 0x10(0x8)
	struct FVector ReturnValue;  // 0x18(0x18)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange
// Size: 0x38(Inherited: 0x0) 
struct FK2_DistanceBetweenTwoSocketsAndMapRange
{
	struct USkeletalMeshComponent* Component;  // 0x0(0x8)
	struct FName SocketOrBoneNameA;  // 0x8(0x8)
	char ERelativeTransformSpace SocketSpaceA;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FName SocketOrBoneNameB;  // 0x14(0x8)
	char ERelativeTransformSpace SocketSpaceB;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool bRemapRange : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	float InRangeMin;  // 0x20(0x4)
	float InRangeMax;  // 0x24(0x4)
	float OutRangeMin;  // 0x28(0x4)
	float OutRangeMax;  // 0x2C(0x4)
	float ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraph
// Size: 0x28(Inherited: 0x0) 
struct FConvertToLinkedAnimGraph
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FLinkedAnimGraphReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap
// Size: 0x10(Inherited: 0x0) 
struct FK2_MakePerlinNoiseAndRemap
{
	float Value;  // 0x0(0x4)
	float RangeOutMin;  // 0x4(0x4)
	float RangeOutMax;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap
// Size: 0x40(Inherited: 0x0) 
struct FK2_MakePerlinNoiseVectorAndRemap
{
	float X;  // 0x0(0x4)
	float Y;  // 0x4(0x4)
	float Z;  // 0x8(0x4)
	float RangeOutMinX;  // 0xC(0x4)
	float RangeOutMaxX;  // 0x10(0x4)
	float RangeOutMinY;  // 0x14(0x4)
	float RangeOutMaxY;  // 0x18(0x4)
	float RangeOutMinZ;  // 0x1C(0x4)
	float RangeOutMaxZ;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector ReturnValue;  // 0x28(0x18)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
// Size: 0xB8(Inherited: 0x0) 
struct FK2_TwoBoneIK
{
	struct FVector RootPos;  // 0x0(0x18)
	struct FVector JointPos;  // 0x18(0x18)
	struct FVector EndPos;  // 0x30(0x18)
	struct FVector JointTarget;  // 0x48(0x18)
	struct FVector Effector;  // 0x60(0x18)
	struct FVector OutJointPos;  // 0x78(0x18)
	struct FVector OutEndPos;  // 0x90(0x18)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bAllowStretching : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float StartStretchRatio;  // 0xAC(0x4)
	float MaxStretchScale;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 
// Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraphPure
// Size: 0x28(Inherited: 0x0) 
struct FConvertToLinkedAnimGraphPure
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	struct FLinkedAnimGraphReference LinkedAnimGraph;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.LinkedAnimGraphLibrary.GetLinkedAnimInstance
// Size: 0x18(Inherited: 0x0) 
struct FGetLinkedAnimInstance
{
	struct FLinkedAnimGraphReference Node;  // 0x0(0x10)
	struct UAnimInstance* ReturnValue;  // 0x10(0x8)

}; 
// Function AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance
// Size: 0x18(Inherited: 0x0) 
struct FHasLinkedAnimInstance
{
	struct FLinkedAnimGraphReference Node;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
// Size: 0x10(Inherited: 0x0) 
struct FOnMontageBlendingOut
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnMontageEnded
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
// Size: 0x28(Inherited: 0x0) 
struct FOnNotifyBeginReceived
{
	struct FName NotifyName;  // 0x0(0x8)
	struct FBranchingPointNotifyPayload BranchingPointNotifyPayload;  // 0x8(0x20)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
// Size: 0x28(Inherited: 0x0) 
struct FOnNotifyEndReceived
{
	struct FName NotifyName;  // 0x0(0x8)
	struct FBranchingPointNotifyPayload BranchingPointNotifyPayload;  // 0x8(0x20)

}; 
// Function AnimGraphRuntime.SkeletalControlLibrary.SetAlpha
// Size: 0x28(Inherited: 0x0) 
struct FSetAlpha
{
	struct FSkeletalControlReference SkeletalControl;  // 0x0(0x10)
	float Alpha;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FSkeletalControlReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluator
// Size: 0x28(Inherited: 0x0) 
struct FConvertToSequenceEvaluator
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FSequenceEvaluatorReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluatorPure
// Size: 0x28(Inherited: 0x0) 
struct FConvertToSequenceEvaluatorPure
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	struct FSequenceEvaluatorReference SequenceEvaluator;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.GetAccumulatedTime
// Size: 0x18(Inherited: 0x0) 
struct FGetAccumulatedTime
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.GetSequence
// Size: 0x28(Inherited: 0x0) 
struct FGetSequence
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	struct UAnimSequenceBase* SequenceBase;  // 0x10(0x8)
	struct FSequencePlayerReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitTime
// Size: 0x28(Inherited: 0x0) 
struct FSetExplicitTime
{
	struct FSequenceEvaluatorReference SequenceEvaluator;  // 0x0(0x10)
	float time;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FSequenceEvaluatorReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.SetSequence
// Size: 0x28(Inherited: 0x0) 
struct FSetSequence
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	struct UAnimSequenceBase* Sequence;  // 0x10(0x8)
	struct FSequencePlayerReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.SetSequenceWithInertialBlending
// Size: 0x40(Inherited: 0x0) 
struct FSetSequenceWithInertialBlending
{
	struct FAnimUpdateContext UpdateContext;  // 0x0(0x10)
	struct FSequencePlayerReference SequencePlayer;  // 0x10(0x10)
	struct UAnimSequenceBase* Sequence;  // 0x20(0x8)
	float BlendTime;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FSequencePlayerReference ReturnValue;  // 0x30(0x10)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayerPure
// Size: 0x28(Inherited: 0x0) 
struct FConvertToSequencePlayerPure
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	struct FSequencePlayerReference SequencePlayer;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.GetLoopAnimation
// Size: 0x18(Inherited: 0x0) 
struct FGetLoopAnimation
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.GetPlayRate
// Size: 0x18(Inherited: 0x0) 
struct FGetPlayRate
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.GetSequencePure
// Size: 0x18(Inherited: 0x0) 
struct FGetSequencePure
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	struct UAnimSequenceBase* ReturnValue;  // 0x10(0x8)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.GetStartPosition
// Size: 0x18(Inherited: 0x0) 
struct FGetStartPosition
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.SetAccumulatedTime
// Size: 0x28(Inherited: 0x0) 
struct FSetAccumulatedTime
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float time;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FSequencePlayerReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.SetPlayRate
// Size: 0x28(Inherited: 0x0) 
struct FSetPlayRate
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float PlayRate;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FSequencePlayerReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition
// Size: 0x28(Inherited: 0x0) 
struct FSetStartPosition
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float StartPosition;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FSequencePlayerReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControl
// Size: 0x28(Inherited: 0x0) 
struct FConvertToSkeletalControl
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FSkeletalControlReference ReturnValue;  // 0x18(0x10)

}; 
// Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControlPure
// Size: 0x28(Inherited: 0x0) 
struct FConvertToSkeletalControlPure
{
	struct FAnimNodeReference Node;  // 0x0(0x10)
	struct FSkeletalControlReference SkeletalControl;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
