#pragma once 
#include <BP_Projectile_5_56_46_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Projectile_5_56_46.BP_Projectile_5_56_45_C
// Size: 0x498(Inherited: 0x488) 
struct ABP_Projectile_5_56_45_C : public ATraceProjectile
{
	struct UStaticMeshComponent* Cube;  // 0x488(0x8)
	struct USceneComponent* Scene;  // 0x490(0x8)

}; 



