#pragma once 
#include "SDK.h" 
 
 
// Function FunctionLibrary.FunctionLibrary_C.GetGameInstance
// Size: 0x21(Inherited: 0x0) 
struct FGetGameInstance
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UBP_PG_GameInstance_C* MyGameIntance;  // 0x8(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct UBP_PG_GameInstance_C* K2Node_DynamicCast_AsBP_PG_Game_Instance;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function FunctionLibrary.FunctionLibrary_C.GetGameModeBP_Game
// Size: 0x21(Inherited: 0x0) 
struct FGetGameModeBP_Game
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ABP_PG_GameMode_Game_C* MyGameMode;  // 0x8(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct ABP_PG_GameMode_Game_C* K2Node_DynamicCast_AsBP_PG_Game_Mode_Game;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function FunctionLibrary.FunctionLibrary_C.GetGameStateBP
// Size: 0x21(Inherited: 0x0) 
struct FGetGameStateBP
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ABP_PG_GameState_Game_C* MyGameState;  // 0x8(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct ABP_PG_GameState_Game_C* K2Node_DynamicCast_AsBP_PG_Game_State_Game;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
