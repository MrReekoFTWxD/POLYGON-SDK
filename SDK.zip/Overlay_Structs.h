#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Overlay.OverlayItem
// Size: 0x30(Inherited: 0x0) 
struct FOverlayItem
{
	struct FTimespan StartTime;  // 0x0(0x8)
	struct FTimespan EndTime;  // 0x8(0x8)
	struct FString Text;  // 0x10(0x10)
	struct FVector2D position;  // 0x20(0x10)

}; 
