#pragma once 
#include <OnlineSubsystemBlueprints_Structs.h>
 
 
 
// Class OnlineSubsystemBlueprints.OnlineAchievementsSubsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlineAchievementsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnAchievementUnlocked;  // 0x58(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.IsSubsystemAvailable
	uint8_t  GetCachedAchievements(struct FUniqueNetIdRepl PlayerId, struct TArray<struct FOnlineAchievementBP>& OutAchievements); // Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.GetCachedAchievements
	uint8_t  GetCachedAchievementDescription(struct FString AchievementId, struct FOnlineAchievementDescBP& OutAchievementDesc); // Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.GetCachedAchievementDescription
	uint8_t  GetCachedAchievement(struct FUniqueNetIdRepl PlayerId, struct FString AchievementId, struct FOnlineAchievementBP& OutAchievement); // Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.GetCachedAchievement
}; 



// Class OnlineSubsystemBlueprints.OnlineUserRef
// Size: 0x48(Inherited: 0x28) 
struct UOnlineUserRef : public UObject
{
	char pad_40[32];  // 0x28(0x20)

	void SetUserLocalAttribute(struct FString Key, struct FString Value, bool& Success); // Function OnlineSubsystemBlueprints.OnlineUserRef.SetUserLocalAttribute
	struct FUniqueNetIdRepl GetUserId(); // Function OnlineSubsystemBlueprints.OnlineUserRef.GetUserId
	struct FString GetUserAttribute(struct FString Key, bool& Found); // Function OnlineSubsystemBlueprints.OnlineUserRef.GetUserAttribute
	struct FString GetRealName(); // Function OnlineSubsystemBlueprints.OnlineUserRef.GetRealName
	struct FString GetDisplayName(); // Function OnlineSubsystemBlueprints.OnlineUserRef.GetDisplayName
}; 



// Class OnlineSubsystemBlueprints.OnlineChatSubsystem
// Size: 0x110(Inherited: 0x30) 
struct UOnlineChatSubsystem : public UGameInstanceSubsystem
{
	char pad_48[96];  // 0x30(0x60)
	struct FMulticastInlineDelegate OnChatRoomCreated;  // 0x90(0x10)
	struct FMulticastInlineDelegate OnChatRoomConfigured;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnChatRoomJoinPublic;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnChatRoomJoinPrivate;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnChatRoomExit;  // 0xD0(0x10)
	struct FMulticastInlineDelegate OnChatRoomMemberJoin;  // 0xE0(0x10)
	struct FMulticastInlineDelegate OnChatRoomMemberExit;  // 0xF0(0x10)
	struct FMulticastInlineDelegate OnChatRoomMemberUpdate;  // 0x100(0x10)

	bool SendRoomChat(struct FUniqueNetIdRepl UserId, struct FString RoomId, struct FString MsgBody); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.SendRoomChat
	bool SendPrivateChat(struct FUniqueNetIdRepl UserId, struct FUniqueNetIdRepl RecipientId, struct FString MsgBody); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.SendPrivateChat
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.IsSubsystemAvailable
	bool IsChatAllowed(struct FUniqueNetIdRepl UserId, struct FUniqueNetIdRepl RecipientId); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.IsChatAllowed
	void GetJoinedRooms(struct FUniqueNetIdRepl UserId, struct TArray<struct FString>& OutRooms); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.GetJoinedRooms
	bool ExitRoom(struct FUniqueNetIdRepl UserId, struct FString RoomId); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.ExitRoom
	void DumpChatState(); // Function OnlineSubsystemBlueprints.OnlineChatSubsystem.DumpChatState
}; 



// Class OnlineSubsystemBlueprints.OnlineIdentitySubsystem
// Size: 0xE0(Inherited: 0x30) 
struct UOnlineIdentitySubsystem : public UGameInstanceSubsystem
{
	char pad_48[96];  // 0x30(0x60)
	struct FMulticastInlineDelegate OnLoginChanged;  // 0x90(0x10)
	struct FMulticastInlineDelegate OnLoginStatusChanged;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnLoginComplete;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnLogoutComplete;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnLoginFlowLogout;  // 0xD0(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.IsSubsystemAvailable
	struct UUserOnlineAccountRef* GetUserAccount(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetUserAccount
	struct FUniqueNetIdRepl GetUniquePlayerId(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetUniquePlayerId
	struct FUniqueNetIdRepl GetSponsorUniquePlayerId(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetSponsorUniquePlayerId
	struct FString GetPlayerNickname(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetPlayerNickname
	int32_t GetPlatformUserIdFromUniqueNetId(struct FUniqueNetIdRepl UniqueNetId); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetPlatformUserIdFromUniqueNetId
	uint8_t  GetLoginStatus(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetLoginStatus
	struct FString GetAuthType(); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetAuthType
	struct FString GetAuthToken(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetAuthToken
	struct TArray<struct UUserOnlineAccountRef*> GetAllUserAccounts(); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetAllUserAccounts
	struct FUniqueNetIdRepl CreateUniquePlayerId(struct FString Str); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.CreateUniquePlayerId
	void ClearCachedAuthToken(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.ClearCachedAuthToken
}; 



// Class OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievements
// Size: 0x88(Inherited: 0x30) 
struct UOnlineAchievementsSubsystemQueryAchievements : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryAchievementsComplete;  // 0x40(0x10)
	struct UOnlineAchievementsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__PlayerId;  // 0x58(0x30)

	struct UOnlineAchievementsSubsystemQueryAchievements* QueryAchievements(struct UOnlineAchievementsSubsystem* Subsystem, struct FUniqueNetIdRepl PlayerId); // Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievements.QueryAchievements
}; 



// Class OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatar
// Size: 0xC0(Inherited: 0x30) 
struct UOnlineAvatarSubsystemGetAvatar : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnGetAvatarComplete;  // 0x40(0x10)
	struct UOnlineAvatarSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FUniqueNetIdRepl __Store__TargetUserId;  // 0x88(0x30)
	struct UTexture* __Store__DefaultTexture;  // 0xB8(0x8)

	struct UOnlineAvatarSubsystemGetAvatar* GetAvatar(struct UOnlineAvatarSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FUniqueNetIdRepl TargetUserId, struct UTexture* DefaultTexture); // Function OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatar.GetAvatar
}; 



// Class OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievementDescriptions
// Size: 0x88(Inherited: 0x30) 
struct UOnlineAchievementsSubsystemQueryAchievementDescriptions : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryAchievementsComplete;  // 0x40(0x10)
	struct UOnlineAchievementsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__PlayerId;  // 0x58(0x30)

	struct UOnlineAchievementsSubsystemQueryAchievementDescriptions* QueryAchievementDescriptions(struct UOnlineAchievementsSubsystem* Subsystem, struct FUniqueNetIdRepl PlayerId); // Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievementDescriptions.QueryAchievementDescriptions
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsForFriends
// Size: 0x70(Inherited: 0x30) 
struct UOnlineLeaderboardsSubsystemReadLeaderboardsForFriends : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLeaderboardReadComplete;  // 0x40(0x10)
	struct UOnlineLeaderboardsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UOnlineLeaderboardRead* __Store__ReadObject;  // 0x68(0x8)

	struct UOnlineLeaderboardsSubsystemReadLeaderboardsForFriends* ReadLeaderboardsForFriends(struct UOnlineLeaderboardsSubsystem* Subsystem, int32_t LocalUserNum, struct UOnlineLeaderboardRead* ReadObject); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsForFriends.ReadLeaderboardsForFriends
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSearch
// Size: 0xB0(Inherited: 0x28) 
struct UOnlineSessionSearch : public UObject
{
	char pad_40[32];  // 0x28(0x20)
	int32_t MaxSearchResults;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bIsLanQuery : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	int32_t PingBucketSize;  // 0x50(0x4)
	int32_t PlatformHash;  // 0x54(0x4)
	float TimeoutInSeconds;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct TMap<struct FName, struct FSessionSearchParamBP> SearchParams;  // 0x60(0x50)

	uint8_t  GetSearchState(); // Function OnlineSubsystemBlueprints.OnlineSessionSearch.GetSearchState
	struct TArray<struct FOnlineSessionSearchResultBP> GetSearchResults(); // Function OnlineSubsystemBlueprints.OnlineSessionSearch.GetSearchResults
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemAcceptInvite
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineFriendsSubsystemAcceptInvite : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnAcceptInviteComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0x60(0x30)
	struct FString __Store__ListName;  // 0x90(0x10)

	struct UOnlineFriendsSubsystemAcceptInvite* AcceptInvite(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemAcceptInvite.AcceptInvite
}; 



// Class OnlineSubsystemBlueprints.OnlineUserCloudSubsystemReadUserFile
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineUserCloudSubsystemReadUserFile : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnReadUserFileComplete;  // 0x40(0x10)
	struct UOnlineUserCloudSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x60(0x30)
	struct FString __Store__FileName;  // 0x90(0x10)

	struct UOnlineUserCloudSubsystemReadUserFile* ReadUserFile(struct UOnlineUserCloudSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString Filename); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemReadUserFile.ReadUserFile
}; 



// Class OnlineSubsystemBlueprints.OnlineIdentitySubsystemLogin
// Size: 0x98(Inherited: 0x30) 
struct UOnlineIdentitySubsystemLogin : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLoginComplete;  // 0x40(0x10)
	struct UOnlineIdentitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FOnlineAccountCredential __Store__AccountCredentials;  // 0x68(0x30)

	struct UOnlineIdentitySubsystemLogin* Login(struct UOnlineIdentitySubsystem* Subsystem, int32_t LocalUserNum, struct FOnlineAccountCredential AccountCredentials); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemLogin.Login
}; 



// Class OnlineSubsystemBlueprints.OnlineAvatarSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineAvatarSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineAvatarSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystem
// Size: 0x208(Inherited: 0x30) 
struct UOnlineFriendsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[216];  // 0x30(0xD8)
	struct FMulticastInlineDelegate OnFriendsChange;  // 0x108(0x10)
	struct FMulticastInlineDelegate OnOutgoingInviteSent;  // 0x118(0x10)
	struct FMulticastInlineDelegate OnInviteReceived;  // 0x128(0x10)
	struct FMulticastInlineDelegate OnInviteAccepted;  // 0x138(0x10)
	struct FMulticastInlineDelegate OnInviteRejected;  // 0x148(0x10)
	struct FMulticastInlineDelegate OnInviteAborted;  // 0x158(0x10)
	struct FMulticastInlineDelegate OnFriendRemoved;  // 0x168(0x10)
	struct FMulticastInlineDelegate OnRejectInviteComplete;  // 0x178(0x10)
	struct FMulticastInlineDelegate OnDeleteFriendComplete;  // 0x188(0x10)
	struct FMulticastInlineDelegate OnBlockedPlayerComplete;  // 0x198(0x10)
	struct FMulticastInlineDelegate OnUnblockedPlayerComplete;  // 0x1A8(0x10)
	struct FMulticastInlineDelegate OnBlockListChange;  // 0x1B8(0x10)
	struct FMulticastInlineDelegate OnQueryRecentPlayersComplete;  // 0x1C8(0x10)
	struct FMulticastInlineDelegate OnQueryBlockedPlayersComplete;  // 0x1D8(0x10)
	struct FMulticastInlineDelegate OnRecentPlayersAdded;  // 0x1E8(0x10)
	struct FMulticastInlineDelegate OnFriendSettingsUpdated;  // 0x1F8(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.IsSubsystemAvailable
	bool IsFriend(int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.IsFriend
	bool GetRecentPlayers(struct FUniqueNetIdRepl UserId, struct FString Namespace, struct TArray<struct UOnlineRecentPlayerRef*>& OutRecentPlayers); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetRecentPlayers
	bool GetFriendsList(int32_t LocalUserNum, struct FString ListName, struct TArray<struct UOnlineFriendRef*>& OutFriends); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetFriendsList
	bool GetFriendSettings(struct FUniqueNetIdRepl UserId, struct TMap<struct FString, struct FOnlineFriendSettingsSourceDataConfig>& OutSettings); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetFriendSettings
	struct UOnlineFriendRef* GetFriend(int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetFriend
	bool GetBlockedPlayers(struct FUniqueNetIdRepl UserId, struct TArray<struct UOnlineUserRef*>& OutBlockedPlayers); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetBlockedPlayers
	void DumpRecentPlayers(); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.DumpRecentPlayers
	void DumpBlockedPlayers(); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.DumpBlockedPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatarUrl
// Size: 0xC8(Inherited: 0x30) 
struct UOnlineAvatarSubsystemGetAvatarUrl : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnGetAvatarUrlComplete;  // 0x40(0x10)
	struct UOnlineAvatarSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FUniqueNetIdRepl __Store__TargetUserId;  // 0x88(0x30)
	struct FString __Store__DefaultAvatarUrl;  // 0xB8(0x10)

	struct UOnlineAvatarSubsystemGetAvatarUrl* GetAvatarUrl(struct UOnlineAvatarSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FUniqueNetIdRepl TargetUserId, struct FString DefaultAvatarUrl); // Function OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatarUrl.GetAvatarUrl
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowLoginUI
// Size: 0x60(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowLoginUI : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLoginUIClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__ControllerIndex;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool __Store__bShowOnlineOnly : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool __Store__bShowSkipButton : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)

	struct UOnlineExternalUISubsystemShowLoginUI* ShowLoginUI(struct UOnlineExternalUISubsystem* Subsystem, int32_t ControllerIndex, bool bShowOnlineOnly, bool bShowSkipButton); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowLoginUI.ShowLoginUI
}; 



// Class OnlineSubsystemBlueprints.VoiceChatUser
// Size: 0x178(Inherited: 0x28) 
struct UVoiceChatUser : public UObject
{
	char pad_40[96];  // 0x28(0x60)
	struct FMulticastInlineDelegate OnVoiceChatAvailableAudioDevicesChanged;  // 0x88(0x10)
	char pad_152[8];  // 0x98(0x8)
	struct FMulticastInlineDelegate OnVoiceChatLoggedIn;  // 0xA0(0x10)
	char pad_176[8];  // 0xB0(0x8)
	struct FMulticastInlineDelegate OnVoiceChatLoggedOut;  // 0xB8(0x10)
	char pad_200[8];  // 0xC8(0x8)
	struct FMulticastInlineDelegate OnVoiceChatChannelJoined;  // 0xD0(0x10)
	char pad_224[8];  // 0xE0(0x8)
	struct FMulticastInlineDelegate OnVoiceChatChannelExited;  // 0xE8(0x10)
	char pad_248[8];  // 0xF8(0x8)
	struct FMulticastInlineDelegate OnVoiceChatPlayerAdded;  // 0x100(0x10)
	char pad_272[8];  // 0x110(0x8)
	struct FMulticastInlineDelegate OnVoiceChatPlayerRemoved;  // 0x118(0x10)
	char pad_296[8];  // 0x128(0x8)
	struct FMulticastInlineDelegate OnVoiceChatPlayerTalkingUpdated;  // 0x130(0x10)
	char pad_320[8];  // 0x140(0x8)
	struct FMulticastInlineDelegate OnVoiceChatPlayerMuteUpdated;  // 0x148(0x10)
	char pad_344[8];  // 0x158(0x8)
	struct FMulticastInlineDelegate OnVoiceChatPlayerVolumeUpdated;  // 0x160(0x10)
	char pad_368[8];  // 0x170(0x8)

	void UnblockPlayers(struct TArray<struct FString> PlayerNames); // Function OnlineSubsystemBlueprints.VoiceChatUser.UnblockPlayers
	void TransmitToSpecificChannel(struct FString ChannelName); // Function OnlineSubsystemBlueprints.VoiceChatUser.TransmitToSpecificChannel
	void TransmitToNoChannels(); // Function OnlineSubsystemBlueprints.VoiceChatUser.TransmitToNoChannels
	void TransmitToAllChannels(); // Function OnlineSubsystemBlueprints.VoiceChatUser.TransmitToAllChannels
	void SetSetting(struct FString Name, struct FString Value); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetSetting
	void SetPlayerVolume(struct FString PlayerName, float Volume); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetPlayerVolume
	void SetPlayerMuted(struct FString PlayerName, bool bMuted); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetPlayerMuted
	void SetOutputDeviceId(struct FString OutputDeviceId); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetOutputDeviceId
	void SetInputDeviceId(struct FString InputDeviceId); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetInputDeviceId
	void SetChannelPlayerMuted(struct FString ChannelName, struct FString PlayerName, bool bAudioMuted); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetChannelPlayerMuted
	void SetAudioOutputVolume(float Volume); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioOutputVolume
	void SetAudioOutputDeviceMuted(bool bIsMuted); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioOutputDeviceMuted
	void SetAudioInputVolume(float Volume); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioInputVolume
	void SetAudioInputDeviceMuted(bool bIsMuted); // Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioInputDeviceMuted
	void Set3DPosition(struct FString ChannelName, struct FVector SpeakerPosition, struct FVector ListenerPosition, struct FVector ListenerForwardDirection, struct FVector ListenerUpDirection); // Function OnlineSubsystemBlueprints.VoiceChatUser.Set3DPosition
	bool IsPlayerTalking(struct FString PlayerName); // Function OnlineSubsystemBlueprints.VoiceChatUser.IsPlayerTalking
	bool IsPlayerMuted(struct FString PlayerName); // Function OnlineSubsystemBlueprints.VoiceChatUser.IsPlayerMuted
	bool IsLoggingIn(); // Function OnlineSubsystemBlueprints.VoiceChatUser.IsLoggingIn
	bool IsLoggedIn(); // Function OnlineSubsystemBlueprints.VoiceChatUser.IsLoggedIn
	bool IsChannelPlayerMuted(struct FString ChannelName, struct FString PlayerName); // Function OnlineSubsystemBlueprints.VoiceChatUser.IsChannelPlayerMuted
	struct FString InsecureGetLoginToken(struct FString PlayerName); // Function OnlineSubsystemBlueprints.VoiceChatUser.InsecureGetLoginToken
	struct FString InsecureGetJoinToken(struct FString ChannelName, uint8_t  ChannelType, struct FVoiceChatChannel3dPropertiesBP Channel3dProperties); // Function OnlineSubsystemBlueprints.VoiceChatUser.InsecureGetJoinToken
	uint8_t  GetTransmitMode(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetTransmitMode
	struct FString GetTransmitChannel(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetTransmitChannel
	struct FString GetSetting(struct FString Name); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetSetting
	float GetPlayerVolume(struct FString PlayerName); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetPlayerVolume
	struct TArray<struct FString> GetPlayersInChannel(struct FString ChannelName); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetPlayersInChannel
	struct FVoiceChatDeviceInfoBP GetOutputDeviceInfo(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetOutputDeviceInfo
	struct FString GetLoggedInPlayerName(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetLoggedInPlayerName
	struct FVoiceChatDeviceInfoBP GetInputDeviceInfo(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetInputDeviceInfo
	struct FVoiceChatDeviceInfoBP GetDefaultOutputDeviceInfo(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetDefaultOutputDeviceInfo
	struct FVoiceChatDeviceInfoBP GetDefaultInputDeviceInfo(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetDefaultInputDeviceInfo
	uint8_t  GetChannelType(struct FString ChannelName); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetChannelType
	struct TArray<struct FString> GetChannels(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetChannels
	struct TArray<struct FVoiceChatDeviceInfoBP> GetAvailableOutputDeviceInfos(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetAvailableOutputDeviceInfos
	struct TArray<struct FVoiceChatDeviceInfoBP> GetAvailableInputDeviceInfos(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetAvailableInputDeviceInfos
	float GetAudioOutputVolume(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioOutputVolume
	bool GetAudioOutputDeviceMuted(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioOutputDeviceMuted
	float GetAudioInputVolume(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioInputVolume
	bool GetAudioInputDeviceMuted(); // Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioInputDeviceMuted
	void BlockPlayers(struct TArray<struct FString> PlayerNames); // Function OnlineSubsystemBlueprints.VoiceChatUser.BlockPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlinePurchaseSubsystemQueryReceipts
// Size: 0x90(Inherited: 0x30) 
struct UOnlinePurchaseSubsystemQueryReceipts : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryReceiptsComplete;  // 0x40(0x10)
	struct UOnlinePurchaseSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool __Store__bRestoreReceipts : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

	struct UOnlinePurchaseSubsystemQueryReceipts* QueryReceipts(struct UOnlinePurchaseSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, bool bRestoreReceipts); // Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystemQueryReceipts.QueryReceipts
}; 



// Class OnlineSubsystemBlueprints.OnlineEntitlementsSubsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlineEntitlementsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnQueryEntitlementsComplete;  // 0x58(0x10)

	bool QueryEntitlements(struct FUniqueNetIdRepl UserId, struct FString Namespace, struct FPagedQueryBP Page); // Function OnlineSubsystemBlueprints.OnlineEntitlementsSubsystem.QueryEntitlements
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineEntitlementsSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResumeActivity
// Size: 0xC0(Inherited: 0x30) 
struct UOnlineGameActivitySubsystemResumeActivity : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnResumeActivityComplete;  // 0x40(0x10)
	struct UOnlineGameActivitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ActivityId;  // 0x88(0x10)
	struct FOnlineActivityTasksToResetBP __Store__TasksToReset;  // 0x98(0x28)

	struct UOnlineGameActivitySubsystemResumeActivity* ResumeActivity(struct UOnlineGameActivitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ActivityId, struct FOnlineActivityTasksToResetBP TasksToReset); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResumeActivity.ResumeActivity
}; 



// Class OnlineSubsystemBlueprints.OnlineEventsSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineEventsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineEventsSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystem
// Size: 0x120(Inherited: 0x30) 
struct UOnlineExternalUISubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct TArray<struct FExternalUIFlowHandlerRegistration> FlowHandlers;  // 0x58(0x10)
	char pad_104[168];  // 0x68(0xA8)
	struct FMulticastInlineDelegate OnExternalUIChange;  // 0x110(0x10)

	bool ShowPlatformMessageBox(struct FUniqueNetIdRepl UserId, uint8_t  MessageType); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowPlatformMessageBox
	bool ShowLeaderboardUI(struct FString LeaderboardName); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowLeaderboardUI
	bool ShowInviteUI(int32_t LocalUserNum, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowInviteUI
	bool ShowFriendsUI(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowFriendsUI
	bool ShowAchievementsUI(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowAchievementsUI
	bool ShowAccountUpgradeUI(struct FUniqueNetIdRepl UniqueId); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowAccountUpgradeUI
	void ReportExitInGameStoreUI(); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ReportExitInGameStoreUI
	void ReportEnterInGameStoreUI(); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ReportEnterInGameStoreUI
	void RemoveLoginFlowHandler(struct TScriptInterface<IExternalUIFlowHandler>& Handler); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.RemoveLoginFlowHandler
	struct FLoginFlowResultBP NotifyLoginRedirectURL(int32_t RequestId, struct FString URL); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.NotifyLoginRedirectURL
	void LoginFlowComplete(int32_t RequestId, struct FLoginFlowResultBP Result); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.LoginFlowComplete
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.IsSubsystemAvailable
	bool CloseWebURL(); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.CloseWebURL
	void AddLoginFlowHandler(struct TScriptInterface<IExternalUIFlowHandler>& Handler); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.AddLoginFlowHandler
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowAccountCreationUI
// Size: 0x60(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowAccountCreationUI : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnAccountCreationUIClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__ControllerIndex;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

	struct UOnlineExternalUISubsystemShowAccountCreationUI* ShowAccountCreationUI(struct UOnlineExternalUISubsystem* Subsystem, int32_t ControllerIndex); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowAccountCreationUI.ShowAccountCreationUI
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowWebURL
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowWebURL : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnShowWebUrlClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FString __Store__Url;  // 0x58(0x10)
	struct FShowWebUrlParameters __Store__ShowParams;  // 0x68(0x38)

	struct UOnlineExternalUISubsystemShowWebURL* ShowWebURL(struct UOnlineExternalUISubsystem* Subsystem, struct FString URL, struct FShowWebUrlParameters ShowParams); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowWebURL.ShowWebURL
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowProfileUI
// Size: 0xB8(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowProfileUI : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnProfileUIClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__Requestor;  // 0x58(0x30)
	struct FUniqueNetIdRepl __Store__Requestee;  // 0x88(0x30)

	struct UOnlineExternalUISubsystemShowProfileUI* ShowProfileUI(struct UOnlineExternalUISubsystem* Subsystem, struct FUniqueNetIdRepl Requestor, struct FUniqueNetIdRepl Requestee); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowProfileUI.ShowProfileUI
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlineGameActivitySubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnGameActivityActivationRequested;  // 0x58(0x10)

	void UpdatePlayerLocation(struct FUniqueNetIdRepl LocalUserId, struct FOnlineActivityPlayerLocationBP& ActivityPlayerLocation); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystem.UpdatePlayerLocation
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowStoreUI
// Size: 0x88(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowStoreUI : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnShowStoreUIClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FShowStoreParameters __Store__ShowParams;  // 0x60(0x28)

	struct UOnlineExternalUISubsystemShowStoreUI* ShowStoreUI(struct UOnlineExternalUISubsystem* Subsystem, int32_t LocalUserNum, struct FShowStoreParameters ShowParams); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowStoreUI.ShowStoreUI
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageUI
// Size: 0x150(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowSendMessageUI : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnShowSendMessageUIClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FShowSendMessageParameters __Store__ShowParams;  // 0x60(0xF0)

	struct UOnlineExternalUISubsystemShowSendMessageUI* ShowSendMessageUI(struct UOnlineExternalUISubsystem* Subsystem, int32_t LocalUserNum, struct FShowSendMessageParameters ShowParams); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageUI.ShowSendMessageUI
}; 



// Class OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageToUserUI
// Size: 0x180(Inherited: 0x30) 
struct UOnlineExternalUISubsystemShowSendMessageToUserUI : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnShowSendMessageUIClosed;  // 0x40(0x10)
	struct UOnlineExternalUISubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FUniqueNetIdRepl __Store__Recipient;  // 0x60(0x30)
	struct FShowSendMessageParameters __Store__ShowParams;  // 0x90(0xF0)

	struct UOnlineExternalUISubsystemShowSendMessageToUserUI* ShowSendMessageToUserUI(struct UOnlineExternalUISubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl Recipient, struct FShowSendMessageParameters ShowParams); // Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageToUserUI.ShowSendMessageToUserUI
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundUser
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineLeaderboardsSubsystemReadLeaderboardsAroundUser : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLeaderboardReadComplete;  // 0x40(0x10)
	struct UOnlineLeaderboardsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__Player;  // 0x60(0x30)
	int64_t __Store__Range;  // 0x90(0x8)
	struct UOnlineLeaderboardRead* __Store__ReadObject;  // 0x98(0x8)

	struct UOnlineLeaderboardsSubsystemReadLeaderboardsAroundUser* ReadLeaderboardsAroundUser(struct UOnlineLeaderboardsSubsystem* Subsystem, struct FUniqueNetIdRepl Player, int64_t Range, struct UOnlineLeaderboardRead* ReadObject); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundUser.ReadLeaderboardsAroundUser
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemReadFriendsList
// Size: 0x70(Inherited: 0x30) 
struct UOnlineFriendsSubsystemReadFriendsList : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnReadFriendsListComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString __Store__ListName;  // 0x60(0x10)

	struct UOnlineFriendsSubsystemReadFriendsList* ReadFriendsList(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemReadFriendsList.ReadFriendsList
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemLoadoutChange
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystemItemLoadoutChange : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnItemLoadoutChangeComplete;  // 0x40(0x10)
	struct UOnlineGameItemStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FString> __Store__EquippedItems;  // 0x88(0x10)
	struct TArray<struct FString> __Store__UnequippedItems;  // 0x98(0x10)

	struct UOnlineGameItemStatsSubsystemItemLoadoutChange* ItemLoadoutChange(struct UOnlineGameItemStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FString> EquippedItems, struct TArray<struct FString> UnequippedItems); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemLoadoutChange.ItemLoadoutChange
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendsList
// Size: 0x70(Inherited: 0x30) 
struct UOnlineFriendsSubsystemDeleteFriendsList : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnDeleteFriendsListComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString __Store__ListName;  // 0x60(0x10)

	struct UOnlineFriendsSubsystemDeleteFriendsList* DeleteFriendsList(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendsList.DeleteFriendsList
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriend
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineFriendsSubsystemDeleteFriend : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnDeleteFriendComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0x68(0x30)
	struct FString __Store__ListName;  // 0x98(0x10)

	struct UOnlineFriendsSubsystemDeleteFriend* DeleteFriend(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriend.DeleteFriend
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemSendInvite
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineFriendsSubsystemSendInvite : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSendInviteComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0x60(0x30)
	struct FString __Store__ListName;  // 0x90(0x10)

	struct UOnlineFriendsSubsystemSendInvite* SendInvite(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemSendInvite.SendInvite
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystemEndActivity
// Size: 0xF0(Inherited: 0x30) 
struct UOnlineGameActivitySubsystemEndActivity : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnEndActivityComplete;  // 0x40(0x10)
	struct UOnlineGameActivitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ActivityId;  // 0x88(0x10)
	uint8_t  __Store__ActivityOutcome;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct TMap<struct FString, struct FVariantDataBP> __Store__Parms;  // 0xA0(0x50)

	struct UOnlineGameActivitySubsystemEndActivity* EndActivity(struct UOnlineGameActivitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ActivityId, uint8_t  ActivityOutcome, struct TMap<struct FString, struct FVariantDataBP> Params); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemEndActivity.EndActivity
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemRejectInvite
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineFriendsSubsystemRejectInvite : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnRejectInviteComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0x68(0x30)
	struct FString __Store__ListName;  // 0x98(0x10)

	struct UOnlineFriendsSubsystemRejectInvite* RejectInvite(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemRejectInvite.RejectInvite
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateLobby
// Size: 0x98(Inherited: 0x30) 
struct UOnlineLobbySubsystemUpdateLobby : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyOperationComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct ULobbyId* __Store__LobbyId;  // 0x88(0x8)
	struct UOnlineLobbyTransaction* __Store__Transaction;  // 0x90(0x8)

	struct UOnlineLobbySubsystemUpdateLobby* UpdateLobby(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, struct UOnlineLobbyTransaction* Transaction); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateLobby.UpdateLobby
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendAlias
// Size: 0xB0(Inherited: 0x30) 
struct UOnlineFriendsSubsystemSetFriendAlias : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSetFriendAliasComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0x60(0x30)
	struct FString __Store__ListName;  // 0x90(0x10)
	struct FString __Store__Alias;  // 0xA0(0x10)

	struct UOnlineFriendsSubsystemSetFriendAlias* SetFriendAlias(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName, struct FString Alias); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendAlias.SetFriendAlias
}; 



// Class OnlineSubsystemBlueprints.OnlineHelpers
// Size: 0x28(Inherited: 0x28) 
struct UOnlineHelpers : public UBlueprintFunctionLibrary
{

	struct FString ReadFileDataAsString(struct UFileData* FileData); // Function OnlineSubsystemBlueprints.OnlineHelpers.ReadFileDataAsString
	struct USaveGame* ReadFileDataAsSaveGame(struct UFileData* FileData); // Function OnlineSubsystemBlueprints.OnlineHelpers.ReadFileDataAsSaveGame
	bool IsValid_PartyId(struct UPartyId* A); // Function OnlineSubsystemBlueprints.OnlineHelpers.IsValid_PartyId
	bool IsValid_LobbyId(struct ULobbyId* A); // Function OnlineSubsystemBlueprints.OnlineHelpers.IsValid_LobbyId
	void GetResolvedConnectStringBySearchResult(struct UOnlineSessionSubsystem* Subsystem, struct FOnlineSessionSearchResultBP SearchResult, struct FName PortType, bool& bWasSuccessful, struct FString& OutConnectInfo); // Function OnlineSubsystemBlueprints.OnlineHelpers.GetResolvedConnectStringBySearchResult
	void GetResolvedConnectStringByName(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName, struct FName PortType, bool& bWasSuccessful, struct FString& OutConnectInfo); // Function OnlineSubsystemBlueprints.OnlineHelpers.GetResolvedConnectStringByName
	int64_t GetPrimaryPartyType(); // Function OnlineSubsystemBlueprints.OnlineHelpers.GetPrimaryPartyType
	struct FUniqueNetIdRepl GetPlayerStateUniqueNetId(struct APlayerState* PlayerState); // Function OnlineSubsystemBlueprints.OnlineHelpers.GetPlayerStateUniqueNetId
	struct FName GetCurrentSubsystemName(struct UObject* WorldContextObject); // Function OnlineSubsystemBlueprints.OnlineHelpers.GetCurrentSubsystemName
	struct FUniqueNetIdRepl GetControllerUniqueNetId(struct APlayerController* PlayerController); // Function OnlineSubsystemBlueprints.OnlineHelpers.GetControllerUniqueNetId
	bool FUniqueNetIdIsValid(struct FUniqueNetIdRepl InNetId); // Function OnlineSubsystemBlueprints.OnlineHelpers.FUniqueNetIdIsValid
	struct FName FUniqueNetIdGetType(struct FUniqueNetIdRepl InNetId); // Function OnlineSubsystemBlueprints.OnlineHelpers.FUniqueNetIdGetType
	bool EqualEqual_PartyIdPartyId(struct UPartyId* A, struct UPartyId* B); // Function OnlineSubsystemBlueprints.OnlineHelpers.EqualEqual_PartyIdPartyId
	bool EqualEqual_LobbyIdLobbyId(struct ULobbyId* A, struct ULobbyId* B); // Function OnlineSubsystemBlueprints.OnlineHelpers.EqualEqual_LobbyIdLobbyId
	bool EqualEqual_FUniqueNetIdReplFUniqueNetIdRepl(struct FUniqueNetIdRepl& InA, struct FUniqueNetIdRepl& InB); // Function OnlineSubsystemBlueprints.OnlineHelpers.EqualEqual_FUniqueNetIdReplFUniqueNetIdRepl
	struct UMutablePartyData* CreateMutablePartyData(struct UReadablePartyData* ReadOnlyPartyData); // Function OnlineSubsystemBlueprints.OnlineHelpers.CreateMutablePartyData
	struct UFileData* CreateFileDataFromString(struct FString String); // Function OnlineSubsystemBlueprints.OnlineHelpers.CreateFileDataFromString
	struct UFileData* CreateFileDataFromSaveGame(struct USaveGame* SaveGame); // Function OnlineSubsystemBlueprints.OnlineHelpers.CreateFileDataFromSaveGame
	struct UOnlinePartyJoinInfo* Conv_ULobbyIdToUOnlinePartyJoinInfo(struct FUniqueNetIdRepl InLocalUserId, struct UOnlinePartySubsystem* InPartySubsystem, struct ULobbyId* InLobbyId); // Function OnlineSubsystemBlueprints.OnlineHelpers.Conv_ULobbyIdToUOnlinePartyJoinInfo
	struct FString Conv_FUniqueNetIdReplToString(struct FUniqueNetIdRepl InNetId); // Function OnlineSubsystemBlueprints.OnlineHelpers.Conv_FUniqueNetIdReplToString
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendAlias
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineFriendsSubsystemDeleteFriendAlias : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnDeleteFriendAliasComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0x60(0x30)
	struct FString __Store__ListName;  // 0x90(0x10)

	struct UOnlineFriendsSubsystemDeleteFriendAlias* DeleteFriendAlias(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl FriendId, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendAlias.DeleteFriendAlias
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemImpact
// Size: 0xB8(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystemItemImpact : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnItemImpactComplete;  // 0x40(0x10)
	struct UOnlineGameItemStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FString> __Store__TargetActors;  // 0x88(0x10)
	struct FString __Store__ImpactInitiatedBy;  // 0x98(0x10)
	struct TArray<struct FString> __Store__ItemsUsed;  // 0xA8(0x10)

	struct UOnlineGameItemStatsSubsystemItemImpact* ItemImpact(struct UOnlineGameItemStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FString> TargetActors, struct FString ImpactInitiatedBy, struct TArray<struct FString> ItemsUsed); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemImpact.ItemImpact
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemAddRecentPlayers
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineFriendsSubsystemAddRecentPlayers : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnAddRecentPlayersComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct TArray<struct FReportPlayedWithUserInfo> __Store__InRecentPlayers;  // 0x88(0x10)
	struct FString __Store__ListName;  // 0x98(0x10)

	struct UOnlineFriendsSubsystemAddRecentPlayers* AddRecentPlayers(struct UOnlineFriendsSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct TArray<struct FReportPlayedWithUserInfo> InRecentPlayers, struct FString ListName); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemAddRecentPlayers.AddRecentPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemCreateLobby
// Size: 0x90(Inherited: 0x30) 
struct UOnlineLobbySubsystemCreateLobby : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyCreateOrConnectComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct UOnlineLobbyTransaction* __Store__Transaction;  // 0x88(0x8)

	struct UOnlineLobbySubsystemCreateLobby* CreateLobby(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct UOnlineLobbyTransaction* Transaction); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemCreateLobby.CreateLobby
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryRecentPlayers
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineFriendsSubsystemQueryRecentPlayers : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryRecentPlayersComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x60(0x30)
	struct FString __Store__Namespace;  // 0x90(0x10)

	struct UOnlineFriendsSubsystemQueryRecentPlayers* QueryRecentPlayers(struct UOnlineFriendsSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString Namespace); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryRecentPlayers.QueryRecentPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlineStatsSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineStatsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineStatsSubsystem.IsSubsystemAvailable
	struct FOnlineStatsUserStatsBP GetStats(struct FUniqueNetIdRepl StatsUserId); // Function OnlineSubsystemBlueprints.OnlineStatsSubsystem.GetStats
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemBlockPlayer
// Size: 0x98(Inherited: 0x30) 
struct UOnlineFriendsSubsystemBlockPlayer : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnBlockedPlayerComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FUniqueNetIdRepl __Store__PlayerId;  // 0x68(0x30)

	struct UOnlineFriendsSubsystemBlockPlayer* BlockPlayer(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl PlayerId); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemBlockPlayer.BlockPlayer
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemUnblockPlayer
// Size: 0x98(Inherited: 0x30) 
struct UOnlineFriendsSubsystemUnblockPlayer : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnUnblockedPlayerComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FUniqueNetIdRepl __Store__PlayerId;  // 0x68(0x30)

	struct UOnlineFriendsSubsystemUnblockPlayer* UnblockPlayer(struct UOnlineFriendsSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl PlayerId); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemUnblockPlayer.UnblockPlayer
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryBlockedPlayers
// Size: 0x90(Inherited: 0x30) 
struct UOnlineFriendsSubsystemQueryBlockedPlayers : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryBlockedPlayersComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x60(0x30)

	struct UOnlineFriendsSubsystemQueryBlockedPlayers* QueryBlockedPlayers(struct UOnlineFriendsSubsystem* Subsystem, struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryBlockedPlayers.QueryBlockedPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemAvailabilityChange
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystemItemAvailabilityChange : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnItemAvailabilityChangeComplete;  // 0x40(0x10)
	struct UOnlineGameItemStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FString> __Store__AvailableItems;  // 0x88(0x10)
	struct TArray<struct FString> __Store__UnavailableItems;  // 0x98(0x10)

	struct UOnlineGameItemStatsSubsystemItemAvailabilityChange* ItemAvailabilityChange(struct UOnlineGameItemStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FString> AvailableItems, struct TArray<struct FString> UnavailableItems); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemAvailabilityChange.ItemAvailabilityChange
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemMitigation
// Size: 0xB8(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystemItemMitigation : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnItemMitigationComplete;  // 0x40(0x10)
	struct UOnlineGameItemStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FString> __Store__ItemsUsed;  // 0x88(0x10)
	struct TArray<struct FString> __Store__ImpactItemsMitigated;  // 0x98(0x10)
	struct FString __Store__ItemUsedBy;  // 0xA8(0x10)

	struct UOnlineGameItemStatsSubsystemItemMitigation* ItemMitigation(struct UOnlineGameItemStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FString> ItemsUsed, struct TArray<struct FString> ImpactItemsMitigated, struct FString ItemUsedBy); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemMitigation.ItemMitigation
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryFriendSettings
// Size: 0x88(Inherited: 0x30) 
struct UOnlineFriendsSubsystemQueryFriendSettings : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSettingsOperationComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)

	struct UOnlineFriendsSubsystemQueryFriendSettings* QueryFriendSettings(struct UOnlineFriendsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryFriendSettings.QueryFriendSettings
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendSettings
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineFriendsSubsystemSetFriendSettings : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSetFriendSettingsComplete;  // 0x40(0x10)
	struct UOnlineFriendsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct FString __Store__Source;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool __Store__bNeverShowAgain : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

	struct UOnlineFriendsSubsystemSetFriendSettings* SetFriendSettings(struct UOnlineFriendsSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString Source, bool bNeverShowAgain); // Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendSettings.SetFriendSettings
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystemStartActivity
// Size: 0xE8(Inherited: 0x30) 
struct UOnlineGameActivitySubsystemStartActivity : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnStartActivityComplete;  // 0x40(0x10)
	struct UOnlineGameActivitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ActivityId;  // 0x88(0x10)
	struct TMap<struct FString, struct FVariantDataBP> __Store__Parms;  // 0x98(0x50)

	struct UOnlineGameActivitySubsystemStartActivity* StartActivity(struct UOnlineGameActivitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ActivityId, struct TMap<struct FString, struct FVariantDataBP> Params); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemStartActivity.StartActivity
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResetAllActiveActivities
// Size: 0x88(Inherited: 0x30) 
struct UOnlineGameActivitySubsystemResetAllActiveActivities : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnResetAllActiveActivitiesComplete;  // 0x40(0x10)
	struct UOnlineGameActivitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)

	struct UOnlineGameActivitySubsystemResetAllActiveActivities* ResetAllActiveActivities(struct UOnlineGameActivitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResetAllActiveActivities.ResetAllActiveActivities
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityAvailability
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineGameActivitySubsystemSetActivityAvailability : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSetActivityAvailabilityComplete;  // 0x40(0x10)
	struct UOnlineGameActivitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ActivityId;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool __Store__bEnabled : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

	struct UOnlineGameActivitySubsystemSetActivityAvailability* SetActivityAvailability(struct UOnlineGameActivitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ActivityId, bool bEnabled); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityAvailability.SetActivityAvailability
}; 



// Class OnlineSubsystemBlueprints.OnlineIdentitySubsystemAutoLogin
// Size: 0x68(Inherited: 0x30) 
struct UOnlineIdentitySubsystemAutoLogin : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLoginComplete;  // 0x40(0x10)
	struct UOnlineIdentitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

	struct UOnlineIdentitySubsystemAutoLogin* AutoLogin(struct UOnlineIdentitySubsystem* Subsystem, int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemAutoLogin.AutoLogin
}; 



// Class OnlineSubsystemBlueprints.OnlineGroupsSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineGroupsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	void SetNamespace(struct FString Ns); // Function OnlineSubsystemBlueprints.OnlineGroupsSubsystem.SetNamespace
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineGroupsSubsystem.IsSubsystemAvailable
	struct FString GetNamespace(); // Function OnlineSubsystemBlueprints.OnlineGroupsSubsystem.GetNamespace
}; 



// Class OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityPriority
// Size: 0xD8(Inherited: 0x30) 
struct UOnlineGameActivitySubsystemSetActivityPriority : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSetActivityPriorityComplete;  // 0x40(0x10)
	struct UOnlineGameActivitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TMap<struct FString, int32_t> __Store__PrioritizedActivities;  // 0x88(0x50)

	struct UOnlineGameActivitySubsystemSetActivityPriority* SetActivityPriority(struct UOnlineGameActivitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TMap<struct FString, int32_t> PrioritizedActivities); // Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityPriority.SetActivityPriority
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemUsage
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystemItemUsage : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnItemUsageComplete;  // 0x40(0x10)
	struct UOnlineGameItemStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ItemUsedBy;  // 0x88(0x10)
	struct TArray<struct FString> __Store__ItemsUsed;  // 0x98(0x10)

	struct UOnlineGameItemStatsSubsystemItemUsage* ItemUsage(struct UOnlineGameItemStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ItemUsedBy, struct TArray<struct FString> ItemsUsed); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemUsage.ItemUsage
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemInventoryChange
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineGameItemStatsSubsystemItemInventoryChange : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnItemInventoryChangeComplete;  // 0x40(0x10)
	struct UOnlineGameItemStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FString> __Store__ItemsToAdd;  // 0x88(0x10)
	struct TArray<struct FString> __Store__ItemsToRemove;  // 0x98(0x10)

	struct UOnlineGameItemStatsSubsystemItemInventoryChange* ItemInventoryChange(struct UOnlineGameItemStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FString> ItemsToAdd, struct TArray<struct FString> ItemsToRemove); // Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemInventoryChange.ItemInventoryChange
}; 



// Class OnlineSubsystemBlueprints.OnlineIdentitySubsystemLogout
// Size: 0x68(Inherited: 0x30) 
struct UOnlineIdentitySubsystemLogout : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLogoutComplete;  // 0x40(0x10)
	struct UOnlineIdentitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

	struct UOnlineIdentitySubsystemLogout* Logout(struct UOnlineIdentitySubsystem* Subsystem, int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemLogout.Logout
}; 



// Class OnlineSubsystemBlueprints.OnlineIdentitySubsystemGetUserPrivilege
// Size: 0x90(Inherited: 0x30) 
struct UOnlineIdentitySubsystemGetUserPrivilege : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnGetUserPrivilegeComplete;  // 0x40(0x10)
	struct UOnlineIdentitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	uint8_t  __Store__Privilege;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

	struct UOnlineIdentitySubsystemGetUserPrivilege* GetUserPrivilege(struct UOnlineIdentitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, uint8_t  Privilege); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemGetUserPrivilege.GetUserPrivilege
}; 



// Class OnlineSubsystemBlueprints.OnlineIdentitySubsystemRevokeAuthToken
// Size: 0x88(Inherited: 0x30) 
struct UOnlineIdentitySubsystemRevokeAuthToken : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnRevokeAuthTokenComplete;  // 0x40(0x10)
	struct UOnlineIdentitySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)

	struct UOnlineIdentitySubsystemRevokeAuthToken* RevokeAuthToken(struct UOnlineIdentitySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId); // Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemRevokeAuthToken.RevokeAuthToken
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem
// Size: 0x80(Inherited: 0x30) 
struct UOnlineLeaderboardsSubsystem : public UGameInstanceSubsystem
{
	char pad_48[48];  // 0x30(0x30)
	struct FMulticastInlineDelegate OnLeaderboardReadComplete;  // 0x60(0x10)
	struct FMulticastInlineDelegate OnLeaderboardFlushComplete;  // 0x70(0x10)

	bool WriteLeaderboards(struct FName SessionName, struct FUniqueNetIdRepl Player, struct UOnlineLeaderboardWrite* WriteObject); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.WriteLeaderboards
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.IsSubsystemAvailable
	void FreeStats(struct UOnlineLeaderboardRead* ReadObject); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.FreeStats
	bool FlushLeaderboards(struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.FlushLeaderboards
}; 



// Class OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadMatchWithID
// Size: 0x68(Inherited: 0x30) 
struct UOnlineTurnBasedSubsystemLoadMatchWithID : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate LoadTurnBasedMatchWithIDSignature;  // 0x40(0x10)
	struct UOnlineTurnBasedSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FString __Store__MatchID;  // 0x58(0x10)

	struct UOnlineTurnBasedSubsystemLoadMatchWithID* LoadMatchWithID(struct UOnlineTurnBasedSubsystem* Subsystem, struct FString MatchID); // Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadMatchWithID.LoadMatchWithID
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboards
// Size: 0x78(Inherited: 0x30) 
struct UOnlineLeaderboardsSubsystemReadLeaderboards : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLeaderboardReadComplete;  // 0x40(0x10)
	struct UOnlineLeaderboardsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct TArray<struct FUniqueNetIdRepl> __Store__Players;  // 0x60(0x10)
	struct UOnlineLeaderboardRead* __Store__ReadObject;  // 0x70(0x8)

	struct UOnlineLeaderboardsSubsystemReadLeaderboards* ReadLeaderboards(struct UOnlineLeaderboardsSubsystem* Subsystem, struct TArray<struct FUniqueNetIdRepl> Players, struct UOnlineLeaderboardRead* ReadObject); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboards.ReadLeaderboards
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundRank
// Size: 0x78(Inherited: 0x30) 
struct UOnlineLeaderboardsSubsystemReadLeaderboardsAroundRank : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLeaderboardReadComplete;  // 0x40(0x10)
	struct UOnlineLeaderboardsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__Rank;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	int64_t __Store__Range;  // 0x68(0x8)
	struct UOnlineLeaderboardRead* __Store__ReadObject;  // 0x70(0x8)

	struct UOnlineLeaderboardsSubsystemReadLeaderboardsAroundRank* ReadLeaderboardsAroundRank(struct UOnlineLeaderboardsSubsystem* Subsystem, int32_t Rank, int64_t Range, struct UOnlineLeaderboardRead* ReadObject); // Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundRank.ReadLeaderboardsAroundRank
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelMatchmaking
// Size: 0x98(Inherited: 0x30) 
struct UOnlineSessionSubsystemCancelMatchmaking : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnCancelMatchmakingComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__SearchingPlayerId;  // 0x60(0x30)
	struct FName __Store__SessionName;  // 0x90(0x8)

	struct UOnlineSessionSubsystemCancelMatchmaking* CancelMatchmaking(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl SearchingPlayerId, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelMatchmaking.CancelMatchmaking
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystem
// Size: 0xC8(Inherited: 0x30) 
struct UOnlineLobbySubsystem : public UGameInstanceSubsystem
{
	char pad_48[72];  // 0x30(0x48)
	struct FMulticastInlineDelegate OnLobbyUpdate;  // 0x78(0x10)
	struct FMulticastInlineDelegate OnLobbyDelete;  // 0x88(0x10)
	struct FMulticastInlineDelegate OnMemberConnect;  // 0x98(0x10)
	struct FMulticastInlineDelegate OnMemberUpdate;  // 0xA8(0x10)
	struct FMulticastInlineDelegate OnMemberDisconnect;  // 0xB8(0x10)

	struct ULobbyId* ParseSerializedLobbyId(struct FString InLobbyId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.ParseSerializedLobbyId
	struct UOnlineLobbyTransaction* MakeUpdateLobbyTransaction(struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.MakeUpdateLobbyTransaction
	struct UOnlineLobbyMemberTransaction* MakeUpdateLobbyMemberTransaction(struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, struct FUniqueNetIdRepl MemberId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.MakeUpdateLobbyMemberTransaction
	struct UOnlineLobbyTransaction* MakeCreateLobbyTransaction(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.MakeCreateLobbyTransaction
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.IsSubsystemAvailable
	bool GetMemberUserId(struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, int32_t MemberIndex, struct FUniqueNetIdRepl& OutMemberId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetMemberUserId
	bool GetMemberMetadataValue(struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, struct FUniqueNetIdRepl MemberId, struct FString MetadataKey, struct FVariantDataBP& OutMetadataValue); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetMemberMetadataValue
	bool GetMemberCount(struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, int32_t& OutMemberCount); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetMemberCount
	bool GetLobbyMetadataValue(struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, struct FString MetadataKey, struct FVariantDataBP& OutMetadataValue); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetLobbyMetadataValue
}; 



// Class OnlineSubsystemBlueprints.VoiceChatUserLogout
// Size: 0x58(Inherited: 0x30) 
struct UVoiceChatUserLogout : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceChatLogoutComplete;  // 0x40(0x10)
	struct UVoiceChatUser* __Store__Subsystem;  // 0x50(0x8)

	struct UVoiceChatUserLogout* Logout(struct UVoiceChatUser* Subsystem); // Function OnlineSubsystemBlueprints.VoiceChatUserLogout.Logout
}; 



// Class OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayNames
// Size: 0x68(Inherited: 0x30) 
struct UOnlineMessageSanitizerSubsystemSanitizeDisplayNames : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnMessageArrayProcessed;  // 0x40(0x10)
	struct UOnlineMessageSanitizerSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct TArray<struct FString> __Store__DisplayNames;  // 0x58(0x10)

	struct UOnlineMessageSanitizerSubsystemSanitizeDisplayNames* SanitizeDisplayNames(struct UOnlineMessageSanitizerSubsystem* Subsystem, struct TArray<struct FString> DisplayNames); // Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayNames.SanitizeDisplayNames
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemDeleteLobby
// Size: 0x90(Inherited: 0x30) 
struct UOnlineLobbySubsystemDeleteLobby : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyOperationComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct ULobbyId* __Store__LobbyId;  // 0x88(0x8)

	struct UOnlineLobbySubsystemDeleteLobby* DeleteLobby(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemDeleteLobby.DeleteLobby
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemConnectLobby
// Size: 0x90(Inherited: 0x30) 
struct UOnlineLobbySubsystemConnectLobby : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyCreateOrConnectComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct ULobbyId* __Store__LobbyId;  // 0x88(0x8)

	struct UOnlineLobbySubsystemConnectLobby* ConnectLobby(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemConnectLobby.ConnectLobby
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionInfo
// Size: 0x38(Inherited: 0x28) 
struct UOnlineSessionInfo : public UObject
{
	char pad_40[16];  // 0x28(0x10)

}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemDisconnectLobby
// Size: 0x90(Inherited: 0x30) 
struct UOnlineLobbySubsystemDisconnectLobby : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyOperationComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct ULobbyId* __Store__LobbyId;  // 0x88(0x8)

	struct UOnlineLobbySubsystemDisconnectLobby* DisconnectLobby(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemDisconnectLobby.DisconnectLobby
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateMemberSelf
// Size: 0x98(Inherited: 0x30) 
struct UOnlineLobbySubsystemUpdateMemberSelf : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyOperationComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct ULobbyId* __Store__LobbyId;  // 0x88(0x8)
	struct UOnlineLobbyMemberTransaction* __Store__Transaction;  // 0x90(0x8)

	struct UOnlineLobbySubsystemUpdateMemberSelf* UpdateMemberSelf(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, struct UOnlineLobbyMemberTransaction* Transaction); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateMemberSelf.UpdateMemberSelf
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemSearch
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineLobbySubsystemSearch : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbySearchComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct FOnlineLobbySearchQueryBP __Store__Query;  // 0x88(0x20)

	struct UOnlineLobbySubsystemSearch* Search(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FOnlineLobbySearchQueryBP Query); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemSearch.Search
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbySubsystemKickMember
// Size: 0xC0(Inherited: 0x30) 
struct UOnlineLobbySubsystemKickMember : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLobbyOperationComplete;  // 0x40(0x10)
	struct UOnlineLobbySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct ULobbyId* __Store__LobbyId;  // 0x88(0x8)
	struct FUniqueNetIdRepl __Store__MemberId;  // 0x90(0x30)

	struct UOnlineLobbySubsystemKickMember* KickMember(struct UOnlineLobbySubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct ULobbyId* LobbyId, struct FUniqueNetIdRepl MemberId); // Function OnlineSubsystemBlueprints.OnlineLobbySubsystemKickMember.KickMember
}; 



// Class OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineMessageSanitizerSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	void ResetBlockedUserCache(); // Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystem.ResetBlockedUserCache
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayName
// Size: 0x68(Inherited: 0x30) 
struct UOnlineMessageSanitizerSubsystemSanitizeDisplayName : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnMessageProcessed;  // 0x40(0x10)
	struct UOnlineMessageSanitizerSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FString __Store__DisplayName;  // 0x58(0x10)

	struct UOnlineMessageSanitizerSubsystemSanitizeDisplayName* SanitizeDisplayName(struct UOnlineMessageSanitizerSubsystem* Subsystem, struct FString DisplayName); // Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayName.SanitizeDisplayName
}; 



// Class OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemQueryBlockedUser
// Size: 0x80(Inherited: 0x30) 
struct UOnlineMessageSanitizerSubsystemQueryBlockedUser : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryUserBlockedResponse;  // 0x40(0x10)
	struct UOnlineMessageSanitizerSubsystem* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__LocalUserNum;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString __Store__FromUserId;  // 0x60(0x10)
	struct FString __Store__FromPlatform;  // 0x70(0x10)

	struct UOnlineMessageSanitizerSubsystemQueryBlockedUser* QueryBlockedUser(struct UOnlineMessageSanitizerSubsystem* Subsystem, int32_t LocalUserNum, struct FString FromUserId, struct FString FromPlatform); // Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemQueryBlockedUser.QueryBlockedUser
}; 



// Class OnlineSubsystemBlueprints.OnlineMessageSubsystem
// Size: 0x90(Inherited: 0x30) 
struct UOnlineMessageSubsystem : public UGameInstanceSubsystem
{
	char pad_48[64];  // 0x30(0x40)
	struct FMulticastInlineDelegate OnEnumerateMessagesComplete;  // 0x70(0x10)
	struct FMulticastInlineDelegate OnSendMessageComplete;  // 0x80(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.IsSubsystemAvailable
	bool EnumerateMessages(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.EnumerateMessages
	bool ClearMessages(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.ClearMessages
	bool ClearMessageHeaders(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.ClearMessageHeaders
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystem
// Size: 0x1E8(Inherited: 0x30) 
struct UOnlinePartySubsystem : public UGameInstanceSubsystem
{
	char pad_48[168];  // 0x30(0xA8)
	struct FMulticastInlineDelegate OnPartyJoined;  // 0xD8(0x10)
	struct FMulticastInlineDelegate OnPartyExited;  // 0xE8(0x10)
	struct FMulticastInlineDelegate OnPartyStateChanged;  // 0xF8(0x10)
	struct FMulticastInlineDelegate OnPartyJIPResponse;  // 0x108(0x10)
	struct FMulticastInlineDelegate OnPartyPromotionLockoutChanged;  // 0x118(0x10)
	struct FMulticastInlineDelegate OnPartyConfigChanged;  // 0x128(0x10)
	struct FMulticastInlineDelegate OnPartyDataReceived;  // 0x138(0x10)
	struct FMulticastInlineDelegate OnPartyMemberPromoted;  // 0x148(0x10)
	struct FMulticastInlineDelegate OnPartyMemberExited;  // 0x158(0x10)
	struct FMulticastInlineDelegate OnPartyMemberJoined;  // 0x168(0x10)
	struct FMulticastInlineDelegate OnPartyMemberDataReceived;  // 0x178(0x10)
	struct FMulticastInlineDelegate OnPartyInvitesChanged;  // 0x188(0x10)
	struct FMulticastInlineDelegate OnPartyInviteRequestReceived;  // 0x198(0x10)
	struct FMulticastInlineDelegate OnPartyInviteReceived;  // 0x1A8(0x10)
	struct FMulticastInlineDelegate OnPartyInviteReceivedEx;  // 0x1B8(0x10)
	struct FMulticastInlineDelegate OnPartyJIPRequestReceived;  // 0x1C8(0x10)
	struct FMulticastInlineDelegate OnFillPartyJoinRequestData;  // 0x1D8(0x10)

	bool UpdatePartyMemberData(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FName Namespace, struct UReadablePartyData* PartyMemberData); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.UpdatePartyMemberData
	bool UpdatePartyData(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FName Namespace, struct UReadablePartyData* PartyData); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.UpdatePartyData
	void RespondToQueryJoinability(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl RecipientId, bool bCanJoin, int32_t DeniedResultCode, struct UReadablePartyData* PartyData); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.RespondToQueryJoinability
	bool RejectInvitation(struct FUniqueNetIdRepl LocalUserId, struct FUniqueNetIdRepl SenderId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.RejectInvitation
	struct FString MakeTokenFromJoinInfo(struct UOnlinePartyJoinInfo* JoinInfo); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.MakeTokenFromJoinInfo
	struct FString MakeJoinInfoJson(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.MakeJoinInfoJson
	bool JIPFromWithinParty(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl PartyLeaderId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.JIPFromWithinParty
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.IsSubsystemAvailable
	bool IsMemberLeader(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl MemberId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.IsMemberLeader
	bool GetPendingInvites(struct FUniqueNetIdRepl LocalUserId, struct TArray<struct UOnlinePartyJoinInfo*>& OutPendingInvitesArray); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPendingInvites
	bool GetPendingInvitedUsers(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct TArray<struct FUniqueNetIdRepl>& OutPendingInvitedUserArray); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPendingInvitedUsers
	bool GetPartyMembers(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct TArray<struct UBlueprintPartyMember*>& OutPartyMembersArray); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMembers
	struct UReadablePartyData* GetPartyMemberData(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl MemberId, struct FName Namespace); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMemberData
	int64_t GetPartyMemberCount(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMemberCount
	struct UBlueprintPartyMember* GetPartyMember(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl MemberId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMember
	struct UReadablePartyData* GetPartyData(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FName Namespace); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyData
	struct UParty* GetParty(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetParty
	bool GetJoinedParties(struct FUniqueNetIdRepl LocalUserId, struct TArray<struct UPartyId*>& OutPartyIdArray); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetJoinedParties
	void DumpPartyState(); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.DumpPartyState
	bool ApproveJoinRequest(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl RecipientId, bool bIsApproved, int32_t DeniedResultCode); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.ApproveJoinRequest
	bool ApproveJIPRequest(struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl RecipientId, bool bIsApproved, int32_t DeniedResultCode); // Function OnlineSubsystemBlueprints.OnlinePartySubsystem.ApproveJIPRequest
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreParties
// Size: 0x88(Inherited: 0x30) 
struct UOnlinePartySubsystemRestoreParties : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnRestorePartiesComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)

	struct UOnlinePartySubsystemRestoreParties* RestoreParties(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreParties.RestoreParties
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreInvites
// Size: 0x88(Inherited: 0x30) 
struct UOnlinePartySubsystemRestoreInvites : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnRestoreInvitesComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)

	struct UOnlinePartySubsystemRestoreInvites* RestoreInvites(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreInvites.RestoreInvites
}; 



// Class OnlineSubsystemBlueprints.OnlineTurnBasedSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineTurnBasedSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystem.IsSubsystemAvailable
	int32_t GetMatchDataSize(); // Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystem.GetMatchDataSize
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemCleanupParties
// Size: 0x88(Inherited: 0x30) 
struct UOnlinePartySubsystemCleanupParties : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnCleanupPartiesComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)

	struct UOnlinePartySubsystemCleanupParties* CleanupParties(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemCleanupParties.CleanupParties
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemCreateParty
// Size: 0xD0(Inherited: 0x30) 
struct UOnlinePartySubsystemCreateParty : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnCreatePartyComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	int64_t __Store__PartyTypeId;  // 0x88(0x8)
	struct FOnlinePartyConfiguration __Store__PartyConfig;  // 0x90(0x40)

	struct UOnlinePartySubsystemCreateParty* CreateParty(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, int64_t PartyTypeId, struct FOnlinePartyConfiguration PartyConfig); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemCreateParty.CreateParty
}; 



// Class OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserIdMapping
// Size: 0x98(Inherited: 0x30) 
struct UOnlineUserSubsystemQueryUserIdMapping : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryUserMappingComplete;  // 0x40(0x10)
	struct UOnlineUserSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct FString __Store__DisplayNameOrEmail;  // 0x88(0x10)

	struct UOnlineUserSubsystemQueryUserIdMapping* QueryUserIdMapping(struct UOnlineUserSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString DisplayNameOrEmail); // Function OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserIdMapping.QueryUserIdMapping
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemUpdateParty
// Size: 0xD8(Inherited: 0x30) 
struct UOnlinePartySubsystemUpdateParty : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnUpdatePartyComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UPartyId* __Store__PartyId;  // 0x88(0x8)
	struct FOnlinePartyConfiguration __Store__PartyConfig;  // 0x90(0x40)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool __Store__bShouldRegenerateReservationKey : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

	struct UOnlinePartySubsystemUpdateParty* UpdateParty(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FOnlinePartyConfiguration PartyConfig, bool bShouldRegenerateReservationKey); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemUpdateParty.UpdateParty
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemJoinParty
// Size: 0x90(Inherited: 0x30) 
struct UOnlinePartySubsystemJoinParty : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnJoinPartyComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UOnlinePartyJoinInfo* __Store__OnlinePartyJoinInfo;  // 0x88(0x8)

	struct UOnlinePartySubsystemJoinParty* JoinParty(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UOnlinePartyJoinInfo* OnlinePartyJoinInfo); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemJoinParty.JoinParty
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemQueryPartyJoinability
// Size: 0x90(Inherited: 0x30) 
struct UOnlinePartySubsystemQueryPartyJoinability : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryPartyJoinabilityComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UOnlinePartyJoinInfo* __Store__OnlinePartyJoinInfo;  // 0x88(0x8)

	struct UOnlinePartySubsystemQueryPartyJoinability* QueryPartyJoinability(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UOnlinePartyJoinInfo* OnlinePartyJoinInfo); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemQueryPartyJoinability.QueryPartyJoinability
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemRejoinParty
// Size: 0xA8(Inherited: 0x30) 
struct UOnlinePartySubsystemRejoinParty : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnJoinPartyComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UPartyId* __Store__PartyId;  // 0x88(0x8)
	int64_t __Store__PartyTypeId;  // 0x90(0x8)
	struct TArray<struct FUniqueNetIdRepl> __Store__FormerMembers;  // 0x98(0x10)

	struct UOnlinePartySubsystemRejoinParty* RejoinParty(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, int64_t PartyTypeId, struct TArray<struct FUniqueNetIdRepl> FormerMembers); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemRejoinParty.RejoinParty
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemLeaveParty
// Size: 0x98(Inherited: 0x30) 
struct UOnlinePartySubsystemLeaveParty : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnLeavePartyComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UPartyId* __Store__PartyId;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool __Store__bSynchronizeLeave : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

	struct UOnlinePartySubsystemLeaveParty* LeaveParty(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, bool bSynchronizeLeave); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemLeaveParty.LeaveParty
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemSendInvitation
// Size: 0xC0(Inherited: 0x30) 
struct UOnlinePartySubsystemSendInvitation : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSendPartyInvitationComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UPartyId* __Store__PartyId;  // 0x88(0x8)
	struct FUniqueNetIdRepl __Store__Recipient;  // 0x90(0x30)

	struct UOnlinePartySubsystemSendInvitation* SendInvitation(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl Recipient); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemSendInvitation.SendInvitation
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemKickMember
// Size: 0xC0(Inherited: 0x30) 
struct UOnlinePartySubsystemKickMember : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnKickPartyMemberComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UPartyId* __Store__PartyId;  // 0x88(0x8)
	struct FUniqueNetIdRepl __Store__TargetMemberId;  // 0x90(0x30)

	struct UOnlinePartySubsystemKickMember* KickMember(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl TargetMemberId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemKickMember.KickMember
}; 



// Class OnlineSubsystemBlueprints.OnlinePartySubsystemPromoteMember
// Size: 0xC0(Inherited: 0x30) 
struct UOnlinePartySubsystemPromoteMember : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnPromotePartyMemberComplete;  // 0x40(0x10)
	struct UOnlinePartySubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct UPartyId* __Store__PartyId;  // 0x88(0x8)
	struct FUniqueNetIdRepl __Store__TargetMemberId;  // 0x90(0x30)

	struct UOnlinePartySubsystemPromoteMember* PromoteMember(struct UOnlinePartySubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct UPartyId* PartyId, struct FUniqueNetIdRepl TargetMemberId); // Function OnlineSubsystemBlueprints.OnlinePartySubsystemPromoteMember.PromoteMember
}; 



// Class OnlineSubsystemBlueprints.OnlinePresenceSubsystem
// Size: 0x80(Inherited: 0x30) 
struct UOnlinePresenceSubsystem : public UGameInstanceSubsystem
{
	char pad_48[48];  // 0x30(0x30)
	struct FMulticastInlineDelegate OnPresenceReceived;  // 0x60(0x10)
	struct FMulticastInlineDelegate OnPresenceArrayUpdated;  // 0x70(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlinePresenceSubsystem.IsSubsystemAvailable
	uint8_t  GetCachedPresenceForApp(struct FUniqueNetIdRepl LocalUserId, struct FUniqueNetIdRepl User, struct FString AppID, struct FOnlineUserPresenceData& OutPresence); // Function OnlineSubsystemBlueprints.OnlinePresenceSubsystem.GetCachedPresenceForApp
	uint8_t  GetCachedPresence(struct FUniqueNetIdRepl User, struct FOnlineUserPresenceData& OutPresence); // Function OnlineSubsystemBlueprints.OnlinePresenceSubsystem.GetCachedPresence
}; 



// Class OnlineSubsystemBlueprints.PartyId
// Size: 0x38(Inherited: 0x28) 
struct UPartyId : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToDebugString(); // Function OnlineSubsystemBlueprints.PartyId.ToDebugString
}; 



// Class OnlineSubsystemBlueprints.OnlinePresenceSubsystemSetPresence
// Size: 0xF0(Inherited: 0x30) 
struct UOnlinePresenceSubsystemSetPresence : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnPresenceTaskComplete;  // 0x40(0x10)
	struct UOnlinePresenceSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__User;  // 0x58(0x30)
	struct FOnlineUserPresenceStatusData __Store__Status;  // 0x88(0x68)

	struct UOnlinePresenceSubsystemSetPresence* SetPresence(struct UOnlinePresenceSubsystem* Subsystem, struct FUniqueNetIdRepl User, struct FOnlineUserPresenceStatusData Status); // Function OnlineSubsystemBlueprints.OnlinePresenceSubsystemSetPresence.SetPresence
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem
// Size: 0xA0(Inherited: 0x30) 
struct UOnlineVoiceChatSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)
	struct UVoiceChatUser* PrimaryVoiceUser;  // 0x50(0x8)
	struct FMulticastInlineDelegate OnVoiceChatReconnected;  // 0x58(0x10)
	char pad_104[8];  // 0x68(0x8)
	struct FMulticastInlineDelegate OnVoiceChatConnected;  // 0x70(0x10)
	char pad_128[8];  // 0x80(0x8)
	struct FMulticastInlineDelegate OnVoiceChatDisconnected;  // 0x88(0x10)
	char pad_152[8];  // 0x98(0x8)

	bool Uninitialize_(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.Uninitialize_
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsSubsystemAvailable
	bool IsInitialized(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsInitialized
	bool IsConnecting(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsConnecting
	bool IsConnected(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsConnected
	bool Initialize_(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.Initialize_
	struct UVoiceChatUser* CreateUser(); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.CreateUser
}; 



// Class OnlineSubsystemBlueprints.OnlinePresenceSubsystemQueryPresence
// Size: 0x88(Inherited: 0x30) 
struct UOnlinePresenceSubsystemQueryPresence : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnPresenceTaskComplete;  // 0x40(0x10)
	struct UOnlinePresenceSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__User;  // 0x58(0x30)

	struct UOnlinePresenceSubsystemQueryPresence* QueryPresence(struct UOnlinePresenceSubsystem* Subsystem, struct FUniqueNetIdRepl User); // Function OnlineSubsystemBlueprints.OnlinePresenceSubsystemQueryPresence.QueryPresence
}; 



// Class OnlineSubsystemBlueprints.OnlinePurchaseSubsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlinePurchaseSubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnUnexpectedPurchaseReceipt;  // 0x58(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystem.IsSubsystemAvailable
	bool IsAllowedToPurchase(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystem.IsAllowedToPurchase
	void FinalizePurchase(struct FUniqueNetIdRepl UserId, struct FString ReceiptId); // Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystem.FinalizePurchase
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbyTransaction
// Size: 0x38(Inherited: 0x28) 
struct UOnlineLobbyTransaction : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void SetPublic(bool Public); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetPublic
	void SetMetadataByMap(struct TMap<struct FString, struct FVariantDataBP>& MetaData); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetMetadataByMap
	void SetMetadata(struct FString Key, struct FVariantDataBP& Value); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetMetadata
	void SetLocked(bool Locked); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetLocked
	void SetCapacity(int64_t Capacity); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetCapacity
	void DeleteMetadataByArray(struct TArray<struct FString>& MetadataKeys); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.DeleteMetadataByArray
	void DeleteMetadata(struct FString Key); // Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.DeleteMetadata
}; 



// Class OnlineSubsystemBlueprints.OnlinePurchaseSubsystemFinalizeReceiptValidationInfo
// Size: 0x98(Inherited: 0x30) 
struct UOnlinePurchaseSubsystemFinalizeReceiptValidationInfo : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFinalizeReceiptValidationInfoComplete;  // 0x40(0x10)
	struct UOnlinePurchaseSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct FString __Store__InReceiptValidationInfo;  // 0x88(0x10)

	struct UOnlinePurchaseSubsystemFinalizeReceiptValidationInfo* FinalizeReceiptValidationInfo(struct UOnlinePurchaseSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString InReceiptValidationInfo); // Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystemFinalizeReceiptValidationInfo.FinalizeReceiptValidationInfo
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystem
// Size: 0x268(Inherited: 0x30) 
struct UOnlineSessionSubsystem : public UGameInstanceSubsystem
{
	char pad_48[216];  // 0x30(0xD8)
	struct FMulticastInlineDelegate OnCreateSessionComplete;  // 0x108(0x10)
	struct FMulticastInlineDelegate OnStartSessionComplete;  // 0x118(0x10)
	struct FMulticastInlineDelegate OnUpdateSessionComplete;  // 0x128(0x10)
	struct FMulticastInlineDelegate OnEndSessionComplete;  // 0x138(0x10)
	struct FMulticastInlineDelegate OnDestroySessionComplete;  // 0x148(0x10)
	struct FMulticastInlineDelegate OnMatchmakingComplete;  // 0x158(0x10)
	struct FMulticastInlineDelegate OnCancelMatchmakingComplete;  // 0x168(0x10)
	struct FMulticastInlineDelegate OnFindSessionsComplete;  // 0x178(0x10)
	struct FMulticastInlineDelegate OnCancelFindSessionsComplete;  // 0x188(0x10)
	struct FMulticastInlineDelegate OnPingSearchResultsComplete;  // 0x198(0x10)
	struct FMulticastInlineDelegate OnJoinSessionComplete;  // 0x1A8(0x10)
	struct FMulticastInlineDelegate OnSessionParticipantsChange;  // 0x1B8(0x10)
	struct FMulticastInlineDelegate OnQosDataRequested;  // 0x1C8(0x10)
	struct FMulticastInlineDelegate OnSessionSettingsUpdated;  // 0x1D8(0x10)
	struct FMulticastInlineDelegate OnSessionParticipantSettingsUpdated;  // 0x1E8(0x10)
	struct FMulticastInlineDelegate OnSessionParticipantRemoved;  // 0x1F8(0x10)
	struct FMulticastInlineDelegate OnFindFriendSessionComplete;  // 0x208(0x10)
	struct FMulticastInlineDelegate OnSessionUserInviteAccepted;  // 0x218(0x10)
	struct FMulticastInlineDelegate OnSessionInviteReceived;  // 0x228(0x10)
	struct FMulticastInlineDelegate OnRegisterPlayersComplete;  // 0x238(0x10)
	struct FMulticastInlineDelegate OnUnregisterPlayersComplete;  // 0x248(0x10)
	struct FMulticastInlineDelegate OnSessionFailure;  // 0x258(0x10)

	bool SendSessionInviteToFriends(struct FUniqueNetIdRepl LocalUserId, struct FName SessionName, struct TArray<struct FUniqueNetIdRepl> Friends); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.SendSessionInviteToFriends
	bool SendSessionInviteToFriend(struct FUniqueNetIdRepl LocalUserId, struct FName SessionName, struct FUniqueNetIdRepl Friend); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.SendSessionInviteToFriend
	void RemovePlayerFromSession(int32_t LocalUserNum, struct FName SessionName, struct FUniqueNetIdRepl TargetPlayerId); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.RemovePlayerFromSession
	void RemoveNamedSession(struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.RemoveNamedSession
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.IsSubsystemAvailable
	bool IsPlayerInSession(struct FName SessionName, struct FUniqueNetIdRepl UniqueId); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.IsPlayerInSession
	bool HasPresenceSession(); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.HasPresenceSession
	uint8_t  GetSessionState(struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetSessionState
	struct UOnlineSessionSettings* GetSessionSettings(struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetSessionSettings
	int32_t GetNumSessions(); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetNumSessions
	struct UNamedOnlineSession* GetNamedSession(struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetNamedSession
	void DumpSessionState(); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.DumpSessionState
	struct FUniqueNetIdRepl CreateSessionIdFromString(struct FString SessionIdStr); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.CreateSessionIdFromString
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemCreateSession
// Size: 0x1C0(Inherited: 0x30) 
struct UOnlineSessionSubsystemCreateSession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnCreateSessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__HostingPlayerId;  // 0x60(0x30)
	struct FName __Store__SessionName;  // 0x90(0x8)
	struct FOnlineSessionSettingsBP __Store__NewSessionSettings;  // 0x98(0x128)

	struct UOnlineSessionSubsystemCreateSession* CreateSession(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl HostingPlayerId, struct FName SessionName, struct FOnlineSessionSettingsBP NewSessionSettings); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemCreateSession.CreateSession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemStartSession
// Size: 0x68(Inherited: 0x30) 
struct UOnlineSessionSubsystemStartSession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnStartSessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FName __Store__SessionName;  // 0x60(0x8)

	struct UOnlineSessionSubsystemStartSession* StartSession(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemStartSession.StartSession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemUpdateSession
// Size: 0x198(Inherited: 0x30) 
struct UOnlineSessionSubsystemUpdateSession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnUpdateSessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FName __Store__SessionName;  // 0x60(0x8)
	struct FOnlineSessionSettingsBP __Store__UpdatedSessionSettings;  // 0x68(0x128)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool __Store__bShouldRefreshOnlineData : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)

	struct UOnlineSessionSubsystemUpdateSession* UpdateSession(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName, struct FOnlineSessionSettingsBP UpdatedSessionSettings, bool bShouldRefreshOnlineData); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemUpdateSession.UpdateSession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemEndSession
// Size: 0x68(Inherited: 0x30) 
struct UOnlineSessionSubsystemEndSession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnEndSessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FName __Store__SessionName;  // 0x60(0x8)

	struct UOnlineSessionSubsystemEndSession* EndSession(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemEndSession.EndSession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemDestroySession
// Size: 0x60(Inherited: 0x30) 
struct UOnlineSessionSubsystemDestroySession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnDestroySessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FName __Store__SessionName;  // 0x58(0x8)

	struct UOnlineSessionSubsystemDestroySession* DestroySession(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemDestroySession.DestroySession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemStartMatchmaking
// Size: 0x1A8(Inherited: 0x30) 
struct UOnlineSessionSubsystemStartMatchmaking : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnMatchmakingComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct TArray<struct FUniqueNetIdRepl> __Store__LocalPlayers;  // 0x60(0x10)
	struct FName __Store__SessionName;  // 0x70(0x8)
	struct FOnlineSessionSettingsBP __Store__NewSessionSettings;  // 0x78(0x128)
	struct UOnlineSessionSearch* __Store__SearchSettings;  // 0x1A0(0x8)

	struct UOnlineSessionSubsystemStartMatchmaking* StartMatchmaking(struct UOnlineSessionSubsystem* Subsystem, struct TArray<struct FUniqueNetIdRepl> LocalPlayers, struct FName SessionName, struct FOnlineSessionSettingsBP NewSessionSettings, struct UOnlineSessionSearch* SearchSettings); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemStartMatchmaking.StartMatchmaking
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessions
// Size: 0x98(Inherited: 0x30) 
struct UOnlineSessionSubsystemFindSessions : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFindSessionsComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__SearchingPlayerId;  // 0x60(0x30)
	struct UOnlineSessionSearch* __Store__SearchSettings;  // 0x90(0x8)

	struct UOnlineSessionSubsystemFindSessions* FindSessions(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl SearchingPlayerId, struct UOnlineSessionSearch* SearchSettings); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessions.FindSessions
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessionById
// Size: 0xF8(Inherited: 0x30) 
struct UOnlineSessionSubsystemFindSessionById : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSingleSessionResultComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__SearchingUserId;  // 0x58(0x30)
	struct FUniqueNetIdRepl __Store__SessionId;  // 0x88(0x30)
	struct FUniqueNetIdRepl __Store__FriendId;  // 0xB8(0x30)
	struct FString __Store__UserData;  // 0xE8(0x10)

	struct UOnlineSessionSubsystemFindSessionById* FindSessionById(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl SearchingUserId, struct FUniqueNetIdRepl SessionId, struct FUniqueNetIdRepl FriendId, struct FString UserData); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessionById.FindSessionById
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelFindSessions
// Size: 0x60(Inherited: 0x30) 
struct UOnlineSessionSubsystemCancelFindSessions : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnCancelFindSessionsComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)

	struct UOnlineSessionSubsystemCancelFindSessions* CancelFindSessions(struct UOnlineSessionSubsystem* Subsystem); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelFindSessions.CancelFindSessions
}; 



// Class OnlineSubsystemBlueprints.OnlineUserCloudSubsystemDeleteUserFile
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineUserCloudSubsystemDeleteUserFile : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnDeleteUserFileComplete;  // 0x40(0x10)
	struct UOnlineUserCloudSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x60(0x30)
	struct FString __Store__FileName;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool __Store__bShouldCloudDelete : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool __Store__bShouldLocallyDelete : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)

	struct UOnlineUserCloudSubsystemDeleteUserFile* DeleteUserFile(struct UOnlineUserCloudSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString Filename, bool bShouldCloudDelete, bool bShouldLocallyDelete); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemDeleteUserFile.DeleteUserFile
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemPingSearchResults
// Size: 0x1F0(Inherited: 0x30) 
struct UOnlineSessionSubsystemPingSearchResults : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnPingSearchResultsComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FOnlineSessionSearchResultBP __Store__SearchResult;  // 0x60(0x190)

	struct UOnlineSessionSubsystemPingSearchResults* PingSearchResults(struct UOnlineSessionSubsystem* Subsystem, struct FOnlineSessionSearchResultBP SearchResult); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemPingSearchResults.PingSearchResults
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemJoinSession
// Size: 0x228(Inherited: 0x30) 
struct UOnlineSessionSubsystemJoinSession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnJoinSessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x60(0x30)
	struct FName __Store__SessionName;  // 0x90(0x8)
	struct FOnlineSessionSearchResultBP __Store__DesiredSession;  // 0x98(0x190)

	struct UOnlineSessionSubsystemJoinSession* JoinSession(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FName SessionName, struct FOnlineSessionSearchResultBP DesiredSession); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemJoinSession.JoinSession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemFindFriendSession
// Size: 0x98(Inherited: 0x30) 
struct UOnlineSessionSubsystemFindFriendSession : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFindFriendSessionComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FUniqueNetIdRepl __Store__Friend;  // 0x68(0x30)

	struct UOnlineSessionSubsystemFindFriendSession* FindFriendSession(struct UOnlineSessionSubsystem* Subsystem, int32_t LocalUserNum, struct FUniqueNetIdRepl Friend); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemFindFriendSession.FindFriendSession
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterPlayers
// Size: 0x80(Inherited: 0x30) 
struct UOnlineSessionSubsystemRegisterPlayers : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnRegisterPlayersComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FName __Store__SessionName;  // 0x60(0x8)
	struct TArray<struct FUniqueNetIdRepl> __Store__Players;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool __Store__bWasInvited : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

	struct UOnlineSessionSubsystemRegisterPlayers* RegisterPlayers(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName, struct TArray<struct FUniqueNetIdRepl> Players, bool bWasInvited); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterPlayers.RegisterPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterPlayers
// Size: 0x78(Inherited: 0x30) 
struct UOnlineSessionSubsystemUnregisterPlayers : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnUnregisterPlayersComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FName __Store__SessionName;  // 0x60(0x8)
	struct TArray<struct FUniqueNetIdRepl> __Store__Players;  // 0x68(0x10)

	struct UOnlineSessionSubsystemUnregisterPlayers* UnregisterPlayers(struct UOnlineSessionSubsystem* Subsystem, struct FName SessionName, struct TArray<struct FUniqueNetIdRepl> Players); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterPlayers.UnregisterPlayers
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterLocalPlayer
// Size: 0x90(Inherited: 0x30) 
struct UOnlineSessionSubsystemRegisterLocalPlayer : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnRegisterLocalPlayerComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__PlayerId;  // 0x58(0x30)
	struct FName __Store__SessionName;  // 0x88(0x8)

	struct UOnlineSessionSubsystemRegisterLocalPlayer* RegisterLocalPlayer(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl PlayerId, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterLocalPlayer.RegisterLocalPlayer
}; 



// Class OnlineSubsystemBlueprints.VoiceChatUserLogin
// Size: 0x80(Inherited: 0x30) 
struct UVoiceChatUserLogin : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceChatLoginComplete;  // 0x40(0x10)
	struct UVoiceChatUser* __Store__Subsystem;  // 0x50(0x8)
	int32_t __Store__PlatformId;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString __Store__PlayerName;  // 0x60(0x10)
	struct FString __Store__Credentials;  // 0x70(0x10)

	struct UVoiceChatUserLogin* Login(struct UVoiceChatUser* Subsystem, int32_t PlatformId, struct FString PlayerName, struct FString Credentials); // Function OnlineSubsystemBlueprints.VoiceChatUserLogin.Login
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterLocalPlayer
// Size: 0x90(Inherited: 0x30) 
struct UOnlineSessionSubsystemUnregisterLocalPlayer : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnUnregisterLocalPlayerComplete;  // 0x40(0x10)
	struct UOnlineSessionSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__PlayerId;  // 0x58(0x30)
	struct FName __Store__SessionName;  // 0x88(0x8)

	struct UOnlineSessionSubsystemUnregisterLocalPlayer* UnregisterLocalPlayer(struct UOnlineSessionSubsystem* Subsystem, struct FUniqueNetIdRepl PlayerId, struct FName SessionName); // Function OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterLocalPlayer.UnregisterLocalPlayer
}; 



// Class OnlineSubsystemBlueprints.OnlineSharedCloudSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineSharedCloudSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool WriteSharedFile(struct FUniqueNetIdRepl UserId, struct FString Filename, struct UFileData*& Contents); // Function OnlineSubsystemBlueprints.OnlineSharedCloudSubsystem.WriteSharedFile
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineSharedCloudSubsystem.IsSubsystemAvailable
	bool ClearSharedFiles(); // Function OnlineSubsystemBlueprints.OnlineSharedCloudSubsystem.ClearSharedFiles
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemCreateChannelCredentials
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineVoiceAdminSubsystemCreateChannelCredentials : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceAdminCreateChannelCredentialsComplete;  // 0x40(0x10)
	struct UOnlineVoiceAdminSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ChannelName;  // 0x88(0x10)
	struct TArray<struct FUniqueNetIdRepl> __Store__TargetUserIds;  // 0x98(0x10)

	struct UOnlineVoiceAdminSubsystemCreateChannelCredentials* CreateChannelCredentials(struct UOnlineVoiceAdminSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ChannelName, struct TArray<struct FUniqueNetIdRepl> TargetUserIds); // Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemCreateChannelCredentials.CreateChannelCredentials
}; 



// Class OnlineSubsystemBlueprints.OnlineSharingSubsystem
// Size: 0xD0(Inherited: 0x30) 
struct UOnlineSharingSubsystem : public UGameInstanceSubsystem
{
	char pad_48[96];  // 0x30(0x60)
	struct FMulticastInlineDelegate OnRequestNewReadPermissionsComplete;  // 0x90(0x10)
	struct FMulticastInlineDelegate OnRequestNewPublishPermissionsComplete;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnReadNewsFeedComplete;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnSharePostComplete;  // 0xC0(0x10)

	bool ReadNewsFeed(int32_t LocalUserNum, int32_t NumPostsToRead); // Function OnlineSubsystemBlueprints.OnlineSharingSubsystem.ReadNewsFeed
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineSharingSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineStatsSubsystemQueryStats
// Size: 0xA8(Inherited: 0x30) 
struct UOnlineStatsSubsystemQueryStats : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnlineStatsQueryUsersStatsComplete;  // 0x40(0x10)
	struct UOnlineStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FUniqueNetIdRepl> __Store__StatUsers;  // 0x88(0x10)
	struct TArray<struct FString> __Store__StatNames;  // 0x98(0x10)

	struct UOnlineStatsSubsystemQueryStats* QueryStats(struct UOnlineStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FUniqueNetIdRepl> StatUsers, struct TArray<struct FString> StatNames); // Function OnlineSubsystemBlueprints.OnlineStatsSubsystemQueryStats.QueryStats
}; 



// Class OnlineSubsystemBlueprints.OnlineStatsSubsystemUpdateStats
// Size: 0x98(Inherited: 0x30) 
struct UOnlineStatsSubsystemUpdateStats : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnlineStatsUpdateStatsComplete;  // 0x40(0x10)
	struct UOnlineStatsSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct TArray<struct FOnlineStatsUserUpdatedStatsBP> __Store__UpdatedUserStats;  // 0x88(0x10)

	struct UOnlineStatsSubsystemUpdateStats* UpdateStats(struct UOnlineStatsSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct TArray<struct FOnlineStatsUserUpdatedStatsBP> UpdatedUserStats); // Function OnlineSubsystemBlueprints.OnlineStatsSubsystemUpdateStats.UpdateStats
}; 



// Class OnlineSubsystemBlueprints.OnlineStoreV2Subsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlineStoreV2Subsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnQueryForAvailablePurchasesComplete;  // 0x58(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineStoreV2Subsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryCategories
// Size: 0x88(Inherited: 0x30) 
struct UOnlineStoreV2SubsystemQueryCategories : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryOnlineStoreCategoriesComplete;  // 0x40(0x10)
	struct UOnlineStoreV2Subsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)

	struct UOnlineStoreV2SubsystemQueryCategories* QueryCategories(struct UOnlineStoreV2Subsystem* Subsystem, struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryCategories.QueryCategories
}; 



// Class OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryOffersById
// Size: 0x98(Inherited: 0x30) 
struct UOnlineStoreV2SubsystemQueryOffersById : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryOnlineStoreOffersComplete;  // 0x40(0x10)
	struct UOnlineStoreV2Subsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct TArray<struct FString> __Store__OfferIds;  // 0x88(0x10)

	struct UOnlineStoreV2SubsystemQueryOffersById* QueryOffersById(struct UOnlineStoreV2Subsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct TArray<struct FString> OfferIds); // Function OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryOffersById.QueryOffersById
}; 



// Class OnlineSubsystemBlueprints.OnlineSubsystem
// Size: 0x80(Inherited: 0x30) 
struct UOnlineSubsystem : public UGameInstanceSubsystem
{
	struct TMap<struct FString, struct UGameInstanceSubsystem*> SubsystemCache;  // 0x30(0x50)

	struct UOnlineVoiceSubsystem* GetNamedVoiceSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedVoiceSubsystem
	struct UOnlineVoiceAdminSubsystem* GetNamedVoiceAdminSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedVoiceAdminSubsystem
	struct UOnlineUserSubsystem* GetNamedUserSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedUserSubsystem
	struct UOnlineUserCloudSubsystem* GetNamedUserCloudSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedUserCloudSubsystem
	struct UOnlineTurnBasedSubsystem* GetNamedTurnBasedSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTurnBasedSubsystem
	struct UOnlineTournamentSubsystem* GetNamedTournamentSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTournamentSubsystem
	struct UOnlineTitleFileSubsystem* GetNamedTitleFileSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTitleFileSubsystem
	struct UOnlineTimeSubsystem* GetNamedTimeSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTimeSubsystem
	struct UOnlineStoreV2Subsystem* GetNamedStoreV2Subsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedStoreV2Subsystem
	struct UOnlineStatsSubsystem* GetNamedStatsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedStatsSubsystem
	struct UOnlineSharingSubsystem* GetNamedSharingSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedSharingSubsystem
	struct UOnlineSharedCloudSubsystem* GetNamedSharedCloudSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedSharedCloudSubsystem
	struct UOnlineSessionSubsystem* GetNamedSessionSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedSessionSubsystem
	struct UOnlinePurchaseSubsystem* GetNamedPurchaseSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedPurchaseSubsystem
	struct UOnlinePresenceSubsystem* GetNamedPresenceSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedPresenceSubsystem
	struct UOnlinePartySubsystem* GetNamedPartySubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedPartySubsystem
	struct UOnlineMessageSubsystem* GetNamedMessageSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedMessageSubsystem
	struct UOnlineMessageSanitizerSubsystem* GetNamedMessageSanitizerSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedMessageSanitizerSubsystem
	struct UOnlineLobbySubsystem* GetNamedLobbySubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedLobbySubsystem
	struct UOnlineLeaderboardsSubsystem* GetNamedLeaderboardsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedLeaderboardsSubsystem
	struct UOnlineIdentitySubsystem* GetNamedIdentitySubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedIdentitySubsystem
	struct UOnlineGroupsSubsystem* GetNamedGroupsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedGroupsSubsystem
	struct UOnlineGameItemStatsSubsystem* GetNamedGameItemStatsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedGameItemStatsSubsystem
	struct UOnlineGameActivitySubsystem* GetNamedGameActivitySubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedGameActivitySubsystem
	struct UOnlineFriendsSubsystem* GetNamedFriendsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedFriendsSubsystem
	struct UOnlineExternalUISubsystem* GetNamedExternalUISubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedExternalUISubsystem
	struct UOnlineEventsSubsystem* GetNamedEventsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedEventsSubsystem
	struct UOnlineEntitlementsSubsystem* GetNamedEntitlementsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedEntitlementsSubsystem
	struct UOnlineChatSubsystem* GetNamedChatSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedChatSubsystem
	struct UOnlineAvatarSubsystem* GetNamedAvatarSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedAvatarSubsystem
	struct UOnlineAchievementsSubsystem* GetNamedAchievementsSubsystem(struct FName SubsystemName); // Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedAchievementsSubsystem
}; 



// Class OnlineSubsystemBlueprints.OnlineTimeSubsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlineTimeSubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnQueryServerUtcTimeComplete;  // 0x58(0x10)

	bool QueryServerUtcTime(); // Function OnlineSubsystemBlueprints.OnlineTimeSubsystem.QueryServerUtcTime
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineTimeSubsystem.IsSubsystemAvailable
	struct FString GetLastServerUtcTime(); // Function OnlineSubsystemBlueprints.OnlineTimeSubsystem.GetLastServerUtcTime
}; 



// Class OnlineSubsystemBlueprints.OnlineTitleFileSubsystem
// Size: 0x98(Inherited: 0x30) 
struct UOnlineTitleFileSubsystem : public UGameInstanceSubsystem
{
	char pad_48[56];  // 0x30(0x38)
	struct FMulticastInlineDelegate OnEnumerateFilesComplete;  // 0x68(0x10)
	struct FMulticastInlineDelegate OnReadFileComplete;  // 0x78(0x10)
	struct FMulticastInlineDelegate OnReadFileProgress;  // 0x88(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.IsSubsystemAvailable
	void GetFileList(struct TArray<struct FCloudFileHeaderBP>& Files); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.GetFileList
	bool GetFileContents(struct FString Filename, struct UFileData*& FileContents); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.GetFileContents
	void DeleteCachedFiles(bool bSkipEnumerated); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.DeleteCachedFiles
	bool ClearFiles(); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.ClearFiles
	bool ClearFile(struct FString Filename); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.ClearFile
}; 



// Class OnlineSubsystemBlueprints.OnlineTitleFileSubsystemEnumerateFiles
// Size: 0x68(Inherited: 0x30) 
struct UOnlineTitleFileSubsystemEnumerateFiles : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnEnumerateFilesComplete;  // 0x40(0x10)
	struct UOnlineTitleFileSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FPagedQueryBP __Store__Page;  // 0x60(0x8)

	struct UOnlineTitleFileSubsystemEnumerateFiles* EnumerateFiles(struct UOnlineTitleFileSubsystem* Subsystem, struct FPagedQueryBP Page); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystemEnumerateFiles.EnumerateFiles
}; 



// Class OnlineSubsystemBlueprints.OnlineTitleFileSubsystemReadFile
// Size: 0x88(Inherited: 0x30) 
struct UOnlineTitleFileSubsystemReadFile : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnReadFileComplete;  // 0x40(0x10)
	struct FMulticastInlineDelegate OnReadFileProgress;  // 0x50(0x10)
	struct UOnlineTitleFileSubsystem* __Store__Subsystem;  // 0x60(0x8)
	char pad_104[16];  // 0x68(0x10)
	struct FString __Store__FileName;  // 0x78(0x10)

	struct UOnlineTitleFileSubsystemReadFile* ReadFile(struct UOnlineTitleFileSubsystem* Subsystem, struct FString Filename); // Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystemReadFile.ReadFile
}; 



// Class OnlineSubsystemBlueprints.OnlineTournamentSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineTournamentSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineTournamentSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadAllMatches
// Size: 0x58(Inherited: 0x30) 
struct UOnlineTurnBasedSubsystemLoadAllMatches : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate LoadTurnBasedMatchesSignature;  // 0x40(0x10)
	struct UOnlineTurnBasedSubsystem* __Store__Subsystem;  // 0x50(0x8)

	struct UOnlineTurnBasedSubsystemLoadAllMatches* LoadAllMatches(struct UOnlineTurnBasedSubsystem* Subsystem); // Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadAllMatches.LoadAllMatches
}; 



// Class OnlineSubsystemBlueprints.ExternalUIFlowHandler
// Size: 0x28(Inherited: 0x28) 
struct UExternalUIFlowHandler : public UInterface
{

	bool OnLoginFlowUIRequired(struct FString RequestedURL, struct UOnlineExternalUISubsystem* ExternalUIContext, int32_t RequestId); // Function OnlineSubsystemBlueprints.ExternalUIFlowHandler.OnLoginFlowUIRequired
	bool OnCreateAccountFlowUIRequired(struct FString RequestedURL, struct UOnlineExternalUISubsystem* ExternalUIContext, int32_t RequestId); // Function OnlineSubsystemBlueprints.ExternalUIFlowHandler.OnCreateAccountFlowUIRequired
}; 



// Class OnlineSubsystemBlueprints.OnlineUserCloudSubsystem
// Size: 0xE0(Inherited: 0x30) 
struct UOnlineUserCloudSubsystem : public UGameInstanceSubsystem
{
	char pad_48[80];  // 0x30(0x50)
	struct FMulticastInlineDelegate OnEnumerateUserFilesComplete;  // 0x80(0x10)
	struct FMulticastInlineDelegate OnReadUserFileComplete;  // 0x90(0x10)
	struct FMulticastInlineDelegate OnWriteUserFileProgress;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnWriteUserFileComplete;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnWriteUserFileCanceled;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnDeleteUserFileComplete;  // 0xD0(0x10)

	bool RequestUsageInfo(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.RequestUsageInfo
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.IsSubsystemAvailable
	void GetUserFileList(struct FUniqueNetIdRepl UserId, struct TArray<struct FCloudFileHeaderBP>& UserFiles); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.GetUserFileList
	bool GetFileContents(struct FUniqueNetIdRepl UserId, struct FString Filename, struct UFileData*& FileContents); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.GetFileContents
	void DumpCloudState(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.DumpCloudState
	void DumpCloudFileState(struct FUniqueNetIdRepl UserId, struct FString Filename); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.DumpCloudFileState
	bool ClearFiles(struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.ClearFiles
	bool ClearFile(struct FUniqueNetIdRepl UserId, struct FString Filename); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.ClearFile
	void CancelWriteUserFile(struct FUniqueNetIdRepl UserId, struct FString Filename); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.CancelWriteUserFile
}; 



// Class OnlineSubsystemBlueprints.OnlineUserCloudSubsystemEnumerateUserFiles
// Size: 0x90(Inherited: 0x30) 
struct UOnlineUserCloudSubsystemEnumerateUserFiles : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnEnumerateUserFilesComplete;  // 0x40(0x10)
	struct UOnlineUserCloudSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x60(0x30)

	struct UOnlineUserCloudSubsystemEnumerateUserFiles* EnumerateUserFiles(struct UOnlineUserCloudSubsystem* Subsystem, struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemEnumerateUserFiles.EnumerateUserFiles
}; 



// Class OnlineSubsystemBlueprints.OnlineUserCloudSubsystemWriteUserFile
// Size: 0xE0(Inherited: 0x30) 
struct UOnlineUserCloudSubsystemWriteUserFile : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnWriteUserFileComplete;  // 0x40(0x10)
	struct FMulticastInlineDelegate OnWriteUserFileProgress;  // 0x50(0x10)
	struct FMulticastInlineDelegate OnWriteUserFileCanceled;  // 0x60(0x10)
	struct UOnlineUserCloudSubsystem* __Store__Subsystem;  // 0x70(0x8)
	char pad_120[24];  // 0x78(0x18)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x90(0x30)
	struct FString __Store__FileName;  // 0xC0(0x10)
	struct UFileData* __Store__FileContents;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool __Store__bCompressBeforeUpload : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)

	struct UOnlineUserCloudSubsystemWriteUserFile* WriteUserFile(struct UOnlineUserCloudSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FString Filename, struct UFileData* FileContents, bool bCompressBeforeUpload); // Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemWriteUserFile.WriteUserFile
}; 



// Class OnlineSubsystemBlueprints.OnlineUserSubsystem
// Size: 0x70(Inherited: 0x30) 
struct UOnlineUserSubsystem : public UGameInstanceSubsystem
{
	char pad_48[48];  // 0x30(0x30)
	struct FMulticastInlineDelegate OnQueryUserInfoComplete;  // 0x60(0x10)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineUserSubsystem.IsSubsystemAvailable
	struct UOnlineUserRef* GetUserInfo(int32_t LocalUserNum, struct FUniqueNetIdRepl UserId); // Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetUserInfo
	void GetExternalIdMappings(struct FExternalIdQueryOptionsBP QueryOptions, struct TArray<struct FString> ExternalIds, struct TArray<struct FUniqueNetIdRepl>& OutIds); // Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetExternalIdMappings
	struct FUniqueNetIdRepl GetExternalIdMapping(struct FExternalIdQueryOptionsBP QueryOptions, struct FString ExternalId); // Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetExternalIdMapping
	bool GetAllUserInfo(int32_t LocalUserNum, struct TArray<struct UOnlineUserRef*>& OutUsers); // Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetAllUserInfo
}; 



// Class OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserInfo
// Size: 0x78(Inherited: 0x30) 
struct UOnlineUserSubsystemQueryUserInfo : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryUserInfoComplete;  // 0x40(0x10)
	struct UOnlineUserSubsystem* __Store__Subsystem;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	int32_t __Store__LocalUserNum;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<struct FUniqueNetIdRepl> __Store__UserIds;  // 0x68(0x10)

	struct UOnlineUserSubsystemQueryUserInfo* QueryUserInfo(struct UOnlineUserSubsystem* Subsystem, int32_t LocalUserNum, struct TArray<struct FUniqueNetIdRepl> UserIds); // Function OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserInfo.QueryUserInfo
}; 



// Class OnlineSubsystemBlueprints.OnlineUserSubsystemQueryExternalIdMappings
// Size: 0xB0(Inherited: 0x30) 
struct UOnlineUserSubsystemQueryExternalIdMappings : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnQueryExternalIdMappingsComplete;  // 0x40(0x10)
	struct UOnlineUserSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__UserId;  // 0x58(0x30)
	struct FExternalIdQueryOptionsBP __Store__QueryOptions;  // 0x88(0x18)
	struct TArray<struct FString> __Store__ExternalIds;  // 0xA0(0x10)

	struct UOnlineUserSubsystemQueryExternalIdMappings* QueryExternalIdMappings(struct UOnlineUserSubsystem* Subsystem, struct FUniqueNetIdRepl UserId, struct FExternalIdQueryOptionsBP QueryOptions, struct TArray<struct FString> ExternalIds); // Function OnlineSubsystemBlueprints.OnlineUserSubsystemQueryExternalIdMappings.QueryExternalIdMappings
}; 



// Class OnlineSubsystemBlueprints.FileData
// Size: 0x38(Inherited: 0x28) 
struct UFileData : public UObject
{
	char pad_40[16];  // 0x28(0x10)

}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystem
// Size: 0x50(Inherited: 0x30) 
struct UOnlineVoiceAdminSubsystem : public UGameInstanceSubsystem
{
	char pad_48[32];  // 0x30(0x20)

	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystem.IsSubsystemAvailable
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemKickParticipant
// Size: 0xC8(Inherited: 0x30) 
struct UOnlineVoiceAdminSubsystemKickParticipant : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceAdminKickParticipantComplete;  // 0x40(0x10)
	struct UOnlineVoiceAdminSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ChannelName;  // 0x88(0x10)
	struct FUniqueNetIdRepl __Store__TargetUserId;  // 0x98(0x30)

	struct UOnlineVoiceAdminSubsystemKickParticipant* KickParticipant(struct UOnlineVoiceAdminSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ChannelName, struct FUniqueNetIdRepl TargetUserId); // Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemKickParticipant.KickParticipant
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemSetParticipantHardMute
// Size: 0xD0(Inherited: 0x30) 
struct UOnlineVoiceAdminSubsystemSetParticipantHardMute : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceAdminSetParticipantHardMuteComplete;  // 0x40(0x10)
	struct UOnlineVoiceAdminSubsystem* __Store__Subsystem;  // 0x50(0x8)
	struct FUniqueNetIdRepl __Store__LocalUserId;  // 0x58(0x30)
	struct FString __Store__ChannelName;  // 0x88(0x10)
	struct FUniqueNetIdRepl __Store__TargetUserId;  // 0x98(0x30)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool __Store__bMuted : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)

	struct UOnlineVoiceAdminSubsystemSetParticipantHardMute* SetParticipantHardMute(struct UOnlineVoiceAdminSubsystem* Subsystem, struct FUniqueNetIdRepl LocalUserId, struct FString ChannelName, struct FUniqueNetIdRepl TargetUserId, bool bMuted); // Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemSetParticipantHardMute.SetParticipantHardMute
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemConnect
// Size: 0x58(Inherited: 0x30) 
struct UOnlineVoiceChatSubsystemConnect : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceChatConnectComplete;  // 0x40(0x10)
	struct UOnlineVoiceChatSubsystem* __Store__Subsystem;  // 0x50(0x8)

	struct UOnlineVoiceChatSubsystemConnect* Connect(struct UOnlineVoiceChatSubsystem* Subsystem); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemConnect.Connect
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemDisconnect
// Size: 0x58(Inherited: 0x30) 
struct UOnlineVoiceChatSubsystemDisconnect : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceChatDisconnectComplete;  // 0x40(0x10)
	struct UOnlineVoiceChatSubsystem* __Store__Subsystem;  // 0x50(0x8)

	struct UOnlineVoiceChatSubsystemDisconnect* Disconnect(struct UOnlineVoiceChatSubsystem* Subsystem); // Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemDisconnect.Disconnect
}; 



// Class OnlineSubsystemBlueprints.OnlineVoiceSubsystem
// Size: 0x68(Inherited: 0x30) 
struct UOnlineVoiceSubsystem : public UGameInstanceSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnPlayerTalkingStateChanged;  // 0x58(0x10)

	bool UnregisterRemoteTalker(struct FUniqueNetIdRepl UniqueId); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnregisterRemoteTalker
	void UnregisterLocalTalkers(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnregisterLocalTalkers
	bool UnregisterLocalTalker(int64_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnregisterLocalTalker
	bool UnmuteRemoteTalker(int32_t LocalUserNum, struct FUniqueNetIdRepl PlayerId, bool bIsSystemWide); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnmuteRemoteTalker
	void StopNetworkedVoice(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.StopNetworkedVoice
	void StartNetworkedVoice(int32_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.StartNetworkedVoice
	void RemoveAllRemoteTalkers(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.RemoveAllRemoteTalkers
	bool RegisterRemoteTalker(struct FUniqueNetIdRepl UniqueId); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.RegisterRemoteTalker
	void RegisterLocalTalkers(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.RegisterLocalTalkers
	bool RegisterLocalTalker(int64_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.RegisterLocalTalker
	void ProcessMuteChangeNotification(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.ProcessMuteChangeNotification
	bool PatchRemoteTalkerOutputToEndpoint(struct FString InDeviceName, bool bMuteInGameOutput); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.PatchRemoteTalkerOutputToEndpoint
	bool PatchLocalTalkerOutputToEndpoint(struct FString InDeviceName); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.PatchLocalTalkerOutputToEndpoint
	bool MuteRemoteTalker(int32_t LocalUserNum, struct FUniqueNetIdRepl PlayerId, bool bIsSystemWide); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.MuteRemoteTalker
	bool IsSubsystemAvailable(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsSubsystemAvailable
	bool IsRemotePlayerTalking(struct FUniqueNetIdRepl UniqueId); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsRemotePlayerTalking
	bool IsMuted(int64_t LocalUserNum, struct FUniqueNetIdRepl UniqueId); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsMuted
	bool IsLocalPlayerTalking(int64_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsLocalPlayerTalking
	bool IsHeadsetPresent(int64_t LocalUserNum); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsHeadsetPresent
	struct FString GetVoiceDebugState(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.GetVoiceDebugState
	int32_t GetNumLocalTalkers(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.GetNumLocalTalkers
	float GetAmplitudeOfRemoteTalker(struct FUniqueNetIdRepl PlayerId); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.GetAmplitudeOfRemoteTalker
	void DisconnectAllEndpoints(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.DisconnectAllEndpoints
	void ClearVoicePackets(); // Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.ClearVoicePackets
}; 



// Class OnlineSubsystemBlueprints.OnlineFriendRef
// Size: 0x58(Inherited: 0x48) 
struct UOnlineFriendRef : public UOnlineUserRef
{
	char pad_72[16];  // 0x48(0x10)

	struct FOnlineUserPresenceData GetPresence(); // Function OnlineSubsystemBlueprints.OnlineFriendRef.GetPresence
	uint8_t  GetInviteStatus(); // Function OnlineSubsystemBlueprints.OnlineFriendRef.GetInviteStatus
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardRead
// Size: 0x38(Inherited: 0x28) 
struct UOnlineLeaderboardRead : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void SetSortedColumn(struct FName SortedColumn); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.SetSortedColumn
	void SetLeaderboardName(struct FName LeaderboardName); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.SetLeaderboardName
	void SetColumns(struct TArray<struct FColumnMetaDataBP> InColumns); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.SetColumns
	struct FName GetSortedColumn(); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetSortedColumn
	struct TArray<struct FOnlineStatsRowBP> GetRows(); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetRows
	uint8_t  GetReadState(); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetReadState
	struct FName GetLeaderboardName(); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetLeaderboardName
	struct TArray<struct FColumnMetaDataBP> GetColumns(); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetColumns
	struct FOnlineStatsRowBP FindPlayerRecord(struct FUniqueNetIdRepl UserId, bool& OutFound); // Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.FindPlayerRecord
}; 



// Class OnlineSubsystemBlueprints.OnlineLeaderboardWrite
// Size: 0x28(Inherited: 0x28) 
struct UOnlineLeaderboardWrite : public UObject
{

}; 



// Class OnlineSubsystemBlueprints.LobbyId
// Size: 0x38(Inherited: 0x28) 
struct ULobbyId : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToDebugString(); // Function OnlineSubsystemBlueprints.LobbyId.ToDebugString
}; 



// Class OnlineSubsystemBlueprints.Lobby
// Size: 0x38(Inherited: 0x28) 
struct ULobby : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FUniqueNetIdRepl GetOwnerId(); // Function OnlineSubsystemBlueprints.Lobby.GetOwnerId
	struct ULobbyId* GetId(); // Function OnlineSubsystemBlueprints.Lobby.GetId
}; 



// Class OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction
// Size: 0x38(Inherited: 0x28) 
struct UOnlineLobbyMemberTransaction : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void SetMetadataByMap(struct TMap<struct FString, struct FVariantDataBP>& MetaData); // Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.SetMetadataByMap
	void SetMetadata(struct FString Key, struct FVariantDataBP& Value); // Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.SetMetadata
	void DeleteMetadataByArray(struct TArray<struct FString>& MetadataKeys); // Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.DeleteMetadataByArray
	void DeleteMetadata(struct FString Key); // Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.DeleteMetadata
}; 



// Class OnlineSubsystemBlueprints.OnlineRecentPlayerRef
// Size: 0x58(Inherited: 0x48) 
struct UOnlineRecentPlayerRef : public UOnlineUserRef
{
	char pad_72[16];  // 0x48(0x10)

	struct FDateTime GetLastSeen(); // Function OnlineSubsystemBlueprints.OnlineRecentPlayerRef.GetLastSeen
}; 



// Class OnlineSubsystemBlueprints.UserOnlineAccountRef
// Size: 0x58(Inherited: 0x48) 
struct UUserOnlineAccountRef : public UOnlineUserRef
{
	char pad_72[16];  // 0x48(0x10)

	bool SetUserAttribute(struct FString Key, struct FString Value); // Function OnlineSubsystemBlueprints.UserOnlineAccountRef.SetUserAttribute
	struct FString GetAuthAttribute(struct FString Key, bool& Found); // Function OnlineSubsystemBlueprints.UserOnlineAccountRef.GetAuthAttribute
	struct FString GetAccessToken(); // Function OnlineSubsystemBlueprints.UserOnlineAccountRef.GetAccessToken
}; 



// Class OnlineSubsystemBlueprints.Party
// Size: 0x38(Inherited: 0x28) 
struct UParty : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	int64_t GetPartyTypeId(); // Function OnlineSubsystemBlueprints.Party.GetPartyTypeId
	struct UPartyId* GetPartyId(); // Function OnlineSubsystemBlueprints.Party.GetPartyId
	struct FUniqueNetIdRepl GetLeaderId(); // Function OnlineSubsystemBlueprints.Party.GetLeaderId
}; 



// Class OnlineSubsystemBlueprints.BlueprintPartyMember
// Size: 0x68(Inherited: 0x28) 
struct UBlueprintPartyMember : public UObject
{
	char pad_40[32];  // 0x28(0x20)
	struct FMulticastInlineDelegate OnAttributeChanged;  // 0x48(0x10)
	struct FMulticastInlineDelegate OnConnectionStatusChanged;  // 0x58(0x10)

	struct FUniqueNetIdRepl GetUserId(); // Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetUserId
	bool GetUserAttribute(struct FString AttrName, struct FString& OutAttrValue); // Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetUserAttribute
	struct FString GetRealName(); // Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetRealName
	struct FString GetDisplayName(struct FString Platform); // Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetDisplayName
}; 



// Class OnlineSubsystemBlueprints.ReadablePartyData
// Size: 0x38(Inherited: 0x28) 
struct UReadablePartyData : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void GetAttribute(struct FString AttrName, bool& OutFound, struct FVariantDataBP& OutAttrValue); // Function OnlineSubsystemBlueprints.ReadablePartyData.GetAttribute
}; 



// Class OnlineSubsystemBlueprints.MutablePartyData
// Size: 0x48(Inherited: 0x38) 
struct UMutablePartyData : public UReadablePartyData
{
	char pad_56[16];  // 0x38(0x10)

	void SetAttribute(struct FString AttrName, struct FVariantDataBP AttrValue); // Function OnlineSubsystemBlueprints.MutablePartyData.SetAttribute
	void RemoveAttribute(struct FString AttrName); // Function OnlineSubsystemBlueprints.MutablePartyData.RemoveAttribute
}; 



// Class OnlineSubsystemBlueprints.OnlinePartyJoinInfo
// Size: 0x38(Inherited: 0x28) 
struct UOnlinePartyJoinInfo : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToDebugString(); // Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.ToDebugString
	struct FUniqueNetIdRepl GetSourceUserId(); // Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.GetSourceUserId
	struct FString GetSourceDisplayName(); // Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.GetSourceDisplayName
	struct UPartyId* GetPartyId(); // Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.GetPartyId
}; 



// Class OnlineSubsystemBlueprints.OnlineSessionSettings
// Size: 0x150(Inherited: 0x28) 
struct UOnlineSessionSettings : public UObject
{
	char pad_40[296];  // 0x28(0x128)

	struct FOnlineSessionSettingsBP GetValue(); // Function OnlineSubsystemBlueprints.OnlineSessionSettings.GetValue
}; 



// Class OnlineSubsystemBlueprints.NamedOnlineSession
// Size: 0x208(Inherited: 0x28) 
struct UNamedOnlineSession : public UObject
{
	char pad_40[480];  // 0x28(0x1E0)

	struct FNamedOnlineSessionBP GetValue(); // Function OnlineSubsystemBlueprints.NamedOnlineSession.GetValue
}; 



// Class OnlineSubsystemBlueprints.VoiceChatUserJoinChannel
// Size: 0x90(Inherited: 0x30) 
struct UVoiceChatUserJoinChannel : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceChatChannelJoinComplete;  // 0x40(0x10)
	struct UVoiceChatUser* __Store__Subsystem;  // 0x50(0x8)
	struct FString __Store__ChannelName;  // 0x58(0x10)
	struct FString __Store__ChannelCredentials;  // 0x68(0x10)
	uint8_t  __Store__ChannelType;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FVoiceChatChannel3dPropertiesBP __Store__Channel3dProperties;  // 0x7C(0x10)
	char pad_140[4];  // 0x8C(0x4)

	struct UVoiceChatUserJoinChannel* JoinChannel(struct UVoiceChatUser* Subsystem, struct FString ChannelName, struct FString ChannelCredentials, uint8_t  ChannelType, struct FVoiceChatChannel3dPropertiesBP Channel3dProperties); // Function OnlineSubsystemBlueprints.VoiceChatUserJoinChannel.JoinChannel
}; 



// Class OnlineSubsystemBlueprints.VoiceChatUserLeaveChannel
// Size: 0x68(Inherited: 0x30) 
struct UVoiceChatUserLeaveChannel : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnCallFailed;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnVoiceChatChannelLeaveComplete;  // 0x40(0x10)
	struct UVoiceChatUser* __Store__Subsystem;  // 0x50(0x8)
	struct FString __Store__ChannelName;  // 0x58(0x10)

	struct UVoiceChatUserLeaveChannel* LeaveChannel(struct UVoiceChatUser* Subsystem, struct FString ChannelName); // Function OnlineSubsystemBlueprints.VoiceChatUserLeaveChannel.LeaveChannel
}; 



