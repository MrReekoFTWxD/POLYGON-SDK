#pragma once 
#include "SDK.h" 
 
 
// Function CommonInput.CommonInputSubsystem.SetGamepadInputType
// Size: 0x8(Inherited: 0x0) 
struct FSetGamepadInputType
{
	struct FName InGamepadInputType;  // 0x0(0x8)

}; 
// ScriptStruct CommonInput.InputDeviceIdentifierPair
// Size: 0x18(Inherited: 0x0) 
struct FInputDeviceIdentifierPair
{
	struct FName InputDeviceName;  // 0x0(0x8)
	struct FString HardwareDeviceIdentifier;  // 0x8(0x10)

}; 
// DelegateFunction CommonInput.InputMethodChangedDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FInputMethodChangedDelegate__DelegateSignature
{
	uint8_t  bNewInputType;  // 0x0(0x1)

}; 
// ScriptStruct CommonInput.CommonInputKeyBrushConfiguration
// Size: 0xF0(Inherited: 0x0) 
struct FCommonInputKeyBrushConfiguration
{
	struct FKey Key;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FSlateBrush KeyBrush;  // 0x20(0xD0)

}; 
// ScriptStruct CommonInput.CommonInputKeySetBrushConfiguration
// Size: 0xE0(Inherited: 0x0) 
struct FCommonInputKeySetBrushConfiguration
{
	struct TArray<struct FKey> Keys;  // 0x0(0x10)
	struct FSlateBrush KeyBrush;  // 0x10(0xD0)

}; 
// ScriptStruct CommonInput.CommonInputPlatformBaseData
// Size: 0x38(Inherited: 0x0) 
struct FCommonInputPlatformBaseData
{
	char pad_0[8];  // 0x0(0x8)
	uint8_t  DefaultInputType;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bSupportsMouseAndKeyboard : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bSupportsGamepad : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	struct FName DefaultGamepadName;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bCanChangeGamepadType : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bSupportsTouch : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData;  // 0x18(0x10)
	struct TArray<UCommonInputBaseControllerData*> ControllerDataClasses;  // 0x28(0x10)

}; 
// Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
// Size: 0x10(Inherited: 0x0) 
struct FGetRegisteredGamepads
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentGamepadName
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function CommonInput.CommonInputSubsystem.IsInputMethodActive
// Size: 0x2(Inherited: 0x0) 
struct FIsInputMethodActive
{
	uint8_t  InputMethod;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function CommonInput.CommonInputSubsystem.GetCurrentInputType
// Size: 0x1(Inherited: 0x0) 
struct FGetCurrentInputType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function CommonInput.CommonInputSubsystem.GetDefaultInputType
// Size: 0x1(Inherited: 0x0) 
struct FGetDefaultInputType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
// Size: 0x1(Inherited: 0x0) 
struct FIsUsingPointerInput
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonInput.CommonInputSubsystem.SetCurrentInputType
// Size: 0x1(Inherited: 0x0) 
struct FSetCurrentInputType
{
	uint8_t  NewInputType;  // 0x0(0x1)

}; 
// Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
// Size: 0x1(Inherited: 0x0) 
struct FShouldShowInputKeys
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
