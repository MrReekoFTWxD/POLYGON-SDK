#pragma once 
#include <GeometryCollectionEngine_Structs.h>
 
 
 
// Class GeometryCollectionEngine.GeometryCollection
// Size: 0x108(Inherited: 0x28) 
struct UGeometryCollection : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool EnableClustering : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t ClusterGroupIndex;  // 0x34(0x4)
	int32_t MaxClusterLevel;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct TArray<float> DamageThreshold;  // 0x40(0x10)
	uint8_t  ClusterConnectionType;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x58(0x10)
	struct TArray<struct FGeometryCollectionEmbeddedExemplar> EmbeddedGeometryExemplar;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bUseFullPrecisionUVs : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool bStripOnCook : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool EnableNanite : 1;  // 0x7A(0x1)
	char pad_123_1 : 7;  // 0x7B(0x1)
	bool bMassAsDensity : 1;  // 0x7B(0x1)
	float Mass;  // 0x7C(0x4)
	float MinimumMassClamp;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool bRemoveOnMaxSleep : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct FVector2D MaximumSleepTime;  // 0x88(0x10)
	struct FVector2D RemovalDuration;  // 0x98(0x10)
	struct TArray<struct FGeometryCollectionSizeSpecificData> SizeSpecificData;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool EnableRemovePiecesOnFracture : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct TArray<struct UMaterialInterface*> RemoveOnFractureMaterials;  // 0xC0(0x10)
	struct FGuid PersistentGuid;  // 0xD0(0x10)
	struct FGuid StateGuid;  // 0xE0(0x10)
	int32_t BoneSelectedMaterialIndex;  // 0xF0(0x4)
	char pad_244[20];  // 0xF4(0x14)

}; 



// Class GeometryCollectionEngine.ChaosDestructionListener
// Size: 0x560(Inherited: 0x2B0) 
struct UChaosDestructionListener : public USceneComponent
{
	char bIsCollisionEventListeningEnabled : 1;  // 0x2B0(0x1)
	char bIsBreakingEventListeningEnabled : 1;  // 0x2B0(0x1)
	char bIsTrailingEventListeningEnabled : 1;  // 0x2B0(0x1)
	char bIsRemovalEventListeningEnabled : 1;  // 0x2B0(0x1)
	char pad_688_1 : 4;  // 0x2B0(0x1)
	char pad_689[4];  // 0x2B1(0x4)
	struct FChaosCollisionEventRequestSettings CollisionEventRequestSettings;  // 0x2B4(0x18)
	struct FChaosBreakingEventRequestSettings BreakingEventRequestSettings;  // 0x2CC(0x18)
	struct FChaosTrailingEventRequestSettings TrailingEventRequestSettings;  // 0x2E4(0x18)
	struct FChaosRemovalEventRequestSettings RemovalEventRequestSettings;  // 0x2FC(0x10)
	char pad_780[4];  // 0x30C(0x4)
	struct TSet<struct AChaosSolverActor*> ChaosSolverActors;  // 0x310(0x50)
	struct TSet<struct AGeometryCollectionActor*> GeometryCollectionActors;  // 0x360(0x50)
	struct FMulticastInlineDelegate OnCollisionEvents;  // 0x3B0(0x10)
	struct FMulticastInlineDelegate OnBreakingEvents;  // 0x3C0(0x10)
	struct FMulticastInlineDelegate OnTrailingEvents;  // 0x3D0(0x10)
	struct FMulticastInlineDelegate OnRemovalEvents;  // 0x3E0(0x10)
	char pad_1008[368];  // 0x3F0(0x170)

	void SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, uint8_t  SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents
	void SortRemovalEvents(struct TArray<struct FChaosRemovalEventData>& RemovalEvents, uint8_t  SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortRemovalEvents
	void SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, uint8_t  SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents
	void SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, uint8_t  SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents
	void SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings
	void SetTrailingEventEnabled(bool BIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled
	void SetRemovalEventRequestSettings(struct FChaosRemovalEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventRequestSettings
	void SetRemovalEventEnabled(bool BIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventEnabled
	void SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings
	void SetCollisionEventEnabled(bool BIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled
	void SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings
	void SetBreakingEventEnabled(bool BIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled
	void RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor
	void RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor
	bool IsEventListening(); // Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening
	void AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor
	void AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor
}; 



// Class GeometryCollectionEngine.GeometryCollectionDebugDrawComponent
// Size: 0xC8(Inherited: 0xB0) 
struct UGeometryCollectionDebugDrawComponent : public UActorComponent
{
	struct AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor;  // 0xB0(0x8)
	struct AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor;  // 0xB8(0x8)
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class GeometryCollectionEngine.GeometryCollectionActor
// Size: 0x288(Inherited: 0x278) 
struct AGeometryCollectionActor : public AActor
{
	struct UGeometryCollectionComponent* GeometryCollectionComponent;  // 0x278(0x8)
	struct UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent;  // 0x280(0x8)

	bool RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit); // Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle
}; 



// Class GeometryCollectionEngine.GeometryCollectionCache
// Size: 0x50(Inherited: 0x28) 
struct UGeometryCollectionCache : public UObject
{
	struct FRecordedTransformTrack RecordedData;  // 0x28(0x10)
	struct UGeometryCollection* SupportedCollection;  // 0x38(0x8)
	struct FGuid CompatibleCollectionState;  // 0x40(0x10)

}; 



// Class GeometryCollectionEngine.GeometryCollectionDebugDrawActor
// Size: 0x338(Inherited: 0x278) 
struct AGeometryCollectionDebugDrawActor : public AActor
{
	struct FGeometryCollectionDebugDrawWarningMessage WarningMessage;  // 0x278(0x1)
	char pad_633[7];  // 0x279(0x7)
	struct FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody;  // 0x280(0x18)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool bDebugDrawWholeCollection : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool bDebugDrawHierarchy : 1;  // 0x299(0x1)
	char pad_666_1 : 7;  // 0x29A(0x1)
	bool bDebugDrawClustering : 1;  // 0x29A(0x1)
	uint8_t  HideGeometry;  // 0x29B(0x1)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool bShowRigidBodyId : 1;  // 0x29C(0x1)
	char pad_669_1 : 7;  // 0x29D(0x1)
	bool bShowRigidBodyCollision : 1;  // 0x29D(0x1)
	char pad_670_1 : 7;  // 0x29E(0x1)
	bool bCollisionAtOrigin : 1;  // 0x29E(0x1)
	char pad_671_1 : 7;  // 0x29F(0x1)
	bool bShowRigidBodyTransform : 1;  // 0x29F(0x1)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool bShowRigidBodyInertia : 1;  // 0x2A0(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool bShowRigidBodyVelocity : 1;  // 0x2A1(0x1)
	char pad_674_1 : 7;  // 0x2A2(0x1)
	bool bShowRigidBodyForce : 1;  // 0x2A2(0x1)
	char pad_675_1 : 7;  // 0x2A3(0x1)
	bool bShowRigidBodyInfos : 1;  // 0x2A3(0x1)
	char pad_676_1 : 7;  // 0x2A4(0x1)
	bool bShowTransformIndex : 1;  // 0x2A4(0x1)
	char pad_677_1 : 7;  // 0x2A5(0x1)
	bool bShowTransform : 1;  // 0x2A5(0x1)
	char pad_678_1 : 7;  // 0x2A6(0x1)
	bool bShowParent : 1;  // 0x2A6(0x1)
	char pad_679_1 : 7;  // 0x2A7(0x1)
	bool bShowLevel : 1;  // 0x2A7(0x1)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool bShowConnectivityEdges : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool bShowGeometryIndex : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool bShowGeometryTransform : 1;  // 0x2AA(0x1)
	char pad_683_1 : 7;  // 0x2AB(0x1)
	bool bShowBoundingBox : 1;  // 0x2AB(0x1)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool bShowFaces : 1;  // 0x2AC(0x1)
	char pad_685_1 : 7;  // 0x2AD(0x1)
	bool bShowFaceIndices : 1;  // 0x2AD(0x1)
	char pad_686_1 : 7;  // 0x2AE(0x1)
	bool bShowFaceNormals : 1;  // 0x2AE(0x1)
	char pad_687_1 : 7;  // 0x2AF(0x1)
	bool bShowSingleFace : 1;  // 0x2AF(0x1)
	int32_t SingleFaceIndex;  // 0x2B0(0x4)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool bShowVertices : 1;  // 0x2B4(0x1)
	char pad_693_1 : 7;  // 0x2B5(0x1)
	bool bShowVertexIndices : 1;  // 0x2B5(0x1)
	char pad_694_1 : 7;  // 0x2B6(0x1)
	bool bShowVertexNormals : 1;  // 0x2B6(0x1)
	char pad_695_1 : 7;  // 0x2B7(0x1)
	bool bUseActiveVisualization : 1;  // 0x2B7(0x1)
	float PointThickness;  // 0x2B8(0x4)
	float LineThickness;  // 0x2BC(0x4)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bTextShadow : 1;  // 0x2C0(0x1)
	char pad_705[3];  // 0x2C1(0x3)
	float TextScale;  // 0x2C4(0x4)
	float NormalScale;  // 0x2C8(0x4)
	float AxisScale;  // 0x2CC(0x4)
	float ArrowScale;  // 0x2D0(0x4)
	struct FColor RigidBodyIdColor;  // 0x2D4(0x4)
	float RigidBodyTransformScale;  // 0x2D8(0x4)
	struct FColor RigidBodyCollisionColor;  // 0x2DC(0x4)
	struct FColor RigidBodyInertiaColor;  // 0x2E0(0x4)
	struct FColor RigidBodyVelocityColor;  // 0x2E4(0x4)
	struct FColor RigidBodyForceColor;  // 0x2E8(0x4)
	struct FColor RigidBodyInfoColor;  // 0x2EC(0x4)
	struct FColor TransformIndexColor;  // 0x2F0(0x4)
	float TransformScale;  // 0x2F4(0x4)
	struct FColor LevelColor;  // 0x2F8(0x4)
	struct FColor ParentColor;  // 0x2FC(0x4)
	float ConnectivityEdgeThickness;  // 0x300(0x4)
	struct FColor GeometryIndexColor;  // 0x304(0x4)
	float GeometryTransformScale;  // 0x308(0x4)
	struct FColor BoundingBoxColor;  // 0x30C(0x4)
	struct FColor FaceColor;  // 0x310(0x4)
	struct FColor FaceIndexColor;  // 0x314(0x4)
	struct FColor FaceNormalColor;  // 0x318(0x4)
	struct FColor SingleFaceColor;  // 0x31C(0x4)
	struct FColor VertexColor;  // 0x320(0x4)
	struct FColor VertexIndexColor;  // 0x324(0x4)
	struct FColor VertexNormalColor;  // 0x328(0x4)
	char pad_812[4];  // 0x32C(0x4)
	struct UBillboardComponent* SpriteComponent;  // 0x330(0x8)

}; 



// Class GeometryCollectionEngine.GeometryCollectionComponent
// Size: 0xAB0(Inherited: 0x570) 
struct UGeometryCollectionComponent : public UMeshComponent
{
	struct AChaosSolverActor* ChaosSolverActor;  // 0x570(0x8)
	char pad_1400[232];  // 0x578(0xE8)
	struct UGeometryCollection* RestCollection;  // 0x660(0x8)
	struct TArray<struct AFieldSystemActor*> InitializationFields;  // 0x668(0x10)
	char pad_1656_1 : 7;  // 0x678(0x1)
	bool Simulating : 1;  // 0x678(0x1)
	char pad_1657[7];  // 0x679(0x7)
	uint8_t  ObjectType;  // 0x680(0x1)
	char pad_1665_1 : 7;  // 0x681(0x1)
	bool bForceMotionBlur : 1;  // 0x681(0x1)
	char pad_1666_1 : 7;  // 0x682(0x1)
	bool EnableClustering : 1;  // 0x682(0x1)
	char pad_1667[1];  // 0x683(0x1)
	int32_t ClusterGroupIndex;  // 0x684(0x4)
	int32_t MaxClusterLevel;  // 0x688(0x4)
	char pad_1676[4];  // 0x68C(0x4)
	struct TArray<float> DamageThreshold;  // 0x690(0x10)
	char pad_1696_1 : 7;  // 0x6A0(0x1)
	bool bUseSizeSpecificDamageThreshold : 1;  // 0x6A0(0x1)
	uint8_t  ClusterConnectionType;  // 0x6A1(0x1)
	char pad_1698[2];  // 0x6A2(0x2)
	int32_t CollisionGroup;  // 0x6A4(0x4)
	float CollisionSampleFraction;  // 0x6A8(0x4)
	float LinearEtherDrag;  // 0x6AC(0x4)
	float AngularEtherDrag;  // 0x6B0(0x4)
	char pad_1716[4];  // 0x6B4(0x4)
	struct UChaosPhysicalMaterial* PhysicalMaterial;  // 0x6B8(0x8)
	uint8_t  InitialVelocityType;  // 0x6C0(0x1)
	char pad_1729[7];  // 0x6C1(0x7)
	struct FVector InitialLinearVelocity;  // 0x6C8(0x18)
	struct FVector InitialAngularVelocity;  // 0x6E0(0x18)
	struct UPhysicalMaterial* PhysicalMaterialOverride;  // 0x6F8(0x8)
	struct FGeomComponentCacheParameters CacheParameters;  // 0x700(0x50)
	struct TArray<struct FTransform> RestTransforms;  // 0x750(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange;  // 0x760(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange;  // 0x770(0x10)
	char pad_1920[24];  // 0x780(0x18)
	struct FMulticastInlineDelegate OnChaosBreakEvent;  // 0x798(0x10)
	struct FMulticastInlineDelegate OnChaosRemovalEvent;  // 0x7A8(0x10)
	float DesiredCacheTime;  // 0x7B8(0x4)
	char pad_1980_1 : 7;  // 0x7BC(0x1)
	bool CachePlayback : 1;  // 0x7BC(0x1)
	char pad_1981[3];  // 0x7BD(0x3)
	struct FMulticastInlineDelegate OnChaosPhysicsCollision;  // 0x7C0(0x10)
	char pad_2000_1 : 7;  // 0x7D0(0x1)
	bool bNotifyBreaks : 1;  // 0x7D0(0x1)
	char pad_2001_1 : 7;  // 0x7D1(0x1)
	bool bNotifyCollisions : 1;  // 0x7D1(0x1)
	char pad_2002_1 : 7;  // 0x7D2(0x1)
	bool bNotifyTrailing : 1;  // 0x7D2(0x1)
	char pad_2003_1 : 7;  // 0x7D3(0x1)
	bool bNotifyRemovals : 1;  // 0x7D3(0x1)
	char pad_2004_1 : 7;  // 0x7D4(0x1)
	bool bStoreVelocities : 1;  // 0x7D4(0x1)
	char pad_2005_1 : 7;  // 0x7D5(0x1)
	bool bShowBoneColors : 1;  // 0x7D5(0x1)
	char pad_2006_1 : 7;  // 0x7D6(0x1)
	bool bEnableReplication : 1;  // 0x7D6(0x1)
	char pad_2007_1 : 7;  // 0x7D7(0x1)
	bool bEnableAbandonAfterLevel : 1;  // 0x7D7(0x1)
	int32_t ReplicationAbandonClusterLevel;  // 0x7D8(0x4)
	char pad_2012[4];  // 0x7DC(0x4)
	struct FGeometryCollectionRepData RepData;  // 0x7E0(0x18)
	char pad_2040[648];  // 0x7F8(0x288)
	struct UBodySetup* DummyBodySetup;  // 0xA80(0x8)
	char pad_2696[8];  // 0xA88(0x8)
	struct TArray<struct UInstancedStaticMeshComponent*> EmbeddedGeometryComponents;  // 0xA90(0x10)
	char pad_2720[16];  // 0xAA0(0x10)

	void SetNotifyRemovals(bool bNewNotifyRemovals); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyRemovals
	void SetNotifyBreaks(bool bNewNotifyBreaks); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo); // Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision
	void OnRep_RepData(struct FGeometryCollectionRepData& OldData); // Function GeometryCollectionEngine.GeometryCollectionComponent.OnRep_RepData
	void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature
	void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature
	void NetAbandonCluster(int32_t TransformIndex); // Function GeometryCollectionEngine.GeometryCollectionComponent.NetAbandonCluster
	void ApplyPhysicsField(bool Enabled, uint8_t  Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField
	void ApplyKinematicField(float Radius, struct FVector position); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField
}; 



// Class GeometryCollectionEngine.GeometryCollectionRenderLevelSetActor
// Size: 0x370(Inherited: 0x278) 
struct AGeometryCollectionRenderLevelSetActor : public AActor
{
	struct UVolumeTexture* TargetVolumeTexture;  // 0x278(0x8)
	struct UMaterial* RayMarchMaterial;  // 0x280(0x8)
	float SurfaceTolerance;  // 0x288(0x4)
	float Isovalue;  // 0x28C(0x4)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool Enabled : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool RenderVolumeBoundingBox : 1;  // 0x291(0x1)
	char pad_658[222];  // 0x292(0xDE)

}; 



