#pragma once 
#include <BP_Item_Accessory_StandartAccessory_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Accessory_StandartAccessory.BP_Item_Accessory_StandartAccessory_C
// Size: 0x2F0(Inherited: 0x2F0) 
struct ABP_Item_Accessory_StandartAccessory_C : public AItem_Module_Accessory
{

}; 



