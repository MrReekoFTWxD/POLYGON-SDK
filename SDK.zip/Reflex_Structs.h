#pragma once 
#include "SDK.h" 
 
 
// Function Reflex.ReflexBlueprintLibrary.GetGameToRenderLatencyInMs
// Size: 0x4(Inherited: 0x0) 
struct FGetGameToRenderLatencyInMs
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Reflex.ReflexBlueprintLibrary.GetFlashIndicatorEnabled
// Size: 0x1(Inherited: 0x0) 
struct FGetFlashIndicatorEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Reflex.ReflexBlueprintLibrary.SetReflexMode
// Size: 0x1(Inherited: 0x0) 
struct FSetReflexMode
{
	uint8_t  Mode;  // 0x0(0x1)

}; 
// Function Reflex.ReflexBlueprintLibrary.GetGameLatencyInMs
// Size: 0x4(Inherited: 0x0) 
struct FGetGameLatencyInMs
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Reflex.ReflexBlueprintLibrary.GetRenderLatencyInMs
// Size: 0x4(Inherited: 0x0) 
struct FGetRenderLatencyInMs
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Reflex.ReflexBlueprintLibrary.GetReflexAvailable
// Size: 0x1(Inherited: 0x0) 
struct FGetReflexAvailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Reflex.ReflexBlueprintLibrary.GetReflexMode
// Size: 0x1(Inherited: 0x0) 
struct FGetReflexMode
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function Reflex.ReflexBlueprintLibrary.SetFlashIndicatorEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetFlashIndicatorEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
