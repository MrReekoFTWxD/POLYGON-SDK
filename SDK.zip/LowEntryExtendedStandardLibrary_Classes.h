#pragma once 
#include <LowEntryExtendedStandardLibrary_Structs.h>
 
 
 
// Class LowEntryExtendedStandardLibrary.LowEntryByteDataReader
// Size: 0x40(Inherited: 0x28) 
struct ULowEntryByteDataReader : public UObject
{
	struct TArray<char> Bytes;  // 0x28(0x10)
	int32_t position;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

	void SetPosition(int32_t Position_); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.SetPosition
	void Reset(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.Reset
	int32_t Remaining(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.Remaining
	struct TArray<struct FString> GetStringUtf8Array(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetStringUtf8Array
	struct FString GetStringUtf8(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetStringUtf8
	struct TArray<int32_t> GetPositiveInteger3Array(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger3Array
	int32_t GetPositiveInteger3(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger3
	struct TArray<int32_t> GetPositiveInteger2Array(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger2Array
	int32_t GetPositiveInteger2(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger2
	struct TArray<int32_t> GetPositiveInteger1Array(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger1Array
	int32_t GetPositiveInteger1(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger1
	int32_t GetPosition(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPosition
	struct TArray<struct ULowEntryLong*> GetLongBytesArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLongBytesArray
	struct ULowEntryLong* GetLongBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLongBytes
	struct TArray<int64_t> GetLongArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLongArray
	int64_t GetLong(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLong
	struct TArray<int32_t> GetIntegerArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetIntegerArray
	int32_t GetInteger(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetInteger
	struct TArray<float> GetFloatArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetFloatArray
	float GetFloat(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetFloat
	struct TArray<struct ULowEntryDouble*> GetDoubleBytesArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetDoubleBytesArray
	struct ULowEntryDouble* GetDoubleBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetDoubleBytes
	struct ULowEntryByteDataReader* GetClone(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetClone
	struct TArray<char> GetByteArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetByteArray
	char GetByte(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetByte
	struct TArray<bool> GetBooleanArray(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetBooleanArray
	bool GetBoolean(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetBoolean
	void Empty(); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.Empty
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryBitDataEntry
// Size: 0xE8(Inherited: 0x28) 
struct ULowEntryBitDataEntry : public UObject
{
	char Type;  // 0x28(0x1)
	char ByteValue;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t IntegerValue;  // 0x2C(0x4)
	int64_t LongValue;  // 0x30(0x8)
	struct ULowEntryLong* LongBytesValue;  // 0x38(0x8)
	float FloatValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct ULowEntryDouble* DoubleBytesValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool BooleanValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString StringUtf8Value;  // 0x58(0x10)
	struct TArray<char> ByteArrayValue;  // 0x68(0x10)
	struct TArray<int32_t> IntegerArrayValue;  // 0x78(0x10)
	struct TArray<int64_t> LongArrayValue;  // 0x88(0x10)
	struct TArray<struct ULowEntryLong*> LongBytesArrayValue;  // 0x98(0x10)
	struct TArray<float> FloatArrayValue;  // 0xA8(0x10)
	struct TArray<struct ULowEntryDouble*> DoubleBytesArrayValue;  // 0xB8(0x10)
	struct TArray<bool> BooleanArrayValue;  // 0xC8(0x10)
	struct TArray<struct FString> StringUtf8ArrayValue;  // 0xD8(0x10)

}; 



// Class LowEntryExtendedStandardLibrary.LowEntryBitDataReader
// Size: 0x48(Inherited: 0x28) 
struct ULowEntryBitDataReader : public UObject
{
	struct TArray<char> Bytes;  // 0x28(0x10)
	int32_t position;  // 0x38(0x4)
	char CurrentByte;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	int32_t CurrentBytePosition;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

	void SetPosition(int32_t Position_); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.SetPosition
	void Reset(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.Reset
	int32_t Remaining(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.Remaining
	struct TArray<struct FString> GetStringUtf8Array(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetStringUtf8Array
	struct FString GetStringUtf8(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetStringUtf8
	struct TArray<int32_t> GetPositiveInteger3Array(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPositiveInteger3Array
	int32_t GetPositiveInteger3(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPositiveInteger3
	struct TArray<int32_t> GetPositiveInteger2Array(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPositiveInteger2Array
	int32_t GetPositiveInteger2(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPositiveInteger2
	struct TArray<int32_t> GetPositiveInteger1Array(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPositiveInteger1Array
	int32_t GetPositiveInteger1(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPositiveInteger1
	int32_t GetPosition(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetPosition
	struct TArray<struct ULowEntryLong*> GetLongBytesArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetLongBytesArray
	struct ULowEntryLong* GetLongBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetLongBytes
	struct TArray<int64_t> GetLongArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetLongArray
	int64_t GetLong(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetLong
	int32_t GetIntegerMostSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerMostSignificantBits
	int32_t GetIntegerLeastSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerLeastSignificantBits
	struct TArray<int32_t> GetIntegerArrayMostSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerArrayMostSignificantBits
	struct TArray<int32_t> GetIntegerArrayLeastSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerArrayLeastSignificantBits
	struct TArray<int32_t> GetIntegerArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerArray
	int32_t GetInteger(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetInteger
	struct TArray<float> GetFloatArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetFloatArray
	float GetFloat(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetFloat
	struct TArray<struct ULowEntryDouble*> GetDoubleBytesArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetDoubleBytesArray
	struct ULowEntryDouble* GetDoubleBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetDoubleBytes
	struct ULowEntryBitDataReader* GetClone(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetClone
	char GetByteMostSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteMostSignificantBits
	char GetByteLeastSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteLeastSignificantBits
	struct TArray<char> GetByteArrayMostSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteArrayMostSignificantBits
	struct TArray<char> GetByteArrayLeastSignificantBits(int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteArrayLeastSignificantBits
	struct TArray<char> GetByteArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteArray
	char GetByte(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByte
	struct TArray<bool> GetBooleanArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetBooleanArray
	bool GetBoolean(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetBoolean
	struct TArray<bool> GetBitArray(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetBitArray
	bool GetBit(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetBit
	void Empty(); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.Empty
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary
// Size: 0x28(Inherited: 0x28) 
struct ULowEntryExtendedStandardLibrary : public UBlueprintFunctionLibrary
{

	bool XboxOnePlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.XboxOnePlatform
	bool WithEditor(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WithEditor
	bool WindowsRtPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsRtPlatform
	bool WindowsRtArmPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsRtArmPlatform
	bool WindowsPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsPlatform
	struct FString WindowsNewlineCharacter(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsNewlineCharacter
	bool Windows64Platform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Windows64Platform
	bool Windows32Platform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Windows32Platform
	void TickSeconds(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, int32_t Ticks, float SecondsInterval, int32_t& Tick); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TickSeconds
	void TickFrames(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, int32_t Ticks, int32_t FramesInterval, int32_t& Tick); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TickFrames
	void TextureUpdateResource(struct UTexture* Texture); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TextureUpdateResource
	void TextureRenderTarget2DToPixels(struct UTextureRenderTarget2D* TextureRenderTarget2D, int32_t& Width, int32_t& Height, struct TArray<struct FColor>& Pixels); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TextureRenderTarget2DToPixels
	void TextureRenderTarget2DToBytes(struct UTextureRenderTarget2D* TextureRenderTarget2D, uint8_t  ImageFormat, struct TArray<char>& ByteArray, int32_t CompressionQuality); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TextureRenderTarget2DToBytes
	void Texture2DToPixels(struct UTexture2D* Texture2D, int32_t& Width, int32_t& Height, struct TArray<struct FColor>& Pixels); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Texture2DToPixels
	void Texture2DToBytes(struct UTexture2D* Texture2D, uint8_t  ImageFormat, struct TArray<char>& ByteArray, int32_t CompressionQuality); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Texture2DToBytes
	bool TestBuild(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TestBuild
	struct FString TabCharacter(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TabCharacter
	bool SwitchPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SwitchPlatform
	struct TArray<char> StringToBytesUtf8(struct FString String); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.StringToBytesUtf8
	void SplitBytes(struct TArray<char>& ByteArray, int32_t LengthA, struct TArray<char>& A, struct TArray<char>& B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SplitBytes
	void SoundClass_SetVolume(struct USoundClass* SoundClass, float Volume); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_SetVolume
	void SoundClass_SetPitch(struct USoundClass* SoundClass, float Pitch); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_SetPitch
	float SoundClass_GetVolume(struct USoundClass* SoundClass); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_GetVolume
	float SoundClass_GetPitch(struct USoundClass* SoundClass); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_GetPitch
	void SortTimespanArrayDirectly(struct TArray<struct FTimespan>& TimespanArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortTimespanArrayDirectly
	struct TArray<struct FTimespan> SortTimespanArray(struct TArray<struct FTimespan>& TimespanArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortTimespanArray
	void SortStringArrayDirectly(struct TArray<struct FString>& StringArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortStringArrayDirectly
	struct TArray<struct FString> SortStringArray(struct TArray<struct FString>& StringArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortStringArray
	void SortObjectArrayDirectly(struct TArray<struct UObject*>& ObjectArray, struct FDelegate Comparator, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortObjectArrayDirectly
	struct TArray<struct UObject*> SortObjectArray(struct TArray<struct UObject*>& ObjectArray, struct FDelegate Comparator, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortObjectArray
	void SortIntegerArrayDirectly(struct TArray<int32_t>& IntegerArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortIntegerArrayDirectly
	struct TArray<int32_t> SortIntegerArray(struct TArray<int32_t>& IntegerArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortIntegerArray
	void SortFloatArrayDirectly(struct TArray<float>& FloatArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortFloatArrayDirectly
	struct TArray<float> SortFloatArray(struct TArray<float>& FloatArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortFloatArray
	void SortDateTimeArrayDirectly(struct TArray<struct FDateTime>& DateTimeArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortDateTimeArrayDirectly
	struct TArray<struct FDateTime> SortDateTimeArray(struct TArray<struct FDateTime>& DateTimeArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortDateTimeArray
	void SortByteArrayDirectly(struct TArray<char>& ByteArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortByteArrayDirectly
	struct TArray<char> SortByteArray(struct TArray<char>& ByteArray, bool Reversed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortByteArray
	void SimpleKismetSystemLibraryPrintString(struct FString InString); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SimpleKismetSystemLibraryPrintString
	bool ShippingBuild(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ShippingBuild
	struct TArray<char> Sha512(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Sha512
	struct TArray<char> Sha256(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Sha256
	struct TArray<char> Sha1(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Sha1
	void SetWorldRenderingEnabled(bool Enabled); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWorldRenderingEnabled
	void SetWindowSize(int32_t Width, int32_t Height); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowSize
	void SetWindowPositionInPercentagesCentered(float X, float Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowPositionInPercentagesCentered
	void SetWindowPosition(int32_t X, int32_t Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowPosition
	void SetWindowPositiomInPercentagesCentered(float X, float Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowPositiomInPercentagesCentered
	void SetWindowMode(bool Fullscreen, bool IsFullscreenWindowed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowMode
	void SetSplitScreenType_TwoPlayers(uint8_t  Type); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetSplitScreenType_TwoPlayers
	void SetSplitScreenType_ThreePlayers(uint8_t  Type); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetSplitScreenType_ThreePlayers
	void SetSplitScreenEnabled(bool Enabled); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetSplitScreenEnabled
	void SetMousePositionInPercentages(float X, float Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetMousePositionInPercentages
	void SetMousePosition(int32_t X, int32_t Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetMousePosition
	void SetMouseLockedToViewport(bool Locked); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetMouseLockedToViewport
	void SetGenericTeamId(struct AActor* Target, char TeamID); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetGenericTeamId
	void ServerChangeMap(struct UObject* WorldContextObject, struct FString Map, struct FString Args, struct APlayerController* SpecificPlayer); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ServerChangeMap
	void SceneCaptureComponent2DToPixels(struct USceneCaptureComponent2D* SceneCaptureComponent2D, int32_t& Width, int32_t& Height, struct TArray<struct FColor>& Pixels); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2DToPixels
	void SceneCaptureComponent2DToBytes(struct USceneCaptureComponent2D* SceneCaptureComponent2D, uint8_t  ImageFormat, struct TArray<char>& ByteArray, int32_t CompressionQuality); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2DToBytes
	void SceneCaptureComponent2D_SetFov(struct USceneCaptureComponent2D* SceneCaptureComponent2D, float FOV); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2D_SetFov
	void SceneCaptureComponent2D_GetFov(struct USceneCaptureComponent2D* SceneCaptureComponent2D, float& FOV); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2D_GetFov
	void SceneCapture2DToPixels(struct ASceneCapture2D* SceneCapture2D, int32_t& Width, int32_t& Height, struct TArray<struct FColor>& Pixels); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2DToPixels
	void SceneCapture2DToBytes(struct ASceneCapture2D* SceneCapture2D, uint8_t  ImageFormat, struct TArray<char>& ByteArray, int32_t CompressionQuality); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2DToBytes
	void SceneCapture2D_SetFov(struct ASceneCapture2D* SceneCapture2D, float FOV); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2D_SetFov
	void SceneCapture2D_GetFov(struct ASceneCapture2D* SceneCapture2D, float& FOV); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2D_GetFov
	float RoundDecimals(float Number, int32_t Decimals); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RoundDecimals
	void RetriggerableRandomDelayFrames(struct UObject* WorldContextObject, int32_t MinFrames, int32_t MaxFrames, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RetriggerableRandomDelayFrames
	void RetriggerableRandomDelay(struct UObject* WorldContextObject, float MinDuration, float MaxDuration, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RetriggerableRandomDelay
	void RetriggerableDelayFrames(struct UObject* WorldContextObject, int32_t Frames, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RetriggerableDelayFrames
	struct FString ReplaceCharactersExcept(struct FString String, struct FString ReplacementCharacter, bool KeepLowercaseAZ, bool KeepUppercaseAZ, bool KeepNumbers, struct FString OtherCharactersToKeep); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ReplaceCharactersExcept
	struct FString RemoveCharactersExcept(struct FString String, bool KeepLowercaseAZ, bool KeepUppercaseAZ, bool KeepNumbers, struct FString OtherCharactersToKeep); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RemoveCharactersExcept
	struct FString RegexReplace(struct FString String, struct FString Pattern, struct FString Replacement); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexReplace
	bool RegexMatch(struct FString String, struct FString Pattern); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexMatch
	struct TArray<struct FLowEntryRegexMatch> RegexGetMatches(struct FString String, struct FString Pattern); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexGetMatches
	int32_t RegexCount(struct FString String, struct FString Pattern); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexCount
	void RandomDelayFrames(struct UObject* WorldContextObject, int32_t MinFrames, int32_t MaxFrames, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RandomDelayFrames
	void RandomDelay(struct UObject* WorldContextObject, float MinDuration, float MaxDuration, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RandomDelay
	void QueueExecutions(struct UObject* WorldContextObject, struct ULowEntryExecutionQueue*& Queue, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.QueueExecutions
	bool Ps4Platform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Ps4Platform
	void PlayerControllerGetLocalPlayer(struct APlayerController* PlayerController, bool& Success, struct ULocalPlayer*& LocalPlayer); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PlayerControllerGetLocalPlayer
	struct UTexture2D* PixelsToTexture2D(int32_t Width, int32_t Height, struct TArray<struct FColor>& Pixels); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PixelsToTexture2D
	struct UTexture2D* PixelsToExistingTexture2D(bool& ReusedGivenTexture2D, struct UTexture2D* Texture2D, int32_t Width, int32_t Height, struct TArray<struct FColor>& Pixels); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PixelsToExistingTexture2D
	void PixelsToBytes(int32_t Width, int32_t Height, struct TArray<struct FColor>& Pixels, uint8_t  ImageFormat, struct TArray<char>& ByteArray, int32_t CompressionQuality); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PixelsToBytes
	struct TArray<char> Pearson(struct TArray<char>& ByteArray, int32_t HashLength, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Pearson
	struct ULowEntryLong* ParseStringIntoLongBytes(struct FString String); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParseStringIntoLongBytes
	int64_t ParseStringIntoLong(struct FString String); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParseStringIntoLong
	struct ULowEntryDouble* ParseStringIntoDoubleBytes(struct FString String); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParseStringIntoDoubleBytes
	bool ParsedHashcashIsValid(struct ULowEntryParsedHashcash* Target); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParsedHashcashIsValid
	void NextQueueExecution(struct ULowEntryExecutionQueue* Queue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.NextQueueExecution
	struct FString NewlineCharacter(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.NewlineCharacter
	struct FString MinString(struct FString A, struct FString B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinString
	void MinOfTimespanArray(struct TArray<struct FTimespan>& TimespanArray, int32_t& IndexOfMinValue, struct FTimespan& MinValue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinOfTimespanArray
	void MinOfStringArray(struct TArray<struct FString>& StringArray, int32_t& IndexOfMinValue, struct FString& MinValue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinOfStringArray
	void MinOfDateTimeArray(struct TArray<struct FDateTime>& DateTimeArray, int32_t& IndexOfMinValue, struct FDateTime& MinValue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinOfDateTimeArray
	struct TArray<char> MergeEncapsulatedByteArrays(struct TArray<struct ULowEntryByteArray*>& ByteArrays); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MergeEncapsulatedByteArrays
	struct TArray<char> MergeBytes(struct TArray<char> A, struct TArray<char> B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MergeBytes
	struct TArray<char> Md5(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Md5
	struct FString MaxString(struct FString A, struct FString B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxString
	void MaxOfTimespanArray(struct TArray<struct FTimespan>& TimespanArray, int32_t& IndexOfMaxValue, struct FTimespan& MaxValue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxOfTimespanArray
	void MaxOfStringArray(struct TArray<struct FString>& StringArray, int32_t& IndexOfMaxValue, struct FString& MaxValue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxOfStringArray
	void MaxOfDateTimeArray(struct TArray<struct FDateTime>& DateTimeArray, int32_t& IndexOfMaxValue, struct FDateTime& MaxValue); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxOfDateTimeArray
	bool MacPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MacPlatform
	struct TArray<char> LongToBytes(int64_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LongToBytes
	struct ULowEntryLong* Long_CreateZero(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Long_CreateZero
	struct ULowEntryLong* Long_Create(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Long_Create
	void LoadVideo(struct UMediaSoundComponent* MediaSoundComponent, struct FString URL, bool& Success, struct UMediaPlayer*& MediaPlayer, struct UMediaTexture*& MediaTexture, bool PlayOnOpen, bool Loop); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LoadVideo
	bool LinuxPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LinuxPlatform
	bool LessStringString(struct FString A, struct FString B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessStringString
	bool LessIntegerFloat(int32_t A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessIntegerFloat
	bool LessIntegerByte(int32_t A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessIntegerByte
	bool LessFloatInteger(float A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessFloatInteger
	bool LessFloatByte(float A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessFloatByte
	bool LessEqualStringString(struct FString A, struct FString B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualStringString
	bool LessEqualIntegerFloat(int32_t A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualIntegerFloat
	bool LessEqualIntegerByte(int32_t A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualIntegerByte
	bool LessEqualFloatInteger(float A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualFloatInteger
	bool LessEqualFloatByte(float A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualFloatByte
	bool LessEqualByteInteger(char A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualByteInteger
	bool LessEqualByteFloat(char A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualByteFloat
	bool LessByteInteger(char A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessByteInteger
	bool LessByteFloat(char A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessByteFloat
	void LatentAction_Create_String(struct ULowEntryLatentActionString*& LatentAction); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_String
	void LatentAction_Create_Object(struct ULowEntryLatentActionObject*& LatentAction); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Object
	void LatentAction_Create_None(struct ULowEntryLatentActionNone*& LatentAction); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_None
	void LatentAction_Create_Integer(struct ULowEntryLatentActionInteger*& LatentAction); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Integer
	void LatentAction_Create_Float(struct ULowEntryLatentActionFloat*& LatentAction); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Float
	void LatentAction_Create_Boolean(struct ULowEntryLatentActionBoolean*& LatentAction); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Boolean
	void JoinGame(struct UObject* WorldContextObject, struct FString ServerAddress, struct FString Args, struct APlayerController* SpecificPlayer); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.JoinGame
	void IsWorldRenderingEnabled(bool& Success, bool& Enabled); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IsWorldRenderingEnabled
	bool IsBitSet(char B, int32_t Bit); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IsBitSet
	bool IosPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IosPlatform
	struct TArray<char> IntegerToBytes(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IntegerToBytes
	bool Html5Platform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Html5Platform
	void HostGame(struct UObject* WorldContextObject, struct FString Map, struct FString Args, struct APlayerController* SpecificPlayer); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HostGame
	struct TArray<char> HMAC(struct TArray<char>& ByteArray, struct TArray<char>& Key, uint8_t  Algorithm, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HMAC
	struct TArray<char> HexToBytes(struct FString Hex); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HexToBytes
	struct TArray<struct ULowEntryParsedHashcash*> HashcashParseArray(struct TArray<struct FString>& Hashes); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashParseArray
	struct ULowEntryParsedHashcash* HashcashParse(struct FString Hash); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashParse
	struct FString HashcashCustomCreationDate(struct FString Resource, struct FDateTime& UtcDate, int32_t Bits); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashCustomCreationDate
	struct TArray<struct FString> HashcashArrayCustomCreationDate(struct TArray<struct FString>& Resources, struct FDateTime& UtcDate, int32_t Bits); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashArrayCustomCreationDate
	struct TArray<struct FString> HashcashArray(struct TArray<struct FString>& Resources, int32_t Bits); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashArray
	struct FString Hashcash(struct FString Resource, int32_t Bits); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Hashcash
	bool GreaterStringString(struct FString A, struct FString B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterStringString
	bool GreaterIntegerFloat(int32_t A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterIntegerFloat
	bool GreaterIntegerByte(int32_t A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterIntegerByte
	bool GreaterFloatInteger(float A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterFloatInteger
	bool GreaterFloatByte(float A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterFloatByte
	bool GreaterEqualStringString(struct FString A, struct FString B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualStringString
	bool GreaterEqualIntegerFloat(int32_t A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualIntegerFloat
	bool GreaterEqualIntegerByte(int32_t A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualIntegerByte
	bool GreaterEqualFloatInteger(float A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualFloatInteger
	bool GreaterEqualFloatByte(float A, char B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualFloatByte
	bool GreaterEqualByteInteger(char A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualByteInteger
	bool GreaterEqualByteFloat(char A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualByteFloat
	bool GreaterByteInteger(char A, int32_t B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterByteInteger
	bool GreaterByteFloat(char A, float B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterByteFloat
	struct TArray<struct FColor> GrayscalePixels(struct TArray<struct FColor>& Pixel); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GrayscalePixels
	struct FColor GrayscalePixel(struct FColor& Pixel); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GrayscalePixel
	void GetWindowSize(bool& Success, int32_t& Width, int32_t& Height); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowSize
	void GetWindowPositionInPercentagesCentered(bool& Success, float& X, float& Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowPositionInPercentagesCentered
	void GetWindowPosition(bool& Success, int32_t& X, int32_t& Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowPosition
	void GetWindowPositiomInPercentagesCentered(bool& Success, float& X, float& Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowPositiomInPercentagesCentered
	void GetWindowMode(bool& Success, bool& Fullscreen, bool& IsFullscreenWindowed); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowMode
	void GetWindowBounds(bool& Success, int32_t& X, int32_t& Y, int32_t& Width, int32_t& Height); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowBounds
	void GetWindowBorderSize(bool& Success, struct FMargin& Margin); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowBorderSize
	struct FName GetUserFocusedWidgetType(int32_t UserIndex); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetUserFocusedWidgetType
	void GetSplitScreenType(uint8_t & Type); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetSplitScreenType
	struct FString GetProjectVersion(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetProjectVersion
	struct FString GetProjectName(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetProjectName
	void GetPrimaryMonitorWorkArea(int32_t& X, int32_t& Y, int32_t& Width, int32_t& Height); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetPrimaryMonitorWorkArea
	void GetPrimaryMonitorResolution(int32_t& Width, int32_t& Height); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetPrimaryMonitorResolution
	void GetMousePositionInPercentages(bool& Success, float& X, float& Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetMousePositionInPercentages
	void GetMousePosition(bool& Success, int32_t& X, int32_t& Y); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetMousePosition
	void GetMaximumVolume(int32_t& Volume, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetMaximumVolume
	struct FVector2D GetLocalToAbsoluteScale(struct FGeometry& Geometry); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetLocalToAbsoluteScale
	struct FName GetKeyboardFocusedWidgetType(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetKeyboardFocusedWidgetType
	void GetGenericTeamId(struct AActor* Target, char& TeamID); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetGenericTeamId
	void GetCurrentVolumePercentage(float& Percentage, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetCurrentVolumePercentage
	void GetCurrentVolume(int32_t& Volume, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetCurrentVolume
	void GetClassWithName(struct FString ClassName, UObject*& Class_, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetClassWithName
	char GetByteWithBitSet(char Byte, int32_t Bit, bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetByteWithBitSet
	void GetBatteryTemperature(float& Celsius, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetBatteryTemperature
	void GetBatteryState(uint8_t & State, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetBatteryState
	void GetBatteryCharge(int32_t& Percentage, bool& Success); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetBatteryCharge
	void GetAndroidVolume(int32_t& Volume); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidVolume
	struct FString GetAndroidVersion(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidVersion
	struct FString GetAndroidOsLanguage(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidOsLanguage
	int32_t GetAndroidNumberOfCores(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidNumberOfCores
	struct FString GetAndroidGpuFamily(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidGpuFamily
	struct FString GetAndroidGlVersion(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidGlVersion
	struct FString GetAndroidDeviceModel(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidDeviceModel
	struct FString GetAndroidDeviceMake(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidDeviceMake
	struct FString GetAndroidDefaultLocale(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidDefaultLocale
	int32_t GetAndroidBuildVersion(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidBuildVersion
	struct FVector2D GetAbsoluteToLocalScale(struct FGeometry& Geometry); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAbsoluteToLocalScale
	struct FVector2D GetAbsoluteSize(struct FGeometry& Geometry); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAbsoluteSize
	void GenerateRandomBytesRandomLength(int32_t MinLength, int32_t MaxLength, struct TArray<char>& ByteArray); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GenerateRandomBytesRandomLength
	void GenerateRandomBytes(int32_t Length, struct TArray<char>& ByteArray); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GenerateRandomBytes
	float FloorDecimals(float Number, int32_t Decimals); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.FloorDecimals
	struct TArray<char> FloatToBytes(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.FloatToBytes
	void ExecToInteger(uint8_t  Branch, int32_t& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ExecToInteger
	void ExecToByte(uint8_t  Branch, char& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ExecToByte
	void ExecToBoolean(uint8_t  Branch, bool& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ExecToBoolean
	struct ULowEntryByteArray* EncapsulateByteArray(struct TArray<char>& ByteArray); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.EncapsulateByteArray
	struct ULowEntryDouble* Double_CreateZero(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Double_CreateZero
	struct ULowEntryDouble* Double_Create(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Double_Create
	struct FVector2D Divide_Vector2dVector2d(struct FVector2D& A, struct FVector2D& B); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Divide_Vector2dVector2d
	bool DevelopmentBuild(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DevelopmentBuild
	bool DesktopPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DesktopPlatform
	void DelayFrames(struct UObject* WorldContextObject, int32_t Frames, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DelayFrames
	bool DebugBuild(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DebugBuild
	void DateTime_ToUnixTimestamp(struct FDateTime& DateTime, struct ULowEntryLong*& Timestamp); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_ToUnixTimestamp
	void DateTime_ToString(struct FDateTime& DateTime, struct FString& String, struct FString Format); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_ToString
	void DateTime_ToIso8601(struct FDateTime& DateTime, struct FString& String); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_ToIso8601
	void DateTime_FromUnixTimestamp(struct ULowEntryLong* Timestamp, struct FDateTime& DateTime); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_FromUnixTimestamp
	struct FString CreateString(int32_t Length, struct FString Filler); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CreateString
	void CreateObject(UObject* Class, struct UObject*& Object); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CreateObject
	void Crash(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Crash
	void ConvertUtcDateToLocalDate(struct FDateTime& Utc, struct FDateTime& Local); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ConvertUtcDateToLocalDate
	void ConvertLocalDateToUtcDate(struct FDateTime& Local, struct FDateTime& Utc); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ConvertLocalDateToUtcDate
	void ClipboardSet(struct FString Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClipboardSet
	struct FString ClipboardGet(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClipboardGet
	void ClearUserFocus(int32_t UserIndex); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClearUserFocus
	void ClearKeyboardFocus(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClearKeyboardFocus
	void ClearAllUserFocus(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClearAllUserFocus
	void ChangeMap(struct UObject* WorldContextObject, struct FString Map, struct FString Args, struct APlayerController* SpecificPlayer); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ChangeMap
	float CeilDecimals(float Number, int32_t Decimals); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CeilDecimals
	void CaseSwitchObject(int32_t OnlyCheckFirstX, struct UObject* Value, struct UObject* _1__, struct UObject* _2__, struct UObject* _3__, struct UObject* _4__, struct UObject* _5__, struct UObject* _6__, struct UObject* _7__, struct UObject* _8__, struct UObject* _9__, struct UObject* _10__, uint8_t & Branch); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CaseSwitchObject
	void CaseSwitchInteger(int32_t OnlyCheckFirstX, int32_t Value, int32_t _1__, int32_t _2__, int32_t _3__, int32_t _4__, int32_t _5__, int32_t _6__, int32_t _7__, int32_t _8__, int32_t _9__, int32_t _10__, uint8_t & Branch); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CaseSwitchInteger
	void CaseSwitchByte(int32_t OnlyCheckFirstX, char Value, char _1__, char _2__, char _3__, char _4__, char _5__, char _6__, char _7__, char _8__, char _9__, char _10__, uint8_t & Branch); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CaseSwitchByte
	struct FString CarriageReturnCharacter(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CarriageReturnCharacter
	struct TArray<char> ByteToBytes(char Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteToBytes
	bool ByteToBoolean(char Byte); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteToBoolean
	void ByteToBits(char Byte, bool& Bit1, bool& Bit2, bool& Bit3, bool& Bit4, bool& Bit5, bool& Bit6, bool& Bit7, bool& Bit8); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteToBits
	struct FString BytesToStringUtf8(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToStringUtf8
	void BytesToPixels(struct TArray<char>& ByteArray, uint8_t  ImageFormat, int32_t& Width, int32_t& Height, struct TArray<struct FColor>& Pixels, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToPixels
	struct ULowEntryLong* BytesToLongBytes(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToLongBytes
	int64_t BytesToLong(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToLong
	int32_t BytesToInteger(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToInteger
	struct UTexture2D* BytesToImage(struct TArray<char>& ByteArray, uint8_t  ImageFormat, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToImage
	struct FString BytesToHex(struct TArray<char>& ByteArray, bool AddSpaces, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToHex
	float BytesToFloat(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToFloat
	struct UTexture2D* BytesToExistingImage(bool& ReusedGivenTexture2D, struct UTexture2D* Texture2D, struct TArray<char>& ByteArray, uint8_t  ImageFormat, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToExistingImage
	struct ULowEntryDouble* BytesToDoubleBytes(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToDoubleBytes
	char BytesToByte(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToByte
	bool BytesToBoolean(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBoolean
	struct FString BytesToBitString(struct TArray<char>& ByteArray, bool AddSpaces, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBitString
	struct FString BytesToBinary(struct TArray<char>& ByteArray, bool AddSpaces, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBinary
	struct FString BytesToBase64Url(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBase64Url
	struct FString BytesToBase64(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBase64
	struct TArray<char> BytesSubArray(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesSubArray
	struct TArray<char> ByteDataWriter_GetBytes(struct ULowEntryByteDataWriter* ByteDataWriter); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataWriter_GetBytes
	struct ULowEntryByteDataWriter* ByteDataWriter_CreateFromEntryArrayPure(struct TArray<struct ULowEntryByteDataEntry*>& Array); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataWriter_CreateFromEntryArrayPure
	struct ULowEntryByteDataWriter* ByteDataWriter_CreateFromEntryArray(struct TArray<struct ULowEntryByteDataEntry*>& Array); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataWriter_CreateFromEntryArray
	struct ULowEntryByteDataReader* ByteDataReader_Create(struct TArray<char>& Bytes, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataReader_Create
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromStringUtf8Array(struct TArray<struct FString>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromStringUtf8Array
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromStringUtf8(struct FString Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromStringUtf8
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromPositiveInteger3Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger3Array
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromPositiveInteger3(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger3
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromPositiveInteger2Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger2Array
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromPositiveInteger2(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger2
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromPositiveInteger1Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger1Array
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromPositiveInteger1(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger1
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromLongBytesArray(struct TArray<struct ULowEntryLong*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLongBytesArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromLongBytes(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLongBytes
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromLongArray(struct TArray<int64_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLongArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromLong(int64_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLong
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromIntegerArray(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromIntegerArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromInteger(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromInteger
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromFloatArray(struct TArray<float>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromFloatArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromFloat(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromFloat
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromDoubleBytesArray(struct TArray<struct ULowEntryDouble*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromDoubleBytesArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromDoubleBytes(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromDoubleBytes
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromByteArray(struct TArray<char>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromByteArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromByte(char Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromByte
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromBooleanArray(struct TArray<bool>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromBooleanArray
	struct ULowEntryByteDataEntry* ByteDataEntry_CreateFromBoolean(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromBoolean
	struct TArray<char> BooleanToBytes(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BooleanToBytes
	char BooleanToByte(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BooleanToByte
	struct TArray<char> BitStringToBytes(struct FString Bits); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitStringToBytes
	void BitsToByte(bool Bit1, bool Bit2, bool Bit3, bool Bit4, bool Bit5, bool Bit6, bool Bit7, bool Bit8, char& Byte); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitsToByte
	struct TArray<char> BitDataWriter_GetBytes(struct ULowEntryBitDataWriter* BitDataWriter); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataWriter_GetBytes
	struct ULowEntryBitDataWriter* BitDataWriter_CreateFromEntryArrayPure(struct TArray<struct ULowEntryBitDataEntry*>& Array); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataWriter_CreateFromEntryArrayPure
	struct ULowEntryBitDataWriter* BitDataWriter_CreateFromEntryArray(struct TArray<struct ULowEntryBitDataEntry*>& Array); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataWriter_CreateFromEntryArray
	struct ULowEntryBitDataReader* BitDataReader_Create(struct TArray<char>& Bytes, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataReader_Create
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromStringUtf8Array(struct TArray<struct FString>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromStringUtf8Array
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromStringUtf8(struct FString Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromStringUtf8
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromPositiveInteger3Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger3Array
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromPositiveInteger3(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger3
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromPositiveInteger2Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger2Array
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromPositiveInteger2(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger2
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromPositiveInteger1Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger1Array
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromPositiveInteger1(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger1
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromLongBytesArray(struct TArray<struct ULowEntryLong*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLongBytesArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromLongBytes(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLongBytes
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromLongArray(struct TArray<int64_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLongArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromLong(int64_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLong
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromIntegerMostSignificantBits(int32_t Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerMostSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromIntegerLeastSignificantBits(int32_t Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerLeastSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromIntegerArrayMostSignificantBits(struct TArray<int32_t>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerArrayMostSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromIntegerArrayLeastSignificantBits(struct TArray<int32_t>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerArrayLeastSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromIntegerArray(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromInteger(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromInteger
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromFloatArray(struct TArray<float>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromFloatArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromFloat(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromFloat
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromDoubleBytesArray(struct TArray<struct ULowEntryDouble*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromDoubleBytesArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromDoubleBytes(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromDoubleBytes
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromByteMostSignificantBits(char Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteMostSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromByteLeastSignificantBits(char Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteLeastSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromByteArrayMostSignificantBits(struct TArray<char>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteArrayMostSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromByteArrayLeastSignificantBits(struct TArray<char>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteArrayLeastSignificantBits
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromByteArray(struct TArray<char>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromByte(char Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByte
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromBooleanArray(struct TArray<bool>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBooleanArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromBoolean(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBoolean
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromBitArray(struct TArray<bool>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBitArray
	struct ULowEntryBitDataEntry* BitDataEntry_CreateFromBit(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBit
	struct TArray<char> BinaryToBytes(struct FString Binary); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BinaryToBytes
	struct TArray<char> BCrypt(struct TArray<char>& ByteArray, struct TArray<char>& Salt, int32_t Strength, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BCrypt
	struct TArray<char> Base64UrlToBytes(struct FString Base64Url); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64UrlToBytes
	struct FString Base64UrlToBase64(struct FString Base64Url); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64UrlToBase64
	struct TArray<char> Base64ToBytes(struct FString Base64); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64ToBytes
	struct FString Base64ToBase64Url(struct FString Base64); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64ToBase64Url
	bool AreBytesEqual(struct TArray<char>& A, struct TArray<char>& B, int32_t IndexA, int32_t LengthA, int32_t IndexB, int32_t LengthB); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.AreBytesEqual
	bool AreAndroidHeadphonesPluggedIn(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.AreAndroidHeadphonesPluggedIn
	bool AndroidPlatform(); // Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.AndroidPlatform
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryBitDataWriter
// Size: 0x40(Inherited: 0x28) 
struct ULowEntryBitDataWriter : public UObject
{
	struct TArray<char> Bytes;  // 0x28(0x10)
	char CurrentByte;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CurrentBytePosition;  // 0x3C(0x4)

	void AddStringUtf8Array(struct TArray<struct FString>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddStringUtf8Array
	void AddStringUtf8(struct FString Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddStringUtf8
	void AddPositiveInteger3Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddPositiveInteger3Array
	void AddPositiveInteger3(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddPositiveInteger3
	void AddPositiveInteger2Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddPositiveInteger2Array
	void AddPositiveInteger2(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddPositiveInteger2
	void AddPositiveInteger1Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddPositiveInteger1Array
	void AddPositiveInteger1(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddPositiveInteger1
	void AddLongBytesArray(struct TArray<struct ULowEntryLong*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddLongBytesArray
	void AddLongBytes(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddLongBytes
	void AddLongArray(struct TArray<int64_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddLongArray
	void AddLong(int64_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddLong
	void AddIntegerMostSignificantBits(int32_t Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerMostSignificantBits
	void AddIntegerLeastSignificantBits(int32_t Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerLeastSignificantBits
	void AddIntegerArrayMostSignificantBits(struct TArray<int32_t>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerArrayMostSignificantBits
	void AddIntegerArrayLeastSignificantBits(struct TArray<int32_t>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerArrayLeastSignificantBits
	void AddIntegerArray(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerArray
	void AddInteger(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddInteger
	void AddFloatArray(struct TArray<float>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddFloatArray
	void AddFloat(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddFloat
	void AddDoubleBytesArray(struct TArray<struct ULowEntryDouble*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddDoubleBytesArray
	void AddDoubleBytes(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddDoubleBytes
	void AddByteMostSignificantBits(char Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteMostSignificantBits
	void AddByteLeastSignificantBits(char Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteLeastSignificantBits
	void AddByteArrayMostSignificantBits(struct TArray<char>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteArrayMostSignificantBits
	void AddByteArrayLeastSignificantBits(struct TArray<char>& Value, int32_t BitCount); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteArrayLeastSignificantBits
	void AddByteArray(struct TArray<char>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteArray
	void AddByte(char Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByte
	void AddBooleanArray(struct TArray<bool>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddBooleanArray
	void AddBoolean(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddBoolean
	void AddBitArray(struct TArray<bool>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddBitArray
	void AddBit(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddBit
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryByteArray
// Size: 0x38(Inherited: 0x28) 
struct ULowEntryByteArray : public UObject
{
	struct TArray<char> ByteArray;  // 0x28(0x10)

}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLatentActionNone
// Size: 0x30(Inherited: 0x28) 
struct ULowEntryLatentActionNone : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Finished : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t KeepAliveCount;  // 0x2C(0x4)

	void WaitTillDone(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionNone.WaitTillDone
	bool IsDone(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionNone.IsDone
	void Done(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionNone.Done
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryByteDataEntry
// Size: 0xE8(Inherited: 0x28) 
struct ULowEntryByteDataEntry : public UObject
{
	char Type;  // 0x28(0x1)
	char ByteValue;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t IntegerValue;  // 0x2C(0x4)
	int64_t LongValue;  // 0x30(0x8)
	struct ULowEntryLong* LongBytesValue;  // 0x38(0x8)
	float FloatValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct ULowEntryDouble* DoubleBytesValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool BooleanValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString StringUtf8Value;  // 0x58(0x10)
	struct TArray<char> ByteArrayValue;  // 0x68(0x10)
	struct TArray<int32_t> IntegerArrayValue;  // 0x78(0x10)
	struct TArray<int64_t> LongArrayValue;  // 0x88(0x10)
	struct TArray<struct ULowEntryLong*> LongBytesArrayValue;  // 0x98(0x10)
	struct TArray<float> FloatArrayValue;  // 0xA8(0x10)
	struct TArray<struct ULowEntryDouble*> DoubleBytesArrayValue;  // 0xB8(0x10)
	struct TArray<bool> BooleanArrayValue;  // 0xC8(0x10)
	struct TArray<struct FString> StringUtf8ArrayValue;  // 0xD8(0x10)

}; 



// Class LowEntryExtendedStandardLibrary.LowEntryDouble
// Size: 0x38(Inherited: 0x28) 
struct ULowEntryDouble : public UObject
{
	struct TArray<char> Bytes;  // 0x28(0x10)

	void SetBytes(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.SetBytes
	bool LongBytes_LessThan(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.LongBytes_LessThan
	bool LongBytes_GreaterThan(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.LongBytes_GreaterThan
	bool Integer_LessThan(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Integer_LessThan
	bool Integer_GreaterThan(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Integer_GreaterThan
	struct TArray<char> GetBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.GetBytes
	void Float_Subtract(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_Subtract
	bool Float_LessThan(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_LessThan
	bool Float_GreaterThan(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_GreaterThan
	bool Float_Equals(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_Equals
	void Float_Add(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_Add
	void DoubleBytes_Subtract(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_Subtract
	bool DoubleBytes_LessThan(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_LessThan
	bool DoubleBytes_GreaterThan(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_GreaterThan
	bool DoubleBytes_Equals(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_Equals
	void DoubleBytes_Add(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_Add
	struct ULowEntryDouble* CreateClone(); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.CreateClone
	struct FString CastToString(int32_t MinFractionalDigits); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.CastToString
	struct ULowEntryLong* CastToLongBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryDouble.CastToLongBytes
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryByteDataWriter
// Size: 0x38(Inherited: 0x28) 
struct ULowEntryByteDataWriter : public UObject
{
	struct TArray<char> Bytes;  // 0x28(0x10)

	void AddStringUtf8Array(struct TArray<struct FString>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddStringUtf8Array
	void AddStringUtf8(struct FString Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddStringUtf8
	void AddPositiveInteger3Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger3Array
	void AddPositiveInteger3(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger3
	void AddPositiveInteger2Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger2Array
	void AddPositiveInteger2(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger2
	void AddPositiveInteger1Array(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger1Array
	void AddPositiveInteger1(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger1
	void AddLongBytesArray(struct TArray<struct ULowEntryLong*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLongBytesArray
	void AddLongBytes(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLongBytes
	void AddLongArray(struct TArray<int64_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLongArray
	void AddLong(int64_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLong
	void AddIntegerArray(struct TArray<int32_t>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddIntegerArray
	void AddInteger(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddInteger
	void AddFloatArray(struct TArray<float>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddFloatArray
	void AddFloat(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddFloat
	void AddDoubleBytesArray(struct TArray<struct ULowEntryDouble*>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddDoubleBytesArray
	void AddDoubleBytes(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddDoubleBytes
	void AddByteArray(struct TArray<char>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddByteArray
	void AddByte(char Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddByte
	void AddBooleanArray(struct TArray<bool>& Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddBooleanArray
	void AddBoolean(bool Value); // Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddBoolean
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLatentActionString
// Size: 0x48(Inherited: 0x28) 
struct ULowEntryLatentActionString : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Finished : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString Result;  // 0x30(0x10)
	int32_t KeepAliveCount;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

	void WaitTillDone(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct FString& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.WaitTillDone
	bool IsDone(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.IsDone
	void GetResult(struct FString& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.GetResult
	void Done(struct FString Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.Done
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryExecutionQueue
// Size: 0x30(Inherited: 0x28) 
struct ULowEntryExecutionQueue : public UObject
{
	int32_t Count;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Next : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLatentActionBoolean
// Size: 0x30(Inherited: 0x28) 
struct ULowEntryLatentActionBoolean : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Finished : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Result : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t KeepAliveCount;  // 0x2C(0x4)

	void WaitTillDone(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, bool& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionBoolean.WaitTillDone
	bool IsDone(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionBoolean.IsDone
	void GetResult(bool& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionBoolean.GetResult
	void Done(bool Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionBoolean.Done
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLatentActionFloat
// Size: 0x38(Inherited: 0x28) 
struct ULowEntryLatentActionFloat : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Finished : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float Result;  // 0x2C(0x4)
	int32_t KeepAliveCount;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

	void WaitTillDone(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, float& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionFloat.WaitTillDone
	bool IsDone(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionFloat.IsDone
	void GetResult(float& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionFloat.GetResult
	void Done(float Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionFloat.Done
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLatentActionInteger
// Size: 0x38(Inherited: 0x28) 
struct ULowEntryLatentActionInteger : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Finished : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Result;  // 0x2C(0x4)
	int32_t KeepAliveCount;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

	void WaitTillDone(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, int32_t& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionInteger.WaitTillDone
	bool IsDone(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionInteger.IsDone
	void GetResult(int32_t& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionInteger.GetResult
	void Done(int32_t Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionInteger.Done
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLatentActionObject
// Size: 0x40(Inherited: 0x28) 
struct ULowEntryLatentActionObject : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Finished : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UObject* Result;  // 0x30(0x8)
	int32_t KeepAliveCount;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

	void WaitTillDone(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UObject*& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionObject.WaitTillDone
	bool IsDone(); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionObject.IsDone
	void GetResult(struct UObject*& Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionObject.GetResult
	void Done(struct UObject* Result_); // Function LowEntryExtendedStandardLibrary.LowEntryLatentActionObject.Done
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryLong
// Size: 0x38(Inherited: 0x28) 
struct ULowEntryLong : public UObject
{
	struct TArray<char> Bytes;  // 0x28(0x10)

	void SetLong(int64_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.SetLong
	void SetBytes(struct TArray<char>& ByteArray, int32_t Index, int32_t Length); // Function LowEntryExtendedStandardLibrary.LowEntryLong.SetBytes
	void LongBytes_Subtract(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_Subtract
	bool LongBytes_LessThan(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_LessThan
	bool LongBytes_GreaterThan(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_GreaterThan
	bool LongBytes_Equals(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_Equals
	void LongBytes_Add(struct ULowEntryLong* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_Add
	void Integer_Subtract(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_Subtract
	bool Integer_LessThan(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_LessThan
	bool Integer_GreaterThan(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_GreaterThan
	bool Integer_Equals(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_Equals
	void Integer_Add(int32_t Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_Add
	int64_t GetLong(); // Function LowEntryExtendedStandardLibrary.LowEntryLong.GetLong
	struct TArray<char> GetBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryLong.GetBytes
	bool Float_LessThan(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Float_LessThan
	bool Float_GreaterThan(float Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.Float_GreaterThan
	bool DoubleBytes_LessThan(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.DoubleBytes_LessThan
	bool DoubleBytes_GreaterThan(struct ULowEntryDouble* Value); // Function LowEntryExtendedStandardLibrary.LowEntryLong.DoubleBytes_GreaterThan
	struct ULowEntryLong* CreateClone(); // Function LowEntryExtendedStandardLibrary.LowEntryLong.CreateClone
	struct FString CastToString(); // Function LowEntryExtendedStandardLibrary.LowEntryLong.CastToString
	struct ULowEntryDouble* CastToDoubleBytes(); // Function LowEntryExtendedStandardLibrary.LowEntryLong.CastToDoubleBytes
}; 



// Class LowEntryExtendedStandardLibrary.LowEntryParsedHashcash
// Size: 0x50(Inherited: 0x28) 
struct ULowEntryParsedHashcash : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Valid : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString Resource;  // 0x30(0x10)
	struct FDateTime Date;  // 0x40(0x8)
	int32_t Bits;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

	struct FString ToString(); // Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.ToString
	struct FString GetResource(); // Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.GetResource
	struct FDateTime GetDate(); // Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.GetDate
	int32_t GetBits(); // Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.GetBits
}; 



