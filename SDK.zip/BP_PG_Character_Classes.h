#pragma once 
#include <BP_PG_Character_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_Character.BP_PG_Character_C
// Size: 0x7B0(Inherited: 0x720) 
struct ABP_PG_Character_C : public APG_Character
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x720(0x8)
	struct UStaticMeshComponent* Beard;  // 0x728(0x8)
	struct UStaticMeshComponent* Clips_04;  // 0x730(0x8)
	struct UStaticMeshComponent* Clips_03;  // 0x738(0x8)
	struct UStaticMeshComponent* Tool;  // 0x740(0x8)
	struct UStaticMeshComponent* Glowstick_01;  // 0x748(0x8)
	struct UStaticMeshComponent* Pistol;  // 0x750(0x8)
	struct UStaticMeshComponent* Grenade_02;  // 0x758(0x8)
	struct UStaticMeshComponent* Grenade_01;  // 0x760(0x8)
	struct UStaticMeshComponent* Pouch_03;  // 0x768(0x8)
	struct UStaticMeshComponent* Pouch_02;  // 0x770(0x8)
	struct UStaticMeshComponent* Pouch_01;  // 0x778(0x8)
	struct UStaticMeshComponent* Radio;  // 0x780(0x8)
	float Timeline_CameraRadialBlur_Alpha_528A8686463CE6A4D0B015899DABE58A;  // 0x788(0x4)
	char ETimelineDirection Timeline_CameraRadialBlur__Direction_528A8686463CE6A4D0B015899DABE58A;  // 0x78C(0x1)
	char pad_1933[3];  // 0x78D(0x3)
	struct UTimelineComponent* Timeline_CameraRadialBlur;  // 0x790(0x8)
	double SaveNeutralizationFire;  // 0x798(0x8)
	struct UMaterialInstanceDynamic* MI_ScopeBlur;  // 0x7A0(0x8)
	struct UMaterialInstanceDynamic* MI_WeaponBlur;  // 0x7A8(0x8)

	void OnAiming(struct AItem_Module_Optic* Optic); // Function BP_PG_Character.BP_PG_Character_C.OnAiming
	void SetMaterialsByFriendly(bool IsFriendly); // Function BP_PG_Character.BP_PG_Character_C.SetMaterialsByFriendly
	void SetPlayerLooksOverride(struct APG_Character* Character, bool IsLooks); // Function BP_PG_Character.BP_PG_Character_C.SetPlayerLooksOverride
	void SetVisibleMarkerByDistance(); // Function BP_PG_Character.BP_PG_Character_C.SetVisibleMarkerByDistance
	void UserConstructionScript(); // Function BP_PG_Character.BP_PG_Character_C.UserConstructionScript
	void Timeline_CameraRadialBlur__FinishedFunc(); // Function BP_PG_Character.BP_PG_Character_C.Timeline_CameraRadialBlur__FinishedFunc
	void Timeline_CameraRadialBlur__UpdateFunc(); // Function BP_PG_Character.BP_PG_Character_C.Timeline_CameraRadialBlur__UpdateFunc
	void CameraNeutralizationEffectEvent(float Damage); // Function BP_PG_Character.BP_PG_Character_C.CameraNeutralizationEffectEvent
	void BndEvt__BP_PG_Character_WeaponComponent_K2Node_ComponentBoundEvent_0_OnAimingDelegate__DelegateSignature(struct AItem_Module_Optic* OpticItem); // Function BP_PG_Character.BP_PG_Character_C.BndEvt__BP_PG_Character_WeaponComponent_K2Node_ComponentBoundEvent_0_OnAimingDelegate__DelegateSignature
	void EventTakeDamage(struct FVector& Origin); // Function BP_PG_Character.BP_PG_Character_C.EventTakeDamage
	void Respawn(); // Function BP_PG_Character.BP_PG_Character_C.Respawn
	void OnIsAlive_Event(); // Function BP_PG_Character.BP_PG_Character_C.OnIsAlive_Event
	void ReceiveBeginPlay(); // Function BP_PG_Character.BP_PG_Character_C.ReceiveBeginPlay
	void SetPlayerLooks(struct APG_Character* Character, bool bIsLooks); // Function BP_PG_Character.BP_PG_Character_C.SetPlayerLooks
	void HitAtProtectedCharacter(); // Function BP_PG_Character.BP_PG_Character_C.HitAtProtectedCharacter
	void DeathEvent(struct APG_PlayerState_Game* killer, uint8_t  deathType); // Function BP_PG_Character.BP_PG_Character_C.DeathEvent
	void ExecuteUbergraph_BP_PG_Character(int32_t EntryPoint); // Function BP_PG_Character.BP_PG_Character_C.ExecuteUbergraph_BP_PG_Character
}; 



