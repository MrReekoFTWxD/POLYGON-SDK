#pragma once 
#include <ActorSequence_Structs.h>
 
 
 
// Class ActorSequence.ActorSequenceComponent
// Size: 0xE0(Inherited: 0xB0) 
struct UActorSequenceComponent : public UActorComponent
{
	char pad_176[8];  // 0xB0(0x8)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings;  // 0xB8(0x14)
	char pad_204[4];  // 0xCC(0x4)
	struct UActorSequence* Sequence;  // 0xD0(0x8)
	struct UActorSequencePlayer* SequencePlayer;  // 0xD8(0x8)

}; 



// Class ActorSequence.ActorSequence
// Size: 0x88(Inherited: 0x60) 
struct UActorSequence : public UMovieSceneSequence
{
	struct UMovieScene* MovieScene;  // 0x60(0x8)
	struct FActorSequenceObjectReferenceMap ObjectReferences;  // 0x68(0x20)

}; 



// Class ActorSequence.ActorSequencePlayer
// Size: 0x4D0(Inherited: 0x4D0) 
struct UActorSequencePlayer : public UMovieSceneSequencePlayer
{

}; 



