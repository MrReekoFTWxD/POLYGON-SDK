#pragma once 
#include <BP_Item_Underbarrel_StandartUnderbarrel_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Underbarrel_StandartUnderbarrel.BP_Item_Underbarrel_StandartUnderbarrel_C
// Size: 0x2E8(Inherited: 0x2E0) 
struct ABP_Item_Underbarrel_StandartUnderbarrel_C : public AItem_Module_General
{
	struct USceneComponent* DefaultSceneRoot;  // 0x2E0(0x8)

}; 



