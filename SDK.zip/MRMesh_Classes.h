#pragma once 
#include <MRMesh_Structs.h>
 
 
 
// Class MRMesh.MeshReconstructorBase
// Size: 0x28(Inherited: 0x28) 
struct UMeshReconstructorBase : public UObject
{

	void StopReconstruction(); // Function MRMesh.MeshReconstructorBase.StopReconstruction
	void StartReconstruction(); // Function MRMesh.MeshReconstructorBase.StartReconstruction
	void PauseReconstruction(); // Function MRMesh.MeshReconstructorBase.PauseReconstruction
	bool IsReconstructionStarted(); // Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	bool IsReconstructionPaused(); // Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	void DisconnectMRMesh(); // Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	void ConnectMRMesh(struct UMRMeshComponent* Mesh); // Function MRMesh.MeshReconstructorBase.ConnectMRMesh
}; 



// Class MRMesh.MRMeshComponent
// Size: 0x5C0(Inherited: 0x540) 
struct UMRMeshComponent : public UPrimitiveComponent
{
	char pad_1344[8];  // 0x540(0x8)
	struct UMaterialInterface* Material;  // 0x548(0x8)
	struct UMaterialInterface* WireframeMaterial;  // 0x550(0x8)
	char pad_1368_1 : 7;  // 0x558(0x1)
	bool bCreateMeshProxySections : 1;  // 0x558(0x1)
	char pad_1369_1 : 7;  // 0x559(0x1)
	bool bUpdateNavMeshOnMeshUpdate : 1;  // 0x559(0x1)
	char pad_1370[1];  // 0x55A(0x1)
	char pad_1371_1 : 7;  // 0x55B(0x1)
	bool bNeverCreateCollisionMesh : 1;  // 0x55B(0x1)
	char pad_1372[68];  // 0x55C(0x44)
	struct TArray<struct UMRMeshBodyHolder*> BodyHolders;  // 0x5A0(0x10)
	char pad_1456[16];  // 0x5B0(0x10)

	void SetWireframeMaterial(struct UMaterialInterface* InMaterial); // Function MRMesh.MRMeshComponent.SetWireframeMaterial
	void SetWireframeColor(struct FLinearColor& InColor); // Function MRMesh.MRMeshComponent.SetWireframeColor
	void SetUseWireframe(bool bUseWireframe); // Function MRMesh.MRMeshComponent.SetUseWireframe
	void SetEnableMeshOcclusion(bool bEnable); // Function MRMesh.MRMeshComponent.SetEnableMeshOcclusion
	void RequestNavMeshUpdate(); // Function MRMesh.MRMeshComponent.RequestNavMeshUpdate
	bool IsConnected(); // Function MRMesh.MRMeshComponent.IsConnected
	struct FLinearColor GetWireframeColor(); // Function MRMesh.MRMeshComponent.GetWireframeColor
	bool GetUseWireframe(); // Function MRMesh.MRMeshComponent.GetUseWireframe
	bool GetEnableMeshOcclusion(); // Function MRMesh.MRMeshComponent.GetEnableMeshOcclusion
	void ForceNavMeshUpdate(); // Function MRMesh.MRMeshComponent.ForceNavMeshUpdate
	void Clear(); // Function MRMesh.MRMeshComponent.Clear
}; 



// Class MRMesh.MRMeshBodyHolder
// Size: 0x230(Inherited: 0x28) 
struct UMRMeshBodyHolder : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UBodySetup* BodySetup;  // 0x30(0x8)
	struct FBodyInstance BodyInstance;  // 0x38(0x190)
	char pad_456[104];  // 0x1C8(0x68)

}; 



// Class MRMesh.MockDataMeshTrackerComponent
// Size: 0x320(Inherited: 0x2B0) 
struct UMockDataMeshTrackerComponent : public USceneComponent
{
	struct FMulticastInlineDelegate OnMeshTrackerUpdated;  // 0x2B0(0x10)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool ScanWorld : 1;  // 0x2C0(0x1)
	char pad_705_1 : 7;  // 0x2C1(0x1)
	bool RequestNormals : 1;  // 0x2C1(0x1)
	char pad_706_1 : 7;  // 0x2C2(0x1)
	bool RequestVertexConfidence : 1;  // 0x2C2(0x1)
	uint8_t  VertexColorMode;  // 0x2C3(0x1)
	char pad_708[4];  // 0x2C4(0x4)
	struct TArray<struct FColor> BlockVertexColors;  // 0x2C8(0x10)
	struct FLinearColor VertexColorFromConfidenceZero;  // 0x2D8(0x10)
	struct FLinearColor VertexColorFromConfidenceOne;  // 0x2E8(0x10)
	float UpdateInterval;  // 0x2F8(0x4)
	char pad_764[4];  // 0x2FC(0x4)
	struct UMRMeshComponent* MRMesh;  // 0x300(0x8)
	char pad_776[24];  // 0x308(0x18)

	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<float>& Confidence); // DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh
}; 



