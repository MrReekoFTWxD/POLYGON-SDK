#pragma once 
#include <BP_FOVManagerComponent_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C
// Size: 0xD8(Inherited: 0xC8) 
struct UBP_FOVManagerComponent_Game_C : public UFOVManagerComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xC8(0x8)
	double AimingFOVAlpha;  // 0xD0(0x8)

	void ReceiveBeginPlay(); // Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.ReceiveBeginPlay
	void OnPossessedPawnChanged_Event(struct APawn* OldPawn, struct APawn* NewPawn); // Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.OnPossessedPawnChanged_Event
	void OnAiming_Event(struct AItem_Module_Optic* OpticItem); // Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.OnAiming_Event
	void ExecuteUbergraph_BP_FOVManagerComponent_Game(int32_t EntryPoint); // Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.ExecuteUbergraph_BP_FOVManagerComponent_Game
}; 



