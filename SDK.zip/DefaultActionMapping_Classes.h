#pragma once 
#include <DefaultActionMapping_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultActionMapping.DefaultActionMapping_C
// Size: 0x2D8(Inherited: 0x2D8) 
struct UDefaultActionMapping_C : public UActionMapping
{

}; 



