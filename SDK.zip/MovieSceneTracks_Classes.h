#pragma once 
#include <MovieSceneTracks_Structs.h>
 
 
 
// Class MovieSceneTracks.MovieSceneEventSectionBase
// Size: 0xE8(Inherited: 0xE8) 
struct UMovieSceneEventSectionBase : public UMovieSceneSection
{

}; 



// Class MovieSceneTracks.MovieSceneHierarchicalBiasSystem
// Size: 0x40(Inherited: 0x40) 
struct UMovieSceneHierarchicalBiasSystem : public UMovieSceneEntityInstantiatorSystem
{

}; 



// Class MovieSceneTracks.MovieSceneTransformOrigin
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneTransformOrigin : public UInterface
{

	struct FTransform BP_GetTransformOrigin(); // Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin
}; 



// Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x490(Inherited: 0xE8) 
struct UMovieSceneColorSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneFloatChannel RedCurve;  // 0xF0(0xE8)
	struct FMovieSceneFloatChannel GreenCurve;  // 0x1D8(0xE8)
	struct FMovieSceneFloatChannel BlueCurve;  // 0x2C0(0xE8)
	struct FMovieSceneFloatChannel AlphaCurve;  // 0x3A8(0xE8)

}; 



// Class MovieSceneTracks.MovieScenePiecewiseDoubleBlenderSystem
// Size: 0x128(Inherited: 0x68) 
struct UMovieScenePiecewiseDoubleBlenderSystem : public UMovieSceneBlenderSystem
{
	char pad_104[192];  // 0x68(0xC0)

}; 



// Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0x148(Inherited: 0xE8) 
struct UMovieSceneParameterSection : public UMovieSceneSection
{
	struct TArray<struct FBoolParameterNameAndCurve> BoolParameterNamesAndCurves;  // 0xE8(0x10)
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves;  // 0xF8(0x10)
	struct TArray<struct FVector2DParameterNameAndCurves> Vector2DParameterNamesAndCurves;  // 0x108(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves;  // 0x118(0x10)
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves;  // 0x128(0x10)
	struct TArray<struct FTransformParameterNameAndCurves> TransformParameterNamesAndCurves;  // 0x138(0x10)

	bool RemoveVectorParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveVectorParameter
	bool RemoveVector2DParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveVector2DParameter
	bool RemoveTransformParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveTransformParameter
	bool RemoveScalarParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveScalarParameter
	bool RemoveColorParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveColorParameter
	bool RemoveBoolParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveBoolParameter
	void GetParameterNames(struct TSet<struct FName>& ParameterNames); // Function MovieSceneTracks.MovieSceneParameterSection.GetParameterNames
	void AddVectorParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FVector InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddVectorParameterKey
	void AddVector2DParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FVector2D InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddVector2DParameterKey
	void AddTransformParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FTransform& InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddTransformParameterKey
	void AddScalarParameterKey(struct FName InParameterName, struct FFrameNumber InTime, float InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddScalarParameterKey
	void AddColorParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FLinearColor InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddColorParameterKey
	void AddBoolParameterKey(struct FName InParameterName, struct FFrameNumber InTime, bool InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddBoolParameterKey
}; 



// Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneAudioTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> AudioSections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeEvaluator
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneCameraShakeEvaluator : public UObject
{

}; 



// Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x1C8(Inherited: 0xE8) 
struct UMovieSceneIntegerSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneIntegerChannel IntegerCurve;  // 0xF0(0xD8)

}; 



// Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0xC0(Inherited: 0x90) 
struct UMovieScenePropertyTrack : public UMovieSceneNameableTrack
{
	struct UMovieSceneSection* SectionToKey;  // 0x90(0x8)
	struct FMovieScenePropertyBinding PropertyBinding;  // 0x98(0x14)
	char pad_172[4];  // 0xAC(0x4)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0xB0(0x10)

}; 



// Class MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction
// Size: 0x80(Inherited: 0x30) 
struct UMovieSceneAsyncAction_SequencePrediction : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate Result;  // 0x30(0x10)
	struct FMulticastInlineDelegate Failure;  // 0x40(0x10)
	char pad_80[16];  // 0x50(0x10)
	struct UMovieSceneSequencePlayer* SequencePlayer;  // 0x60(0x8)
	struct USceneComponent* SceneComponent;  // 0x68(0x8)
	char pad_112[16];  // 0x70(0x10)

	struct UMovieSceneAsyncAction_SequencePrediction* PredictWorldTransformAtTime(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, float TimeInSeconds); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictWorldTransformAtTime
	struct UMovieSceneAsyncAction_SequencePrediction* PredictWorldTransformAtFrame(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, struct FFrameTime FrameTime); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictWorldTransformAtFrame
	struct UMovieSceneAsyncAction_SequencePrediction* PredictLocalTransformAtTime(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, float TimeInSeconds); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictLocalTransformAtTime
	struct UMovieSceneAsyncAction_SequencePrediction* PredictLocalTransformAtFrame(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, struct FFrameTime FrameTime); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictLocalTransformAtFrame
}; 



// Class MovieSceneTracks.MovieSceneDoublePropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneDoublePropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0xA58(Inherited: 0xE8) 
struct UMovieScene3DTransformSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneTransformMask TransformMask;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct FMovieSceneDoubleChannel Translation[3];  // 0xF8(0x2D0)
	struct FMovieSceneDoubleChannel Rotation[3];  // 0x3C8(0x2D0)
	struct FMovieSceneDoubleChannel Scale[3];  // 0x698(0x2D0)
	struct FMovieSceneFloatChannel ManualWeight;  // 0x968(0xE8)
	char pad_2640_1 : 7;  // 0xA50(0x1)
	bool bUseQuaternionInterpolation : 1;  // 0xA50(0x1)
	char pad_2641[7];  // 0xA51(0x7)

}; 



// Class MovieSceneTracks.IntegerChannelEvaluatorSystem
// Size: 0x40(Inherited: 0x40) 
struct UIntegerChannelEvaluatorSystem : public UMovieSceneEntitySystem
{

}; 



// Class MovieSceneTracks.FloatChannelEvaluatorSystem
// Size: 0x40(Inherited: 0x40) 
struct UFloatChannelEvaluatorSystem : public UMovieSceneEntitySystem
{

}; 



// Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0xC0(Inherited: 0xC0) 
struct UMovieSceneTransformTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneCameraAnimTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> CameraAnimSections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.ByteChannelEvaluatorSystem
// Size: 0x40(Inherited: 0x40) 
struct UByteChannelEvaluatorSystem : public UMovieSceneEntitySystem
{

}; 



// Class MovieSceneTracks.DoubleChannelEvaluatorSystem
// Size: 0x40(Inherited: 0x40) 
struct UDoubleChannelEvaluatorSystem : public UMovieSceneEntitySystem
{

}; 



// Class MovieSceneTracks.MovieScenePropertySystem
// Size: 0x58(Inherited: 0x40) 
struct UMovieScenePropertySystem : public UMovieSceneEntitySystem
{
	char pad_64[8];  // 0x40(0x8)
	struct UMovieScenePropertyInstantiatorSystem* InstantiatorSystem;  // 0x48(0x8)
	char pad_80[8];  // 0x50(0x8)

}; 



// Class MovieSceneTracks.MovieSceneDoubleTrack
// Size: 0xC0(Inherited: 0xC0) 
struct UMovieSceneDoubleTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneCameraShakeTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> CameraShakeSections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x200(Inherited: 0x110) 
struct UMovieScene3DPathSection : public UMovieScene3DConstraintSection
{
	struct FMovieSceneFloatChannel TimingCurve;  // 0x110(0xE8)
	uint8_t  FrontAxisEnum;  // 0x1F8(0x1)
	uint8_t  UpAxisEnum;  // 0x1F9(0x1)
	char pad_506[2];  // 0x1FA(0x2)
	char bFollow : 1;  // 0x1FC(0x1)
	char bReverse : 1;  // 0x1FC(0x1)
	char bForceUpright : 1;  // 0x1FC(0x1)
	char pad_508_1 : 5;  // 0x1FC(0x1)
	char pad_509[4];  // 0x1FD(0x4)

}; 



// Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0x110(Inherited: 0xE8) 
struct UMovieScene3DConstraintSection : public UMovieSceneSection
{
	struct FGuid ConstraintId;  // 0xE8(0x10)
	struct FMovieSceneObjectBindingID ConstraintBindingID;  // 0xF8(0x18)

	void SetConstraintBindingID(struct FMovieSceneObjectBindingID& InConstraintBindingID); // Function MovieSceneTracks.MovieScene3DConstraintSection.SetConstraintBindingID
	struct FMovieSceneObjectBindingID GetConstraintBindingID(); // Function MovieSceneTracks.MovieScene3DConstraintSection.GetConstraintBindingID
}; 



// Class MovieSceneTracks.MovieSceneCVarTrackInstance
// Size: 0xA0(Inherited: 0x50) 
struct UMovieSceneCVarTrackInstance : public UMovieSceneTrackInstance
{
	char pad_80[80];  // 0x50(0x50)

}; 



// Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneColorTrack : public UMovieScenePropertyTrack
{
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bIsSlateColor : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)

}; 



// Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0x130(Inherited: 0x110) 
struct UMovieScene3DAttachSection : public UMovieScene3DConstraintSection
{
	char pad_272[8];  // 0x110(0x8)
	struct FName AttachSocketName;  // 0x118(0x8)
	struct FName AttachComponentName;  // 0x120(0x8)
	uint8_t  AttachmentLocationRule;  // 0x128(0x1)
	uint8_t  AttachmentRotationRule;  // 0x129(0x1)
	uint8_t  AttachmentScaleRule;  // 0x12A(0x1)
	uint8_t  DetachmentLocationRule;  // 0x12B(0x1)
	uint8_t  DetachmentRotationRule;  // 0x12C(0x1)
	uint8_t  DetachmentScaleRule;  // 0x12D(0x1)
	char pad_302[2];  // 0x12E(0x2)

}; 



// Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneEnumTrack : public UMovieScenePropertyTrack
{
	struct UEnum* Enum;  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0xA0(Inherited: 0x90) 
struct UMovieScene3DConstraintTrack : public UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> ConstraintSections;  // 0x90(0x10)

}; 



// Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0xA0(Inherited: 0xA0) 
struct UMovieScene3DAttachTrack : public UMovieScene3DConstraintTrack
{

}; 



// Class MovieSceneTracks.MovieSceneDataLayerSystem
// Size: 0xD0(Inherited: 0x40) 
struct UMovieSceneDataLayerSystem : public UMovieSceneEntitySystem
{
	char pad_64[144];  // 0x40(0x90)

}; 



// Class MovieSceneTracks.MovieSceneEulerTransformTrack
// Size: 0xC0(Inherited: 0xC0) 
struct UMovieSceneEulerTransformTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x5A0(Inherited: 0xE8) 
struct UMovieSceneAudioSection : public UMovieSceneSection
{
	struct USoundBase* Sound;  // 0xE8(0x8)
	struct FFrameNumber StartFrameOffset;  // 0xF0(0x4)
	float StartOffset;  // 0xF4(0x4)
	float AudioStartTime;  // 0xF8(0x4)
	float AudioDilationFactor;  // 0xFC(0x4)
	float AudioVolume;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct FMovieSceneFloatChannel SoundVolume;  // 0x108(0xE8)
	struct FMovieSceneFloatChannel PitchMultiplier;  // 0x1F0(0xE8)
	struct TMap<struct FName, struct FMovieSceneFloatChannel> Inputs_Float;  // 0x2D8(0x50)
	struct TMap<struct FName, struct FMovieSceneStringChannel> Inputs_String;  // 0x328(0x50)
	struct TMap<struct FName, struct FMovieSceneBoolChannel> Inputs_Bool;  // 0x378(0x50)
	struct TMap<struct FName, struct FMovieSceneIntegerChannel> Inputs_Int;  // 0x3C8(0x50)
	struct TMap<struct FName, struct FMovieSceneAudioTriggerChannel> Inputs_Trigger;  // 0x418(0x50)
	struct FMovieSceneActorReferenceData AttachActorData;  // 0x468(0xF8)
	char pad_1376_1 : 7;  // 0x560(0x1)
	bool bLooping : 1;  // 0x560(0x1)
	char pad_1377_1 : 7;  // 0x561(0x1)
	bool bSuppressSubtitles : 1;  // 0x561(0x1)
	char pad_1378_1 : 7;  // 0x562(0x1)
	bool bOverrideAttenuation : 1;  // 0x562(0x1)
	char pad_1379[5];  // 0x563(0x5)
	struct USoundAttenuation* AttenuationSettings;  // 0x568(0x8)
	struct FDelegate OnQueueSubtitles;  // 0x570(0x10)
	struct FMulticastInlineDelegate OnAudioFinished;  // 0x580(0x10)
	struct FMulticastInlineDelegate OnAudioPlaybackPercent;  // 0x590(0x10)

	void SetStartOffset(struct FFrameNumber InStartOffset); // Function MovieSceneTracks.MovieSceneAudioSection.SetStartOffset
	void SetSound(struct USoundBase* InSound); // Function MovieSceneTracks.MovieSceneAudioSection.SetSound
	struct FFrameNumber GetStartOffset(); // Function MovieSceneTracks.MovieSceneAudioSection.GetStartOffset
	struct USoundBase* GetSound(); // Function MovieSceneTracks.MovieSceneAudioSection.GetSound
}; 



// Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0xA8(Inherited: 0xA0) 
struct UMovieScene3DPathTrack : public UMovieScene3DConstraintTrack
{
	char pad_160[8];  // 0xA0(0x8)

}; 



// Class MovieSceneTracks.MovieScene3DTransformPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieScene3DTransformPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneComponentTransformSystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneComponentTransformSystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeSourceShakeSection
// Size: 0x110(Inherited: 0xE8) 
struct UMovieSceneCameraShakeSourceShakeSection : public UMovieSceneSection
{
	struct FMovieSceneCameraShakeSectionData ShakeData;  // 0xE8(0x28)

}; 



// Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0xC0(Inherited: 0xC0) 
struct UMovieScene3DTransformTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x270(Inherited: 0xE8) 
struct UMovieSceneActorReferenceSection : public UMovieSceneSection
{
	struct FMovieSceneActorReferenceData ActorReferenceData;  // 0xE8(0xF8)
	struct FIntegralCurve ActorGuidIndexCurve;  // 0x1E0(0x80)
	struct TArray<struct FString> ActorGuidStrings;  // 0x260(0x10)

}; 



// Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneActorReferenceTrack : public UMovieScenePropertyTrack
{
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieSceneBaseValueEvaluatorSystem
// Size: 0x40(Inherited: 0x40) 
struct UMovieSceneBaseValueEvaluatorSystem : public UMovieSceneEntitySystem
{

}; 



// Class MovieSceneTracks.MovieSceneBoolPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneBoolPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneBoolTrack : public UMovieScenePropertyTrack
{
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieSceneBytePropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneBytePropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneCVarSection
// Size: 0x140(Inherited: 0xE8) 
struct UMovieSceneCVarSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneCVarOverrides ConsoleVariables;  // 0xF0(0x50)

	void SetFromString(struct FString InString); // Function MovieSceneTracks.MovieSceneCVarSection.SetFromString
	struct FString GetString(); // Function MovieSceneTracks.MovieSceneCVarSection.GetString
}; 



// Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x1D0(Inherited: 0xE8) 
struct UMovieSceneByteSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneByteChannel ByteCurve;  // 0xF0(0xE0)

}; 



// Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneByteTrack : public UMovieScenePropertyTrack
{
	struct UEnum* Enum;  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieSceneCameraAnimSection
// Size: 0x128(Inherited: 0xE8) 
struct UMovieSceneCameraAnimSection : public UMovieSceneSection
{
	struct FMovieSceneCameraAnimSectionData AnimData;  // 0xE8(0x20)
	struct UCameraAnim* CameraAnim;  // 0x108(0x8)
	float PlayRate;  // 0x110(0x4)
	float PlayScale;  // 0x114(0x4)
	float BlendInTime;  // 0x118(0x4)
	float BlendOutTime;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bLooping : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)

}; 



// Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x1D0(Inherited: 0xE8) 
struct UMovieSceneEnumSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneByteChannel EnumCurve;  // 0xF0(0xE0)

}; 



// Class MovieSceneTracks.MovieSceneCVarTrack
// Size: 0xA0(Inherited: 0x90) 
struct UMovieSceneCVarTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x90(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0x190(Inherited: 0xE8) 
struct UMovieSceneCameraCutSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bLockPreviousCamera : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	struct FGuid CameraGuid;  // 0xF4(0x10)
	struct FMovieSceneObjectBindingID CameraBindingID;  // 0x104(0x18)
	char pad_284[4];  // 0x11C(0x4)
	struct FTransform InitialCameraCutTransform;  // 0x120(0x60)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool bHasInitialCameraCutTransform : 1;  // 0x180(0x1)
	char pad_385[15];  // 0x181(0xF)

	void SetCameraBindingID(struct FMovieSceneObjectBindingID& InCameraBindingID); // Function MovieSceneTracks.MovieSceneCameraCutSection.SetCameraBindingID
	struct FMovieSceneObjectBindingID GetCameraBindingID(); // Function MovieSceneTracks.MovieSceneCameraCutSection.GetCameraBindingID
}; 



// Class MovieSceneTracks.MovieSceneComponentAttachmentInvalidatorSystem
// Size: 0x40(Inherited: 0x40) 
struct UMovieSceneComponentAttachmentInvalidatorSystem : public UMovieSceneEntityInstantiatorSystem
{

}; 



// Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneCameraCutTrack : public UMovieSceneNameableTrack
{
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bCanBlend : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCameraCutTrackInstance
// Size: 0xC8(Inherited: 0x50) 
struct UMovieSceneCameraCutTrackInstance : public UMovieSceneTrackInstance
{
	char pad_80[120];  // 0x50(0x78)

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0x138(Inherited: 0xE8) 
struct UMovieSceneCameraShakeSection : public UMovieSceneSection
{
	struct FMovieSceneCameraShakeSectionData ShakeData;  // 0xE8(0x28)
	UCameraShakeBase* ShakeClass;  // 0x110(0x8)
	float PlayScale;  // 0x118(0x4)
	uint8_t  PlaySpace;  // 0x11C(0x1)
	char pad_285[3];  // 0x11D(0x3)
	struct FRotator UserDefinedPlaySpace;  // 0x120(0x18)

}; 



// Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0xA0(Inherited: 0xA0) 
struct UMovieSceneCinematicShotTrack : public UMovieSceneSubTrack
{

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeSourceShakeTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneCameraShakeSourceShakeTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> CameraShakeSections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeSourceTriggerSection
// Size: 0x1B8(Inherited: 0xE8) 
struct UMovieSceneCameraShakeSourceTriggerSection : public UMovieSceneSection
{
	struct FMovieSceneCameraShakeSourceTriggerChannel Channel;  // 0xE8(0xD0)

}; 



// Class MovieSceneTracks.MovieSceneDataLayerTrack
// Size: 0xA0(Inherited: 0x90) 
struct UMovieSceneDataLayerTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x90(0x10)

}; 



// Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneParticleParameterTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeSourceTriggerTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneCameraShakeSourceTriggerTrack : public UMovieSceneTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x150(Inherited: 0x128) 
struct UMovieSceneCinematicShotSection : public UMovieSceneSubSection
{
	struct FString ShotDisplayName;  // 0x128(0x10)
	struct FText DisplayName;  // 0x138(0x18)

	void SetShotDisplayName(struct FString InShotDisplayName); // Function MovieSceneTracks.MovieSceneCinematicShotSection.SetShotDisplayName
	struct FString GetShotDisplayName(); // Function MovieSceneTracks.MovieSceneCinematicShotSection.GetShotDisplayName
}; 



// Class MovieSceneTracks.MovieScenePiecewiseEnumBlenderSystem
// Size: 0x90(Inherited: 0x68) 
struct UMovieScenePiecewiseEnumBlenderSystem : public UMovieSceneBlenderSystem
{
	char pad_104[40];  // 0x68(0x28)

}; 



// Class MovieSceneTracks.MovieSceneColorPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneColorPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneComponentAttachmentSystem
// Size: 0x1C0(Inherited: 0x40) 
struct UMovieSceneComponentAttachmentSystem : public UMovieSceneEntityInstantiatorSystem
{
	char pad_64[384];  // 0x40(0x180)

}; 



// Class MovieSceneTracks.MovieSceneFloatVectorSection
// Size: 0x498(Inherited: 0xE8) 
struct UMovieSceneFloatVectorSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneFloatChannel Curves[4];  // 0xF0(0x3A0)
	int32_t ChannelsUsed;  // 0x490(0x4)
	char pad_1172[4];  // 0x494(0x4)

}; 



// Class MovieSceneTracks.MovieSceneComponentMobilitySystem
// Size: 0x220(Inherited: 0x40) 
struct UMovieSceneComponentMobilitySystem : public UMovieSceneEntityInstantiatorSystem
{
	char pad_64[480];  // 0x40(0x1E0)

}; 



// Class MovieSceneTracks.MovieSceneDoubleSection
// Size: 0x1E0(Inherited: 0xE8) 
struct UMovieSceneDoubleSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneDoubleChannel DoubleCurve;  // 0xF0(0xF0)

}; 



// Class MovieSceneTracks.MovieSceneDataLayerSection
// Size: 0x108(Inherited: 0xE8) 
struct UMovieSceneDataLayerSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct TArray<struct FActorDataLayer> DataLayers;  // 0xF0(0x10)
	uint8_t  DesiredState;  // 0x100(0x1)
	uint8_t  PrerollState;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool bFlushOnUnload : 1;  // 0x102(0x1)
	char pad_259[5];  // 0x103(0x5)

	void SetPrerollState(uint8_t  InPrerollState); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetPrerollState
	void SetFlushOnUnload(bool bFlushOnUnload); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetFlushOnUnload
	void SetDesiredState(uint8_t  InDesiredState); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetDesiredState
	void SetDataLayers(struct TArray<struct FActorDataLayer>& InDataLayers); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetDataLayers
	uint8_t  GetPrerollState(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetPrerollState
	bool GetFlushOnUnload(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetFlushOnUnload
	uint8_t  GetDesiredState(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetDesiredState
	struct TArray<struct FActorDataLayer> GetDataLayers(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetDataLayers
}; 



// Class MovieSceneTracks.MovieSceneDeferredComponentMovementSystem
// Size: 0x58(Inherited: 0x40) 
struct UMovieSceneDeferredComponentMovementSystem : public UMovieSceneEntitySystem
{
	char pad_64[24];  // 0x40(0x18)

}; 



// Class MovieSceneTracks.MovieSceneEnumPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneEnumPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneEulerTransformPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneEulerTransformPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneEventRepeaterSection
// Size: 0x118(Inherited: 0xE8) 
struct UMovieSceneEventRepeaterSection : public UMovieSceneEventSectionBase
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneEvent Event;  // 0xF0(0x28)

}; 



// Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x230(Inherited: 0xE8) 
struct UMovieSceneEventSection : public UMovieSceneSection
{
	struct FNameCurve Events;  // 0xE8(0x78)
	struct FMovieSceneEventSectionData EventData;  // 0x160(0xD0)

}; 



// Class MovieSceneTracks.MovieSceneEventSystem
// Size: 0x90(Inherited: 0x40) 
struct UMovieSceneEventSystem : public UMovieSceneEntitySystem
{
	char pad_64[80];  // 0x40(0x50)

}; 



// Class MovieSceneTracks.MovieScenePreSpawnEventSystem
// Size: 0x90(Inherited: 0x90) 
struct UMovieScenePreSpawnEventSystem : public UMovieSceneEventSystem
{

}; 



// Class MovieSceneTracks.MovieScenePostSpawnEventSystem
// Size: 0x90(Inherited: 0x90) 
struct UMovieScenePostSpawnEventSystem : public UMovieSceneEventSystem
{

}; 



// Class MovieSceneTracks.MovieScenePostEvalEventSystem
// Size: 0x90(Inherited: 0x90) 
struct UMovieScenePostEvalEventSystem : public UMovieSceneEventSystem
{

}; 



// Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0xB8(Inherited: 0x90) 
struct UMovieSceneEventTrack : public UMovieSceneNameableTrack
{
	char pad_144[16];  // 0x90(0x10)
	char bFireEventsWhenForwards : 1;  // 0xA0(0x1)
	char bFireEventsWhenBackwards : 1;  // 0xA0(0x1)
	char pad_160_1 : 6;  // 0xA0(0x1)
	char pad_161[4];  // 0xA1(0x4)
	uint8_t  EventPosition;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0xA8(0x10)

}; 



// Class MovieSceneTracks.MovieSceneEventTriggerSection
// Size: 0x1C0(Inherited: 0xE8) 
struct UMovieSceneEventTriggerSection : public UMovieSceneEventSectionBase
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneEventChannel EventChannel;  // 0xF0(0xD0)

}; 



// Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x1E8(Inherited: 0xE8) 
struct UMovieSceneFadeSection : public UMovieSceneSection
{
	struct FMovieSceneFloatChannel FloatCurve;  // 0xE8(0xE8)
	struct FLinearColor FadeColor;  // 0x1D0(0x10)
	char bFadeAudio : 1;  // 0x1E0(0x1)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	char pad_481[8];  // 0x1E1(0x8)

}; 



// Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0xC0(Inherited: 0xC0) 
struct UMovieSceneFloatTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneInitialValueSystem
// Size: 0x40(Inherited: 0x40) 
struct UMovieSceneInitialValueSystem : public UMovieSceneEntityInstantiatorSystem
{

}; 



// Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneFadeTrack : public UMovieSceneFloatTrack
{
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieSceneFloatPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneFloatPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x1D8(Inherited: 0xE8) 
struct UMovieSceneFloatSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneFloatChannel FloatCurve;  // 0xF0(0xE8)

}; 



// Class MovieSceneTracks.MovieSceneIntegerPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneIntegerPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0xC0(Inherited: 0xC0) 
struct UMovieSceneIntegerTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneInterrogatedPropertyInstantiatorSystem
// Size: 0x1E8(Inherited: 0x40) 
struct UMovieSceneInterrogatedPropertyInstantiatorSystem : public UMovieSceneEntityInstantiatorSystem
{
	char pad_64[424];  // 0x40(0x1A8)

}; 



// Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0x108(Inherited: 0xE8) 
struct UMovieSceneLevelVisibilitySection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	uint8_t  Visibility;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct TArray<struct FName> LevelNames;  // 0xF8(0x10)

	void SetVisibility(uint8_t  InVisibility); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetVisibility
	void SetLevelNames(struct TArray<struct FName>& InLevelNames); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetLevelNames
	uint8_t  GetVisibility(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetVisibility
	struct TArray<struct FName> GetLevelNames(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetLevelNames
}; 



// Class MovieSceneTracks.MovieSceneLevelVisibilitySystem
// Size: 0x1A8(Inherited: 0x40) 
struct UMovieSceneLevelVisibilitySystem : public UMovieSceneEntitySystem
{
	char pad_64[360];  // 0x40(0x168)

}; 



// Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0xA0(Inherited: 0x90) 
struct UMovieSceneLevelVisibilityTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x90(0x10)

}; 



// Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0xA0(Inherited: 0x90) 
struct UMovieSceneMaterialTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x90(0x10)

}; 



// Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0xB0(Inherited: 0xA0) 
struct UMovieSceneMaterialParameterCollectionTrack : public UMovieSceneMaterialTrack
{
	char pad_160[8];  // 0xA0(0x8)
	struct UMaterialParameterCollection* MPC;  // 0xA8(0x8)

}; 



// Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0xB0(Inherited: 0xA0) 
struct UMovieSceneComponentMaterialTrack : public UMovieSceneMaterialTrack
{
	char pad_160[8];  // 0xA0(0x8)
	int32_t MaterialIndex;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 



// Class MovieSceneTracks.MovieSceneMotionVectorSimulationSystem
// Size: 0x98(Inherited: 0x40) 
struct UMovieSceneMotionVectorSimulationSystem : public UMovieSceneEntitySystem
{
	char pad_64[88];  // 0x40(0x58)

}; 



// Class MovieSceneTracks.MovieSceneObjectPropertySection
// Size: 0x1F0(Inherited: 0xE8) 
struct UMovieSceneObjectPropertySection : public UMovieSceneSection
{
	struct FMovieSceneObjectPathChannel ObjectChannel;  // 0xE8(0x108)

}; 



// Class MovieSceneTracks.MovieSceneObjectPropertyTrack
// Size: 0xD0(Inherited: 0xC0) 
struct UMovieSceneObjectPropertyTrack : public UMovieScenePropertyTrack
{
	char pad_192[8];  // 0xC0(0x8)
	 PropertyClass;  // 0xC8(0x8)

}; 



// Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x1C8(Inherited: 0xE8) 
struct UMovieSceneParticleSection : public UMovieSceneSection
{
	struct FMovieSceneParticleChannel ParticleKeys;  // 0xE8(0xE0)

}; 



// Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0xA8(Inherited: 0x90) 
struct UMovieSceneParticleTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> ParticleSections;  // 0x98(0x10)

}; 



// Class MovieSceneTracks.MovieScenePiecewiseBoolBlenderSystem
// Size: 0x90(Inherited: 0x68) 
struct UMovieScenePiecewiseBoolBlenderSystem : public UMovieSceneBlenderSystem
{
	char pad_104[40];  // 0x68(0x28)

}; 



// Class MovieSceneTracks.MovieScenePiecewiseByteBlenderSystem
// Size: 0x90(Inherited: 0x68) 
struct UMovieScenePiecewiseByteBlenderSystem : public UMovieSceneBlenderSystem
{
	char pad_104[40];  // 0x68(0x28)

}; 



// Class MovieSceneTracks.MovieScenePiecewiseFloatBlenderSystem
// Size: 0x128(Inherited: 0x68) 
struct UMovieScenePiecewiseFloatBlenderSystem : public UMovieSceneBlenderSystem
{
	char pad_104[192];  // 0x68(0xC0)

}; 



// Class MovieSceneTracks.MovieScenePiecewiseIntegerBlenderSystem
// Size: 0xB0(Inherited: 0x68) 
struct UMovieScenePiecewiseIntegerBlenderSystem : public UMovieSceneBlenderSystem
{
	char pad_104[72];  // 0x68(0x48)

}; 



// Class MovieSceneTracks.MovieScenePredictionSystem
// Size: 0xF0(Inherited: 0x40) 
struct UMovieScenePredictionSystem : public UMovieSceneEntitySystem
{
	char pad_64[144];  // 0x40(0x90)
	struct TArray<struct UMovieSceneAsyncAction_SequencePrediction*> PendingPredictions;  // 0xD0(0x10)
	struct TArray<struct UMovieSceneAsyncAction_SequencePrediction*> ProcessingPredictions;  // 0xE0(0x10)

}; 



// Class MovieSceneTracks.MovieScenePrimitiveMaterialSection
// Size: 0x1F0(Inherited: 0xE8) 
struct UMovieScenePrimitiveMaterialSection : public UMovieSceneSection
{
	struct FMovieSceneObjectPathChannel MaterialChannel;  // 0xE8(0x108)

}; 



// Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Size: 0xD0(Inherited: 0xC0) 
struct UMovieScenePrimitiveMaterialTrack : public UMovieScenePropertyTrack
{
	char pad_192[8];  // 0xC0(0x8)
	int32_t MaterialIndex;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class MovieSceneTracks.MovieScenePropertyInstantiatorSystem
// Size: 0x248(Inherited: 0x40) 
struct UMovieScenePropertyInstantiatorSystem : public UMovieSceneEntityInstantiatorSystem
{
	char pad_64[520];  // 0x40(0x208)

}; 



// Class MovieSceneTracks.MovieSceneQuaternionInterpolationRotationSystem
// Size: 0x40(Inherited: 0x40) 
struct UMovieSceneQuaternionInterpolationRotationSystem : public UMovieSceneEntitySystem
{

}; 



// Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x320(Inherited: 0xE8) 
struct UMovieSceneSkeletalAnimationSection : public UMovieSceneSection
{
	struct FMovieSceneSkeletalAnimationParams Params;  // 0xE8(0x128)
	struct UAnimSequence* AnimSequence;  // 0x210(0x8)
	struct UAnimSequenceBase* Animation;  // 0x218(0x8)
	float StartOffset;  // 0x220(0x4)
	float EndOffset;  // 0x224(0x4)
	float PlayRate;  // 0x228(0x4)
	char bReverse : 1;  // 0x22C(0x1)
	char pad_556_1 : 7;  // 0x22C(0x1)
	char pad_557[4];  // 0x22D(0x4)
	struct FName SlotName;  // 0x230(0x8)
	struct FVector StartLocationOffset;  // 0x238(0x18)
	struct FRotator StartRotationOffset;  // 0x250(0x18)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool bMatchWithPrevious : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	struct FName MatchedBoneName;  // 0x26C(0x8)
	char pad_628[4];  // 0x274(0x4)
	struct FVector MatchedLocationOffset;  // 0x278(0x18)
	struct FRotator MatchedRotationOffset;  // 0x290(0x18)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool bMatchTranslation : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool bMatchIncludeZHeight : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool bMatchRotationYaw : 1;  // 0x2AA(0x1)
	char pad_683_1 : 7;  // 0x2AB(0x1)
	bool bMatchRotationPitch : 1;  // 0x2AB(0x1)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool bMatchRotationRoll : 1;  // 0x2AC(0x1)
	char pad_685[115];  // 0x2AD(0x73)

}; 



// Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0xE8(Inherited: 0x90) 
struct UMovieSceneSkeletalAnimationTrack : public UMovieSceneNameableTrack
{
	char pad_144[8];  // 0x90(0x8)
	struct TArray<struct UMovieSceneSection*> AnimationSections;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bUseLegacySectionIndexBlend : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FMovieSceneSkeletalAnimRootMotionTrackParams RootMotionParams;  // 0xB0(0x30)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bBlendFirstChildOfRoot : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)

}; 



// Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x1D0(Inherited: 0xE8) 
struct UMovieSceneSlomoSection : public UMovieSceneSection
{
	struct FMovieSceneFloatChannel FloatCurve;  // 0xE8(0xE8)

}; 



// Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneSlomoTrack : public UMovieSceneFloatTrack
{
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x1D0(Inherited: 0xE8) 
struct UMovieSceneStringSection : public UMovieSceneSection
{
	struct FMovieSceneStringChannel StringCurve;  // 0xE8(0xE8)

}; 



// Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneStringTrack : public UMovieScenePropertyTrack
{
	char pad_192[8];  // 0xC0(0x8)

}; 



// Class MovieSceneTracks.MovieSceneTransformOriginSystem
// Size: 0x78(Inherited: 0x40) 
struct UMovieSceneTransformOriginSystem : public UMovieSceneEntitySystem
{
	char pad_64[56];  // 0x40(0x38)

}; 



// Class MovieSceneTracks.MovieSceneFloatVectorPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneFloatVectorPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneDoubleVectorPropertySystem
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneDoubleVectorPropertySystem : public UMovieScenePropertySystem
{

}; 



// Class MovieSceneTracks.MovieSceneDoubleVectorSection
// Size: 0x4B8(Inherited: 0xE8) 
struct UMovieSceneDoubleVectorSection : public UMovieSceneSection
{
	char pad_232[8];  // 0xE8(0x8)
	struct FMovieSceneDoubleChannel Curves[4];  // 0xF0(0x3C0)
	int32_t ChannelsUsed;  // 0x4B0(0x4)
	char pad_1204[4];  // 0x4B4(0x4)

}; 



// Class MovieSceneTracks.MovieSceneFloatVectorTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneFloatVectorTrack : public UMovieScenePropertyTrack
{
	int32_t NumChannelsUsed;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)

}; 



// Class MovieSceneTracks.MovieSceneDoubleVectorTrack
// Size: 0xC8(Inherited: 0xC0) 
struct UMovieSceneDoubleVectorTrack : public UMovieScenePropertyTrack
{
	int32_t NumChannelsUsed;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)

}; 



// Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0xC8(Inherited: 0xC8) 
struct UMovieSceneVisibilityTrack : public UMovieSceneBoolTrack
{

}; 



// Class MovieSceneTracks.MovieSceneHierarchicalEasingInstantiatorSystem
// Size: 0x90(Inherited: 0x40) 
struct UMovieSceneHierarchicalEasingInstantiatorSystem : public UMovieSceneEntityInstantiatorSystem
{
	char pad_64[80];  // 0x40(0x50)

}; 



// Class MovieSceneTracks.WeightAndEasingEvaluatorSystem
// Size: 0x78(Inherited: 0x40) 
struct UWeightAndEasingEvaluatorSystem : public UMovieSceneEntitySystem
{
	char pad_64[56];  // 0x40(0x38)

}; 



