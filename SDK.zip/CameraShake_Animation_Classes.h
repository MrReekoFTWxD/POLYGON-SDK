#pragma once 
#include <CameraShake_Animation_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_Animation.CameraShake_Animation_C
// Size: 0x230(Inherited: 0x230) 
struct UCameraShake_Animation_C : public UMatineeCameraShake
{

}; 



