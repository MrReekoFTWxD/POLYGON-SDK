#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimationWarpingRuntime.AnimNode_OrientationWarping
// Size: 0x160(Inherited: 0xC8) 
struct FAnimNode_OrientationWarping : public FAnimNode_SkeletalControlBase
{
	uint8_t  Mode;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float OrientationAngle;  // 0xCC(0x4)
	float LocomotionAngle;  // 0xD0(0x4)
	float LocomotionAngleDeltaThreshold;  // 0xD4(0x4)
	struct TArray<struct FBoneReference> SpineBones;  // 0xD8(0x10)
	struct FBoneReference IKFootRootBone;  // 0xE8(0x10)
	struct TArray<struct FBoneReference> IKFootBones;  // 0xF8(0x10)
	char EAxis RotationAxis;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	float DistributedBoneOrientationAlpha;  // 0x10C(0x4)
	float RotationInterpSpeed;  // 0x110(0x4)
	char pad_276[76];  // 0x114(0x4C)

}; 
// ScriptStruct AnimationWarpingRuntime.StrideWarpingFootDefinition
// Size: 0x30(Inherited: 0x0) 
struct FStrideWarpingFootDefinition
{
	struct FBoneReference IKFootBone;  // 0x0(0x10)
	struct FBoneReference FKFootBone;  // 0x10(0x10)
	struct FBoneReference ThighBone;  // 0x20(0x10)

}; 
// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootDefinition
// Size: 0x28(Inherited: 0x0) 
struct FSlopeWarpingFootDefinition
{
	struct FBoneReference IKFootBone;  // 0x0(0x10)
	struct FBoneReference FKFootBone;  // 0x10(0x10)
	int32_t NumBonesInLimb;  // 0x20(0x4)
	float FootSize;  // 0x24(0x4)

}; 
// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootData
// Size: 0xB0(Inherited: 0x0) 
struct FSlopeWarpingFootData
{
	char pad_0[176];  // 0x0(0xB0)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_StrideWarping
// Size: 0x238(Inherited: 0xC8) 
struct FAnimNode_StrideWarping : public FAnimNode_SkeletalControlBase
{
	uint8_t  Mode;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct FVector StrideDirection;  // 0xD0(0x18)
	float StrideScale;  // 0xE8(0x4)
	float LocomotionSpeed;  // 0xEC(0x4)
	float MinLocomotionSpeedThreshold;  // 0xF0(0x4)
	struct FBoneReference PelvisBone;  // 0xF4(0x10)
	struct FBoneReference IKFootRootBone;  // 0x104(0x10)
	char pad_276[4];  // 0x114(0x4)
	struct TArray<struct FStrideWarpingFootDefinition> FootDefinitions;  // 0x118(0x10)
	struct FInputClampConstants StrideScaleModifier;  // 0x128(0x14)
	char pad_316[4];  // 0x13C(0x4)
	struct FWarpingVectorValue FloorNormalDirection;  // 0x140(0x20)
	struct FWarpingVectorValue GravityDirection;  // 0x160(0x20)
	struct FIKFootPelvisPullDownSolver PelvisIKFootSolver;  // 0x180(0x70)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool bOrientStrideDirectionUsingFloorNormal : 1;  // 0x1F0(0x1)
	char pad_497_1 : 7;  // 0x1F1(0x1)
	bool bCompensateIKUsingFKThighRotation : 1;  // 0x1F1(0x1)
	char pad_498_1 : 7;  // 0x1F2(0x1)
	bool bClampIKUsingFKLimits : 1;  // 0x1F2(0x1)
	char pad_499[69];  // 0x1F3(0x45)

}; 
// ScriptStruct AnimationWarpingRuntime.AnimNode_SlopeWarping
// Size: 0x2E0(Inherited: 0xC8) 
struct FAnimNode_SlopeWarping : public FAnimNode_SkeletalControlBase
{
	char pad_200[24];  // 0xC8(0x18)
	struct FBoneReference IKFootRootBone;  // 0xE0(0x10)
	struct FBoneReference PelvisBone;  // 0xF0(0x10)
	struct TArray<struct FSlopeWarpingFootDefinition> FeetDefinitions;  // 0x100(0x10)
	struct TArray<struct FSlopeWarpingFootData> FeetData;  // 0x110(0x10)
	struct FVectorRK4SpringInterpolator PelvisOffsetInterpolator;  // 0x120(0x8)
	char pad_296[88];  // 0x128(0x58)
	struct FVector GravityDir;  // 0x180(0x18)
	struct FVector CustomFloorOffset;  // 0x198(0x18)
	float CachedDeltaTime;  // 0x1B0(0x4)
	char pad_436[4];  // 0x1B4(0x4)
	struct FVector TargetFloorNormalWorldSpace;  // 0x1B8(0x18)
	struct FVectorRK4SpringInterpolator FloorNormalInterpolator;  // 0x1D0(0x8)
	char pad_472[88];  // 0x1D8(0x58)
	struct FVector TargetFloorOffsetLocalSpace;  // 0x230(0x18)
	struct FVectorRK4SpringInterpolator FloorOffsetInterpolator;  // 0x248(0x8)
	char pad_592[88];  // 0x250(0x58)
	float MaxStepHeight;  // 0x2A8(0x4)
	char bKeepMeshInsideOfCapsule : 1;  // 0x2AC(0x1)
	char bPullPelvisDown : 1;  // 0x2AC(0x1)
	char bUseCustomFloorOffset : 1;  // 0x2AC(0x1)
	char bWasOnGround : 1;  // 0x2AC(0x1)
	char bShowDebug : 1;  // 0x2AC(0x1)
	char bFloorSmoothingInitialized : 1;  // 0x2AC(0x1)
	char pad_684_1 : 2;  // 0x2AC(0x1)
	char pad_685[4];  // 0x2AD(0x4)
	struct FVector ActorLocation;  // 0x2B0(0x18)
	struct FVector GravityDirCompSpace;  // 0x2C8(0x18)

}; 
