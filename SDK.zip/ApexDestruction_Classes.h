#pragma once 
#include <ApexDestruction_Structs.h>
 
 
 
// Class ApexDestruction.DestructibleActor
// Size: 0x290(Inherited: 0x278) 
struct ADestructibleActor : public AActor
{
	struct UDestructibleComponent* DestructibleComponent;  // 0x278(0x8)
	struct FMulticastInlineDelegate OnActorFracture;  // 0x280(0x10)

}; 



// Class ApexDestruction.DestructibleComponent
// Size: 0x8E0(Inherited: 0x820) 
struct UDestructibleComponent : public USkinnedMeshComponent
{
	char bFractureEffectOverride : 1;  // 0x820(0x1)
	char pad_2080_1 : 7;  // 0x820(0x1)
	char pad_2081[8];  // 0x821(0x8)
	struct TArray<struct FFractureEffect> FractureEffects;  // 0x828(0x10)
	char pad_2104_1 : 7;  // 0x838(0x1)
	bool bEnableHardSleeping : 1;  // 0x838(0x1)
	char pad_2105[3];  // 0x839(0x3)
	float LargeChunkThreshold;  // 0x83C(0x4)
	struct FMulticastInlineDelegate OnComponentFracture;  // 0x840(0x10)
	char pad_2128[144];  // 0x850(0x90)

	void SetDestructibleMesh(struct UDestructibleMesh* NewMesh); // Function ApexDestruction.DestructibleComponent.SetDestructibleMesh
	struct UDestructibleMesh* GetDestructibleMesh(); // Function ApexDestruction.DestructibleComponent.GetDestructibleMesh
	void ApplyRadiusDamage(float BaseDamage, struct FVector& HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage); // Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage
	void ApplyDamage(float DamageAmount, struct FVector& HitLocation, struct FVector& ImpulseDir, float ImpulseStrength); // Function ApexDestruction.DestructibleComponent.ApplyDamage
}; 



// Class ApexDestruction.DestructibleFractureSettings
// Size: 0xB0(Inherited: 0x28) 
struct UDestructibleFractureSettings : public UObject
{
	int32_t CellSiteCount;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FFractureMaterial FractureMaterialDesc;  // 0x30(0x40)
	int32_t RandomSeed;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct TArray<struct FVector> VoronoiSites;  // 0x78(0x10)
	int32_t OriginalSubmeshCount;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x90(0x10)
	struct TArray<struct FDestructibleChunkParameters> ChunkParameters;  // 0xA0(0x10)

}; 



// Class ApexDestruction.DestructibleMesh
// Size: 0x528(Inherited: 0x470) 
struct UDestructibleMesh : public USkeletalMesh
{
	struct FDestructibleParameters DefaultDestructibleParameters;  // 0x470(0xA8)
	struct TArray<struct FFractureEffect> FractureEffects;  // 0x518(0x10)

}; 



